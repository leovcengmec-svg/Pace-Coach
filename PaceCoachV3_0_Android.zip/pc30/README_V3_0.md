# Pace Coach V3.0

V3.0 is the first release prepared for real Android CI compilation.

## Main changes
- Structured workout launch button is wired to the foreground RunService.
- Application version is 3.0 / versionCode 30.
- GitHub Actions workflow builds `assembleDebug` using JDK 17 and Gradle 8.9.
- APK is uploaded as a GitHub Actions artifact named `pace-coach-debug-apk`.
- Existing GPS, pace, TTS, free-run and structured-workout layers are preserved.

## Current validation status
- Source-level inspection: completed.
- Core deterministic tests present in `app/src/test`.
- Android compilation in this environment: not performed because Android SDK/Gradle tooling is not installed here.
- Physical phone/GPS test: pending.

## GitHub
Create a repository, upload this project, then run the **Build Pace Coach APK** workflow from the Actions tab. The generated debug APK will be available as a workflow artifact.
