package org.runnerup.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TabHost;

/**
 * TabHost that keeps the existing tab layout/indicators but also supports
 * horizontal swipe navigation between tabs. Vertical gestures are left to
 * the currently displayed tab content (for example ScrollView scrolling).
 */
public class SwipeTabHost extends TabHost {
  private float downX;
  private float downY;
  private boolean horizontalSwipe;
  private final int touchSlop;
  private boolean touchStartedInsideGraph;

  public SwipeTabHost(Context context) {
    super(context);
    touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
  }

  public SwipeTabHost(Context context, AttributeSet attrs) {
    super(context, attrs);
    touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
  }

  public SwipeTabHost(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
  }

  @Override
  public boolean onInterceptTouchEvent(MotionEvent event) {
    switch (event.getActionMasked()) {
      case MotionEvent.ACTION_DOWN:
        downX = event.getX();
        downY = event.getY();
        horizontalSwipe = false;
        touchStartedInsideGraph = isInsideInteractiveGraph(this, downX, downY);
        break;

      case MotionEvent.ACTION_MOVE:
        float dx = event.getX() - downX;
        float dy = event.getY() - downY;
        // Graphs use horizontal dragging to select a point. Never let the
        // tab host interpret that same gesture as a request to change tabs.
        if (!touchStartedInsideGraph
            && !horizontalSwipe
            && Math.abs(dx) > touchSlop
            && Math.abs(dx) > Math.abs(dy) * 1.35f) {
          horizontalSwipe = true;
          return true;
        }
        break;

      case MotionEvent.ACTION_UP:
      case MotionEvent.ACTION_CANCEL:
        if (touchStartedInsideGraph) {
          touchStartedInsideGraph = false;
          horizontalSwipe = false;
          // Never let TabHost consume the end of a gesture that started on a
          // chart. GraphView owns that gesture for cursor selection.
          return false;
        }
        break;
    }

    // A chart gesture must remain entirely inside the chart. Calling the
    // superclass here would allow TabHost's own horizontal navigation logic
    // to see the same MOVE/UP events and switch tabs while the user drags the
    // graph cursor.
    if (touchStartedInsideGraph) {
      return false;
    }

    return super.onInterceptTouchEvent(event);
  }

  /** Returns true when the initial touch is inside one of the interactive charts. */
  private boolean isInsideInteractiveGraph(View view, float x, float y) {
    if ("graph-interactive".equals(view.getTag())) return true;
    if (!(view instanceof ViewGroup)) return false;

    ViewGroup group = (ViewGroup) view;
    for (int i = 0; i < group.getChildCount(); i++) {
      View child = group.getChildAt(i);
      float childX = x - child.getLeft();
      float childY = y - child.getTop();
      if (childX >= 0 && childX < child.getWidth()
          && childY >= 0 && childY < child.getHeight()
          && isInsideInteractiveGraph(child, childX, childY)) {
        return true;
      }
    }
    return false;
  }

  @Override
  public boolean onTouchEvent(MotionEvent event) {
    if (horizontalSwipe) {
      if (event.getActionMasked() == MotionEvent.ACTION_UP) {
        float dx = event.getX() - downX;
        int current = getCurrentTab();
        int count = getTabWidget().getTabCount();
        int target = dx < 0 ? current + 1 : current - 1;

        horizontalSwipe = false;
        if (Math.abs(dx) >= Math.max(80, touchSlop * 3)
            && target >= 0
            && target < count) {
          setCurrentTab(target);
        }
        return true;
      }

      if (event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
        horizontalSwipe = false;
      }
      return true;
    }

    return super.onTouchEvent(event);
  }
}
