# Pace Coach / RunnerUp — revisão interna v380

## Correção desta revisão

- Corrigido o erro de compilação em `PersistentGpsLoggerListener.java`: o overload de `onLocationChanged` que recebe metadados do treino é chamado diretamente por `Tracker` e não implementa o callback Android `LocationListener`; foi removido o `@Override` incorreto e documentada a razão.
- Preservado o callback herdado `onLocationChanged(Location)` da classe `LocationListenerBase`.
- Preservadas as correções de compilação da revisão v378 para `Constants.DB` e a importação de `DBHelper`.

## Identificação

- Revisão interna Android: `versionCode = 380` (o Gradle soma o offset de `minSdk`; com `minSdk 23`, o APK esperado reportará `23000380`).
- `versionName = 2.11.0.6`.
- Artefato do workflow: `pacecoach-apk-v380-phase2-fix`.
- O Wear continua usando o código Android +1, conforme configuração existente.

## Validação

A revisão foi verificada por inspeção do código, verificações estruturais, análise sintática Java e integridade do ZIP. A compilação Android completa precisa ser confirmada pelo GitHub Actions; os testes em dispositivo também permanecem pendentes.
