# Pace Coach V1.4 — Coach de Alvo

Objetivo desta versão: deixar o comportamento do alvo de pace mais claro e
preparar a base para um coach que toma decisões durante a corrida.

Mantidos da V1.3:
- GPS e serviço em primeiro plano
- pace suavizado
- TTS em pt-BR
- anúncios por tempo ou distância
- tela bloqueada/fone
- margem de alvo
- redução do tempo de fala e Audio Focus

Evolução V1.4:
- exibição explícita do pace-alvo;
- exibição da faixa de tolerância em segundos/km;
- mensagens diferenciadas para dentro, mais lento e mais rápido;
- base preparada para decisões de coach por estado.

Observação: esta é uma versão de projeto-fonte. A validação física do atraso,
GPS e áudio continua dependente de um APK instalado no Android.
