# Pace Coach V1.8 — Treino estruturado

A V1.8 introduz a base para condução automática de uma sessão.

Modelo:
- aquecimento;
- corrida com distância ou tempo;
- alvo de pace opcional;
- recuperação;
- repetições;
- desaquecimento;
- conclusão automática.

Exemplo conceitual:
10 min aquecimento
4 x (1 km a 4:50/km + 2 min recuperação)
10 min desaquecimento

O WorkoutEngine controla a progressão por tempo/distância e o WorkoutVoice
gera as mensagens de transição.

Nesta etapa a estrutura está criada no projeto. A integração completa com a
tela para criação/edição de treinos e o teste físico virão em etapas seguintes.
