# Pace Coach V2.4 — Ponte com o RunService

A V2.4 cria a camada RunServiceCoachAdapter, preparada para ser chamada pelo
serviço de corrida a cada atualização de GPS.

Fluxo:
1. RunService recebe localização;
2. PaceCalculator calcula pace;
3. Adapter consulta a etapa ativa;
4. CoachController decide;
5. Adapter retorna a mensagem;
6. RunService entrega a mensagem ao VoiceCoach.

A camada foi mantida separada para facilitar testes e evitar alterações
arriscadas no serviço antes da validação.

Próxima etapa: integrar o adapter no RunService existente, incluindo início,
atualizações, mudança de etapa, GPS incerto e finalização.
