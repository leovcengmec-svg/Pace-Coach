# Pace Coach / RunnerUp — revisão interna v378

## Correção de compilação após a v376

- Corrigido o import da classe DB: ela é a interface aninhada `Constants.DB`, em `org.runnerup.common.util.Constants`, e não uma classe independente em `org.runnerup.db`.
- Adicionado o import ausente de `org.runnerup.db.DBHelper` em `SettingsMaintenanceFragment`.
- Atualizada a revisão interna para `versionCode = 378` e `versionName = 2.11.0.4`. O app usa o offset Android de minSdk; com minSdk 23, o versionCode reportado pelo APK deverá ser `23000378`.
- Artefato do workflow: `pacecoach-apk-v378-phase2-fix`.

## Validação

A revisão precisa passar pelo GitHub Actions. A correção dos imports resolve as causas visíveis nas capturas, mas não equivale a uma compilação Android bem-sucedida.
