package com.pacecoach.v1.run

import kotlin.math.abs

data class CoachRuntimeState(
    val step: ActiveStep?,
    val paceSeconds: Int?,
    val targetPaceSeconds: Int?,
    val state: CoachState
)

class CoachRuntime {

    fun evaluate(
        step: ActiveStep?,
        paceSeconds: Int?,
        gpsQuality: GpsQuality,
        targetMarginSeconds: Int
    ): CoachRuntimeState {
        if (step == null) {
            return CoachRuntimeState(null, paceSeconds, null, CoachState.FINISHED)
        }

        if (gpsQuality == GpsQuality.POOR || paceSeconds == null) {
            return CoachRuntimeState(
                step,
                paceSeconds,
                step.step.targetPaceSeconds,
                CoachState.GPS_UNCERTAIN
            )
        }

        val target = step.step.targetPaceSeconds
        if (target == null) {
            return CoachRuntimeState(step, paceSeconds, null, CoachState.ON_TARGET)
        }

        val diff = paceSeconds - target
        val state = when {
            abs(diff) <= targetMarginSeconds -> CoachState.ON_TARGET
            diff > 0 -> CoachState.SLOWER_THAN_TARGET
            else -> CoachState.FASTER_THAN_TARGET
        }

        return CoachRuntimeState(step, paceSeconds, target, state)
    }
}
