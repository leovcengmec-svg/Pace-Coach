package com.pacecoach.v1.run

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class RunService : Service() {

    private lateinit var fused: FusedLocationProviderClient
    private lateinit var calculator: PaceCalculator
    private lateinit var voice: VoiceCoach
    private val coachAdapter = RunServiceCoachAdapter()

    private var targetPace = 300
    private var targetMargin = 5
    private var announceMode = MODE_DISTANCE
    private var announceInterval = 100.0
    private var nextDistanceAnnouncement = 100.0
    private var nextTimeAnnouncement = 20L
    private var startTime = 0L
    private var lastSpokenAt = 0L
    private var structuredWorkout = false

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            result.locations.forEach { process(it) }
        }
    }

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
        calculator = PaceCalculator(20)
        voice = VoiceCoach(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START || intent?.action == ACTION_START_WORKOUT) {
            targetPace = intent.getIntExtra(EXTRA_TARGET_PACE_SECONDS, 300).coerceIn(180, 900)
            targetMargin = intent.getIntExtra(EXTRA_TARGET_MARGIN, 5).coerceIn(0, 60)
            announceMode = intent.getStringExtra(EXTRA_ANNOUNCE_MODE) ?: MODE_DISTANCE
            announceInterval = intent.getDoubleExtra(EXTRA_ANNOUNCE_INTERVAL, 100.0).coerceIn(5.0, 5000.0)
            structuredWorkout = intent.action == ACTION_START_WORKOUT
            startRun()
        }
        return START_STICKY
    }

    private fun startRun() {
        if (!hasLocationPermission()) {
            stopSelf()
            return
        }

        calculator.reset()
        nextDistanceAnnouncement = announceInterval
        nextTimeAnnouncement = announceInterval.toLong().coerceAtLeast(5L)
        startTime = System.currentTimeMillis()
        lastSpokenAt = 0L

        val workout = if (structuredWorkout) {
            WorkoutRepository.all().lastOrNull() ?: ExampleWorkouts.interval4x1k()
        } else {
            StructuredWorkout(
                name = "Corrida livre",
                steps = listOf(
                    WorkoutStep(
                        kind = StepKind.RUN,
                        targetPaceSeconds = targetPace,
                        label = "Corrida"
                    )
                )
            )
        }
        if (structuredWorkout) {
            coachAdapter.begin(workout, startTime, 0f)?.let { speakCoach(it) }
        }

        startForeground(NOTIFICATION_ID, buildNotification("Corrida em andamento"))
        broadcastState(true)

        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
            .setMinUpdateIntervalMillis(500L)
            .setMinUpdateDistanceMeters(2f)
            .build()

        fused.requestLocationUpdates(request, callback, mainLooper)
    }

    private fun process(location: Location) {
        val distance = calculator.addLocation(location)
        val now = System.currentTimeMillis()
        val pace = calculator.currentPaceSecondsPerKm()
        val elapsed = (now - startTime) / 1000L

        if (pace != null) {
            sendUpdate(pace, distance, elapsed)
        } else {
            sendBroadcast(Intent(ACTION_UPDATE).apply {
                setPackage(packageName)
                putExtra(EXTRA_DISTANCE_METERS, distance)
                putExtra(EXTRA_ELAPSED_SECONDS, elapsed)
            })
        }

        // Structured workouts advance by time or distance independently of pace
        // availability. This is essential for warm-up, recovery and cool-down steps.
        if (structuredWorkout) {
            val coachEvent = coachAdapter.onLiveUpdate(
                nowMs = now,
                distanceM = distance.toFloat(),
                paceSeconds = pace?.roundToInt(),
                gpsAccuracyMeters = location.accuracy,
                targetMarginSeconds = targetMargin
            )

            coachAdapter.currentStep()?.let { step ->
                sendWorkoutUpdate(step, coachAdapter.isRunning())
            }

            when (coachEvent) {
                is CoachEvent.Speak -> speakCoach(coachEvent.message)
                is CoachEvent.Finished -> {
                    coachEvent.message?.let { speakCoach(it) }
                    stopRunInternal()
                    return
                }
                CoachEvent.None, CoachEvent.GpsUncertain -> Unit
                is CoachEvent.StepChanged -> speakCoach(WorkoutVoice.next(coachEvent.step))
            }
        }

        // In structured mode the active step owns the target pace; in free run
        // mode the user-defined global target is used.
        if (pace != null && announceMode == MODE_DISTANCE && distance >= nextDistanceAnnouncement && canSpeak()) {
            while (distance >= nextDistanceAnnouncement) nextDistanceAnnouncement += announceInterval
            speakPace(pace)
        } else if (pace != null && announceMode == MODE_TIME && elapsed >= nextTimeAnnouncement && canSpeak()) {
            while (elapsed >= nextTimeAnnouncement) nextTimeAnnouncement += announceInterval.toLong().coerceAtLeast(5L)
            speakPace(pace)
        }
    }

    private fun sendUpdate(pace: Double, distance: Double, elapsed: Long) {
        sendBroadcast(Intent(ACTION_UPDATE).apply {
            setPackage(packageName)
            putExtra(EXTRA_PACE_SECONDS, pace)
            putExtra(EXTRA_DISTANCE_METERS, distance)
            putExtra(EXTRA_ELAPSED_SECONDS, elapsed)
        })
    }


    private fun sendWorkoutUpdate(step: ActiveStep, running: Boolean) {
        sendBroadcast(Intent(ACTION_WORKOUT_UPDATE).apply {
            setPackage(packageName)
            putExtra(EXTRA_WORKOUT_STEP_INDEX, step.index)
            putExtra(EXTRA_WORKOUT_REPETITION, step.repetition)
            putExtra(EXTRA_WORKOUT_LABEL, step.step.label)
            putExtra(EXTRA_WORKOUT_KIND, step.step.kind.name)
            putExtra(EXTRA_WORKOUT_RUNNING, running)
            putExtra(EXTRA_WORKOUT_FINISHED, !running)
        })
    }

    private fun speakPace(paceSeconds: Double) {
        val rounded = paceSeconds.roundToInt()
        val min = rounded / 60
        val sec = rounded % 60
        val effectiveTarget = if (structuredWorkout) {
            coachAdapter.currentStep()?.step?.targetPaceSeconds ?: targetPace
        } else targetPace
        val diff = rounded - effectiveTarget
        val paceText = String.format(Locale.US, "%d:%02d", min, sec)

        val message = when {
            abs(diff) <= targetMargin ->
                "Ritmo $paceText. Dentro do alvo."
            diff > 0 ->
                "Ritmo $paceText. ${diff} segundos mais lento."
            else ->
                "Ritmo $paceText. ${-diff} segundos mais rápido."
        }

        speakCoach(message)
    }

    private fun speakCoach(message: String) {
        voice.speak(message)
        lastSpokenAt = System.currentTimeMillis()
    }

    private fun canSpeak(): Boolean = System.currentTimeMillis() - lastSpokenAt >= 3000L

    private fun stopRunInternal() {
        fused.removeLocationUpdates(callback)
        coachAdapter.stop()
        broadcastState(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun broadcastState(running: Boolean) {
        sendBroadcast(Intent(ACTION_STATE).apply {
            setPackage(packageName)
            putExtra(EXTRA_RUNNING, running)
        })
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Pace Coach")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()

    private fun createChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Corrida", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    override fun onDestroy() {
        fused.removeLocationUpdates(callback)
        coachAdapter.stop()
        voice.release()
        broadcastState(false)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.pacecoach.v1.START"
        const val ACTION_START_WORKOUT = "com.pacecoach.v1.START_WORKOUT"
        const val ACTION_UPDATE = "com.pacecoach.v1.UPDATE"
        const val ACTION_STATE = "com.pacecoach.v1.STATE"
        const val ACTION_WORKOUT_UPDATE = "com.pacecoach.v1.WORKOUT_UPDATE"
        const val MODE_DISTANCE = "distance"
        const val MODE_TIME = "time"

        const val EXTRA_TARGET_PACE_SECONDS = "target_pace_seconds"
        const val EXTRA_ANNOUNCE_MODE = "announce_mode"
        const val EXTRA_ANNOUNCE_INTERVAL = "announce_interval"
        const val EXTRA_TARGET_MARGIN = "target_margin"

        const val EXTRA_PACE_SECONDS = "pace_seconds"
        const val EXTRA_DISTANCE_METERS = "distance_meters"
        const val EXTRA_ELAPSED_SECONDS = "elapsed_seconds"
        const val EXTRA_RUNNING = "running"
        const val EXTRA_WORKOUT_STEP_INDEX = "workout_step_index"
        const val EXTRA_WORKOUT_REPETITION = "workout_repetition"
        const val EXTRA_WORKOUT_LABEL = "workout_label"
        const val EXTRA_WORKOUT_KIND = "workout_kind"
        const val EXTRA_WORKOUT_RUNNING = "workout_running"
        const val EXTRA_WORKOUT_ELAPSED_STEP_SECONDS = "workout_elapsed_step_seconds"
        const val EXTRA_WORKOUT_DISTANCE_STEP_METERS = "workout_distance_step_meters"
        const val EXTRA_WORKOUT_FINISHED = "workout_finished"

        private const val CHANNEL_ID = "pace_coach_run"
        private const val NOTIFICATION_ID = 1001
    }
}
