package org.runnerup.util;

/** Rejects implausible point-to-point GPS jumps when rebuilding activity totals. */
public final class GpsSegmentSanitizer {
  private static final double MAX_RUNNING_SPEED_METERS_PER_SECOND = 12.0d;
  private static final double BASE_ALLOWANCE_METERS = 8.0d;
  private static final double MAX_ACCURACY_ALLOWANCE_METERS = 25.0d;

  private GpsSegmentSanitizer() {}

  public static boolean isPlausible(double distanceMeters, long durationMillis, double accuracyMeters) {
    if (Double.isNaN(distanceMeters) || Double.isInfinite(distanceMeters) || distanceMeters < 0d) return false;
    if (durationMillis <= 0L) return false;
    double accuracyAllowance = Double.isNaN(accuracyMeters) || Double.isInfinite(accuracyMeters)
        ? 0d : Math.max(0d, Math.min(MAX_ACCURACY_ALLOWANCE_METERS, accuracyMeters));
    double allowed = BASE_ALLOWANCE_METERS
        + MAX_RUNNING_SPEED_METERS_PER_SECOND * (durationMillis / 1000.0d)
        + accuracyAllowance;
    return distanceMeters <= allowed;
  }
}
