/*
 * Copyright (C) 2012 - 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.view;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.preference.PreferenceManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import org.runnerup.BuildConfig;
import org.runnerup.R;
import org.runnerup.common.tracker.TrackerState;
import org.runnerup.common.util.Constants;
import org.runnerup.common.util.Constants.DB;
import org.runnerup.common.util.ValueModel;
import org.runnerup.db.DBHelper;
import org.runnerup.hr.HRProvider;
import org.runnerup.hr.MockHRProvider;
import org.runnerup.notification.GpsBoundState;
import org.runnerup.notification.GpsSearchingState;
import org.runnerup.notification.NotificationManagerDisplayStrategy;
import org.runnerup.notification.NotificationStateManager;
import org.runnerup.tracker.GpsInformation;
import org.runnerup.tracker.Tracker;
import org.runnerup.tracker.component.TrackerCadence;
import org.runnerup.tracker.component.TrackerHRM;
import org.runnerup.tracker.component.TrackerWear;
import org.runnerup.util.Formatter;
import org.runnerup.util.SafeParse;
import org.runnerup.util.TickListener;
import org.runnerup.widget.SpinnerInterface.OnCloseDialogListener;
import org.runnerup.widget.SpinnerInterface.OnSetValueListener;
import org.runnerup.widget.TitleSpinner;
import org.runnerup.widget.WidgetUtil;
import org.runnerup.workout.Dimension;
import org.runnerup.workout.Workout;
import org.runnerup.workout.Workout.StepListEntry;
import org.runnerup.workout.WorkoutBuilder;
import org.runnerup.workout.WorkoutSerializer;

public class StartFragment extends Fragment implements TickListener, GpsInformation {

  private enum GpsLevel {
    NOT_FIXED,
    POOR,
    ACCEPTABLE,
    GOOD
  }

  private static final String TAB_BASIC = "basic";
  private static final String TAB_INTERVAL = "interval";
  static final String TAB_ADVANCED = "advanced";

  private boolean statusDetailsShown = false;

  // StartFragment normally stop GPS in onDestroy (or onStop)
  // but if the fragment stop as it has started a RunActivity
  // it should not!
  // TODO Figure out a way to do this prettier
  private boolean runActivityPending = false;
  // Pace Coach preview: when the user taps INICIAR TREINO, start GPS if needed and
  // launch RunActivity automatically as soon as the tracker reaches CONNECTED.
  private boolean coachStartPending = false;
  private Tracker mTracker = null;
  private org.runnerup.tracker.GpsStatus mGpsStatus = null;

  private TabHost tabHost = null;
  private View startButton = null;

  private ImageView expandIcon = null;
  private TextView noDevicesConnected = null;

  private Button gpsEnable = null;
  private ImageView gpsIndicator = null;
  private TextView gpsMessage = null;
  private LinearLayout gpsDetailRow = null;
  private ImageView gpsDetailIndicator = null;
  private TextView gpsDetailMessage = null;

  private View hrIndicator = null;
  private TextView hrMessage = null;

  private View wearOsIndicator = null;
  private TextView wearOsMessage = null;
  private TrackerWear.WearNotifier mWearNotifier = null;

  boolean sportWithoutGps = false;
  boolean batteryLevelMessageShown = false;

  TitleSpinner simpleTargetType = null;
  TitleSpinner simpleTargetPaceMin = null;
  TitleSpinner simpleTargetPaceValue = null;
  TitleSpinner simpleTargetTime = null;
  TitleSpinner simpleTargetDistance = null;
  TitleSpinner simpleTargetHrz = null;
  AudioSchemeListAdapter simpleAudioListAdapter = null;
  HRZonesListAdapter hrZonesAdapter = null;

  TitleSpinner intervalType = null;
  TitleSpinner intervalTime = null;
  TitleSpinner intervalDistance = null;
  TitleSpinner intervalPaceMin = null;
  TitleSpinner intervalPaceMax = null;
  TitleSpinner intervalRestType = null;
  TitleSpinner intervalRestTime = null;
  TitleSpinner intervalRestDistance = null;
  TitleSpinner intervalRestPaceMin = null;
  TitleSpinner intervalRestPaceMax = null;
  TitleSpinner intervalWarmupType = null;
  TitleSpinner intervalWarmupTime = null;
  TitleSpinner intervalWarmupDistance = null;
  TitleSpinner intervalWarmupPaceMin = null;
  TitleSpinner intervalWarmupPaceMax = null;
  TitleSpinner intervalCooldownType = null;
  TitleSpinner intervalCooldownTime = null;
  TitleSpinner intervalCooldownDistance = null;
  TitleSpinner intervalCooldownPaceMin = null;
  TitleSpinner intervalCooldownPaceMax = null;
  AudioSchemeListAdapter intervalAudioListAdapter = null;

  TitleSpinner advancedWorkoutSpinner = null;
  WorkoutListAdapter advancedWorkoutListAdapter = null;
  Workout advancedWorkout = null;
  View coachDashboard = null;
  View coachWorkspace = null;
  TextView coachWorkspaceTitle = null;
  TextView coachWorkspaceSubtitle = null;
  private TextView coachWorkoutCount = null;
  private TextView coachTotalTime = null;
  private TextView coachTotalDistance = null;
  ListView advancedStepList = null;
  final WorkoutStepsAdapter advancedWorkoutStepsAdapter = new WorkoutStepsAdapter();
  AudioSchemeListAdapter advancedAudioListAdapter = null;

  SQLiteDatabase mDB = null;

  Formatter formatter = null;
  private NotificationStateManager notificationStateManager;
  private GpsSearchingState gpsSearchingState;
  private GpsBoundState gpsBoundState;
  // Id to identify a permission request.
  // Note that the result is not used, the user is dropped back to initial view when a request is
  // done.
  private static final int REQUEST_LOCATION = 3000;
  private static final int START_ACTIVITY = 112;

  private final SharedPreferences.OnSharedPreferenceChangeListener prefChangeListener =
      (sharedPrefs, key) -> {
        assert key != null;
        if (key.equals(getString(R.string.pref_advanced_workout))) {
          String newName = sharedPrefs.getString(key, "");
          if (!newName.isEmpty()) {
            loadAdvanced(newName);
            if (advancedWorkoutSpinner != null) {
              advancedWorkoutSpinner.setValue(newName);
            }
            if (advancedWorkoutListAdapter != null) {
              advancedWorkoutListAdapter.reload();
            }
          }
        }
      };

  public StartFragment() {
    super(R.layout.start);
  }

  @Override
  public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);

    AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);

    Context context = requireContext();
    mDB = DBHelper.getWritableDatabase(context);
    formatter = new Formatter(context);

    bindGpsTracker();
    mGpsStatus = new org.runnerup.tracker.GpsStatus(context);
    NotificationManager notificationManager =
        ContextCompat.getSystemService(context, NotificationManager.class);
    notificationStateManager =
        new NotificationStateManager(new NotificationManagerDisplayStrategy(notificationManager));
    gpsSearchingState = new GpsSearchingState(context, this);
    gpsBoundState = new GpsBoundState(context);

    // Pace Coach is a running-only app: keep the activity sport fixed to Running.
    PreferenceManager.getDefaultSharedPreferences(context)
        .edit()
        .putInt(getString(R.string.pref_sport), DB.ACTIVITY.SPORT_RUNNING)
        .apply();

    startButton = view.findViewById(R.id.start_button);
    startButton.setOnClickListener(startButtonClick);

    expandIcon = view.findViewById(R.id.expand_icon);
    noDevicesConnected = view.findViewById(R.id.device_status);

    gpsIndicator = view.findViewById(R.id.gps_indicator);
    gpsMessage = view.findViewById(R.id.gps_message);
    gpsDetailRow = view.findViewById(R.id.gps_detail_row);
    gpsDetailIndicator = view.findViewById(R.id.gps_detail_indicator);
    gpsDetailMessage = view.findViewById(R.id.gps_detail_message);

    gpsEnable = view.findViewById(R.id.gps_enable_button);
    gpsEnable.setOnClickListener(gpsEnableClick);

    hrMessage = view.findViewById(R.id.hr_message);
    hrIndicator = view.findViewById(R.id.hr_indicator);

    wearOsIndicator = view.findViewById(R.id.wearos_indicator);
    wearOsMessage = view.findViewById(R.id.wearos_message);

    // Pace Coach home/workspaces do not display the legacy GPS status bar.
    View legacyStatusLayout = view.findViewById(R.id.status_layout);
    if (legacyStatusLayout != null) {
      legacyStatusLayout.setVisibility(View.GONE);
      legacyStatusLayout.setOnClickListener(null);
    }

    // TODO: Replace TabHost with ViewPager2 and TabLayout
    tabHost = view.findViewById(R.id.tabhost_start);
    tabHost.setup();
    TabSpec tabSpec = tabHost.newTabSpec(TAB_BASIC);
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(context, getString(org.runnerup.common.R.string.Basic)));
    tabSpec.setContent(R.id.start_basic_tab);
    tabHost.addTab(tabSpec);

    tabSpec = tabHost.newTabSpec(TAB_INTERVAL);
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(
            context, getString(org.runnerup.common.R.string.Interval)));
    tabSpec.setContent(R.id.start_interval_tab);
    tabHost.addTab(tabSpec);

    tabSpec = tabHost.newTabSpec(TAB_ADVANCED);
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(
            context, getString(org.runnerup.common.R.string.Advanced)));
    tabSpec.setContent(R.id.start_advanced_tab);
    tabHost.addTab(tabSpec);

    tabHost.setOnTabChangedListener(onTabChangeListener);

    // Pace Coach home: keep the dashboard clean and open each mode in its own workspace.
    coachDashboard = view.findViewById(R.id.coach_dashboard);
    coachWorkspace = view.findViewById(R.id.coach_workspace);
    coachWorkspaceTitle = view.findViewById(R.id.coach_workspace_title);
    coachWorkspaceSubtitle = view.findViewById(R.id.coach_workspace_subtitle);
    coachWorkoutCount = view.findViewById(R.id.coach_workout_count);
    coachTotalTime = view.findViewById(R.id.coach_total_time);
    coachTotalDistance = view.findViewById(R.id.coach_total_distance);
    view.findViewById(R.id.coach_card_free).setOnClickListener(v -> openCoachWorkspace(TAB_BASIC, "Treino Livre"));
    view.findViewById(R.id.coach_card_interval).setOnClickListener(v -> openCoachWorkspace(TAB_INTERVAL, "Treino Intervalado"));
    view.findViewById(R.id.coach_card_workout).setOnClickListener(v -> openCoachWorkspace(TAB_ADVANCED, "Treino Estruturado"));
    View historyCard = view.findViewById(R.id.coach_history_card);
    View.OnClickListener openHistory = v -> {
      if (getActivity() instanceof MainLayout) {
        ((MainLayout) getActivity()).navigateToPage(1);
      }
    };
    if (historyCard != null) historyCard.setOnClickListener(openHistory);
    view.findViewById(R.id.coach_back_button).setOnClickListener(v -> closeCoachWorkspace());

    // Pace Coach structured-workout preview actions. The preview uses the existing RunnerUp
    // workout/tracker engine; these buttons only provide the modern entry points.
    view.findViewById(R.id.advanced_preview_start).setOnClickListener(v -> startCoachWorkout());
    view.findViewById(R.id.advanced_preview_edit).setOnClickListener(v -> openCurrentAdvancedWorkoutForEdit());
    view.findViewById(R.id.basic_preview_edit).setOnClickListener(v -> openBasicEditor());
    view.findViewById(R.id.basic_editor_save).setOnClickListener(v -> saveBasicEditor());

    // tabHost.getTabWidget().setBackgroundColor(Color.DKGRAY);

    LayoutInflater inflater = getLayoutInflater();
    simpleAudioListAdapter = new AudioSchemeListAdapter(mDB, inflater, false);
    simpleAudioListAdapter.reload();
    simpleTargetType = view.findViewById(R.id.tab_basic_target_type);
    simpleTargetPaceMin = view.findViewById(R.id.tab_basic_target_pace_min);
    simpleTargetPaceValue = view.findViewById(R.id.tab_basic_target_pace_max);
    simpleTargetTime = view.findViewById(R.id.tab_basic_target_time);
    simpleTargetDistance = view.findViewById(R.id.tab_basic_target_distance);
    hrZonesAdapter = new HRZonesListAdapter(context, inflater);
    simpleTargetHrz = view.findViewById(R.id.tab_basic_target_hrz);
    simpleTargetHrz.setAdapter(hrZonesAdapter);
    simpleTargetType.setOnCloseDialogListener(simpleTargetTypeClick);
    // Pace Coach free run supports only time + pace or distance + pace.
    int savedFreeTarget = simpleTargetType.getValueInt();
    if (savedFreeTarget != DB.DIMENSION.TIME && savedFreeTarget != DB.DIMENSION.DISTANCE) {
      simpleTargetType.setValue(DB.DIMENSION.TIME);
    }
    view.findViewById(R.id.basic_preview_start).setOnClickListener(v -> startCoachWorkout());
    view.findViewById(R.id.interval_preview_start).setOnClickListener(v -> startCoachWorkout());

    intervalType = view.findViewById(R.id.interval_type);
    intervalTime = view.findViewById(R.id.start_interval_time);
    intervalTime.setOnSetValueListener(onSetTimeValidator);
    intervalDistance = view.findViewById(R.id.interval_distance);
    intervalPaceMin = view.findViewById(R.id.interval_pace_min);
    intervalPaceMax = view.findViewById(R.id.interval_pace_max);
    intervalType.setOnSetValueListener(intervalTypeSetValue);
    intervalRestType = view.findViewById(R.id.interval_rest_type);
    intervalRestTime = view.findViewById(R.id.interval_rest_time);
    intervalRestTime.setOnSetValueListener(onSetTimeValidator);
    intervalRestDistance = view.findViewById(R.id.interval_rest_distance);
    intervalRestPaceMin = view.findViewById(R.id.interval_rest_pace_min);
    intervalRestPaceMax = view.findViewById(R.id.interval_rest_pace_max);
    intervalRestType.setOnSetValueListener(intervalRestTypeSetValue);

    intervalWarmupType = view.findViewById(R.id.interval_warmup_type);
    intervalWarmupTime = view.findViewById(R.id.interval_warmup_time);
    intervalWarmupDistance = view.findViewById(R.id.interval_warmup_distance);
    intervalWarmupPaceMin = view.findViewById(R.id.interval_warmup_pace_min);
    intervalWarmupPaceMax = view.findViewById(R.id.interval_warmup_pace_max);
    intervalWarmupType.setOnSetValueListener(intervalWarmupTypeSetValue);
    intervalWarmupTypeSetValue.preSetValue(intervalWarmupType.getValueInt());

    intervalCooldownType = view.findViewById(R.id.interval_cooldown_type);
    intervalCooldownTime = view.findViewById(R.id.interval_cooldown_time);
    intervalCooldownDistance = view.findViewById(R.id.interval_cooldown_distance);
    intervalCooldownPaceMin = view.findViewById(R.id.interval_cooldown_pace_min);
    intervalCooldownPaceMax = view.findViewById(R.id.interval_cooldown_pace_max);
    intervalCooldownType.setOnSetValueListener(intervalCooldownTypeSetValue);
    intervalCooldownTypeSetValue.preSetValue(intervalCooldownType.getValueInt());
    intervalAudioListAdapter = new AudioSchemeListAdapter(mDB, inflater, false);
    intervalAudioListAdapter.reload();
    TitleSpinner intervalAudioSpinner = view.findViewById(R.id.interval_audio_cue_spinner);
    intervalAudioSpinner.setAdapter(intervalAudioListAdapter);
    intervalAudioSpinner.setOnSetValueListener(
        new OnConfigureAudioListener(intervalAudioListAdapter));

    advancedAudioListAdapter = new AudioSchemeListAdapter(mDB, inflater, false);
    advancedAudioListAdapter.reload();
    TitleSpinner advancedAudioSpinner = view.findViewById(R.id.advanced_audio_cue_spinner);
    advancedAudioSpinner.setAdapter(advancedAudioListAdapter);
    advancedAudioSpinner.setOnSetValueListener(
        new OnConfigureAudioListener(advancedAudioListAdapter));

    advancedWorkoutSpinner = view.findViewById(R.id.advanced_workout_spinner);
    advancedWorkoutListAdapter = new WorkoutListAdapter(inflater);
    advancedWorkoutListAdapter.reload();
    advancedWorkoutSpinner.setAdapter(advancedWorkoutListAdapter);
    advancedWorkoutSpinner.setOnSetValueListener(
        new OnConfigureWorkoutsListener(advancedWorkoutListAdapter));
    advancedStepList = view.findViewById(R.id.advanced_step_list);
    advancedStepList.setDividerHeight(0);
    advancedStepList.setAdapter(advancedWorkoutStepsAdapter);

    Intent i = requireActivity().getIntent();
    if (i != null) {
      if (i.hasExtra("mode")) {
        if (Objects.equals(i.getStringExtra("mode"), TAB_ADVANCED)) {
          tabHost.setCurrentTab(2);
          i.removeExtra("mode");
        }
      }
    }

    updateTargetView();

    mWearNotifier = new TrackerWear.WearNotifier(requireActivity().getApplicationContext());
    mWearNotifier.onViewCreated();

  }

  private void setGpsNotRequired(boolean val) {
    if (sportWithoutGps == val) {
      return;
    }

    sportWithoutGps = val;
    if (sportWithoutGps) {
      // Turning GPS off
      if (mTracker != null) {
        mTracker.setWithoutGps(true);
      }
    } else {
      // Toggling GPS on
      Log.e(getClass().getName(), "mTracker.reset()");
      if (mTracker != null) {
        mTracker.setWithoutGps(false);
        mTracker.reset();
        if (mGpsStatus.isStarted()) {
          mTracker.setup();
          startGps();
        }
      }
    }
  }

  private class OnConfigureAudioListener implements OnSetValueListener {
    final AudioSchemeListAdapter adapter;

    OnConfigureAudioListener(AudioSchemeListAdapter adapter) {
      this.adapter = adapter;
    }

    @Override
    public String preSetValue(String newValue) throws IllegalArgumentException {
      if (newValue != null
          && newValue.contentEquals((String) adapter.getItem(adapter.getCount() - 1))) {
        Intent i = new Intent(requireContext(), AudioCueSettingsActivity.class);
        startActivity(i);
        throw new IllegalArgumentException();
      }
      return newValue;
    }

    @Override
    public int preSetValue(int newValueId) throws IllegalArgumentException {
      return newValueId;
    }
  }

  private class OnConfigureWorkoutsListener implements OnSetValueListener {
    final WorkoutListAdapter adapter;

    OnConfigureWorkoutsListener(WorkoutListAdapter adapter) {
      this.adapter = adapter;
    }

    @Override
    public String preSetValue(String newValue) throws IllegalArgumentException {
      if (newValue != null
          && newValue.contentEquals((String) adapter.getItem(adapter.getCount() - 1))) {
        Intent i = new Intent(requireContext(), ManageWorkoutsActivity.class);
        startActivity(i);
        throw new IllegalArgumentException();
      }
      loadAdvanced(newValue);
      return newValue;
    }

    @Override
    public int preSetValue(int newValueId) throws IllegalArgumentException {
      loadAdvanced(null);
      return newValueId;
    }
  }

  @Override
  public void onStart() {
    super.onStart();
    registerStartEventListener();
  }

  @Override
  public void onResume() {
    super.onResume();
    simpleAudioListAdapter.reload();
    intervalAudioListAdapter.reload();
    advancedAudioListAdapter.reload();
    advancedWorkoutListAdapter.reload();

    // Ensure spinner reflects current preference after returning from CreateAdvancedWorkout
    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(requireContext());
    String currentWorkoutName = prefs.getString(getString(R.string.pref_advanced_workout), "");
    if (!currentWorkoutName.isEmpty() && advancedWorkoutSpinner != null) {
      advancedWorkoutSpinner.setValue(currentWorkoutName);
    }
    hrZonesAdapter.reload();
    simpleTargetHrz.setAdapter(hrZonesAdapter);
    if (!hrZonesAdapter.hrZones.isConfigured()) {
      simpleTargetType.addDisabledValue(DB.DIMENSION.HRZ);
    } else {
      simpleTargetType.clearDisabled();
    }

    if (Objects.requireNonNull(tabHost.getCurrentTabTag()).contentEquals(TAB_ADVANCED)) {
      loadAdvanced(null);
    }

    if (!mIsBound || mTracker == null) {
      bindGpsTracker();
    } else {
      onGpsTrackerBound();
    }
    updateCoachDashboardStats();
    this.updateView();
    PreferenceManager.getDefaultSharedPreferences(requireContext())
        .registerOnSharedPreferenceChangeListener(prefChangeListener);
    mWearNotifier.onResume();
  }

  @Override
  public void onPause() {
    super.onPause();
    PreferenceManager.getDefaultSharedPreferences(requireContext())
        .unregisterOnSharedPreferenceChangeListener(prefChangeListener);

    if (getAutoStartGps()) {
      // If autoStartGps, then stop it during pause
      stopGps();
    } else {
      if (mTracker != null
          && ((mTracker.getState() == TrackerState.INITIALIZED)
              || (mTracker.getState() == TrackerState.INITIALIZING))) {
        Log.i(getClass().getName(), "mTracker.reset()");
        mTracker.reset();
      }
    }
    mWearNotifier.onPause();
  }

  @Override
  public void onStop() {
    super.onStop();
    unregisterStartEventListener();
  }

  @Override
  public void onDestroy() {
    stopGps();
    unbindGpsTracker();
    mGpsStatus = null;

    DBHelper.closeDB(mDB);
    super.onDestroy();
    mWearNotifier.onDestroy();
  }

  private final BroadcastReceiver startEventBroadcastReceiver =
      new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
          requireActivity()
              .runOnUiThread(
                  () -> {
                    if (mTracker == null || startButton.getVisibility() != View.VISIBLE) {
                      return;
                    }

                    if (mTracker.getState() == TrackerState.INIT /* this will start gps */
                        || mTracker.getState() == TrackerState.INITIALIZED /* ...start a workout*/
                        || mTracker.getState() == TrackerState.CONNECTED) {
                      startButton.performClick();
                    }
                  });
        }
      };

  private void registerStartEventListener() {
    IntentFilter intentFilter = new IntentFilter();
    // START_WORKOUT is used by Wear when GPS is captured
    // START_ACTIVITY should also start GPS if not done
    intentFilter.addAction(Constants.Intents.START_ACTIVITY);
    intentFilter.addAction(Constants.Intents.START_WORKOUT);
    ContextCompat.registerReceiver(
        requireActivity(),
        startEventBroadcastReceiver,
        intentFilter,
        ContextCompat.RECEIVER_NOT_EXPORTED);
  }

  private void unregisterStartEventListener() {
    try {
      requireActivity().unregisterReceiver(startEventBroadcastReceiver);
    } catch (Exception ignored) {
    }
  }

  private void onGpsTrackerBound() {
    // check and request permissions at startup
    boolean missingEssentialPermission = checkPermissions(false);
    mTracker.setWithoutGps(sportWithoutGps);
    if (!missingEssentialPermission && getAutoStartGps()) {
      startGps();
    } else {
      Log.d(getClass().getName(), "onGpsTrackerBound state: " + mTracker.getState());
      switch (mTracker.getState()) {
        case INIT:
        case CLEANUP:
          mTracker.setup();
          break;
        case INITIALIZING:
        case INITIALIZED:
          break;
        case CONNECTING:
        case CONNECTED:
        case STARTED:
        case PAUSED:
          break;
        case ERROR:
          break;
      }
    }
    updateView();
  }

  public boolean getAutoStartGps() {
    Context ctx = requireActivity().getApplicationContext();
    SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
    return pref.getBoolean(getString(R.string.pref_startgps), false);
  }

  private void startGps() {
    Log.d(getClass().getName(), "StartFragment.startGps()");
    if (!sportWithoutGps) {
      if (!mGpsStatus.isEnabled()) {
        startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
      }
      notificationStateManager.displayNotificationState(gpsSearchingState);
    }

    if (mGpsStatus != null && !mGpsStatus.isStarted()) {
      mGpsStatus.start(this);
    }

    if (mTracker != null) {
      mTracker.setWithoutGps(sportWithoutGps);
      mTracker.connect();
    }
  }

  public void stopGps() {
    Log.d(getClass().getName(), "StartFragment.stopGps() skipStop: " + this.runActivityPending);
    if (runActivityPending) {
      return;
    }

    if (mGpsStatus != null) {
      mGpsStatus.stop(this);
    }

    if (mTracker != null) {
      mTracker.reset();
    }

    notificationStateManager.cancelNotification();
  }

  public boolean isGpsLogging() {
    if (mGpsStatus == null) {
      // If mGpsStatus is null, GPS logging is not possible.
      return false;
    }
    return mGpsStatus.isLogging();
  }

  private void notificationBatteryLevel(int batteryLevel) {
    if ((batteryLevel < 0) || (batteryLevel > 100)) {
      return;
    }

    Context context = requireContext();
    final String pref_key = getString(R.string.pref_battery_level_low_notification_discard);
    final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);

    int batteryLevelHighThreshold =
        SafeParse.parseInt(
            prefs.getString(getString(R.string.pref_battery_level_high_threshold), "75"), 75);
    if ((batteryLevel > batteryLevelHighThreshold) && (prefs.contains(pref_key))) {
      prefs.edit().remove(pref_key).apply();
      return;
    }

    int batteryLevelLowThreshold =
        SafeParse.parseInt(
            prefs.getString(getString(R.string.pref_battery_level_low_threshold), "15"), 15);
    if (batteryLevel > batteryLevelLowThreshold) {
      return;
    }

    if (prefs.getBoolean(pref_key, false)) {
      return;
    }

    final CheckBox dontShowAgain = new CheckBox(context);
    dontShowAgain.setText(getResources().getText(org.runnerup.common.R.string.Do_not_show_again));

    new AlertDialog.Builder(context)
        .setView(dontShowAgain)
        .setCancelable(false)
        .setTitle(org.runnerup.common.R.string.Warning)
        .setMessage(
            getResources().getText(org.runnerup.common.R.string.Low_HRM_battery_level)
                + "\n"
                + getResources().getText(org.runnerup.common.R.string.Battery_level)
                + ": "
                + batteryLevel
                + "%")
        .setPositiveButton(
            org.runnerup.common.R.string.OK,
            (dialog, which) -> {
              if (dontShowAgain.isChecked()) {
                prefs.edit().putBoolean(pref_key, true).apply();
              }
            })
        .show();
  }

  private final OnTabChangeListener onTabChangeListener =
      tabId -> {
        if (tabId.contentEquals(TAB_ADVANCED)) {
          loadAdvanced(null);
        }
        updateView();
      };

  private void openBasicEditor() {
    if (coachWorkspaceTitle != null) coachWorkspaceTitle.setText("Treino Livre");
    if (coachWorkspaceSubtitle != null) coachWorkspaceSubtitle.setVisibility(View.GONE);
    if (tabHost != null) tabHost.setCurrentTabByTag(TAB_BASIC);
    View root = getView();
    if (root != null) {
      View preview = root.findViewById(R.id.basic_free_preview_content);
      View editor = root.findViewById(R.id.basic_editor_content);
      if (preview != null) preview.setVisibility(View.GONE);
      if (editor != null) editor.setVisibility(View.VISIBLE);
      updateTargetView();
    }
  }

  private void saveBasicEditor() {
    updateBasicPreview();
    View root = getView();
    if (root != null) {
      View preview = root.findViewById(R.id.basic_free_preview_content);
      View editor = root.findViewById(R.id.basic_editor_content);
      if (editor != null) editor.setVisibility(View.GONE);
      if (preview != null) preview.setVisibility(View.VISIBLE);
    }
    if (coachWorkspaceTitle != null) coachWorkspaceTitle.setText("Treino Livre");
    if (coachWorkspaceSubtitle != null) {
      coachWorkspaceSubtitle.setText("Revise seu treino antes de iniciar.");
      coachWorkspaceSubtitle.setVisibility(View.VISIBLE);
    }
  }

  private void updateCoachDashboardStats() {
    if (mDB == null || coachWorkoutCount == null || coachTotalTime == null || coachTotalDistance == null) {
      return;
    }

    Cursor cursor = null;
    try {
      cursor =
          mDB.rawQuery(
              "SELECT COUNT(*), COALESCE(SUM(" + DB.ACTIVITY.TIME + "), 0), "
                  + "COALESCE(SUM(" + DB.ACTIVITY.DISTANCE + "), 0) "
                  + "FROM " + DB.ACTIVITY.TABLE
                  + " WHERE " + DB.ACTIVITY.DELETED + " = 0 AND " + DB.ACTIVITY.SPORT + " = ?",
              new String[] {String.valueOf(DB.ACTIVITY.SPORT_RUNNING)});

      if (cursor.moveToFirst()) {
        long workoutCount = cursor.getLong(0);
        long totalTimeSeconds = cursor.getLong(1);
        double totalDistanceMeters = cursor.getDouble(2);

        coachWorkoutCount.setText(String.valueOf(workoutCount));
        coachTotalTime.setText(formatter.formatElapsedTime(Formatter.Format.TXT, totalTimeSeconds));
        coachTotalDistance.setText(
            String.format(Locale.getDefault(), "%.1f km", totalDistanceMeters / 1000.0));
      }
    } finally {
      if (cursor != null) {
        cursor.close();
      }
    }
  }

  private void openCoachWorkspace(String tab, String title) {
    if (coachDashboard != null) coachDashboard.setVisibility(View.GONE);
    if (coachWorkspace != null) coachWorkspace.setVisibility(View.VISIBLE);
    if (coachWorkspaceTitle != null) coachWorkspaceTitle.setText(title);
    if (coachWorkspaceSubtitle != null) {
      coachWorkspaceSubtitle.setText("Revise seu treino antes de iniciar.");
      coachWorkspaceSubtitle.setVisibility(View.VISIBLE);
    }
    if (tabHost != null) tabHost.setCurrentTabByTag(tab);
    View root = getView();
    if (root != null && tab.contentEquals(TAB_BASIC)) {
      View preview = root.findViewById(R.id.basic_free_preview_content);
      View editor = root.findViewById(R.id.basic_editor_content);
      if (preview != null) preview.setVisibility(View.VISIBLE);
      if (editor != null) editor.setVisibility(View.GONE);
      updateBasicPreview();
    }
  }

  private void closeCoachWorkspace() {
    if (coachWorkspace != null) coachWorkspace.setVisibility(View.GONE);
    if (coachDashboard != null) coachDashboard.setVisibility(View.VISIBLE);
  }

  private Workout prepareWorkout() {
    Context ctx = requireActivity().getApplicationContext();
    SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
    SharedPreferences audioPref;
    Workout w;

    if (Objects.requireNonNull(tabHost.getCurrentTabTag()).contentEquals(TAB_BASIC)) {
      audioPref =
          WorkoutBuilder.getAudioCuePreferences(ctx, pref, getString(R.string.pref_basic_audio));
      Dimension target = Dimension.valueOf(simpleTargetType.getValueInt());
      w = WorkoutBuilder.createDefaultWorkout(getResources(), pref, target);
    } else if (tabHost.getCurrentTabTag().contentEquals(TAB_INTERVAL)) {
      audioPref =
          WorkoutBuilder.getAudioCuePreferences(ctx, pref, getString(R.string.pref_interval_audio));
      w = WorkoutBuilder.createDefaultIntervalWorkout(getResources(), pref);
    } else if (tabHost.getCurrentTabTag().contentEquals(TAB_ADVANCED)) {
      audioPref =
          WorkoutBuilder.getAudioCuePreferences(ctx, pref, getString(R.string.pref_advanced_audio));
      w = advancedWorkout;
    } else {
      w = null;
      audioPref = null;
    }
    if (w != null) {
      WorkoutBuilder.prepareWorkout(getResources(), pref, w);
      WorkoutBuilder.addAudioCuesToWorkout(getResources(), w, audioPref, pref);
    }
    return w;
  }

  /**
   * Starts a Pace Coach workout from the modern preview screen. Unlike the legacy
   * start button, the preview action must not require the user to first wait for
   * the GPS/Tracker button to become visible. If the tracker is already connected
   * we launch immediately; otherwise we request the required permissions and start
   * GPS, then launch automatically when CONNECTED is reached.
   */
  private void startCoachWorkout() {
    if (runActivityPending) {
      return;
    }

    if (checkPermissions(true)) {
      // The Android permission dialog is now responsible for the next step.
      return;
    }

    if (mTracker == null || mGpsStatus == null) {
      updateView();
      return;
    }

    if (mTracker.getState() == TrackerState.CONNECTED) {
      coachStartPending = false;
      startWorkout();
      return;
    }

    coachStartPending = true;
    startGps();
    updateView();
  }

  private void startWorkout() {
    mGpsStatus.stop(StartFragment.this);

    // unregister receivers
    unregisterStartEventListener();

    // This will start the advancedWorkoutSpinner!
    mTracker.setWorkout(prepareWorkout());
    mTracker.start();

    runActivityPending = true;
    Intent intent = new Intent(requireContext(), RunActivity.class);
    // TODO: Use the Activity Result API
    StartFragment.this.startActivityForResult(intent, START_ACTIVITY);
    notificationStateManager.cancelNotification(); // will be added by RunActivity
  }

  private final OnClickListener startButtonClick =
      v -> {
        if (mTracker.getState() == TrackerState.CONNECTED) {
          startWorkout();
          return;
        }
        updateView();
      };

  private final OnClickListener gpsEnableClick =
      v -> {
        if (checkPermissions(true)) {
          // Handle view update etc in permission callback
          return;
        }

        if (mTracker.getState() != TrackerState.CONNECTED) {
          startGps();
        }
        updateView();
      };

  private List<String> getPermissions() {
    List<String> requiredPerms = new ArrayList<>();
    requiredPerms.add(Manifest.permission.ACCESS_FINE_LOCATION);
    requiredPerms.add(Manifest.permission.ACCESS_COARSE_LOCATION);

    Context ctx = requireContext();
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      requiredPerms.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION);

      final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
      boolean enabled =
          prefs.getBoolean(
              this.getString(org.runnerup.R.string.pref_use_cadence_step_sensor), true);
      if (enabled && TrackerCadence.isAvailable(ctx)) {
        requiredPerms.add(Manifest.permission.ACTIVITY_RECOGNITION);
      }
    }

    PackageManager packageManager = requireContext().getPackageManager();
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S /* Android12, sdk31*/
        && (packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)
            || packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH))) {
      final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
      final String btDeviceName = prefs.getString(getString(R.string.pref_bt_name), null);
      if (btDeviceName != null && !btDeviceName.isEmpty()) {
        requiredPerms.add(Manifest.permission.BLUETOOTH_CONNECT);
        requiredPerms.add(Manifest.permission.BLUETOOTH_SCAN);
      }
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      requiredPerms.add(Manifest.permission.POST_NOTIFICATIONS);
    }

    return requiredPerms;
  }

  /**
   * Check that required permissions are allowed
   *
   * @param popup
   * @return
   */
  private boolean checkPermissions(boolean popup) {
    boolean missingEssentialPermission = false;
    boolean missingAnyPermission = false;
    List<String> requiredPerms = getPermissions();
    List<String> requestPerms = new ArrayList<>();
    Context ctx = requireContext();

    for (final String perm : requiredPerms) {
      if (ContextCompat.checkSelfPermission(ctx, perm) != PackageManager.PERMISSION_GRANTED) {
        missingAnyPermission = true;
        // Filter non essential permissions for result
        boolean nonEssential =
            (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                    && perm.equals(Manifest.permission.ACTIVITY_RECOGNITION)
                || Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    && (perm.equals(Manifest.permission.BLUETOOTH_CONNECT)
                        || perm.equals(Manifest.permission.BLUETOOTH_SCAN))
                || Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                    && perm.equals(Manifest.permission.POST_NOTIFICATIONS));
        missingEssentialPermission = missingEssentialPermission || !nonEssential;
        if (ActivityCompat.shouldShowRequestPermissionRationale(requireActivity(), perm)) {
          // A denied permission, show motivation in a popup
          String s = "Permission " + perm + " is explicitly denied";
          Log.i(getClass().getName(), s);
        } else {
          requestPerms.add(perm);
        }
      }
    }

    if (missingAnyPermission) {
      final String[] permissions = new String[requestPerms.size()];
      requestPerms.toArray(permissions);

      if (popup && missingEssentialPermission || !requestPerms.isEmpty()) {
        // Essential or requestable permissions missing
        String baseMessage =
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                ? getString(org.runnerup.common.R.string.GPS_permission_text_Android12)
                : Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                    ? getString(org.runnerup.common.R.string.GPS_permission_text)
                    : getString(org.runnerup.common.R.string.GPS_permission_text_pre_Android10);

        AlertDialog.Builder builder =
            new AlertDialog.Builder(ctx)
                .setTitle(org.runnerup.common.R.string.GPS_permission_required)
                .setNegativeButton(
                    org.runnerup.common.R.string.Cancel, (dialog, which) -> dialog.dismiss());
        if (!requestPerms.isEmpty()) {
          // Let Android request the permissions
          builder
              .setPositiveButton(
                  org.runnerup.common.R.string.OK,
                  (dialog, id) -> {
                    Activity activity = getActivity();
                    if (activity != null) {
                      ActivityCompat.requestPermissions(activity, permissions, REQUEST_LOCATION);
                    }
                  })
              .setMessage(
                  baseMessage
                      + "\n"
                      + getString(org.runnerup.common.R.string.Request_permission_text));
        } else {
          // Open settings for the app (no direct shortcut to permissions)
          Intent intent =
              new Intent()
                  .setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                  .setData(Uri.fromParts("package", ctx.getPackageName(), null));
          builder
              .setPositiveButton(
                  org.runnerup.common.R.string.OK, (dialog, id) -> startActivity(intent))
              .setMessage(
                  baseMessage
                      + "\n\n"
                      + getString(org.runnerup.common.R.string.Request_permission_text));
        }
        builder.show();
      }
    }

    // https://developer.android.com/training/monitoring-device-state/doze-standby#support_for_other_use_cases
    // Permission REQUEST_IGNORE_BATTERY_OPTIMIZATIONS requires special approval in Play
    final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
    final Resources res = this.getResources();
    final boolean suppressOptimizeBatteryPopup =
        prefs.getBoolean(res.getString(R.string.pref_suppress_battery_optimization_popup), false);
    PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
    if ((popup || getAutoStartGps())
        && !suppressOptimizeBatteryPopup
        && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
        && !pm.isIgnoringBatteryOptimizations(ctx.getPackageName())) {
      Intent intent;
      int msgId;
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        // Around Android 9 the Battery usage setting is available in the app setting too, which is
        // easier to
        // change than in the system settings
        intent =
            new Intent()
                .setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                .setData(Uri.fromParts("package", ctx.getPackageName(), null));
        msgId = org.runnerup.common.R.string.Battery_optimization_check_text_Android9;
      } else {
        intent = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
        msgId = org.runnerup.common.R.string.Battery_optimization_check_text;
      }

      new AlertDialog.Builder(ctx)
          .setTitle(org.runnerup.common.R.string.Battery_optimization_check)
          .setMessage(msgId)
          .setPositiveButton(
              org.runnerup.common.R.string.OK, (dialog, which) -> this.startActivity(intent))
          .setNeutralButton(
              org.runnerup.common.R.string.Do_not_show_again,
              (dialog, which) ->
                  prefs
                      .edit()
                      .putBoolean(
                          res.getString(R.string.pref_suppress_battery_optimization_popup), true)
                      .apply())
          .setNegativeButton(
              org.runnerup.common.R.string.Cancel, (dialog, which) -> dialog.dismiss())
          .show();
    }

    return missingEssentialPermission;
  }

  private void toggleStatusDetails() {
    statusDetailsShown = !statusDetailsShown;
    float bottomMargin;

    if (statusDetailsShown) {
      expandIcon.setImageResource(R.drawable.ic_expand_down_white_24dp);
      bottomMargin = getResources().getDimension(R.dimen.fab_margin_68row);
    } else {
      expandIcon.setImageResource(R.drawable.ic_expand_up_white_24dp);
      bottomMargin = getResources().getDimension(R.dimen.fab_margin_44row);
    }

    ViewGroup.MarginLayoutParams params =
        (ViewGroup.MarginLayoutParams) startButton.getLayoutParams();
    params.setMargins(params.leftMargin, params.topMargin, params.rightMargin, (int) bottomMargin);
    startButton.setLayoutParams(params);

    updateView();
  }

  private GpsLevel getGpsLevel(double gpsAccuracyMeters, int sats) {
    if (!mGpsStatus.isFixed()) {
      return GpsLevel.NOT_FIXED;
    }
    if (gpsAccuracyMeters <= 7 && sats > 7) {
      return GpsLevel.GOOD;
    } else if (gpsAccuracyMeters <= 15 && sats > 4) {
      return GpsLevel.ACCEPTABLE;
    } else {
      return GpsLevel.POOR;
    }
  }

  public void updateView() {
    updateStartGpsButtonView();
    updateStartButtonView();
    updateGPSView();
    boolean hrPresent = updateHRView();
    boolean wearPresent = updateWearOSView();

    if (!hrPresent && !wearPresent && statusDetailsShown) {
      noDevicesConnected.setVisibility(View.VISIBLE);
    } else {
      noDevicesConnected.setVisibility(View.GONE);
    }
  }

  private void updateStartButtonView() {
    do {
      if (!mGpsStatus.isStarted()) {
        break;
      }

      if (!sportWithoutGps) {
        if (!mGpsStatus.isLogging()) {
          break;
        }

        if (!mGpsStatus.isFixed()) {
          break;
        }
      }

      if (mTracker == null || !mIsBound) {
        break;
      }

      if (mTracker.getState() != TrackerState.CONNECTED) {
        break;
      }

      if (Objects.requireNonNull(tabHost.getCurrentTabTag()).contentEquals(TAB_ADVANCED)
          && advancedWorkout == null) {
        break;
      }

      startButton.setVisibility(View.VISIBLE);
      return;
    } while (false);

    startButton.setVisibility(View.GONE);
  }

  private void updateStartGpsButtonView() {
    do {
      if (mGpsStatus.isStarted()) {
        break;
      }

      //
      if (sportWithoutGps) {
        gpsEnable.setText(org.runnerup.common.R.string.Start_tracker);
      } else if (mGpsStatus.isEnabled()) {
        gpsEnable.setText(org.runnerup.common.R.string.Start_GPS);
      } else {
        gpsEnable.setText(org.runnerup.common.R.string.Enable_GPS);
      }
      gpsEnable.setVisibility(View.VISIBLE);
      return;
    } while (false);

    gpsEnable.setVisibility(View.GONE);
  }

  private void updateGPSView() {
    if (!mGpsStatus.isEnabled() || !mGpsStatus.isStarted() || sportWithoutGps) {

      if (statusDetailsShown) {
        gpsDetailMessage.setText(org.runnerup.common.R.string.GPS_indicator_off);
        gpsDetailRow.setVisibility(View.VISIBLE);
        gpsMessage.setVisibility(View.GONE);
      } else {
        gpsMessage.setText(org.runnerup.common.R.string.GPS_indicator_off);
        gpsMessage.setVisibility(View.VISIBLE);
        gpsDetailRow.setVisibility(View.GONE);
      }

      gpsIndicator.setVisibility(View.GONE);
      gpsDetailIndicator.setVisibility(View.GONE);
      return;
    }

    if (statusDetailsShown) {
      gpsIndicator.setVisibility(View.GONE);
      gpsMessage.setVisibility(View.GONE);
      gpsDetailRow.setVisibility(View.VISIBLE);
    } else {
      gpsIndicator.setVisibility(View.VISIBLE);
      gpsMessage.setVisibility(View.VISIBLE);
      gpsDetailRow.setVisibility(View.GONE);
    }

    gpsDetailIndicator.setVisibility(View.VISIBLE);

    int satFixedCount = mGpsStatus.getSatellitesFixed();
    int satAvailCount = mGpsStatus.getSatellitesAvailable();

    // gps accuracy
    float accuracy = getGpsAccuracy();

    // gps details
    String gpsAccuracy = getGpsAccuracyString(accuracy);
    String gpsDetail =
        gpsAccuracy.isEmpty()
            ? String.format(
                getString(org.runnerup.common.R.string.GPS_status_no_accuracy),
                satFixedCount,
                satAvailCount)
            : String.format(
                getString(org.runnerup.common.R.string.GPS_status_accuracy),
                satFixedCount,
                satAvailCount,
                gpsAccuracy);
    gpsDetailMessage.setText(gpsDetail);

    var gpsLevel = getGpsLevel(accuracy, satFixedCount);
    switch (gpsLevel) {
      case NOT_FIXED:
        gpsIndicator.setImageResource(R.drawable.ic_gps_0);
        gpsDetailIndicator.setImageResource(R.drawable.ic_gps_0);
        gpsMessage.setText(org.runnerup.common.R.string.Waiting_for_GPS);
        break;
      case POOR:
        gpsIndicator.setImageResource(R.drawable.ic_gps_1);
        gpsDetailIndicator.setImageResource(R.drawable.ic_gps_1);
        gpsMessage.setText(org.runnerup.common.R.string.GPS_level_poor);
        break;
      case ACCEPTABLE:
        gpsIndicator.setImageResource(R.drawable.ic_gps_2);
        gpsDetailIndicator.setImageResource(R.drawable.ic_gps_2);
        gpsMessage.setText(org.runnerup.common.R.string.GPS_level_acceptable);
        break;
      case GOOD:
        gpsIndicator.setImageResource(R.drawable.ic_gps_3);
        gpsDetailIndicator.setImageResource(R.drawable.ic_gps_3);
        gpsMessage.setText(org.runnerup.common.R.string.GPS_level_good);
        break;
    }
    if (gpsLevel == GpsLevel.NOT_FIXED) {
      notificationStateManager.displayNotificationState(gpsSearchingState);
    } else {
      notificationStateManager.displayNotificationState(gpsBoundState);
    }
  }

  private boolean updateHRView() {
    if (mTracker == null || !mTracker.isComponentConfigured(TrackerHRM.NAME)) {
      hrIndicator.setVisibility(View.GONE);
      hrMessage.setVisibility(View.GONE);
      return false;
    }
    Integer hrVal = null;
    if (mTracker.isComponentConnected(TrackerHRM.NAME)) {
      hrVal = mTracker.getCurrentHRValue();
    }
    if (hrVal != null) {
      if (!batteryLevelMessageShown) {
        batteryLevelMessageShown = true;
        notificationBatteryLevel(mTracker.getCurrentBatteryLevel());
      }
    }

    hrMessage.setText(getHRDetailString());
    hrIndicator.setVisibility(View.VISIBLE);
    if (statusDetailsShown) {
      hrMessage.setVisibility(View.VISIBLE);
    } else {
      hrMessage.setVisibility(View.GONE);
    }

    return true;
  }

  private boolean updateWearOSView() {
    if (mTracker == null || !mTracker.isComponentConfigured(TrackerWear.NAME)) {
      wearOsIndicator.setVisibility(View.GONE);
      wearOsMessage.setVisibility(View.GONE);
      return false;
    }

    wearOsIndicator.setVisibility(View.VISIBLE);

    if (!mTracker.isComponentConnected(TrackerWear.NAME)) {
      wearOsMessage.setVisibility(View.VISIBLE);
      wearOsMessage.setText("?");
    } else if (statusDetailsShown) {
      // wearOsMessage.setText(""); //todo show device name
      wearOsMessage.setVisibility(View.GONE);
    } else {
      wearOsMessage.setVisibility(View.GONE);
    }

    return true;
  }

  @Override
  public float getGpsAccuracy() {
    if (mTracker != null) {
      Location l = mTracker.getLastKnownLocation();

      if (l != null) {
        return l.getAccuracy();
      }
    }
    return -1;
  }

  public String getGpsAccuracyString(float accuracy) {
    String res = "";
    if (accuracy > 0) {
      String accString = formatter.formatElevation(Formatter.Format.TXT_LONG, accuracy);
      if (mTracker.getCurrentElevation() != null) {
        res =
            String.format(
                Locale.getDefault(),
                getString(org.runnerup.common.R.string.GPS_accuracy_elevation),
                accString,
                formatter.formatElevation(
                    Formatter.Format.TXT_LONG, mTracker.getCurrentElevation()));
      } else {
        res =
            String.format(
                Locale.getDefault(),
                getString(org.runnerup.common.R.string.GPS_accuracy_no_elevation),
                accString);
      }
    }
    if (BuildConfig.DEBUG && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      // Extra info in debug builds
      if (mTracker != null) {
        Location l = mTracker.getLastKnownLocation();

        if (l != null) {
          res +=
              String.format(
                  Locale.getDefault(),
                  " [%1$s, %2$s/%3$s, %4$.1f/%5$.1f deg]",
                  formatter.formatElevation(
                      Formatter.Format.TXT_LONG, l.getVerticalAccuracyMeters()),
                  formatter.formatSpeed(Formatter.Format.TXT_SHORT, l.getSpeed()),
                  formatter.formatSpeed(
                      Formatter.Format.TXT_LONG, l.getSpeedAccuracyMetersPerSecond()),
                  l.getBearing(),
                  l.getBearingAccuracyDegrees());
        }
      }
    }
    return res;
  }

  private String getHRDetailString() {
    StringBuilder str = new StringBuilder();

    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(requireContext());
    final String btDeviceName = prefs.getString(getString(R.string.pref_bt_name), null);

    if (btDeviceName != null) {
      str.append(btDeviceName);
    } else if (MockHRProvider.NAME.contentEquals(
        prefs.getString(getString(R.string.pref_bt_provider), ""))) {
      str.append("mock: ").append(prefs.getString(getString(R.string.pref_bt_address), "???"));
    }

    if (mTracker.isComponentConnected(TrackerHRM.NAME)) {
      Integer hrVal = mTracker.getCurrentHRValue();
      if (hrVal != null) {
        str.append(" ").append(hrVal);
        Integer batteryLevel = mTracker.getCurrentBatteryLevel();

        if (batteryLevel != HRProvider.BATTERY_LEVEL_UNAVAILABLE) {
          str.append(" ").append(batteryLevel).append("%");
        }
      }
    }
    return str.toString();
  }

  private boolean mIsBound = false;
  private final ServiceConnection mConnection =
      new ServiceConnection() {
        public void onServiceConnected(ComponentName className, IBinder service) {
          // This is called when the connection with the service has been
          // established, giving us the service object we can use to
          // interact with the service. Because we have bound to a explicit
          // service that we know is running in our own process, we can
          // cast its IBinder to a concrete class and directly access it.
          mTracker = ((Tracker.LocalBinder) service).getService();
          // Tell the user about this for our demo.
          StartFragment.this.onGpsTrackerBound();
          if (mTracker != null) {
            mTracker.registerTrackerStateListener(trackerStateListener);
          }
        }

        public void onServiceDisconnected(ComponentName className) {
          // This is called when the connection with the service has been
          // unexpectedly disconnected -- that is, its process crashed.
          // Because it is running in our same process, we should never
          // see this happen.
          if (mTracker != null) {
            mTracker.unregisterTrackerStateListener(trackerStateListener);
          }
          mTracker = null;
        }
      };

  private void bindGpsTracker() {
    // Establish a connection with the service. We use an explicit
    // class name because we want a specific service implementation that
    // we know will be running in our own process (and thus won't be
    // supporting component replacement by other applications).
    mIsBound =
        requireActivity()
            .getApplicationContext()
            .bindService(
                new Intent(requireContext(), Tracker.class), mConnection, Context.BIND_AUTO_CREATE);
  }

  private void unbindGpsTracker() {
    if (mIsBound) {
      // Detach our existing connection.
      requireActivity().getApplicationContext().unbindService(mConnection);
      mIsBound = false;
    }
    if (mTracker != null) {
      mTracker.unregisterTrackerStateListener(trackerStateListener);
    }
    mTracker = null;
  }

  // TODO: Use Activity Result API
  @Override
  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    registerStartEventListener();

    if (data != null) {
      if (data.getStringExtra("url") != null)
        Log.d(
            getClass().getName(), "data.getStringExtra(\"url\") => " + data.getStringExtra("url"));
      if (data.getStringExtra("ex") != null)
        Log.d(getClass().getName(), "data.getStringExtra(\"ex\") => " + data.getStringExtra("ex"));
      if (data.getStringExtra("obj") != null)
        Log.d(
            getClass().getName(), "data.getStringExtra(\"obj\") => " + data.getStringExtra("obj"));
    }
    if (requestCode == START_ACTIVITY) {
      runActivityPending = false;
      if (!mIsBound || mTracker == null) {
        bindGpsTracker();
      } else {
        onGpsTrackerBound();
      }
    } else {
      advancedWorkoutListAdapter.reload();
    }
    updateView();
  }

  @Override
  public void onTick() {
    updateView();
    updateBasicPreview();
    updateIntervalPreview();
  }

  private final OnCloseDialogListener simpleTargetTypeClick =
      (spinner, ok) -> {
        if (ok) {
          updateTargetView();
          updateBasicPreview();
        }
      };

  private void updateTargetView() {
    Dimension dim = Dimension.valueOf(simpleTargetType.getValueInt());

    simpleTargetTime.setEnabled(false);
    simpleTargetDistance.setEnabled(false);
    simpleTargetPaceMin.setEnabled(false);
    simpleTargetPaceValue.setEnabled(false);

    simpleTargetTime.setVisibility(View.GONE);
    simpleTargetDistance.setVisibility(View.GONE);
    viewVisibility(R.id.basic_target_time_helper, View.GONE);
    viewVisibility(R.id.basic_target_time_example, View.GONE);
    viewVisibility(R.id.basic_target_distance_helper, View.GONE);
    viewVisibility(R.id.basic_target_distance_example, View.GONE);
    viewVisibility(R.id.basic_target_divider, View.VISIBLE);
    simpleTargetPaceMin.setVisibility(View.VISIBLE);
    simpleTargetPaceValue.setVisibility(View.VISIBLE);
    viewVisibility(R.id.basic_pace_title, View.VISIBLE);
    viewVisibility(R.id.basic_pace_fields, View.VISIBLE);

    if (dim == Dimension.TIME) {
      simpleTargetTime.setEnabled(true);
      simpleTargetTime.setVisibility(View.VISIBLE);
      viewVisibility(R.id.basic_target_time_helper, View.VISIBLE);
      viewVisibility(R.id.basic_target_time_example, View.VISIBLE);
    } else if (dim == Dimension.DISTANCE) {
      simpleTargetDistance.setEnabled(true);
      simpleTargetDistance.setVisibility(View.VISIBLE);
      viewVisibility(R.id.basic_target_distance_helper, View.VISIBLE);
      viewVisibility(R.id.basic_target_distance_example, View.VISIBLE);
    } else {
      // Old preferences may contain unsupported free-run target values.
      simpleTargetType.setValue(DB.DIMENSION.TIME);
      simpleTargetTime.setEnabled(true);
      simpleTargetTime.setVisibility(View.VISIBLE);
    }
    simpleTargetPaceMin.setEnabled(true);
    simpleTargetPaceValue.setEnabled(true);
}

  private void updateBasicPreview() {
    View root = getView();
    if (root == null) return;

    TextView distanceView = root.findViewById(R.id.basic_summary_distance);
    TextView timeView = root.findViewById(R.id.basic_summary_time);
    TextView stepDistance = root.findViewById(R.id.basic_free_step_distance);
    TextView stepTime = root.findViewById(R.id.basic_free_step_time);
    TextView stepAvgPace = root.findViewById(R.id.basic_free_step_avg_pace);
    if (distanceView == null || timeView == null || stepDistance == null || stepTime == null) return;

    Dimension dim = Dimension.valueOf(simpleTargetType.getValueInt());
    if (dim != Dimension.TIME && dim != Dimension.DISTANCE) dim = Dimension.TIME;

    double paceFast = SafeParse.parseSeconds(
        simpleTargetPaceMin.getValue() == null ? "00:05:10" : simpleTargetPaceMin.getValue().toString(),
        5 * 60 + 10);
    double paceSlow = SafeParse.parseSeconds(
        simpleTargetPaceValue.getValue() == null ? "00:06:40" : simpleTargetPaceValue.getValue().toString(),
        6 * 60 + 40);
    if (paceFast <= 0) paceFast = 5 * 60 + 10;
    if (paceSlow <= 0) paceSlow = 6 * 60 + 40;
    if (paceSlow < paceFast) {
      double tmp = paceFast; paceFast = paceSlow; paceSlow = tmp;
    }
    double paceAverage = (paceFast + paceSlow) / 2.0;
    String paceText = normalizePace(simpleTargetPaceMin.getValue()) + " – "
        + normalizePace(simpleTargetPaceValue.getValue()) + " /km";
    String avgPaceText = formatPaceShort(paceAverage) + " /km";

    double distanceKm;
    double seconds;
    if (dim == Dimension.TIME) {
      seconds = SafeParse.parseSeconds(
          simpleTargetTime.getValue() == null ? "00:30:00" : simpleTargetTime.getValue().toString(),
          30 * 60);
      if (seconds < 0) seconds = 0;
      distanceKm = seconds / paceAverage;
    } else {
      double meters = SafeParse.parseDouble(
          simpleTargetDistance.getValue() == null ? "5000" : simpleTargetDistance.getValue().toString(),
          5000);
      if (meters < 0) meters = 0;
      distanceKm = meters / 1000.0;
      seconds = distanceKm * paceAverage;
    }

    String distanceText = formatDistanceKm(distanceKm);
    String timeText = formatDurationShort(seconds);
    distanceView.setText(distanceText);
    timeView.setText(timeText);
    stepDistance.setText(distanceText);
    stepTime.setText(timeText);
    if (stepAvgPace != null) stepAvgPace.setText(avgPaceText);
  }

  private String formatPaceShort(double secondsPerKm) {
    long total = Math.max(0, Math.round(secondsPerKm));
    long minutes = total / 60;
    long seconds = total % 60;
    return String.format(Locale.getDefault(), "%d:%02d", minutes, seconds);
  }

  private String formatDistanceKm(double km) {
    return String.format(Locale.getDefault(), "%.1f km", Math.max(0, km));
  }

  private String formatDurationShort(double seconds) {
    long total = Math.max(0, Math.round(seconds));

    // Pace Coach duration display rule:
    // zero -> 00:00; under one hour -> MM:SS min;
    // one hour or more -> HhMM.
    // Examples: 00:30 -> 00:30 min, 00:59 -> 00:59 min,
    // 01:00 -> 1h00, 01:30 -> 1h30.
    if (total == 0) return "00:00";
    if (total < 3600) {
      long minutes = total / 60;
      long secs = total % 60;
      return String.format(Locale.getDefault(), "%02d:%02d min", minutes, secs);
    }

    long hours = total / 3600;
    long minutes = (total % 3600) / 60;
    return String.format(Locale.getDefault(), "%dh%02d", hours, minutes);
  }

  private void updateIntervalPreview() {
    View root = getView();
    if (root == null || intervalType == null || intervalRestType == null || intervalWarmupType == null || intervalCooldownType == null) return;
    LinearLayout container = root.findViewById(R.id.interval_preview_container);
    if (container == null) return;
    container.removeAllViews();

    int n = 1;
    addIntervalPreviewStep(container, n++, "↗", R.color.stepWarmup, "Aquecimento", intervalValue(intervalWarmupType, intervalWarmupTime, intervalWarmupDistance));
    addIntervalPreviewStep(container, n++, "▶", R.color.sportRunning, "Intervalo", intervalValue(intervalType, intervalTime, intervalDistance) + " • Pace " + normalizePace(intervalPaceMin.getValue()) + "–" + normalizePace(intervalPaceMax.getValue()));
    addIntervalPreviewStep(container, n++, "■", R.color.stepRecovery, "Recuperação", intervalValue(intervalRestType, intervalRestTime, intervalRestDistance));
    addIntervalPreviewStep(container, n, "↘", R.color.stepRecovery, "Desaquecimento", intervalValue(intervalCooldownType, intervalCooldownTime, intervalCooldownDistance));
  }

  private String intervalValue(TitleSpinner type, TitleSpinner time, TitleSpinner distance) {
    if (type == null) return "Livre";
    return type.getValueInt() == 0 ? String.valueOf(time.getValue()) : String.valueOf(distance.getValue());
  }

  private void addIntervalPreviewStep(LinearLayout container, int number, String symbol, int colorRes, String title, String detail) {
    LinearLayout card = new LinearLayout(requireContext());
    card.setOrientation(LinearLayout.HORIZONTAL);
    card.setGravity(android.view.Gravity.CENTER_VERTICAL);
    card.setPadding(dp(12), dp(10), dp(12), dp(10));
    card.setBackgroundResource(R.drawable.bg_coach_step);
    LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    cp.bottomMargin = dp(8);
    card.setLayoutParams(cp);

    TextView badge = new TextView(requireContext());
    badge.setText(String.valueOf(number));
    badge.setGravity(android.view.Gravity.CENTER);
    badge.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorText));
    badge.setTextSize(12);
    badge.setTypeface(null, android.graphics.Typeface.BOLD);
    badge.setBackgroundResource(R.drawable.bg_coach_step_number);
    card.addView(badge, new LinearLayout.LayoutParams(dp(34), dp(34)));

    TextView ico = new TextView(requireContext());
    ico.setText(symbol);
    ico.setTextColor(ContextCompat.getColor(requireContext(), colorRes));
    ico.setTextSize(20);
    ico.setGravity(android.view.Gravity.CENTER);
    LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(34), dp(34));
    ip.setMargins(dp(8), 0, dp(6), 0);
    card.addView(ico, ip);

    LinearLayout body = new LinearLayout(requireContext());
    body.setOrientation(LinearLayout.VERTICAL);
    body.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
    TextView t = new TextView(requireContext());
    t.setText(title);
    t.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorText));
    t.setTextSize(15);
    t.setTypeface(null, android.graphics.Typeface.BOLD);
    body.addView(t);
    TextView d = new TextView(requireContext());
    d.setText(detail);
    d.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorTextSecondary));
    d.setTextSize(12);
    body.addView(d);
    card.addView(body);
    container.addView(card);
  }

  private String normalizePace(CharSequence value) {
    if (value == null) return "00:00";
    String s = value.toString().trim();
    if (s.matches("\\d{2}:\\d{2}:\\d{2}")) return s.substring(3);
    if (s.matches("\\d{1}:\\d{2}")) return "0" + s;
    if (s.matches("\\d{2}:\\d{2}")) return s;
    return s;
  }

  private void viewVisibility(int id, int visibility) {
    View v = getView();
    if (v != null) {
      View target = v.findViewById(id);
      if (target != null) target.setVisibility(visibility);
    }
  }

  private final OnSetValueListener intervalTypeSetValue =
      new OnSetValueListener() {

        @Override
        public String preSetValue(String newValue) throws IllegalArgumentException {
          return newValue;
        }

        @Override
        public int preSetValue(int newValue) throws IllegalArgumentException {
          boolean time = (newValue == 0);
          intervalTime.setVisibility(time ? View.VISIBLE : View.GONE);
          intervalDistance.setVisibility(time ? View.GONE : View.VISIBLE);
          return newValue;
        }
      };

  private final OnSetValueListener intervalRestTypeSetValue =
      new OnSetValueListener() {

        @Override
        public String preSetValue(String newValue) throws IllegalArgumentException {
          return newValue;
        }

        @Override
        public int preSetValue(int newValue) throws IllegalArgumentException {
          boolean time = (newValue == 0);
          intervalRestTime.setVisibility(time ? View.VISIBLE : View.GONE);
          intervalRestDistance.setVisibility(time ? View.GONE : View.VISIBLE);
          intervalRestPaceMin.setVisibility(View.VISIBLE);
          intervalRestPaceMax.setVisibility(View.VISIBLE);
          return newValue;
        }
      };

  private final OnSetValueListener intervalWarmupTypeSetValue =
      new OnSetValueListener() {
        @Override
        public String preSetValue(String newValue) throws IllegalArgumentException {
          return newValue;
        }

        @Override
        public int preSetValue(int newValue) throws IllegalArgumentException {
          boolean time = newValue == 0;
          intervalWarmupTime.setVisibility(time ? View.VISIBLE : View.GONE);
          intervalWarmupDistance.setVisibility(time ? View.GONE : View.VISIBLE);
          return newValue;
        }
      };

  private final OnSetValueListener intervalCooldownTypeSetValue =
      new OnSetValueListener() {
        @Override
        public String preSetValue(String newValue) throws IllegalArgumentException {
          return newValue;
        }

        @Override
        public int preSetValue(int newValue) throws IllegalArgumentException {
          boolean time = newValue == 0;
          intervalCooldownTime.setVisibility(time ? View.VISIBLE : View.GONE);
          intervalCooldownDistance.setVisibility(time ? View.GONE : View.VISIBLE);
          return newValue;
        }
      };

  private void openCurrentAdvancedWorkoutForEdit() {
    if (advancedWorkoutSpinner == null || advancedWorkout == null) return;
    String name = advancedWorkoutSpinner.getValue().toString();
    if (name == null || name.trim().isEmpty()) return;
    Intent intent = new Intent(requireContext(), CreateAdvancedWorkout.class);
    intent.putExtra(ManageWorkoutsActivity.WORKOUT_NAME, name);
    intent.putExtra(ManageWorkoutsActivity.WORKOUT_EDIT_MODE, true);
    startActivity(intent);
  }

  private void renderAdvancedPreview() {
    if (getView() == null) return;
    LinearLayout container = getView().findViewById(R.id.advanced_preview_container);
    if (container == null) return;
    container.removeAllViews();

    if (advancedWorkout == null || advancedWorkout.getStepList().isEmpty()) {
      TextView empty = new TextView(requireContext());
      empty.setText("Crie ou selecione um treino para visualizar os blocos aqui.");
      empty.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorTextSecondary));
      empty.setTextSize(13);
      empty.setPadding(dp(4), dp(8), dp(4), dp(8));
      container.addView(empty);
      return;
    }

    List<StepListEntry> entries = advancedWorkout.getStepList();
    int shown = 0;
    for (StepListEntry entry : entries) {
      if (shown >= 8) break;
      container.addView(createPreviewCard(entry, shown + 1));
      shown++;
    }
    if (entries.size() > shown) {
      TextView more = new TextView(requireContext());
      more.setText("+ " + (entries.size() - shown) + " etapas");
      more.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorAccent));
      more.setTextSize(12);
      more.setGravity(android.view.Gravity.CENTER);
      more.setPadding(dp(4), dp(10), dp(4), dp(4));
      container.addView(more);
    }

    TextView total = getView().findViewById(R.id.advanced_preview_total);
    if (total != null) total.setText(buildAdvancedDistanceSummary(entries));
    TextView count = getView().findViewById(R.id.advanced_preview_count);
    if (count != null) count.setText(entries.size() + (entries.size() == 1 ? " etapa" : " etapas"));
  }

  private View createPreviewCard(StepListEntry entry, int number) {
    LinearLayout card = new LinearLayout(requireContext());
    card.setOrientation(LinearLayout.HORIZONTAL);
    card.setGravity(android.view.Gravity.CENTER_VERTICAL);
    card.setPadding(dp(12), dp(12), dp(12), dp(12));
    card.setBackgroundResource(R.drawable.bg_coach_step);
    LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    cp.bottomMargin = dp(8);
    card.setLayoutParams(cp);

    TextView badge = new TextView(requireContext());
    badge.setText(String.valueOf(number));
    badge.setGravity(android.view.Gravity.CENTER);
    badge.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorText));
    badge.setTextSize(12);
    badge.setTypeface(null, android.graphics.Typeface.BOLD);
    badge.setBackgroundResource(R.drawable.bg_coach_step_number);
    card.addView(badge, new LinearLayout.LayoutParams(dp(34), dp(34)));

    LinearLayout body = new LinearLayout(requireContext());
    body.setOrientation(LinearLayout.VERTICAL);
    body.setPadding(dp(12), 0, 0, 0);
    card.addView(body, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

    TextView title = new TextView(requireContext());
    title.setText(previewIntensity(entry.step()));
    title.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorText));
    title.setTextSize(15);
    title.setTypeface(null, android.graphics.Typeface.BOLD);
    body.addView(title);

    LinearLayout meta = new LinearLayout(requireContext());
    meta.setOrientation(LinearLayout.HORIZONTAL);
    meta.setPadding(0, dp(5), 0, 0);
    body.addView(meta);

    TextView duration = new TextView(requireContext());
    duration.setText(formatStepDuration(entry.step()));
    duration.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorTextSecondary));
    duration.setTextSize(12);
    meta.addView(duration);

    TextView pace = new TextView(requireContext());
    String paceText = formatStepTarget(entry.step());
    if (!paceText.isEmpty()) {
      pace.setText("  •  " + paceText);
      pace.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorAccent));
      pace.setTextSize(12);
      meta.addView(pace);
    }

    TextView arrow = new TextView(requireContext());
    arrow.setText("›");
    arrow.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorAccent));
    arrow.setTextSize(26);
    card.addView(arrow);
    return card;
  }

  private String previewIntensity(org.runnerup.workout.Step step) {
    switch (step.getIntensity()) {
      case WARMUP: return "Aquecimento";
      case ACTIVE: return "Esforço";
      case RECOVERY: return "Recuperação";
      case COOLDOWN: return "Desaquecimento";
      case REPEAT: return "Repetições";
      case RESTING: return "Descanso";
      default: return "Bloco";
    }
  }

  private String formatStepDuration(org.runnerup.workout.Step step) {
    Dimension type = step.getDurationType();
    if (type == null) return "Livre";
    return formatter.format(Formatter.Format.TXT_SHORT, type, step.getDurationValue());
  }

  private String formatStepTarget(org.runnerup.workout.Step step) {
    Dimension type = step.getTargetType();
    if (type != Dimension.PACE || step.getTargetValue() == null) return "";
    String min = formatter.format(Formatter.Format.TXT_SHORT, Dimension.PACE, step.getTargetValue().minValue);
    String max = formatter.format(Formatter.Format.TXT_SHORT, Dimension.PACE, step.getTargetValue().maxValue);
    return "Pace " + min + "–" + max + " min/km";
  }

  private String buildAdvancedDistanceSummary(List<StepListEntry> entries) {
    double meters = 0;
    for (StepListEntry entry : entries) {
      if (entry.step().getDurationType() == Dimension.DISTANCE) {
        meters += entry.step().getDurationValue();
      }
    }
    if (meters <= 0) return "Distância configurada por tempo ou livre";
    return formatter.format(Formatter.Format.TXT_SHORT, Dimension.DISTANCE, meters);
  }

  private int dp(int value) {
    return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
  }

  private void loadAdvanced(String name) {
    Context ctx = requireActivity().getApplicationContext();
    if (name == null) {
      SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
      name = pref.getString(getResources().getString(R.string.pref_advanced_workout), "");
    }
    advancedWorkout = null;
    if ("".contentEquals(name)) {
      renderAdvancedPreview();
      return;
    }
    try {
      advancedWorkout = WorkoutSerializer.readFile(ctx, name);
      advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
      advancedWorkoutStepsAdapter.notifyDataSetChanged();
      renderAdvancedPreview();
    } catch (Exception ex) {
      ex.printStackTrace();
      new AlertDialog.Builder(requireActivity())
          .setTitle(getString(org.runnerup.common.R.string.Failed_to_load_workout))
          .setMessage(ex.toString())
          .setPositiveButton(org.runnerup.common.R.string.OK, (dialog, which) -> dialog.dismiss())
          .show();
    }
  }

  @Override
  public int getSatellitesAvailable() {
    return mGpsStatus.getSatellitesAvailable();
  }

  @Override
  public int getSatellitesFixed() {
    return mGpsStatus.getSatellitesFixed();
  }

  final class WorkoutStepsAdapter extends BaseAdapter {

    List<StepListEntry> steps = new ArrayList<>();

    @Override
    public int getCount() {
      return steps.size();
    }

    @Override
    public Object getItem(int position) {
      return steps.get(position);
    }

    @Override
    public long getItemId(int position) {
      return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      StepListEntry entry = steps.get(position);
      StepButton button =
          (convertView instanceof StepButton)
              ? (StepButton) convertView
              : new StepButton(requireContext(), null);
      button.setStep(entry.step());

      float pxToDp = getResources().getDisplayMetrics().density;
      button.setPadding((int) (entry.level() * 8 * pxToDp + 0.5f), 0, 0, 0);
      button.setOnChangedListener(onWorkoutChanged);
      return button;
    }
  }

  private final Runnable onWorkoutChanged =
      () -> {
        String name = advancedWorkoutSpinner.getValue().toString();
        if (advancedWorkout != null) {
          Context ctx = requireActivity().getApplicationContext();
          try {
            WorkoutSerializer.writeFile(ctx, name, advancedWorkout);
          } catch (Exception ex) {
            new AlertDialog.Builder(requireContext())
                .setTitle(org.runnerup.common.R.string.Failed_to_load_workout)
                .setMessage(ex.toString())
                .setPositiveButton(
                    org.runnerup.common.R.string.OK, (dialog, which) -> dialog.dismiss())
                .show();
          }
        }
      };

  private final OnSetValueListener onSetTimeValidator =
      new OnSetValueListener() {

        @Override
        public String preSetValue(String newValue) throws IllegalArgumentException {

          if (WorkoutBuilder.validateSeconds(newValue)) return newValue;

          throw new IllegalArgumentException("Unable to parse time value: " + newValue);
        }

        @Override
        public int preSetValue(int newValue) throws IllegalArgumentException {
          return newValue;
        }
      };

  private final ValueModel.ChangeListener<TrackerState> trackerStateListener =
      new ValueModel.ChangeListener<>() {
        @Override
        public void onValueChanged(
            ValueModel<TrackerState> instance, TrackerState oldValue, TrackerState newValue) {
          onTick();

          if (coachStartPending
              && newValue == TrackerState.CONNECTED
              && !runActivityPending) {
            coachStartPending = false;
            startWorkout();
          }
        }
      };
}
