/*
 * Pace Coach full backup and restore.
 *
 * Version 2 backups include a manifest with per-file size and SHA-256 checksums.
 * Version 1 backups remain readable for backwards compatibility.
 */
package org.runnerup.util;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.runnerup.common.util.Constants.DB;
import org.runnerup.db.DBHelper;
import org.runnerup.tracker.Tracker;
import org.runnerup.workout.WorkoutSerializer;

public final class PaceCoachBackupManager {
  private static final String TAG = "PaceCoachBackup";
  public static final String MIME_TYPE = "application/zip";
  public static final String FILE_EXTENSION = ".pacecoachbackup";
  private static final String MANIFEST = "pacecoach-manifest.json";
  private static final String DATABASE_ENTRY = "database/runnerup.db";
  private static final String WORKOUTS_PREFIX = "workouts/";
  private static final String FILES_PREFIX = "files/";
  private static final String PREFS_PREFIX = "shared_prefs/";
  private static final int FORMAT_VERSION = 2;
  private static final int BUFFER_SIZE = 32 * 1024;
  private static final int MAX_ENTRIES = 20000;
  private static final long MAX_ARCHIVE_BYTES = 512L * 1024L * 1024L;
  private static final long MAX_ENTRY_BYTES = 512L * 1024L * 1024L;
  private static final long MAX_TOTAL_UNCOMPRESSED_BYTES = 1024L * 1024L * 1024L;
  private static final int MAX_MANIFEST_BYTES = 8 * 1024 * 1024;

  private PaceCoachBackupManager() {}

  public static String suggestedFileName() {
    String stamp =
        new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
            .format(new Date(System.currentTimeMillis()));
    return "PaceCoach_Backup_" + stamp + FILE_EXTENSION;
  }

  /** Exports only the SQLite database from a consistent snapshot. */
  public static synchronized void exportDatabaseOnly(Context context, Uri destination)
      throws Exception {
    if (destination == null) throw new IOException("Destino da exportação não informado");
    if (!Tracker.prepareForDatabaseMaintenance()) {
      throw new IOException(
          "Finalize a corrida e aguarde o rastreador terminar a transição antes da exportação.");
    }

    Context app = context.getApplicationContext();
    File staging = null;
    try {
      staging = createStagingDirectory(app, "pacecoach_database_export_");
      File snapshot = new File(staging, "runnerup.db");
      DBHelper.createConsistentBackupSnapshot(app, snapshot);
      if (snapshot.length() > MAX_ENTRY_BYTES) {
        throw new IOException("O banco de dados excede o tamanho máximo de exportação");
      }
      validateDatabase(snapshot);
      try (InputStream in = new BufferedInputStream(new FileInputStream(snapshot), BUFFER_SIZE)) {
        OutputStream raw = app.getContentResolver().openOutputStream(destination, "w");
        if (raw == null) throw new IOException("Não foi possível abrir o destino da exportação");
        try (OutputStream out = new BufferedOutputStream(raw, BUFFER_SIZE)) {
          copy(in, out);
          out.flush();
        }
      }
    } finally {
      if (staging != null) deleteRecursively(staging);
      try {
        Tracker.reopenDatabaseAfterMaintenance();
      } catch (Exception reopenFailure) {
        Log.e(TAG, "Could not reattach Tracker after database export", reopenFailure);
      }
    }
  }

  /**
   * Imports a raw SQLite database only after validating it, then replaces the current database
   * with a rollback snapshot available until the new database passes integrity checks.
   */
  public static synchronized void importDatabaseOnly(Context context, Uri source) throws Exception {
    if (source == null) throw new IOException("Arquivo de banco não informado");
    if (Tracker.isWorkoutActive()) {
      throw new IOException("Finalize ou encerre a corrida antes de importar um banco de dados.");
    }

    Context app = context.getApplicationContext();
    File staging = createStagingDirectory(app, "pacecoach_database_import_");
    boolean trackerPrepared = false;
    boolean databaseMaintenanceStarted = false;
    boolean replacementStarted = false;
    File rollbackDatabase = new File(staging, "rollback/runnerup.db");

    try {
      File importedDatabase = new File(staging, "imported/runnerup.db");
      ensureDirectory(importedDatabase.getParentFile());
      try (InputStream raw = app.getContentResolver().openInputStream(source)) {
        if (raw == null) throw new IOException("Não foi possível abrir o banco selecionado");
        try (InputStream in = new BufferedInputStream(raw, BUFFER_SIZE);
            OutputStream out = new BufferedOutputStream(new FileOutputStream(importedDatabase), BUFFER_SIZE)) {
          copyLimited(in, out, MAX_ENTRY_BYTES, null);
        }
      }
      validateDatabase(importedDatabase);

      if (!Tracker.prepareForDatabaseMaintenance()) {
        throw new IOException(
            "Não é possível importar durante uma corrida ativa/pausada ou durante uma transição do rastreador.");
      }
      trackerPrepared = true;

      File currentDatabase = new File(DBHelper.getDbPath(app));
      ensureDirectory(rollbackDatabase.getParentFile());
      if (currentDatabase.isFile()) {
        DBHelper.createConsistentBackupSnapshot(app, rollbackDatabase);
      }

      DBHelper.closeForMaintenance();
      databaseMaintenanceStarted = true;
      replacementStarted = true;
      deleteDatabaseSidecars(currentDatabase);
      replaceFileAtomically(importedDatabase, currentDatabase);
      validateDatabase(currentDatabase);
      Log.i(TAG, "Database-only import completed; restart the app to reload cached data.");
    } catch (Exception failure) {
      if (replacementStarted && databaseMaintenanceStarted) {
        try {
          File currentDatabase = new File(DBHelper.getDbPath(app));
          if (rollbackDatabase.isFile()) {
            deleteDatabaseSidecars(currentDatabase);
            replaceFileAtomically(rollbackDatabase, currentDatabase);
            validateDatabase(currentDatabase);
          } else if (currentDatabase.exists() && !currentDatabase.delete()) {
            throw new IOException("Não foi possível remover o banco parcialmente importado");
          }
        } catch (Exception rollbackFailure) {
          failure.addSuppressed(rollbackFailure);
          Log.e(TAG, "Database import failed and rollback could not fully complete", rollbackFailure);
        }
      }
      throw failure;
    } finally {
      if (databaseMaintenanceStarted) DBHelper.endMaintenance();
      if (trackerPrepared) {
        try {
          Tracker.reopenDatabaseAfterMaintenance();
        } catch (Exception reopenFailure) {
          Log.e(TAG, "Could not reattach Tracker after database import", reopenFailure);
        }
      }
      deleteRecursively(staging);
    }
  }

  /** Creates a complete backup from a stable local snapshot. */
  public static synchronized void exportBackup(Context context, Uri destination) throws Exception {
    if (destination == null) throw new IOException("Destino do backup não informado");
    if (!Tracker.prepareForDatabaseMaintenance()) {
      throw new IOException(
          "Finalize a corrida e aguarde o rastreador terminar a transição antes do backup.");
    }

    Context app = context.getApplicationContext();
    File staging = null;
    try {
      staging = createStagingDirectory(app, "pacecoach_backup_export_");
      File payload = new File(staging, "payload");
      ensureDirectory(payload);

      File database = new File(payload, DATABASE_ENTRY);
      ensureDirectory(database.getParentFile());
      DBHelper.createConsistentBackupSnapshot(app, database);
      validateDatabase(database);

      copyDirectory(app.getDir(WorkoutSerializer.WORKOUTS_DIR, 0),
          new File(payload, "workouts"));
      copyDirectory(app.getFilesDir(), new File(payload, "files"));
      copyDirectory(new File(app.getApplicationInfo().dataDir, "shared_prefs"),
          new File(payload, "shared_prefs"));

      List<File> payloadFiles = collectFiles(payload);
      if (payloadFiles.size() + 1 > MAX_ENTRIES) {
        throw new IOException("O backup contém arquivos demais");
      }

      JSONArray fileManifest = new JSONArray();
      long totalBytes = 0L;
      for (File file : payloadFiles) {
        String relativePath = relativePath(payload, file);
        long size = file.length();
        totalBytes += size;
        if (size > MAX_ENTRY_BYTES || totalBytes > MAX_TOTAL_UNCOMPRESSED_BYTES) {
          throw new IOException("O backup excede o limite de tamanho permitido");
        }
        JSONObject metadata = new JSONObject();
        metadata.put("path", relativePath);
        metadata.put("size", size);
        metadata.put("sha256", sha256(file));
        fileManifest.put(metadata);
      }

      JSONObject manifest = new JSONObject();
      manifest.put("format", "PaceCoachBackup");
      manifest.put("version", FORMAT_VERSION);
      manifest.put("createdAt", System.currentTimeMillis());
      manifest.put("package", app.getPackageName());
      manifest.put("database", DATABASE_ENTRY);
      manifest.put("databaseSchemaVersion", DBHelper.DATABASE_VERSION);
      manifest.put("entryCount", payloadFiles.size());
      manifest.put("entries", fileManifest);
      manifest.put("includesWorkouts", true);
      manifest.put("includesFiles", true);
      manifest.put("includesPreferences", true);

      File archive = new File(staging, "backup.zip");
      try (OutputStream raw = new FileOutputStream(archive);
          BufferedOutputStream buffered = new BufferedOutputStream(raw, BUFFER_SIZE);
          ZipOutputStream zip = new ZipOutputStream(buffered)) {
        writeBytes(zip, MANIFEST, manifest.toString(2).getBytes(StandardCharsets.UTF_8));
        for (File file : payloadFiles) {
          addFile(zip, file, relativePath(payload, file));
        }
      }

      if (archive.length() > MAX_ARCHIVE_BYTES) {
        throw new IOException("O arquivo de backup excede o limite permitido");
      }
      try (InputStream in = new BufferedInputStream(new FileInputStream(archive), BUFFER_SIZE)) {
        OutputStream raw = app.getContentResolver().openOutputStream(destination, "w");
        if (raw == null) throw new IOException("Não foi possível abrir o destino do backup");
        try (BufferedOutputStream out = new BufferedOutputStream(raw, BUFFER_SIZE)) {
          copy(in, out);
          out.flush();
        }
      }
    } finally {
      if (staging != null) deleteRecursively(staging);
      try {
        Tracker.reopenDatabaseAfterMaintenance();
      } catch (Exception reopenFailure) {
        Log.e(TAG, "Could not reattach Tracker after backup export", reopenFailure);
      }
    }
  }

  /**
   * Restores a full backup using staged validation and a rollback snapshot. No live workout may
   * be running or paused while the database and app-owned directories are replaced.
   */
  public static synchronized void importBackup(Context context, Uri source) throws Exception {
    if (source == null) throw new IOException("Arquivo de backup não informado");
    if (Tracker.isWorkoutActive()) {
      throw new IOException("Finalize ou encerre a corrida antes de restaurar um backup.");
    }

    Context app = context.getApplicationContext();
    File staging = createStagingDirectory(app, "pacecoach_restore_");
    boolean trackerPrepared = false;
    boolean databaseMaintenanceStarted = false;
    boolean stateReplacementStarted = false;
    File rollback = new File(staging, "rollback");

    try {
      File archive = new File(staging, "backup.zip");
      try (InputStream raw = app.getContentResolver().openInputStream(source)) {
        if (raw == null) throw new IOException("Não foi possível abrir o backup");
        try (InputStream in = new BufferedInputStream(raw, BUFFER_SIZE);
            OutputStream out = new BufferedOutputStream(new FileOutputStream(archive), BUFFER_SIZE)) {
          copyLimited(in, out, MAX_ARCHIVE_BYTES, null);
        }
      }

      JSONObject manifest = extractAndValidateArchive(archive, staging);
      validateManifestPayload(manifest, staging);

      File stagedDb = new File(staging, DATABASE_ENTRY);
      validateDatabase(stagedDb);
      ensureDirectory(new File(staging, "workouts"));
      ensureDirectory(new File(staging, "files"));
      ensureDirectory(new File(staging, "shared_prefs"));

      if (!Tracker.prepareForDatabaseMaintenance()) {
        throw new IOException(
          "Não é possível restaurar durante uma corrida ativa/pausada ou durante uma transição do rastreador.");
      }
      trackerPrepared = true;

      File currentDb = new File(DBHelper.getDbPath(app));
      File rollbackDatabase = new File(rollback, "database/runnerup.db");
      ensureDirectory(rollbackDatabase.getParentFile());
      if (currentDb.isFile()) {
        DBHelper.createConsistentBackupSnapshot(app, rollbackDatabase);
      }

      File currentWorkouts = app.getDir(WorkoutSerializer.WORKOUTS_DIR, 0);
      File currentFiles = app.getFilesDir();
      File currentPreferences = new File(app.getApplicationInfo().dataDir, "shared_prefs");
      snapshotDirectory(currentWorkouts, new File(rollback, "workouts"));
      snapshotDirectory(currentFiles, new File(rollback, "files"));
      snapshotDirectory(currentPreferences, new File(rollback, "shared_prefs"));

      DBHelper.closeForMaintenance();
      databaseMaintenanceStarted = true;
      stateReplacementStarted = true;

      deleteDatabaseSidecars(currentDb);
      replaceFileAtomically(stagedDb, currentDb);
      replaceDirectoryContents(new File(staging, "workouts"), currentWorkouts);
      replaceDirectoryContents(new File(staging, "files"), currentFiles);
      replaceDirectoryContents(new File(staging, "shared_prefs"), currentPreferences);
      validateDatabase(currentDb);

      Log.i(TAG, "Backup restored successfully. Restart the app to refresh in-memory preferences.");
    } catch (Exception failure) {
      if (stateReplacementStarted && databaseMaintenanceStarted) {
        try {
          rollbackCurrentState(app, rollback);
        } catch (Exception rollbackFailure) {
          failure.addSuppressed(rollbackFailure);
          Log.e(TAG, "Restore failed and rollback could not fully complete", rollbackFailure);
        }
      }
      throw failure;
    } finally {
      if (databaseMaintenanceStarted) {
        DBHelper.endMaintenance();
      }
      if (trackerPrepared) {
        try {
          Tracker.reopenDatabaseAfterMaintenance();
        } catch (Exception reopenFailure) {
          Log.e(TAG, "Could not reattach Tracker to the restored database", reopenFailure);
        }
      }
      deleteRecursively(staging);
    }
  }

  private static File createStagingDirectory(Context app, String prefix) throws IOException {
    File staging = new File(app.getCacheDir(), prefix + System.currentTimeMillis());
    if (!staging.mkdirs()) throw new IOException("Não foi possível criar a área temporária");
    return staging;
  }

  private static JSONObject extractAndValidateArchive(File archive, File staging)
      throws IOException {
    if (!archive.isFile() || archive.length() == 0 || archive.length() > MAX_ARCHIVE_BYTES) {
      throw new IOException("Arquivo de backup vazio ou acima do tamanho permitido");
    }

    Set<String> names = new HashSet<>();
    long[] totalExtracted = {0L};
    int entries = 0;
    try (ZipFile zip = new ZipFile(archive)) {
      java.util.Enumeration<? extends ZipEntry> enumeration = zip.entries();
      while (enumeration.hasMoreElements()) {
        ZipEntry entry = enumeration.nextElement();
        entries++;
        if (entries > MAX_ENTRIES) throw new IOException("O backup contém entradas demais");

        String name = entry.getName();
        validateEntryName(name, entry.isDirectory());
        if (!names.add(name)) throw new IOException("O backup contém caminhos duplicados: " + name);
        if (!isAllowedEntry(name)) {
          throw new IOException("O backup contém um caminho não permitido: " + name);
        }
        if (entry.isDirectory()) {
          File directory = resolveStagingTarget(staging, trimTrailingSlash(name));
          ensureDirectory(directory);
          continue;
        }

        long size = entry.getSize();
        if (size > MAX_ENTRY_BYTES) throw new IOException("Arquivo muito grande no backup: " + name);
        long limit = MANIFEST.equals(name) ? MAX_MANIFEST_BYTES : MAX_ENTRY_BYTES;
        File target = resolveStagingTarget(staging, name);
        ensureDirectory(target.getParentFile());
        try (InputStream in = new BufferedInputStream(zip.getInputStream(entry), BUFFER_SIZE);
            OutputStream out = new BufferedOutputStream(new FileOutputStream(target), BUFFER_SIZE)) {
          copyLimited(in, out, limit, totalExtracted);
        }
      }
    } catch (IOException ex) {
      throw ex;
    } catch (Exception ex) {
      throw new IOException("Não foi possível ler o arquivo de backup", ex);
    }

    File manifestFile = new File(staging, MANIFEST);
    File databaseFile = new File(staging, DATABASE_ENTRY);
    if (!manifestFile.isFile() || !databaseFile.isFile()) {
      throw new IOException("Este arquivo não é um backup completo do Pace Coach");
    }

    try (InputStream in = new BufferedInputStream(new FileInputStream(manifestFile));
        ByteArrayOutputStream out = new ByteArrayOutputStream()) {
      copyLimited(in, out, MAX_MANIFEST_BYTES, null);
      try {
        JSONObject manifest = new JSONObject(out.toString(StandardCharsets.UTF_8.name()));
        if (!"PaceCoachBackup".equals(manifest.optString("format"))) {
          throw new IOException("Formato de backup inválido");
        }
        int version = manifest.optInt("version", -1);
        if (version < 1 || version > FORMAT_VERSION) {
          throw new IOException("Versão de backup não suportada: " + version);
        }
        String databaseName = manifest.optString("database", DATABASE_ENTRY);
        if (!DATABASE_ENTRY.equals(databaseName)) {
          throw new IOException("O manifesto aponta para um banco de dados inválido");
        }
        return manifest;
      } catch (JSONException ex) {
        throw new IOException("Manifesto de backup inválido", ex);
      }
    }
  }

  private static void validateManifestPayload(JSONObject manifest, File staging) throws IOException {
    int version = manifest.optInt("version", 1);
    if (version < 2) return; // Version 1 backups did not include checksums.

    JSONArray entries = manifest.optJSONArray("entries");
    if (entries == null || entries.length() > MAX_ENTRIES
        || manifest.optInt("entryCount", -1) != entries.length()) {
      throw new IOException("Manifesto sem lista válida de arquivos");
    }

    Map<String, JSONObject> expected = new HashMap<>();
    for (int i = 0; i < entries.length(); i++) {
      JSONObject metadata = entries.optJSONObject(i);
      if (metadata == null) throw new IOException("Metadado de arquivo inválido no manifesto");
      String path = metadata.optString("path", "");
      validateEntryName(path, false);
      if (!isAllowedPayloadFile(path) || expected.put(path, metadata) != null) {
        throw new IOException("Caminho duplicado ou inválido no manifesto: " + path);
      }
    }

    List<File> actualFiles = collectPayloadFiles(staging);
    if (actualFiles.size() != expected.size()) {
      throw new IOException("O conteúdo do backup não corresponde ao manifesto");
    }
    for (File file : actualFiles) {
      String path = relativePath(staging, file);
      JSONObject metadata = expected.get(path);
      if (metadata == null) throw new IOException("Arquivo não declarado no manifesto: " + path);
      long expectedSize = metadata.optLong("size", -1L);
      String expectedHash = metadata.optString("sha256", "");
      if (expectedSize < 0 || file.length() != expectedSize) {
        throw new IOException("Tamanho inválido para o arquivo: " + path);
      }
      if (!expectedHash.matches("(?i)[0-9a-f]{64}") || !expectedHash.equalsIgnoreCase(sha256(file))) {
        throw new IOException("A verificação de integridade falhou para: " + path);
      }
    }
  }

  private static void validateDatabase(File dbFile) throws IOException {
    if (!dbFile.isFile() || dbFile.length() == 0) {
      throw new IOException("Backup sem banco de dados válido");
    }

    SQLiteDatabase db = null;
    try {
      db = SQLiteDatabase.openDatabase(
          dbFile.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
      try (Cursor integrity = db.rawQuery("PRAGMA integrity_check", null)) {
        if (!integrity.moveToFirst() || !"ok".equalsIgnoreCase(integrity.getString(0))) {
          throw new IOException("O banco de dados do backup está inconsistente");
        }
        do {
          if (!"ok".equalsIgnoreCase(integrity.getString(0))) {
            throw new IOException("O banco de dados do backup falhou na verificação de integridade");
          }
        } while (integrity.moveToNext());
      }

      requireTable(db, DB.ACTIVITY.TABLE);
      requireTable(db, DB.LOCATION.TABLE);
      requireTable(db, DB.LAP.TABLE);
      requireTable(db, DB.ACCOUNT.TABLE);

      try (Cursor versionCursor = db.rawQuery("PRAGMA user_version", null)) {
        if (versionCursor.moveToFirst() && versionCursor.getInt(0) > DBHelper.DATABASE_VERSION) {
          throw new IOException("O backup foi criado por uma versão mais nova do banco de dados");
        }
      }
    } catch (IOException ex) {
      throw ex;
    } catch (Exception ex) {
      throw new IOException("Não foi possível validar o banco do backup", ex);
    } finally {
      if (db != null && db.isOpen()) db.close();
    }
  }

  private static void requireTable(SQLiteDatabase db, String tableName) throws IOException {
    try (Cursor cursor =
        db.rawQuery(
            "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?",
            new String[] {tableName})) {
      if (!cursor.moveToFirst() || cursor.getInt(0) != 1) {
        throw new IOException("Banco incompatível: tabela obrigatória ausente (" + tableName + ")");
      }
    }
  }

  private static void rollbackCurrentState(Context app, File rollback) throws IOException {
    File currentDb = new File(DBHelper.getDbPath(app));
    File rollbackDb = new File(rollback, "database/runnerup.db");
    if (rollbackDb.isFile()) {
      deleteDatabaseSidecars(currentDb);
      replaceFileAtomically(rollbackDb, currentDb);
    } else if (currentDb.exists() && !currentDb.delete()) {
      throw new IOException("Não foi possível remover o banco parcialmente restaurado");
    }

    replaceDirectoryContents(new File(rollback, "workouts"),
        app.getDir(WorkoutSerializer.WORKOUTS_DIR, 0));
    replaceDirectoryContents(new File(rollback, "files"), app.getFilesDir());
    replaceDirectoryContents(new File(rollback, "shared_prefs"),
        new File(app.getApplicationInfo().dataDir, "shared_prefs"));
    if (rollbackDb.isFile()) validateDatabase(currentDb);
  }

  private static void snapshotDirectory(File source, File snapshot) throws IOException {
    deleteRecursively(snapshot);
    copyDirectory(source, snapshot);
  }

  private static void replaceDirectoryContents(File source, File destination) throws IOException {
    ensureDirectory(destination);
    clearDirectoryContents(destination);
    if (source.isDirectory()) copyDirectory(source, destination);
  }

  private static void replaceFileAtomically(File source, File destination) throws IOException {
    File parent = destination.getParentFile();
    ensureDirectory(parent);
    File temporary = new File(destination.getAbsolutePath() + ".restore_tmp");
    File previous = new File(destination.getAbsolutePath() + ".restore_previous");
    if (!deleteRecursively(temporary) || !deleteRecursively(previous)) {
      throw new IOException("Não foi possível limpar os arquivos temporários da restauração");
    }
    copyFile(source, temporary);

    boolean hadDestination = destination.exists();
    if (hadDestination && !destination.renameTo(previous)) {
      deleteRecursively(temporary);
      throw new IOException("Não foi possível preservar o banco anterior");
    }
    if (!temporary.renameTo(destination)) {
      if (hadDestination && !previous.renameTo(destination)) {
        throw new IOException("Falha ao instalar o banco e ao recuperar o banco anterior");
      }
      deleteRecursively(temporary);
      throw new IOException("Não foi possível instalar o banco restaurado");
    }
    if (!deleteRecursively(previous)) {
      Log.w(TAG, "O arquivo temporário anterior não pôde ser removido: " + previous);
    }
  }

  private static void deleteDatabaseSidecars(File database) throws IOException {
    String[] suffixes = {"-wal", "-shm", "-journal"};
    for (String suffix : suffixes) {
      File sidecar = new File(database.getAbsolutePath() + suffix);
      if (sidecar.exists() && !sidecar.delete() && sidecar.exists()) {
        throw new IOException("Não foi possível remover arquivo SQLite auxiliar: " + suffix);
      }
    }
  }

  static void validateEntryName(String name, boolean directory) throws IOException {
    if (name == null || name.isEmpty() || name.startsWith("/") || name.indexOf('\\') >= 0
        || name.indexOf(':') >= 0) {
      throw new IOException("Caminho inválido no backup");
    }
    String normalized = trimTrailingSlash(name);
    if (normalized.isEmpty()) throw new IOException("Caminho vazio no backup");
    String[] segments = normalized.split("/", -1);
    for (String segment : segments) {
      if (segment.isEmpty() || ".".equals(segment) || "..".equals(segment)) {
        throw new IOException("O backup contém caminho inseguro: " + name);
      }
    }
    if (directory && !name.endsWith("/")) {
      throw new IOException("Entrada de diretório malformada: " + name);
    }
  }

  static boolean isAllowedEntry(String name) {
    String path = trimTrailingSlash(name);
    return MANIFEST.equals(path) || DATABASE_ENTRY.equals(path)
        || path.startsWith(WORKOUTS_PREFIX) || path.startsWith(FILES_PREFIX)
        || path.startsWith(PREFS_PREFIX)
        || (name.endsWith("/") && ("workouts".equals(path) || "files".equals(path)
            || "shared_prefs".equals(path) || "database".equals(path)));
  }

  static boolean isAllowedPayloadFile(String name) {
    return DATABASE_ENTRY.equals(name) || name.startsWith(WORKOUTS_PREFIX)
        || name.startsWith(FILES_PREFIX) || name.startsWith(PREFS_PREFIX);
  }

  private static File resolveStagingTarget(File staging, String entryName) throws IOException {
    File target = new File(staging, entryName);
    String root = staging.getCanonicalPath() + File.separator;
    if (!target.getCanonicalPath().startsWith(root)) {
      throw new IOException("O backup tenta gravar fora da área temporária");
    }
    return target;
  }

  static String trimTrailingSlash(String name) {
    return name != null && name.endsWith("/") ? name.substring(0, name.length() - 1) : name;
  }

  private static void copyLimited(InputStream in, OutputStream out, long limit, long[] total)
      throws IOException {
    byte[] buffer = new byte[BUFFER_SIZE];
    long copied = 0L;
    int read;
    while ((read = in.read(buffer)) != -1) {
      copied += read;
      if (copied > limit) throw new IOException("O backup excede o limite de tamanho permitido");
      if (total != null) {
        total[0] += read;
        if (total[0] > MAX_TOTAL_UNCOMPRESSED_BYTES) {
          throw new IOException("O conteúdo descompactado excede o limite permitido");
        }
      }
      out.write(buffer, 0, read);
    }
  }

  private static void copyDirectory(File source, File destination) throws IOException {
    ensureDirectory(destination);
    if (source == null || !source.isDirectory()) return;
    File[] children = source.listFiles();
    if (children == null) throw new IOException("Não foi possível listar o diretório: " + source);
    for (File child : children) {
      File target = new File(destination, child.getName());
      if (child.isDirectory()) {
        copyDirectory(child, target);
      } else if (child.isFile()) {
        copyFile(child, target);
      }
    }
  }

  private static List<File> collectFiles(File root) throws IOException {
    List<File> result = new ArrayList<>();
    collectFilesRecursive(root, result);
    Collections.sort(result, (left, right) -> left.getAbsolutePath().compareTo(right.getAbsolutePath()));
    return result;
  }

  private static List<File> collectPayloadFiles(File staging) throws IOException {
    List<File> result = new ArrayList<>();
    for (String directory : new String[] {"database", "workouts", "files", "shared_prefs"}) {
      File root = new File(staging, directory);
      if (root.isDirectory()) collectFilesRecursive(root, result);
    }
    Collections.sort(result, (left, right) -> left.getAbsolutePath().compareTo(right.getAbsolutePath()));
    return result;
  }

  private static void collectFilesRecursive(File directory, List<File> result) throws IOException {
    File[] children = directory.listFiles();
    if (children == null) throw new IOException("Não foi possível listar o diretório: " + directory);
    for (File child : children) {
      if (child.isDirectory()) {
        collectFilesRecursive(child, result);
      } else if (child.isFile()) {
        result.add(child);
      }
    }
  }

  private static String relativePath(File root, File file) throws IOException {
    String rootPath = root.getCanonicalPath() + File.separator;
    String filePath = file.getCanonicalPath();
    if (!filePath.startsWith(rootPath)) throw new IOException("Arquivo fora do pacote de backup");
    return filePath.substring(rootPath.length()).replace(File.separatorChar, '/');
  }

  private static String sha256(File file) throws IOException {
    try {
      MessageDigest digest = MessageDigest.getInstance("SHA-256");
      try (InputStream in = new BufferedInputStream(new FileInputStream(file), BUFFER_SIZE)) {
        byte[] buffer = new byte[BUFFER_SIZE];
        int read;
        while ((read = in.read(buffer)) != -1) digest.update(buffer, 0, read);
      }
      StringBuilder result = new StringBuilder(64);
      for (byte value : digest.digest()) result.append(String.format(Locale.US, "%02x", value & 0xff));
      return result.toString();
    } catch (NoSuchAlgorithmException ex) {
      throw new IOException("SHA-256 não está disponível neste dispositivo", ex);
    }
  }

  private static void ensureDirectory(File directory) throws IOException {
    if (directory == null) throw new IOException("Diretório de destino inválido");
    if (!directory.isDirectory() && !directory.mkdirs() && !directory.isDirectory()) {
      throw new IOException("Não foi possível criar o diretório: " + directory);
    }
  }

  private static void clearDirectoryContents(File directory) throws IOException {
    ensureDirectory(directory);
    File[] children = directory.listFiles();
    if (children == null) throw new IOException("Não foi possível listar o diretório: " + directory);
    for (File child : children) {
      if (!deleteRecursively(child)) throw new IOException("Não foi possível remover: " + child);
    }
  }

  private static void addFile(ZipOutputStream zip, File file, String entryName) throws IOException {
    zip.putNextEntry(new ZipEntry(entryName));
    try (InputStream in = new BufferedInputStream(new FileInputStream(file), BUFFER_SIZE)) {
      copy(in, zip);
    }
    zip.closeEntry();
  }

  private static void writeBytes(ZipOutputStream zip, String entryName, byte[] data)
      throws IOException {
    zip.putNextEntry(new ZipEntry(entryName));
    zip.write(data);
    zip.closeEntry();
  }

  private static void copyFile(File from, File to) throws IOException {
    File parent = to.getParentFile();
    ensureDirectory(parent);
    try (InputStream in = new BufferedInputStream(new FileInputStream(from), BUFFER_SIZE);
        FileOutputStream fileOut = new FileOutputStream(to);
        OutputStream out = new BufferedOutputStream(fileOut, BUFFER_SIZE)) {
      copy(in, out);
      out.flush();
      fileOut.getFD().sync();
    }
  }

  private static void copy(InputStream in, OutputStream out) throws IOException {
    byte[] buffer = new byte[BUFFER_SIZE];
    int read;
    while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
  }

  private static boolean deleteRecursively(File file) {
    if (file == null || !file.exists()) return true;
    if (file.isDirectory()) {
      File[] children = file.listFiles();
      if (children == null) return false;
      for (File child : children) {
        if (!deleteRecursively(child)) return false;
      }
    }
    return file.delete() || !file.exists();
  }
}
