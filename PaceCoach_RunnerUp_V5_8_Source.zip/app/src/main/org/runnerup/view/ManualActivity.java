/*
 * Copyright (C) 2012 - 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.view;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Toast;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import java.text.SimpleDateFormat;
import java.util.Locale;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import org.runnerup.R;
import org.runnerup.common.util.Constants.DB;
import org.runnerup.db.DBHelper;
import org.runnerup.util.Formatter;
import org.runnerup.util.SafeParse;
import org.runnerup.util.ViewUtil;
import org.runnerup.widget.SpinnerInterface.OnSetValueListener;
import org.runnerup.widget.TitleSpinner;
import org.runnerup.workout.Sport;

public class ManualActivity extends AppCompatActivity {

  TitleSpinner manualSport = null;
  TitleSpinner manualDate = null;
  TitleSpinner manualTime = null;
  TitleSpinner manualDistance = null;
  TitleSpinner manualDuration = null;
  TitleSpinner manualPace = null;
  EditText manualNotes = null;
  TextView manualDateValue = null;
  TextView manualTimeValue = null;
  TextView manualDurationValue = null;
  TextView manualDistanceValue = null;
  TextView manualPaceValue = null;

  SQLiteDatabase mDB = null;

  Formatter formatter = null;

  /** Called when the activity is first created. */
  @Override
  public void onCreate(Bundle savedInstanceState) {
    EdgeToEdge.enable(this);
    Window window = getWindow();
    WindowCompat.getInsetsController(window, window.getDecorView())
        .setAppearanceLightStatusBars(false);
    super.onCreate(savedInstanceState);

    mDB = DBHelper.getWritableDatabase(this);
    formatter = new Formatter(this);

    setContentView(R.layout.manual);

    manualSport = findViewById(R.id.manual_sport);

    Button saveButton = findViewById(R.id.manual_save_button);
    saveButton.setOnClickListener(v -> saveEntry());
    findViewById(R.id.manual_back).setOnClickListener(v -> finish());
    manualDate = findViewById(R.id.manual_date);
    manualTime = findViewById(R.id.manual_time);
    manualDistance = findViewById(R.id.manual_distance);
    manualDistance.setOnSetValueListener(onSetManualDistance);
    manualDuration = findViewById(R.id.manual_duration);
    manualDuration.setOnSetValueListener(onSetManualDuration);
    manualPace = findViewById(R.id.manual_pace);
    manualNotes = findViewById(R.id.manual_notes);

    manualDateValue = findViewById(R.id.manual_date_value);
    manualTimeValue = findViewById(R.id.manual_time_value);
    manualDurationValue = findViewById(R.id.manual_duration_value);
    manualDistanceValue = findViewById(R.id.manual_distance_value);
    manualPaceValue = findViewById(R.id.manual_pace_value);

    ViewUtil.Insets(findViewById(R.id.tab_manual), true);

    manualSport.setArrayEntries(Sport.getStringArray(getResources()));
    // Pace Coach is a running-only app: manual activities are always saved as Running.
    manualSport.setValue(Sport.RUNNING.getDbValue());
    manualSport.setVisibility(View.GONE);

    // The visible cards are the approved Pace Coach UI; the existing TitleSpinner controls
    // remain hidden and are opened programmatically so the original picker/persistence logic is preserved.
    findViewById(R.id.manual_date_card).setOnClickListener(v -> openDatePicker());
    findViewById(R.id.manual_time_card).setOnClickListener(v -> openTimePicker());
    findViewById(R.id.manual_duration_card).setOnClickListener(v -> openPicker(manualDuration));
    findViewById(R.id.manual_distance_card).setOnClickListener(v -> openPicker(manualDistance));
    findViewById(R.id.manual_pace_card).setOnClickListener(v -> openPicker(manualPace));

    manualDate.setOnCloseDialogListener((spinner, ok) -> { if (ok) refreshManualDisplay(); });
    manualTime.setOnCloseDialogListener((spinner, ok) -> { if (ok) refreshManualDisplay(); });
    manualDuration.setOnCloseDialogListener((spinner, ok) -> { if (ok) refreshManualDisplay(); });
    manualDistance.setOnCloseDialogListener((spinner, ok) -> { if (ok) refreshManualDisplay(); });
    manualPace.setOnCloseDialogListener((spinner, ok) -> { if (ok) refreshManualDisplay(); });

    manualNotes.addTextChangedListener(new TextWatcher() {
      @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
      @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
        TextView counter = findViewById(R.id.manual_notes_counter);
        counter.setText(s.length() + "/300");
      }
      @Override public void afterTextChanged(Editable s) {}
    });

    refreshManualDisplay();
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.manual_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == R.id.menu_save) {
      saveEntry();
      return true;
    }
    return super.onOptionsItemSelected(item);
  }

  @Override
  public void onDestroy() {
    DBHelper.closeDB(mDB);
    super.onDestroy();
  }

  private void openDatePicker() {
    Calendar c = Calendar.getInstance();
    try {
      Date d = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
          .parse(manualDate.getValue().toString());
      if (d != null) c.setTime(d);
    } catch (Exception ignored) {
    }
    DatePickerDialog dialog = new DatePickerDialog(
        this,
        (view, year, month, dayOfMonth) -> {
          Calendar selected = Calendar.getInstance();
          selected.set(year, month, dayOfMonth);
          manualDate.setValue(new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
              .format(selected.getTime()));
          refreshManualDisplay();
        },
        c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
    dialog.show();
  }

  private void openTimePicker() {
    Calendar c = Calendar.getInstance();
    try {
      Date d = new SimpleDateFormat("HH:mm", Locale.getDefault())
          .parse(manualTime.getValue().toString());
      if (d != null) {
        Calendar parsed = Calendar.getInstance();
        parsed.setTime(d);
        c.set(Calendar.HOUR_OF_DAY, parsed.get(Calendar.HOUR_OF_DAY));
        c.set(Calendar.MINUTE, parsed.get(Calendar.MINUTE));
      }
    } catch (Exception ignored) {
    }
    TimePickerDialog dialog = new TimePickerDialog(
        this,
        (view, hourOfDay, minute) -> {
          Calendar selected = Calendar.getInstance();
          selected.set(Calendar.HOUR_OF_DAY, hourOfDay);
          selected.set(Calendar.MINUTE, minute);
          manualTime.setValue(new SimpleDateFormat("HH:mm", Locale.getDefault())
              .format(selected.getTime()));
          refreshManualDisplay();
        },
        c.get(Calendar.HOUR_OF_DAY),
        c.get(Calendar.MINUTE),
        true);
    dialog.show();
  }

  private void openPicker(TitleSpinner spinner) {
    View layout = spinner.findViewById(org.runnerup.R.id.title_spinner_layout);
    if (layout != null) layout.performClick();
  }

  private void refreshManualDisplay() {
    if (manualDateValue == null) return;
    manualDateValue.setText(manualDate.getValue());
    manualTimeValue.setText(manualTime.getValue());

    long durationSeconds = manualDuration.getValueInt();
    manualDurationValue.setText(formatManualDuration(durationSeconds));

    double distanceMeters = manualDistance.getValueInt();
    manualDistanceValue.setText(String.format(Locale.getDefault(), "%.1f", distanceMeters / 1000.0)
        .replace('.', ','));

    long paceSeconds = manualPace.getValueInt();
    manualPaceValue.setText(paceSeconds > 0 ? formatManualPace(paceSeconds) : "--:--");
  }

  private String formatManualDuration(long totalSeconds) {
    if (totalSeconds <= 0) return "00:00";
    long hours = totalSeconds / 3600;
    long minutes = (totalSeconds % 3600) / 60;
    long seconds = totalSeconds % 60;
    if (hours > 0) {
      return String.format(Locale.getDefault(), "%d:%02d:%02d", hours, minutes, seconds);
    }
    return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
  }

  private String formatManualPace(long totalSeconds) {
    long minutes = totalSeconds / 60;
    long seconds = totalSeconds % 60;
    return String.format(Locale.getDefault(), "%d:%02d", minutes, seconds);
  }

  @Override
  public void onActivityResult(
      int requestCode, int resultCode, Intent data) { // todo is this log needed?
    super.onActivityResult(requestCode, resultCode, data);
    if (data != null) {
      if (data.getStringExtra("url") != null)
        Log.d(
            getClass().getName(), "data.getStringExtra(\"url\") => " + data.getStringExtra("url"));
      if (data.getStringExtra("ex") != null)
        Log.d(getClass().getName(), "data.getStringExtra(\"ex\") => " + data.getStringExtra("ex"));
      if (data.getStringExtra("obj") != null)
        Log.d(
            getClass().getName(), "data.getStringExtra(\"obj\") => " + data.getStringExtra("obj"));
    }
  }

  void setManualPace(String distance, String duration) {
    Log.d(getClass().getName(), "distance: >" + distance + "< duration: >" + duration + "<");
    double dist = SafeParse.parseDouble(distance, 0); // convert to meters
    long seconds = SafeParse.parseSeconds(duration, 0);
    if (seconds == 0 || dist <= 0) {
      manualPace.setValue("--:--");
      manualPace.setVisibility(View.VISIBLE);
      return;
    }
    manualPace.setValue(
        formatter.formatPace(Formatter.Format.TXT_SHORT, seconds / dist));
    manualPace.setVisibility(View.VISIBLE);
    refreshManualDisplay();
  }

  final OnSetValueListener onSetManualDistance =
      new OnSetValueListener() {

        @Override
        public String preSetValue(String newValue) throws IllegalArgumentException {
          setManualPace(newValue, manualDuration.getValue().toString());
          return newValue;
        }

        @Override
        public int preSetValue(int newValue) throws IllegalArgumentException {
          return newValue;
        }
      };

  final OnSetValueListener onSetManualDuration =
      new OnSetValueListener() {

        @Override
        public String preSetValue(String newValue) throws IllegalArgumentException {
          setManualPace(manualDistance.getValue().toString(), newValue);
          return newValue;
        }

        @Override
        public int preSetValue(int newValue) throws IllegalArgumentException {
          return newValue;
        }
      };

  final void saveEntry() {
    ContentValues save = new ContentValues();
    int sport = manualSport.getValueInt();
    CharSequence date = manualDate.getValue();
    CharSequence time = manualTime.getValue();
    CharSequence distance = manualDistance.getValue();
    CharSequence duration = manualDuration.getValue();
    String notes = manualNotes.getText().toString().trim();
    long start_time = 0;

    if (notes.length() > 0) {
      save.put(DB.ACTIVITY.COMMENT, notes);
    }
    double dist = 0;
    if (distance.length() > 0) {
      dist = SafeParse.parseDouble(distance.toString(), 0.0); // convert to
      // meters
      save.put(DB.ACTIVITY.DISTANCE, dist);
    }
    long secs = 0;
    if (duration.length() > 0) {
      secs = SafeParse.parseSeconds(duration.toString(), 0);
      save.put(DB.ACTIVITY.TIME, secs);
    }
    if (date.length() > 0 && time.length() > 0) { // todo deal with parse exceptions
      DateFormat dfd = android.text.format.DateFormat.getDateFormat(ManualActivity.this);
      DateFormat dft = android.text.format.DateFormat.getTimeFormat(ManualActivity.this);
      try {
        Date d = dfd.parse(date.toString());
        Date t = dft.parse(time.toString());
        Calendar cd = Calendar.getInstance();
        Calendar ct = Calendar.getInstance();
        cd.setTime(d);
        ct.setTime(t);
        // We parsed day and time separately and now need to copy the time from t to d
        // while making sure that the time zone of d keeps being used, thus we copy the
        // individual time fields. It is not unusual that t uses a different time zone
        // than d, e.g., during daylight savings time.
        cd.set(Calendar.HOUR_OF_DAY, ct.get(Calendar.HOUR_OF_DAY));
        cd.set(Calendar.MINUTE, ct.get(Calendar.MINUTE));
        cd.set(Calendar.SECOND, ct.get(Calendar.SECOND));
        cd.set(Calendar.MILLISECOND, ct.get(Calendar.MILLISECOND));
        start_time = cd.getTime().getTime() / 1000;
      } catch (ParseException e) {
      }
    }
    save.put(DB.ACTIVITY.START_TIME, start_time);

    save.put(DB.ACTIVITY.SPORT, sport);
    long id = mDB.insert(DB.ACTIVITY.TABLE, null, save);
    if (id < 0) {
      Toast.makeText(this, "Não foi possível salvar o treino", Toast.LENGTH_SHORT).show();
      return;
    }

    ContentValues lap = new ContentValues();
    lap.put(DB.LAP.ACTIVITY, id);
    lap.put(DB.LAP.LAP, 0);
    lap.put(DB.LAP.INTENSITY, DB.INTENSITY.ACTIVE);
    lap.put(DB.LAP.TIME, secs);
    lap.put(DB.LAP.DISTANCE, dist);
    mDB.insert(DB.LAP.TABLE, null, lap);

    Toast.makeText(this, "Treino salvo", Toast.LENGTH_SHORT).show();
    finish();
  }
}
