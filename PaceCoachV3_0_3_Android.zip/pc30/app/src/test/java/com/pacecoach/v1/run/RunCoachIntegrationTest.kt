package com.pacecoach.v1.run

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RunCoachIntegrationTest {
    @Test
    fun livePaceIsEvaluatedAgainstActiveStep() {
        val workout = WorkoutBuilder("Teste")
            .addDistanceStep(
                StepKind.RUN, 1000f, 300, "1 km"
            ).build()

        val integration = RunCoachIntegration()
        integration.startWorkout(workout, 1000L, 0f)

        val decision = integration.update(
            nowMs = 5000L,
            distanceM = 100f,
            paceSeconds = 302,
            gpsAccuracyMeters = 5f,
            targetMarginSeconds = 5
        )

        assertEquals(CoachState.ON_TARGET, decision.state.state)
        assertTrue(decision.message != null)
    }
}
