package com.pacecoach.v1.run

data class WorkoutExecutionSnapshot(
    val activeStep: ActiveStep?,
    val elapsedStepSeconds: Long,
    val distanceStepMeters: Float,
    val finished: Boolean
)

class WorkoutExecutor(
    private val engine: WorkoutEngine
) {
    private var started = false
    private var lastAnnouncedStep: Pair<Int, Int>? = null

    fun start(nowMs: Long, distanceM: Float): WorkoutExecutionSnapshot {
        engine.start(nowMs, distanceM)
        started = true
        lastAnnouncedStep = null
        return snapshot(nowMs, distanceM)
    }

    fun update(nowMs: Long, distanceM: Float): WorkoutExecutionSnapshot {
        if (!started) return snapshot(nowMs, distanceM)
        engine.update(nowMs, distanceM)
        return snapshot(nowMs, distanceM)
    }

    fun currentStep(): ActiveStep? = engine.current()

    fun isFinished(): Boolean = engine.isFinished()

    fun shouldAnnounceCurrentStep(): Boolean {
        val current = engine.current() ?: return false
        val key = current.index to current.repetition
        if (key == lastAnnouncedStep) return false
        lastAnnouncedStep = key
        return true
    }

    private fun snapshot(nowMs: Long, distanceM: Float): WorkoutExecutionSnapshot {
        val current = engine.current()
        return WorkoutExecutionSnapshot(
            activeStep = current,
            elapsedStepSeconds = engine.elapsedStepSeconds(nowMs),
            distanceStepMeters = engine.distanceStepMeters(distanceM),
            finished = engine.isFinished()
        )
    }
}
