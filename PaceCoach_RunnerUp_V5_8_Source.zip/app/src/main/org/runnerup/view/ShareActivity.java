package org.runnerup.view;

import android.content.ContentValues;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.TextView;
import android.view.ViewGroup;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import org.runnerup.R;
import org.runnerup.common.util.Constants;
import org.runnerup.content.ShareImageProvider;
import org.runnerup.db.DBHelper;
import org.runnerup.workout.Intensity;

/** Pace Coach visual activity sharing. Generates deterministic PNG cards from stored activity data. */
public class ShareActivity extends AppCompatActivity implements Constants {
  private static final int CARD_W = 1080;
  private static final int CARD_H = 1350;
  private static final int TEMPLATE_SUMMARY = 0;
  private static final int TEMPLATE_MAP = 1;
  private static final int TEMPLATE_STATS = 2;
  private static final int TEMPLATE_PACE = 3;
  private static final int TEMPLATE_BLOCKS = 4;
  private static final int TEMPLATE_MINIMAL = 5;
  private static final int TEMPLATE_SPLITS = 6;
  private static final int TEMPLATE_METRICS = 7;
  private static final int TEMPLATE_HERO = 8;
  private static final int TEMPLATE_OVERLAY = 9;
  private static final int TEMPLATE_ELEVATION = 10;
  private static final int FORMAT_PORTRAIT = 0;
  private static final int FORMAT_STORY = 1;
  private static final int FORMAT_SQUARE = 2;

  private long activityId;
  private ActivityData data;
  private ImageView preview;
  private int template = TEMPLATE_SUMMARY;
  private Bitmap rendered;
  private int format = FORMAT_PORTRAIT;
  private boolean transparentBackground = false;
  private ArrayList<ContentValues> blocks = new ArrayList<>();
  private final ArrayList<Button> templateButtons = new ArrayList<>();
  private final ArrayList<Button> formatButtons = new ArrayList<>();

  @Override protected void onCreate(Bundle state) {
    super.onCreate(state);
    setContentView(R.layout.share_activity);
    activityId = getIntent().getLongExtra("activity_id", -1L);
    if (activityId < 0) { finish(); return; }
    data = loadActivity(activityId);
    if (data == null) { Toast.makeText(this, "Atividade não encontrada", Toast.LENGTH_SHORT).show(); finish(); return; }
    preview = findViewById(R.id.share_preview);
    buildTemplateButtons();
    buildFormatButtons();
    findViewById(R.id.share_image_button).setOnClickListener(v -> shareImage());
    findViewById(R.id.share_copy_button).setOnClickListener(v -> copyImage());
    android.widget.CheckBox transparent = findViewById(R.id.share_transparent_background);
    transparent.setChecked(false);
    transparent.setOnCheckedChangeListener((button, checked) -> { transparentBackground = checked; render(); });
    render();
  }

  private void buildTemplateButtons() {
    LinearLayout container = findViewById(R.id.share_templates);
    container.removeAllViews(); templateButtons.clear();
    String[] labels = {"Resumo", "Mapa", "Estatísticas", "Ritmo", "Blocos", "Minimalista", "Parciais", "Métricas", "Distância", "Foto", "Elevação"};
    // A two-row grid exposes every approved design immediately; no hidden models behind a swipe.
    int columns = 3;
    int rowCount = (labels.length + columns - 1) / columns;
    for (int rowIndex = 0; rowIndex < rowCount; rowIndex++) {
      LinearLayout row = new LinearLayout(this);
      row.setOrientation(LinearLayout.HORIZONTAL);
      row.setGravity(Gravity.CENTER_VERTICAL);
      LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, dp(42));
      if (rowIndex > 0) rowLp.topMargin = dp(4);
      container.addView(row, rowLp);
      for (int col = 0; col < columns; col++) {
        final int choice = rowIndex * columns + col;
        if (choice >= labels.length) {
          View spacer = new View(this);
          row.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));
          continue;
        }
        Button b = new Button(this);
        b.setText(labels[choice]); b.setAllCaps(false); b.setTextSize(12.5f);
        b.setTypeface(Typeface.DEFAULT_BOLD); b.setMinHeight(0); b.setMinimumHeight(0);
        b.setMinWidth(0); b.setPadding(dp(2), 0, dp(2), 0);
        b.setIncludeFontPadding(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        lp.setMargins(dp(3), 0, dp(3), 0); row.addView(b, lp); templateButtons.add(b);
        b.setOnClickListener(v -> { template = choice; updateSelectorStyles(); render(); });
      }
    }
    updateSelectorStyles();
  }

  private void buildFormatButtons() {
    LinearLayout row = findViewById(R.id.share_formats);
    row.removeAllViews(); formatButtons.clear();
    String[] labels = {"4:5", "9:16", "1:1"};
    for (int i = 0; i < labels.length; i++) {
      final int choice = i;
      Button b = new Button(this);
      b.setText(labels[i]); b.setAllCaps(false); b.setTextSize(12); b.setTypeface(Typeface.DEFAULT_BOLD);
      b.setMinHeight(0); b.setMinimumHeight(0); b.setPadding(0, 0, 0, 0);
      LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), 1f);
      lp.setMargins(dp(2), 0, dp(2), 0); row.addView(b, lp); formatButtons.add(b);
      b.setOnClickListener(v -> { format = choice; updateSelectorStyles(); render(); });
    }
    updateSelectorStyles();
  }

  private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

  private void updateSelectorStyles() {
    for (int i = 0; i < templateButtons.size(); i++) styleSelector(templateButtons.get(i), i == template);
    for (int i = 0; i < formatButtons.size(); i++) styleSelector(formatButtons.get(i), i == format);
  }

  private void styleSelector(Button button, boolean selected) {
    GradientDrawable bg = new GradientDrawable();
    bg.setColor(selected ? Color.rgb(22,119,210) : Color.rgb(18,38,52));
    bg.setCornerRadius(dp(8));
    if (selected) bg.setStroke(dp(2), Color.rgb(83,177,255));
    else bg.setStroke(dp(1), Color.rgb(39,62,78));
    button.setBackground(bg);
    button.setTextColor(selected ? Color.WHITE : Color.rgb(184,202,215));
    if (android.os.Build.VERSION.SDK_INT >= 21) button.setElevation(selected ? dp(2) : 0);
  }

  private void render() {
    int w = CARD_W;
    int h = format == FORMAT_STORY ? 1920 : (format == FORMAT_SQUARE ? 1080 : CARD_H);
    if (template == TEMPLATE_BLOCKS || template == TEMPLATE_SPLITS) h = Math.max(h, 500 + blocks.size() * 80);
    rendered = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
    Canvas c = new Canvas(rendered);
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
    if (transparentBackground) c.drawColor(Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR);
    else c.drawColor(Color.rgb(4, 15, 23));
    // Fit the same design system to each social format instead of cropping metrics.
    if (format == FORMAT_STORY) {
      // Enlarge the approved 4:5 composition into the 9:16 canvas. This avoids
      // the narrow card floating in a large empty story while preserving margins.
      c.translate(0f, (h - CARD_H * 1.2f) / 2f);
      c.scale(1.2f, 1.2f);
    } else if (format == FORMAT_SQUARE) {
      // Scale to a square-safe composition without cropping the side metrics.
      c.translate(135f, 0f);
      c.scale(0.8f, 0.8f);
    }
    if (template != TEMPLATE_HERO) drawHeader(c, p);
    if (template == TEMPLATE_MAP) drawMap(c, p);
    if (template == TEMPLATE_STATS) drawStats(c, p);
    if (template == TEMPLATE_PACE) drawPace(c, p);
    if (template == TEMPLATE_BLOCKS) drawBlocks(c, p);
    if (template == TEMPLATE_MINIMAL) drawMinimal(c, p);
    if (template == TEMPLATE_SUMMARY) drawSummary(c, p);
    if (template == TEMPLATE_SPLITS) drawSplits(c, p);
    if (template == TEMPLATE_METRICS) drawMetricTiles(c, p);
    if (template == TEMPLATE_HERO) drawHero(c, p);
    if (template == TEMPLATE_OVERLAY) drawOverlay(c, p);
    if (template == TEMPLATE_ELEVATION) drawElevation(c, p);
    preview.setImageBitmap(rendered);
  }

  private void drawHeader(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(56); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("Pace", 70, 105, p);
    p.setColor(Color.rgb(80,170,255)); c.drawText(" Coach", 205, 105, p);
    p.setTypeface(Typeface.DEFAULT); p.setColor(Color.rgb(190,205,215)); p.setTextSize(25);
    String title = data.name == null ? "Corrida" : data.name;
    if (p.measureText(title) > 900) {
      while (title.length() > 4 && p.measureText(title + "…") > 900) title = title.substring(0, title.length()-1);
      title += "…";
    }
    c.drawText(title, 70, 148, p);
    p.setColor(Color.rgb(30,90,120)); c.drawRoundRect(60, 180, 1020, 187, 4, 4, p);
  }

  private void drawBlocks(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(44); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText(data.name, 70, 270, p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(25); p.setColor(Color.LTGRAY);
    c.drawText(blocks.size() + " blocos  •  " + formatDistance(data.distance) + "  •  " + formatTime(data.time), 70, 315, p);
    int y = 375;
    int target = 0, inside = 0, slower = 0, faster = 0;
    int footerHeight = 150;
    int available = Math.max(1, rendered.getHeight() - y - footerHeight);
    int rowHeight = blocks.isEmpty() ? 80 : Math.max(42, Math.min(100, available / blocks.size()));
    float rowTextSize = rowHeight < 58 ? 17 : (rowHeight < 75 ? 21 : 25);
    for (int i=0; i<blocks.size(); i++) {
      ContentValues b = blocks.get(i);
      double d = getDouble(b, DB.LAP.DISTANCE);
      long t = getLong(b, DB.LAP.TIME);
      double actual = t > 0 && d > 0 ? t * 1000.0 / d : 0;
      double min = getTarget(b, DB.LAP.PLANNED_PACE_MIN, DB.LAP.PLANNED_PACE);
      double max = getTarget(b, DB.LAP.PLANNED_PACE_MAX, DB.LAP.PLANNED_PACE);
      boolean has = min > 0 && max > 0;
      if (has) { target++; if (actual >= min && actual <= max) inside++; else if (actual < min) faster++; else if (actual > max) slower++; }
      int intensity = getInt(b, DB.LAP.INTENSITY, 1);
      int color = blockColor(intensity);
      p.setColor(color); c.drawRoundRect(new RectF(70,y-27,91,y-6), 5,5,p);
      p.setColor(Color.WHITE); p.setTextSize(rowTextSize); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText((i+1)+"  "+blockTitle(intensity), 108,y-5,p);
      p.setTypeface(Typeface.DEFAULT); p.setTextSize(Math.max(14,rowTextSize-4)); p.setColor(Color.LTGRAY);
      String info = formatDistance(d) + "  •  " + formatTime(t) + "  •  " + (actual>0?formatPace(actual):"—");
      c.drawText(info, 108, y+Math.max(15,rowHeight*0.25f), p);
      if (has && rowHeight >= 55) c.drawText("Alvo " + formatRange(min,max), 650, y+Math.max(15,rowHeight*0.25f), p);
      y += rowHeight;
    }
    if (target > 0) {
      int success = inside + faster;
      p.setColor(Color.WHITE); p.setTextSize(30); p.setTypeface(Typeface.DEFAULT_BOLD);
      c.drawText("Desempenho",70,rendered.getHeight()-120,p);
      p.setTypeface(Typeface.DEFAULT); p.setTextSize(25); p.setColor(Color.rgb(90,220,120));
      c.drawText(Math.round(success*100f/target)+"% dentro ou mais rápido que o alvo",70,rendered.getHeight()-78,p);
      p.setColor(Color.LTGRAY); c.drawText(inside+" dentro  •  "+slower+" mais lento  •  "+faster+" mais rápido",70,rendered.getHeight()-42,p);
    }
  }

  private void drawMinimal(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(34); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("PACE COACH",70,220,p);
    p.setColor(Color.rgb(80,170,255)); p.setTextSize(110); c.drawText(formatDistance(data.distance),70,430,p);
    p.setColor(Color.WHITE); p.setTextSize(58); c.drawText(formatPace(data.distance,data.time),70,535,p);
    p.setColor(Color.LTGRAY); p.setTextSize(30); c.drawText(formatTime(data.time),70,595,p);
    p.setColor(Color.rgb(80,170,255)); c.drawRoundRect(70,690,1010,700,5,5,p);
    p.setColor(Color.LTGRAY); p.setTextSize(26); c.drawText(data.name,70,780,p);
  }

  private void drawSplits(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(46); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("Parciais", 70, 270, p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(25); p.setColor(Color.LTGRAY);
    c.drawText("Segmentos registrados nesta atividade", 70, 315, p);
    if (blocks.isEmpty()) { c.drawText("Sem parciais registradas", 70, 410, p); return; }
    int top=380, bottom=rendered.getHeight()-120;
    int rh=Math.max(36,Math.min(88,(bottom-top)/blocks.size()));
    for(int i=0;i<blocks.size();i++) {
      ContentValues b=blocks.get(i); int y=top+i*rh;
      double d=getDouble(b,DB.LAP.DISTANCE); long t=getLong(b,DB.LAP.TIME);
      double pace=d>0&&t>0?t*1000.0/d:0;
      p.setColor(Color.rgb(25,43,55)); c.drawRoundRect(new RectF(65,y,1015,y+rh-5),12,12,p);
      p.setColor(Color.WHITE); p.setTextSize(rh<55?20:27); p.setTypeface(Typeface.DEFAULT_BOLD);
      c.drawText(String.valueOf(i+1),85,y+rh*0.62f,p);
      p.setTypeface(Typeface.DEFAULT); c.drawText(formatDistance(d),155,y+rh*0.62f,p);
      c.drawText(formatTime(t),470,y+rh*0.62f,p);
      c.drawText(pace>0?formatPace(pace):"—",740,y+rh*0.62f,p);
    }
  }

  private void drawMetricTiles(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(46); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(data.name,70,270,p);
    tile(c,p,"DISTÂNCIA",formatDistance(data.distance),70,350,490,570,Color.rgb(35,155,240));
    tile(c,p,"TEMPO TOTAL",formatTime(data.time),535,350,1010,570,Color.rgb(0,190,220));
    tile(c,p,"RITMO MÉDIO",formatPace(data.distance,data.time),70,610,490,830,Color.rgb(30,210,130));
    tile(c,p,"ELEVAÇÃO",data.elevation>0?formatNumber(data.elevation)+" m":"—",535,610,1010,830,Color.rgb(100,190,230));
    tile(c,p,"FC MÉDIA",data.avgHr>0?data.avgHr+" bpm":"—",70,870,490,1090,Color.rgb(245,90,105));
    tile(c,p,"CADÊNCIA",data.avgCadence>0?formatNumber(data.avgCadence)+" ppm":"—",535,870,1010,1090,Color.rgb(170,120,255));
  }

  private void tile(Canvas c,Paint p,String label,String value,float l,float t,float r,float b,int accent) {
    p.setColor(Color.argb(220,13,27,38)); c.drawRoundRect(new RectF(l,t,r,b),28,28,p);
    p.setColor(accent); c.drawRoundRect(l,t,l+9,b,5,5,p);
    p.setColor(Color.LTGRAY); p.setTextSize(23); p.setTypeface(Typeface.DEFAULT); c.drawText(label,l+28,t+52,p);
    p.setColor(Color.WHITE); p.setTextSize(48); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(value,l+28,t+125,p);
  }

  private void drawHero(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(38); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("Pace Coach",70,130,p);
    p.setTextSize(54); c.drawText(data.name,70,245,p);
    p.setColor(Color.rgb(255,145,30)); c.drawRoundRect(70,285,1010,300,7,7,p);
    p.setColor(Color.WHITE); p.setTextSize(160); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(formatDistance(data.distance).replace(" km", ""),70,600,p);
    p.setTextSize(52); c.drawText(data.distance>=1000?"KM":"METROS",80,665,p);
    stat(c,p,"TEMPO",formatTime(data.time),70,870);
    stat(c,p,"RITMO MÉDIO",formatPace(data.distance,data.time),560,870);
    stat(c,p,"ELEVAÇÃO",data.elevation>0?formatNumber(data.elevation)+" m":"—",70,1110);
    p.setColor(Color.LTGRAY); p.setTextSize(22); c.drawText(new SimpleDateFormat("dd MMM yyyy · HH:mm",Locale.getDefault()).format(new Date(data.startTime*1000L)),560,1175,p);
  }

  private void drawElevation(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(46); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("Perfil de elevação",70,270,p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(26); p.setColor(Color.LTGRAY);
    c.drawText(data.elevation>0?"Ganho acumulado: "+formatNumber(data.elevation)+" m":"Dados de altitude indisponíveis",70,325,p);
    float x=75,y=410,w=930,h=590;
    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.rgb(35,75,90));
    for(int i=0;i<5;i++) c.drawLine(x,y+i*h/4f,x+w,y+i*h/4f,p);
    double min=Double.MAX_VALUE,max=-Double.MAX_VALUE; int count=0;
    for(double[] pt:data.route) if(pt.length>2&&!Double.isNaN(pt[2])) {min=Math.min(min,pt[2]);max=Math.max(max,pt[2]);count++;}
    if(count>=2&&max>min) {
      Path path=new Path(); boolean first=true; int valid=0;
      for(int i=0;i<data.route.size();i++){double[] pt=data.route.get(i);if(pt.length<=2||Double.isNaN(pt[2]))continue;float xx=x+(w*valid/(float)Math.max(1,count-1));float yy=y+h-(float)((pt[2]-min)/(max-min))*h;if(first){path.moveTo(xx,yy);first=false;}else path.lineTo(xx,yy);valid++;}
      p.setColor(Color.rgb(40,220,135));p.setStrokeWidth(8);c.drawPath(path,p);
      p.setStyle(Paint.Style.FILL);p.setColor(Color.LTGRAY);p.setTextSize(23);c.drawText(formatNumber(min)+" m",75,1035,p);c.drawText(formatNumber(max)+" m",75,385,p);
    } else {
      p.setStyle(Paint.Style.FILL);p.setColor(Color.LTGRAY);p.setTextSize(28);c.drawText("Esta atividade não possui pontos de altitude suficientes.",70,570,p);
    }
    stat(c,p,"DISTÂNCIA",formatDistance(data.distance),70,1130);
    stat(c,p,"TEMPO",formatTime(data.time),560,1130);
  }

  private void drawOverlay(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(48); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(data.name,70,260,p);
    p.setColor(Color.rgb(80,170,255)); p.setStrokeWidth(8); c.drawRoundRect(70,290,1010,300,5,5,p);
    stat(c,p,"DISTÂNCIA",formatDistance(data.distance),70,430);
    stat(c,p,"TEMPO",formatTime(data.time),560,430);
    stat(c,p,"RITMO MÉDIO",formatPace(data.distance,data.time),70,690);
    stat(c,p,"ELEVAÇÃO",data.elevation>0?formatNumber(data.elevation)+" m":"—",560,690);
    p.setColor(Color.WHITE); p.setTextSize(26); p.setTypeface(Typeface.DEFAULT); c.drawText("Pace Coach",70,1120,p);
  }

  private int blockColor(int intensity) {
    Intensity type = Intensity.valueOf(intensity);
    if (type == Intensity.WARMUP) return Color.rgb(255,138,0);
    if (type == Intensity.RECOVERY) return Color.rgb(176,108,255);
    if (type == Intensity.RESTING) return Color.rgb(0,199,217);
    if (type == Intensity.COOLDOWN) return Color.rgb(92,107,192);
    return Color.rgb(45,155,240);
  }

  private String blockTitle(int intensity) {
    Intensity type = Intensity.valueOf(intensity);
    if (type == Intensity.WARMUP) return "Aquecimento";
    if (type == Intensity.RECOVERY) return "Recuperação";
    if (type == Intensity.RESTING) return "Descanso Off";
    if (type == Intensity.COOLDOWN) return "Desaquecimento";
    return "Intervalo";
  }

  private double getTarget(ContentValues b, String preferred, String legacy) {
    double v = b.containsKey(preferred) ? b.getAsDouble(preferred) * 1000.0 : 0;
    if (v > 0) return v;
    return b.containsKey(legacy) ? b.getAsDouble(legacy) * 1000.0 : 0;
  }

  private double getDouble(ContentValues b, String key) { return b.containsKey(key) ? b.getAsDouble(key) : 0; }
  private long getLong(ContentValues b, String key) { return b.containsKey(key) ? b.getAsLong(key) : 0; }
  private int getInt(ContentValues b, String key, int fallback) { return b.containsKey(key) ? b.getAsInteger(key) : fallback; }
  private String formatPace(double sec) { if (sec<=0) return "—"; long s=Math.round(sec); return String.format(Locale.getDefault(),"%d:%02d/km",s/60,s%60); }
  private String formatRange(double min,double max) { return Math.abs(min-max)<0.5 ? formatPace(min) : formatPace(min).replace("/km","")+" – "+formatPace(max).replace("/km",""); }

  private void drawSummary(Canvas c, Paint p) {
    // Editorial sports card inspired by the approved Pace Coach references.
    // All values are read from the selected activity; unavailable values stay hidden or use a dash.
    p.setColor(Color.rgb(8, 23, 34));
    c.drawRoundRect(new RectF(32, 205, 1048, 1310), 30, 30, p);

    // Brand header and accent rail.
    p.setColor(Color.rgb(22, 119, 210));
    c.drawRoundRect(new RectF(62, 238, 1018, 246), 4, 4, p);
    p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(38); p.setColor(Color.WHITE);
    c.drawText("PACE", 70, 305, p);
    p.setColor(Color.rgb(80, 170, 255)); c.drawText(" COACH", 183, 305, p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(23); p.setColor(Color.rgb(163, 184, 198));
    String title = data.name == null ? "Corrida" : data.name;
    while (title.length() > 4 && p.measureText(title) > 880) title = title.substring(0, title.length() - 1);
    c.drawText(title, 72, 347, p);

    // Hero distance panel.
    p.setColor(Color.rgb(13, 36, 52)); c.drawRoundRect(new RectF(62, 385, 1018, 615), 24, 24, p);
    p.setColor(Color.rgb(80, 170, 255)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(104);
    String distance = formatDistance(data.distance);
    while (distance.length() > 4 && p.measureText(distance) > 830) { p.setTextSize(p.getTextSize() - 4); }
    c.drawText(distance, 92, 500, p);
    p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(22); p.setColor(Color.rgb(175, 197, 211));
    c.drawText("DISTÂNCIA TOTAL", 96, 548, p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(22); p.setColor(Color.rgb(218, 229, 237));
    c.drawText(new SimpleDateFormat("dd MMM yyyy · HH:mm", Locale.getDefault()).format(new Date(data.startTime * 1000L)), 96, 585, p);

    // Primary metrics, balanced two-column grid.
    tile(c,p,"TEMPO TOTAL",formatTime(data.time),62,645,510,815,Color.rgb(0,190,220));
    tile(c,p,"RITMO MÉDIO",formatPace(data.distance,data.time),535,645,1018,815,Color.rgb(30,210,130));
    tile(c,p,"FC MÉDIA",data.avgHr>0?data.avgHr+" bpm":"—",62,840,510,1010,Color.rgb(245,90,105));
    tile(c,p,"CADÊNCIA",data.avgCadence>0?formatNumber(data.avgCadence)+" ppm":"—",535,840,1018,1010,Color.rgb(170,120,255));

    // Footer band mirrors the compact metrics strip in the approved designs.
    p.setColor(Color.rgb(18, 42, 58)); c.drawRoundRect(new RectF(62, 1035, 1018, 1210), 22, 22, p);
    float[] centers = {220, 540, 860};
    String[] labels = {"ELEVAÇÃO", "DURAÇÃO", "DISTÂNCIA"};
    String[] values = {data.elevation>0?formatNumber(data.elevation)+" m":"—", formatTime(data.time), formatDistance(data.distance)};
    int[] accents = {Color.rgb(50,190,230), Color.rgb(0,190,220), Color.rgb(80,170,255)};
    for (int i=0;i<centers.length;i++) {
      p.setColor(accents[i]); c.drawCircle(centers[i]-64, 1084, 7, p);
      p.setColor(Color.rgb(155,178,193)); p.setTextSize(19); p.setTypeface(Typeface.DEFAULT_BOLD);
      c.drawText(labels[i], centers[i]-44, 1091, p);
      p.setColor(Color.WHITE); p.setTextSize(28); p.setTypeface(Typeface.DEFAULT_BOLD);
      c.drawText(values[i], centers[i]-64, 1150, p);
    }
    p.setColor(Color.rgb(80,170,255)); p.setTextSize(20); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("SEU TREINO. SEU RITMO.", 70, 1260, p);
  }

  private void drawStats(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(44); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("Estatísticas", 70, 270, p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(24); p.setColor(Color.rgb(153,174,188));
    c.drawText("Os números desta atividade", 70, 315, p);
    tile(c,p,"DISTÂNCIA",formatDistance(data.distance),70,365,510,535,Color.rgb(35,155,240));
    tile(c,p,"TEMPO TOTAL",formatTime(data.time),535,365,1010,535,Color.rgb(0,190,220));
    tile(c,p,"RITMO MÉDIO",formatPace(data.distance,data.time),70,560,510,730,Color.rgb(30,210,130));
    tile(c,p,"FC MÉDIA",data.avgHr>0?data.avgHr+" bpm":"—",535,560,1010,730,Color.rgb(245,90,105));
    tile(c,p,"CADÊNCIA",data.avgCadence>0?formatNumber(data.avgCadence)+" ppm":"—",70,755,510,925,Color.rgb(170,120,255));
    tile(c,p,"ELEVAÇÃO",data.elevation>0?formatNumber(data.elevation)+" m":"—",535,755,1010,925,Color.rgb(100,190,230));
    p.setColor(Color.rgb(18,39,53)); c.drawRoundRect(new RectF(70,960,1010,1190),22,22,p);
    p.setColor(Color.rgb(80,170,255)); p.setTextSize(25); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("ATIVIDADE REGISTRADA",100,1010,p);
    p.setColor(Color.rgb(190,205,215)); p.setTextSize(23); p.setTypeface(Typeface.DEFAULT);
    c.drawText(data.name,100,1055,p);
    c.drawText(new SimpleDateFormat("dd MMM yyyy · HH:mm",Locale.getDefault()).format(new Date(data.startTime*1000L)),100,1100,p);
    p.setColor(Color.rgb(80,170,255)); c.drawRoundRect(100,1140,980,1148,4,4,p);
  }

  private void drawPace(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(46); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("Ritmo da corrida", 70, 270, p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(26); p.setColor(Color.LTGRAY); c.drawText("Ritmo médio",70,360,p);
    p.setColor(Color.WHITE); p.setTextSize(88); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(formatPace(data.distance,data.time),70,470,p);
    drawSimplePaceGraph(c,p,70,570,940,430);
  }

  private void drawMap(Canvas c, Paint p) {
    // Stylized dark map canvas with street grid and the actual recorded GPS trace.
    RectF map = new RectF(45, 215, 1035, 900);
    p.setColor(Color.rgb(11, 43, 48)); c.drawRoundRect(map, 28, 28, p);
    c.save(); c.clipRect(map);
    p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND);
    for (int i=0;i<12;i++) {
      float x=map.left-100+i*105;
      p.setColor(i%3==0?Color.rgb(48,82,83):Color.rgb(31,66,70)); p.setStrokeWidth(i%3==0?10:4);
      Path road=new Path(); road.moveTo(x,map.top-20); road.cubicTo(x+60,400,x-65,650,x+35,map.bottom+30); c.drawPath(road,p);
    }
    for (int i=0;i<10;i++) {
      float y=map.top-20+i*78;
      p.setColor(i%3==0?Color.rgb(49,82,80):Color.rgb(30,64,68)); p.setStrokeWidth(i%3==0?8:3);
      Path road=new Path(); road.moveTo(map.left-20,y); road.cubicTo(330,y+45,690,y-55,map.right+20,y+25); c.drawPath(road,p);
    }
    p.setStyle(Paint.Style.FILL);
    if (data.route.size() >= 2) {
      double minLat=Double.MAX_VALUE,maxLat=-Double.MAX_VALUE,minLon=Double.MAX_VALUE,maxLon=-Double.MAX_VALUE;
      for (double[] pt:data.route){minLat=Math.min(minLat,pt[0]);maxLat=Math.max(maxLat,pt[0]);minLon=Math.min(minLon,pt[1]);maxLon=Math.max(maxLon,pt[1]);}
      double latSpan=Math.max(0.00001,maxLat-minLat), lonSpan=Math.max(0.00001,maxLon-minLon);
      ArrayList<float[]> points = new ArrayList<>();
      for(double[] pt:data.route){float x=(float)(map.left+55+(pt[1]-minLon)/lonSpan*(map.width()-110));float y=(float)(map.bottom-55-(pt[0]-minLat)/latSpan*(map.height()-110));points.add(new float[]{x,y});}
      p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(18); p.setColor(Color.argb(90,0,0,0));
      Path shadow=new Path(); shadow.moveTo(points.get(0)[0],points.get(0)[1]); for(int i=1;i<points.size();i++)shadow.lineTo(points.get(i)[0],points.get(i)[1]); c.drawPath(shadow,p);
      for(int i=1;i<points.size();i++){
        float[] a=points.get(i-1),b=points.get(i); float progress=i/(float)(points.size()-1);
        p.setColor(progress<0.34f?Color.rgb(45,220,105):(progress<0.68f?Color.rgb(255,205,40):Color.rgb(255,95,65)));
        p.setStrokeWidth(11); p.setStrokeCap(Paint.Cap.ROUND); c.drawLine(a[0],a[1],b[0],b[1],p);
      }
      p.setStyle(Paint.Style.FILL); float[] first=points.get(0),last=points.get(points.size()-1);
      p.setColor(Color.WHITE); c.drawCircle(first[0],first[1],19,p); p.setColor(Color.rgb(40,210,105)); c.drawCircle(first[0],first[1],13,p);
      p.setColor(Color.WHITE); c.drawCircle(last[0],last[1],19,p); p.setColor(Color.rgb(15,28,38)); c.drawCircle(last[0],last[1],13,p);
    } else {
      p.setColor(Color.rgb(180,200,205)); p.setTextSize(29); p.setTypeface(Typeface.DEFAULT_BOLD);
      c.drawText("Percurso GPS indisponível",180,560,p);
      p.setTextSize(22); p.setTypeface(Typeface.DEFAULT); c.drawText("O restante das estatísticas continua disponível",180,600,p);
    }
    c.restore(); p.setStyle(Paint.Style.FILL);
    p.setColor(Color.WHITE); p.setTextSize(40); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("Percurso da corrida",70,970,p);
    tile(c,p,"DISTÂNCIA",formatDistance(data.distance),70,1010,510,1175,Color.rgb(35,155,240));
    tile(c,p,"TEMPO TOTAL",formatTime(data.time),535,1010,1010,1175,Color.rgb(0,190,220));
    p.setColor(Color.rgb(80,170,255)); p.setTextSize(25); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("RITMO MÉDIO  "+formatPace(data.distance,data.time),70,1230,p);
  }

  private void drawSimplePaceGraph(Canvas c, Paint p, float x,float y,float w,float h) {
    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(Color.rgb(30,80,105));
    for(int i=0;i<5;i++){float yy=y+i*h/4f;c.drawLine(x,yy,x+w,yy,p);}
    if(data.route.size()>=2){
      ArrayList<double[]> samples=new ArrayList<>(); double total=0; double[] prev=data.route.get(0);
      for(int i=1;i<data.route.size();i++){double[] cur=data.route.get(i);double meters=distanceMeters(prev[0],prev[1],cur[0],cur[1]);double seconds=(cur[3]-prev[3])/1000d;if(meters>=2&&seconds>0&&seconds<120){total+=meters;samples.add(new double[]{total,seconds*1000d/meters});}prev=cur;}
      if(!samples.isEmpty()&&total>0){p.setColor(Color.rgb(60,190,255));p.setStrokeWidth(8);Path path=new Path();boolean first=true;for(double[] sample:samples){float xx=x+(float)(sample[0]/Math.max(total,data.distance)*w);double pace=Math.max(240,Math.min(600,sample[1]));float yy=y+(float)((pace-240)/360d*h);if(first){path.moveTo(xx,yy);first=false;}else path.lineTo(xx,yy);}c.drawPath(path,p);}
    }
    p.setStyle(Paint.Style.FILL);
  }

  private double distanceMeters(double lat1,double lon1,double lat2,double lon2) {
    double dLat=Math.toRadians(lat2-lat1),dLon=Math.toRadians(lon2-lon1);
    double a=Math.sin(dLat/2)*Math.sin(dLat/2)+Math.cos(Math.toRadians(lat1))*Math.cos(Math.toRadians(lat2))*Math.sin(dLon/2)*Math.sin(dLon/2);
    return 6371000d*2*Math.atan2(Math.sqrt(a),Math.sqrt(Math.max(0,1-a)));
  }

  private void stat(Canvas c, Paint p, String label, String value, float x, float y) {
    p.setColor(Color.rgb(150,160,165)); p.setTextSize(24); p.setTypeface(Typeface.DEFAULT); c.drawText(label.toUpperCase(Locale.getDefault()),x,y,p);
    p.setColor(Color.WHITE); p.setTextSize(56); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(value,x,y+65,p);
  }

  private ActivityData loadActivity(long id) {
    SQLiteDatabase db=DBHelper.getReadableDatabase(this);
    ActivityData d=new ActivityData();
    Cursor c=db.query(DB.ACTIVITY.TABLE,new String[]{DB.ACTIVITY.NAME,DB.ACTIVITY.START_TIME,DB.ACTIVITY.DISTANCE,DB.ACTIVITY.TIME,DB.ACTIVITY.AVG_HR,DB.ACTIVITY.AVG_CADENCE},"_id=?",new String[]{String.valueOf(id)},null,null,null);
    if(!c.moveToFirst()){c.close();return null;}
    d.name=safe(c.getString(0),"Corrida"); d.startTime=c.getLong(1); d.distance=c.isNull(2)?0:c.getDouble(2); d.time=c.isNull(3)?0:c.getLong(3); d.avgHr=c.isNull(4)?0:c.getInt(4); d.avgCadence=c.isNull(5)?0:c.getDouble(5); c.close();
    Cursor l=db.query(DB.LOCATION.TABLE,new String[]{DB.LOCATION.LATITUDE,DB.LOCATION.LONGITUDE,DB.LOCATION.TYPE,DB.LOCATION.ALTITUDE,DB.LOCATION.TIME},DB.LOCATION.ACTIVITY+"=? AND ("+DB.LOCATION.TYPE+"=? OR "+DB.LOCATION.TYPE+"=?)",new String[]{String.valueOf(id),String.valueOf(DB.LOCATION.TYPE_GPS),String.valueOf(DB.LOCATION.TYPE_START)},null,null,DB.LOCATION.TIME+" ASC");
    double previousAltitude=Double.NaN;
    while(l.moveToNext()) { double altitude=l.isNull(3)?Double.NaN:l.getDouble(3); d.route.add(new double[]{l.getDouble(0),l.getDouble(1),altitude,l.getLong(4)}); if(!Double.isNaN(altitude)){if(!Double.isNaN(previousAltitude)&&altitude>previousAltitude&&altitude-previousAltitude<20)d.elevation+=altitude-previousAltitude;previousAltitude=altitude;} } l.close();
    Cursor bcur=db.query(DB.LAP.TABLE,new String[]{DB.LAP.INTENSITY,DB.LAP.TIME,DB.LAP.DISTANCE,DB.LAP.PLANNED_PACE,DB.LAP.PLANNED_PACE_MIN,DB.LAP.PLANNED_PACE_MAX},DB.LAP.ACTIVITY+"=?",new String[]{String.valueOf(id)},null,null,"_id ASC");
    while(bcur.moveToNext()) { ContentValues b=new ContentValues(); b.put(DB.LAP.INTENSITY,bcur.getInt(0)); b.put(DB.LAP.TIME,bcur.getLong(1)); b.put(DB.LAP.DISTANCE,bcur.getDouble(2)); if(!bcur.isNull(3)) b.put(DB.LAP.PLANNED_PACE,bcur.getDouble(3)); if(!bcur.isNull(4)) b.put(DB.LAP.PLANNED_PACE_MIN,bcur.getDouble(4)); if(!bcur.isNull(5)) b.put(DB.LAP.PLANNED_PACE_MAX,bcur.getDouble(5)); blocks.add(b); } bcur.close();
    return d;
  }

  private void shareImage() {
    try {
      File dir=new File(getCacheDir(),"share_cards"); if(!dir.exists()&&!dir.mkdirs()) throw new Exception("cache");
      String name="pacecoach_"+activityId+"_"+template+".png"; File file=new File(dir,name);
      try(FileOutputStream out=new FileOutputStream(file)){rendered.compress(Bitmap.CompressFormat.PNG,100,out);}
      Uri uri=Uri.parse("content://"+ShareImageProvider.AUTHORITY+"/"+name);
      Intent send=new Intent(Intent.ACTION_SEND); send.setType("image/png"); send.putExtra(Intent.EXTRA_STREAM,uri); send.setClipData(ClipData.newUri(getContentResolver(), data.name, uri)); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
      startActivity(Intent.createChooser(send,"Compartilhar atividade"));
    } catch(Exception e){Toast.makeText(this,"Não foi possível gerar a imagem",Toast.LENGTH_SHORT).show();}
  }

  private void copyImage() {
    try {
      File dir=new File(getCacheDir(),"share_cards"); if(!dir.exists()&&!dir.mkdirs()) throw new Exception("cache");
      String name="pacecoach_"+activityId+"_"+template+"_clipboard.png"; File file=new File(dir,name);
      try(FileOutputStream out=new FileOutputStream(file)){rendered.compress(Bitmap.CompressFormat.PNG,100,out);}
      Uri uri=Uri.parse("content://"+ShareImageProvider.AUTHORITY+"/"+name);
      ClipData clip=ClipData.newUri(getContentResolver(),data.name,uri);
      ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
      if(clipboard==null) throw new Exception("clipboard");
      clipboard.setPrimaryClip(clip);
      Toast.makeText(this,"Imagem copiada. Cole em um app compatível com imagens.",Toast.LENGTH_LONG).show();
    } catch(Exception e){Toast.makeText(this,"Não foi possível copiar a imagem",Toast.LENGTH_SHORT).show();}
  }

  private static String safe(String s,String fallback){return s==null||s.trim().isEmpty()?fallback:s.trim();}
  private static String formatDistance(double meters){return meters>=1000?String.format(Locale.getDefault(),"%.2f km",meters/1000d):String.format(Locale.getDefault(),"%.0f m",meters);}
  private static String formatTime(long seconds){long sec=Math.max(0,seconds);if(sec>=3600)return String.format(Locale.getDefault(),"%02d:%02d:%02d",sec/3600,(sec%3600)/60,sec%60);return String.format(Locale.getDefault(),"%02d:%02d",sec/60,sec%60);}
  private static String formatPace(double meters,long ms){if(meters<=0||ms<=0)return "—";double secPerKm=(ms)/(meters/1000d);int s=(int)Math.round(secPerKm);return String.format(Locale.getDefault(),"%d:%02d/km",s/60,s%60);}
  private static String formatNumber(double v){return String.format(Locale.getDefault(),"%.0f",v);}

  private static class ActivityData {String name;long startTime,time;double distance,avgCadence,elevation;int avgHr;ArrayList<double[]> route=new ArrayList<>();}
}
