# Pace Coach V1.5 — Anúncios inteligentes

Objetivo:
reduzir a quantidade de falas repetidas sem perder informação útil.

A política considera:
- mudança de estado (dentro / mais lento / mais rápido);
- mudança mínima de pace (3 s/km por padrão);
- intervalo mínimo entre falas.

A versão mantém os intervalos por tempo/distância e deixa a base pronta
para o coach decidir quando um aviso realmente acrescenta informação.

A integração final da política com todas as rotas do serviço deve ser validada
na compilação Android e no teste físico.
