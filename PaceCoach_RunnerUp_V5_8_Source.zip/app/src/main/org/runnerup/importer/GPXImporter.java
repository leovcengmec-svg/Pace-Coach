package org.runnerup.importer;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Xml;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.runnerup.common.util.Constants;
import org.runnerup.db.DBHelper;

/** Imports standard GPX track data into the Pace Coach activity database. */
public final class GPXImporter {
  private GPXImporter() {}

  private static final class Point {
    double lat;
    double lon;
    Double ele;
    long time;
    Integer hr;
    Double cadence;
    double cumulativeDistance;
    int lapIndex = -1;
  }

  private static final class LapMeta {
    int number;
    Double targetMinPaceSecKm;
    Double targetMaxPaceSecKm;
    Double preservedDistanceMeters;
    Long preservedTimeSeconds;
    int intensity = Constants.DB.INTENSITY.ACTIVE;
  }

  private static final class ActivityMeta {
    Double preservedDistanceMeters;
    Long preservedTimeSeconds;
    Integer workoutType;
    boolean present;
  }

  public static long importGpx(Context context, Uri uri) throws Exception {
    return importGpx(context, uri, false);
  }

  /**
   * Imports a GPX using one of two explicit policies:
   * false = plain import, preserving Pace Coach metadata when present;
   * true = full recalculation from the GPS track.
   */
  public static long importGpx(Context context, Uri uri, boolean recalculate) throws Exception {
    List<Point> points = new ArrayList<>();
    String name = null;
    String description = null;
    List<LapMeta> lapMetas = new ArrayList<>();
    ActivityMeta activityMeta = new ActivityMeta();
    int currentLapIndex = -1;
    boolean hasPaceCoachLaps = false;

    try (InputStream in = context.getContentResolver().openInputStream(uri)) {
      if (in == null) throw new IllegalArgumentException("Não foi possível abrir o arquivo GPX");
      org.xmlpull.v1.XmlPullParser parser = Xml.newPullParser();
      parser.setInput(in, "UTF-8");
      Point current = null;
      String currentTag = null;
      int event;
      while ((event = parser.next()) != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
        if (event == org.xmlpull.v1.XmlPullParser.START_TAG) {
          String tag = parser.getName();
          if ("trkseg".equalsIgnoreCase(tag)) {
            currentLapIndex = -1;
          } else if (tag.endsWith(":activity") || "activity".equalsIgnoreCase(tag)) {
            activityMeta.present = true;
            activityMeta.preservedDistanceMeters = parseDouble(parser.getAttributeValue(null, "distance"));
            Long preservedTime = parseLong(parser.getAttributeValue(null, "time"));
            activityMeta.preservedTimeSeconds = preservedTime;
            activityMeta.workoutType = parseInt(parser.getAttributeValue(null, "workoutType"));
          } else if (tag.endsWith(":lap") || "lap".equalsIgnoreCase(tag)) {
            int lapNumber = parseInt(parser.getAttributeValue(null, "number")) != null
                ? parseInt(parser.getAttributeValue(null, "number")) : lapMetas.size();
            LapMeta meta = null;
            for (LapMeta existing : lapMetas) {
              if (existing.number == lapNumber) {
                meta = existing;
                break;
              }
            }
            if (meta == null) {
              meta = new LapMeta();
              meta.number = lapNumber;
              lapMetas.add(meta);
            }
            meta.targetMinPaceSecKm = parseDouble(parser.getAttributeValue(null, "targetMinPace"));
            meta.targetMaxPaceSecKm = parseDouble(parser.getAttributeValue(null, "targetMaxPace"));
            meta.preservedDistanceMeters = parseDouble(parser.getAttributeValue(null, "distance"));
            meta.preservedTimeSeconds = parseLong(parser.getAttributeValue(null, "time"));
            Integer intensity = parseInt(parser.getAttributeValue(null, "intensity"));
            if (intensity != null) meta.intensity = intensity;
            currentLapIndex = lapNumber;
            hasPaceCoachLaps = true;
          } else if ("trkpt".equalsIgnoreCase(tag)) {
            current = new Point();
            current.lapIndex = currentLapIndex;
            current.lat = Double.parseDouble(parser.getAttributeValue(null, "lat"));
            current.lon = Double.parseDouble(parser.getAttributeValue(null, "lon"));
          } else if (current != null && "ele".equalsIgnoreCase(tag)) currentTag = "ele";
          else if (current != null && "time".equalsIgnoreCase(tag)) currentTag = "time";
          else if (current != null && ("hr".equalsIgnoreCase(tag) || tag.endsWith(":hr"))) currentTag = "hr";
          else if (current != null && ("cad".equalsIgnoreCase(tag) || tag.endsWith(":cad"))) currentTag = "cad";
          else if (current == null && "name".equalsIgnoreCase(tag)) currentTag = "name";
          else if (current == null && "desc".equalsIgnoreCase(tag)) currentTag = "desc";
        } else if (event == org.xmlpull.v1.XmlPullParser.TEXT && currentTag != null) {
          String text = parser.getText();
          if (current != null) {
            if ("ele".equals(currentTag)) current.ele = parseDouble(text);
            else if ("time".equals(currentTag)) current.time = parseIsoTime(text);
            else if ("hr".equals(currentTag)) current.hr = parseInt(text);
            else if ("cad".equals(currentTag)) current.cadence = parseDouble(text);
          } else if ("name".equals(currentTag)) name = text;
          else if ("desc".equals(currentTag)) description = text;
        } else if (event == org.xmlpull.v1.XmlPullParser.END_TAG) {
          String tag = parser.getName();
          if ("trkpt".equalsIgnoreCase(tag) && current != null) {
            points.add(current);
            current = null;
            currentTag = null;
          } else if ("ele".equalsIgnoreCase(tag) || "time".equalsIgnoreCase(tag)
              || "name".equalsIgnoreCase(tag) || "desc".equalsIgnoreCase(tag)
              || "hr".equalsIgnoreCase(tag) || "cad".equalsIgnoreCase(tag)) currentTag = null;
        }
      }
    }

    if (points.isEmpty()) throw new IllegalArgumentException("O GPX não contém pontos de corrida");

    double totalDistance = 0.0;
    long firstTime = 0L;
    long lastTime = 0L;
    for (int i = 0; i < points.size(); i++) {
      Point p = points.get(i);
      if (p.time > 0 && firstTime == 0) firstTime = p.time;
      if (i > 0) {
        Point prev = points.get(i - 1);
        totalDistance += distanceMeters(prev.lat, prev.lon, p.lat, p.lon);
      }
      p.cumulativeDistance = totalDistance;
      if (p.time > 0) lastTime = p.time;
    }
    if (firstTime == 0) firstTime = System.currentTimeMillis();
    long durationSeconds = lastTime > firstTime ? Math.round((lastTime - firstTime) / 1000.0) : 0L;
    if (!recalculate && activityMeta.present) {
      if (activityMeta.preservedDistanceMeters != null && activityMeta.preservedDistanceMeters >= 0) {
        totalDistance = activityMeta.preservedDistanceMeters;
      }
      if (activityMeta.preservedTimeSeconds != null && activityMeta.preservedTimeSeconds >= 0) {
        durationSeconds = activityMeta.preservedTimeSeconds;
      }
    }

    SQLiteDatabase db = DBHelper.getWritableDatabase(context);
    db.beginTransaction();
    try {
      ContentValues activity = new ContentValues();
      activity.put(Constants.DB.ACTIVITY.START_TIME, firstTime / 1000L);
      activity.put(Constants.DB.ACTIVITY.DISTANCE, totalDistance);
      activity.put(Constants.DB.ACTIVITY.TIME, durationSeconds);
      activity.put(Constants.DB.ACTIVITY.SPORT, Constants.DB.ACTIVITY.SPORT_RUNNING);
      if (activityMeta.workoutType != null) {
        activity.put(Constants.DB.ACTIVITY.WORKOUT_TYPE, activityMeta.workoutType);
      }
      activity.put(Constants.DB.ACTIVITY.NAME,
          name == null || name.trim().isEmpty() ? "Corrida importada" : name.trim());
      if (description != null && !description.trim().isEmpty()) {
        activity.put(Constants.DB.ACTIVITY.COMMENT, description.trim());
      }
      long activityId = db.insert(Constants.DB.ACTIVITY.TABLE, null, activity);
      if (activityId < 0) throw new IllegalStateException("Não foi possível salvar o treino importado");

      for (int i = 0; i < points.size(); i++) {
        Point p = points.get(i);
        ContentValues location = new ContentValues();
        location.put(Constants.DB.LOCATION.ACTIVITY, activityId);
        location.put(Constants.DB.LOCATION.LAP,
            hasPaceCoachLaps && p.lapIndex >= 0
                ? p.lapIndex
                : Math.max(0, (int) Math.ceil(p.cumulativeDistance / 1000.0) - 1));
        location.put(Constants.DB.LOCATION.TYPE, Constants.DB.LOCATION.TYPE_GPS);
        location.put(Constants.DB.LOCATION.TIME, p.time > 0 ? p.time : firstTime);
        location.put(Constants.DB.LOCATION.LATITUDE, p.lat);
        location.put(Constants.DB.LOCATION.LONGITUDE, p.lon);
        location.put(Constants.DB.LOCATION.DISTANCE, p.cumulativeDistance);
        if (p.ele != null) location.put(Constants.DB.LOCATION.ALTITUDE, p.ele);
        if (p.hr != null) location.put(Constants.DB.LOCATION.HR, p.hr);
        if (p.cadence != null) location.put(Constants.DB.LOCATION.CADENCE, p.cadence);
        if (i > 0 && p.time > 0 && points.get(i - 1).time > 0) {
          Point prev = points.get(i - 1);
          double dt = (p.time - prev.time) / 1000.0;
          if (dt > 0) location.put(Constants.DB.LOCATION.SPEED,
              distanceMeters(prev.lat, prev.lon, p.lat, p.lon) / dt);
        }
        db.insert(Constants.DB.LOCATION.TABLE, null, location);
      }

      if (hasPaceCoachLaps && !lapMetas.isEmpty()) {
        for (int i = 0; i < lapMetas.size(); i++) {
          LapMeta meta = lapMetas.get(i);
          Point first = null;
          Point last = null;
          for (Point point : points) {
            if (point.lapIndex == meta.number) {
              if (first == null) first = point;
              last = point;
            }
          }
          if (first == null || last == null) continue;
          double lapDistance = Math.max(0.0, last.cumulativeDistance - first.cumulativeDistance);
          long lapTime = first.time > 0 && last.time >= first.time ? (last.time - first.time) / 1000L : 0L;
          if (!recalculate) {
            if (meta.preservedDistanceMeters != null && meta.preservedDistanceMeters >= 0) {
              lapDistance = meta.preservedDistanceMeters;
            }
            if (meta.preservedTimeSeconds != null && meta.preservedTimeSeconds >= 0) {
              lapTime = meta.preservedTimeSeconds;
            }
          }
          ContentValues lap = new ContentValues();
          lap.put(Constants.DB.LAP.ACTIVITY, activityId);
          lap.put(Constants.DB.LAP.LAP, meta.number);
          lap.put(Constants.DB.LAP.INTENSITY, meta.intensity);
          lap.put(Constants.DB.LAP.DISTANCE, lapDistance);
          lap.put(Constants.DB.LAP.TIME, lapTime);
          if (meta.targetMinPaceSecKm != null && meta.targetMaxPaceSecKm != null
              && meta.targetMinPaceSecKm > 0 && meta.targetMaxPaceSecKm > 0) {
            double min = Math.min(meta.targetMinPaceSecKm, meta.targetMaxPaceSecKm) / 1000.0;
            double max = Math.max(meta.targetMinPaceSecKm, meta.targetMaxPaceSecKm) / 1000.0;
            lap.put(Constants.DB.LAP.PLANNED_PACE_MIN, min);
            lap.put(Constants.DB.LAP.PLANNED_PACE_MAX, max);
            lap.put(Constants.DB.LAP.PLANNED_PACE, (min + max) / 2.0);
          }
          db.insert(Constants.DB.LAP.TABLE, null, lap);
        }
      } else {
        double lapStartDistance = 0.0;
        long lapStartTime = firstTime;
        int lapNumber = 0;
        do {
          double lapEndDistance = Math.min(totalDistance, lapStartDistance + 1000.0);
          long lapEndTime = interpolateTime(points, lapEndDistance, lastTime > 0 ? lastTime : firstTime);
          ContentValues lap = new ContentValues();
          lap.put(Constants.DB.LAP.ACTIVITY, activityId);
          lap.put(Constants.DB.LAP.LAP, lapNumber++);
          lap.put(Constants.DB.LAP.INTENSITY, Constants.DB.INTENSITY.ACTIVE);
          lap.put(Constants.DB.LAP.DISTANCE, lapEndDistance - lapStartDistance);
          lap.put(Constants.DB.LAP.TIME, Math.max(0L, (lapEndTime - lapStartTime) / 1000L));
          db.insert(Constants.DB.LAP.TABLE, null, lap);
          lapStartDistance = lapEndDistance;
          lapStartTime = lapEndTime;
        } while (lapStartDistance < totalDistance);
      }

      db.setTransactionSuccessful();
      return activityId;
    } finally {
      db.endTransaction();
      DBHelper.closeDB(db);
    }
  }

  private static long interpolateTime(List<Point> points, double targetDistance, long fallback) {
    if (targetDistance <= 0) return points.get(0).time > 0 ? points.get(0).time : fallback;
    Point prev = points.get(0);
    for (int i = 1; i < points.size(); i++) {
      Point cur = points.get(i);
      if (cur.cumulativeDistance >= targetDistance) {
        if (prev.time <= 0 || cur.time <= 0 || cur.cumulativeDistance <= prev.cumulativeDistance) {
          return cur.time > 0 ? cur.time : fallback;
        }
        double ratio = (targetDistance - prev.cumulativeDistance)
            / (cur.cumulativeDistance - prev.cumulativeDistance);
        return prev.time + Math.round((cur.time - prev.time) * ratio);
      }
      prev = cur;
    }
    return points.get(points.size() - 1).time > 0 ? points.get(points.size() - 1).time : fallback;
  }

  private static double distanceMeters(double lat1, double lon1, double lat2, double lon2) {
    double r = 6371000.0;
    double dLat = Math.toRadians(lat2 - lat1);
    double dLon = Math.toRadians(lon2 - lon1);
    double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
        + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
        * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return 2 * r * Math.atan2(Math.sqrt(a), Math.sqrt(Math.max(0, 1 - a)));
  }

  private static Double parseDouble(String value) {
    try { return Double.parseDouble(value.trim()); } catch (Exception e) { return null; }
  }

  private static Integer parseInt(String value) {
    try { return Integer.parseInt(value.trim()); } catch (Exception e) { return null; }
  }

  private static Long parseLong(String value) {
    try { return Long.parseLong(value.trim()); } catch (Exception e) { return null; }
  }

  private static long parseIsoTime(String value) {
    String s = value.trim();
    String[] patterns = {
      "yyyy-MM-dd'T'HH:mm:ss.SSSX", "yyyy-MM-dd'T'HH:mm:ssX",
      "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'"
    };
    for (String pattern : patterns) {
      try {
        SimpleDateFormat f = new SimpleDateFormat(pattern, Locale.US);
        f.setLenient(false);
        return f.parse(s).getTime();
      } catch (ParseException ignored) {}
    }
    return 0L;
  }
}
