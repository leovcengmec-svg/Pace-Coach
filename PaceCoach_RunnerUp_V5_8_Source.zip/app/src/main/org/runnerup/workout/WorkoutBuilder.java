/*
 * Copyright (C) 2012 - 2014 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.workout;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.text.format.DateUtils;
import android.util.Log;
import android.util.Pair;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.runnerup.R;
import org.runnerup.common.util.Constants;
import org.runnerup.common.util.Constants.DB;
import org.runnerup.util.Formatter;
import org.runnerup.util.HRZones;
import org.runnerup.util.SafeParse;
import org.runnerup.view.AudioCueSettingsActivity;
import org.runnerup.workout.Workout.StepListEntry;
import org.runnerup.workout.feedback.AudioCountdownFeedback;
import org.runnerup.workout.feedback.PaceCoachSummaryFeedback;
import org.runnerup.workout.feedback.PaceCoachBlockFeedback;
import org.runnerup.workout.feedback.PaceCoachActivitySummaryFeedback;
import org.runnerup.workout.feedback.PaceCoachStartBlockFeedback;
import org.runnerup.workout.feedback.AudioFeedback;
import org.runnerup.workout.feedback.CoachFeedback;
import org.runnerup.workout.feedback.CountdownFeedback;
import org.runnerup.workout.feedback.HRMStateChangeFeedback;

public class WorkoutBuilder {

  /**
   * Create a basic workout from settings
   *
   * @return workout based on SharedPreferences
   */
  public static Workout createDefaultWorkout(
      Resources res, SharedPreferences prefs, Dimension target) {
    Workout w = new Workout();
    w.sport = prefs.getInt(res.getString(R.string.pref_sport), DB.ACTIVITY.SPORT_RUNNING);
    w.setWorkoutType(Constants.WORKOUT_TYPE.BASIC);

    if (prefs.getBoolean(res.getString(R.string.pref_countdown_active), false)) {
      long val;
      String vals = prefs.getString(res.getString(R.string.pref_countdown_time), "0");
      try {
        val = Long.parseLong(vals);
      } catch (NumberFormatException e) {
        val = 0;
      }
      if (val > 0) {
        Step step = Step.createRestStep(Dimension.TIME, val, false);
        w.steps.add(step);
      }
    }

    // Add an active step
    Step step = new Step();
    w.steps.add(step);

    // Treino Livre is a single continuous block and the block itself carries
    // the complete prescription from the moment execution starts.
    int coachRhythm = prefs.getInt(res.getString(R.string.pref_basic_target_rhythm), 1);
    step.setCoachRhythm(coachRhythm);
    String[] rhythmNames = {"Devagar", "Constante", "Rápido"};
    int rhythmIndex = Math.max(0, Math.min(2, coachRhythm));
    step.setName("Treino Livre");

    // Pace is part of every Pace Coach free-run configuration. The user chooses
    // either time + pace or distance + pace; the active step therefore carries
    // both a duration and a pace target.
    double paceMinSecKm =
        SafeParse.parseSeconds(
            prefs.getString(res.getString(R.string.pref_basic_target_pace_min), "00:05:10"),
            5 * 60 + 10);
    double paceMaxSecKm =
        SafeParse.parseSeconds(
            prefs.getString(res.getString(R.string.pref_basic_target_pace_max), "00:06:40"),
            6 * 60 + 40);
    Range paceRange = new Range(paceMinSecKm / 1000.0, paceMaxSecKm / 1000.0);
    if (target == Dimension.TIME) {
      double seconds =
          SafeParse.parseSeconds(
              prefs.getString(res.getString(R.string.pref_basic_target_time), "00:30:00"),
              30 * 60);
      if (seconds > 0) {
        // Rule 1: Treino Livre carries the complete prescription, but completion
        // is distance-based. The configured time is retained as part of the
        // prescription and the expected distance is calculated from the target
        // pace range (average of the two limits).
        double averagePaceSecKm = (paceMinSecKm + paceMaxSecKm) / 2.0;
        double meters = (seconds / averagePaceSecKm) * 1000.0;
        step.durationType = Dimension.DISTANCE;
        step.durationValue = Math.max(0, meters);
        step.targetType = Dimension.PACE;
        step.targetValue = paceRange;
        step.setPaceCoachFreeRun(true);
        step.setPaceCoachPlannedTimeSeconds(seconds);
        step.setPaceCoachPlannedDistanceMeters(meters);
      }
    } else if (target == Dimension.DISTANCE) {
      String value =
          prefs.getString(res.getString(R.string.pref_basic_target_distance), "5000");
      double meters = 5000;
      try {
        meters = Double.parseDouble(value);
      } catch (NumberFormatException ignored) {
        // Keep a safe default when the picker preference is malformed.
      }
      if (meters > 0) {
        double averagePaceSecKm = (paceMinSecKm + paceMaxSecKm) / 2.0;
        double seconds = (meters / 1000.0) * averagePaceSecKm;
        step.durationType = Dimension.DISTANCE;
        step.durationValue = meters;
        step.targetType = Dimension.PACE;
        step.targetValue = paceRange;
        step.setPaceCoachFreeRun(true);
        step.setPaceCoachPlannedTimeSeconds(seconds);
        step.setPaceCoachPlannedDistanceMeters(meters);
      }
    } else if (target == Dimension.HRZ) {
      HRZones hrCalc = new HRZones(res, prefs);
      int zone = prefs.getInt(res.getString(R.string.pref_basic_target_hrz), -1);
      if (zone >= 0) {
        Pair<Integer, Integer> vals = hrCalc.getHRValues(zone + 1);
        if (vals != null) {
          step.targetType = Dimension.HR;
          step.targetValue = new Range(vals.first, vals.second);
        }
      }
    }

    return w;
  }

  private static void addAutoPauseTrigger(Resources res, Step step, SharedPreferences prefs) {
    boolean enableAutoPause =
        prefs.getBoolean(res.getString(R.string.pref_autopause_active), false);
    if (!enableAutoPause) return;

    float autoPauseMinSpeed = 0;
    float autoPauseAfterSeconds = 5f;

    String val = prefs.getString(res.getString(R.string.pref_autopause_minpace), "20");
    try {
      float autoPauseMinPace = Float.parseFloat(val);
      if (autoPauseMinPace > 0) autoPauseMinSpeed = 1000 / (autoPauseMinPace * 60);
    } catch (NumberFormatException e) {
    }
    val = prefs.getString(res.getString(R.string.pref_autopause_afterseconds), "5");
    try {
      autoPauseAfterSeconds = Float.parseFloat(val);
    } catch (NumberFormatException e) {
    }
    AutoPauseTrigger tr = new AutoPauseTrigger(autoPauseAfterSeconds, autoPauseMinSpeed);
    step.triggers.add(tr);
  }

  /**
   * Create an interval workout, for the Interval tab
   *
   * @param res
   * @param prefs
   * @return
   */
  public static Workout createDefaultIntervalWorkout(Resources res, SharedPreferences prefs) {
    Workout w = new Workout();
    w.sport = prefs.getInt(res.getString(R.string.pref_sport), DB.ACTIVITY.SPORT_RUNNING);
    w.setWorkoutType(Constants.WORKOUT_TYPE.INTERVAL);

    final boolean warmup = true;
    final boolean cooldown = true;
    final boolean convertRestToRecovery =
        prefs.getBoolean(
            res.getString(R.string.pref_convert_interval_distance_rest_to_recovery), true);

    // User-configurable warmup: time or distance + pace target.
    if (warmup) {
      int warmupType = prefs.getInt(res.getString(R.string.pref_interval_warmup_type), 1);
      long warmupTime = SafeParse.parseSeconds(
          prefs.getString(res.getString(R.string.pref_interval_warmup_time), "00:10:00"), 10 * 60);
      double warmupDistance = SafeParse.parseDouble(
          prefs.getString(res.getString(R.string.pref_interval_warmup_distance), "2000"), 2000);
      Step step = new Step();
      step.intensity = Intensity.WARMUP;
      step.durationType = warmupType == 0 ? Dimension.TIME : Dimension.DISTANCE;
      step.durationValue = warmupType == 0 ? warmupTime : warmupDistance;
      long warmupPaceMin = SafeParse.parseSeconds(
          prefs.getString(res.getString(R.string.pref_interval_warmup_pace_min),
              prefs.getString(res.getString(R.string.pref_interval_warmup_pace), "00:06:20")),
          6 * 60 + 20);
      long warmupPaceMax = SafeParse.parseSeconds(
          prefs.getString(res.getString(R.string.pref_interval_warmup_pace_max),
              prefs.getString(res.getString(R.string.pref_interval_warmup_pace), "00:06:40")),
          6 * 60 + 40);
      step.targetType = Dimension.PACE;
      step.targetValue = new Range(warmupPaceMin / 1000.0, warmupPaceMax / 1000.0);
      w.steps.add(step);
    }

    int repetitions =
        (int)
            SafeParse.parseDouble(
                prefs.getString(res.getString(R.string.pref_interval_repetitions), "5"), 5);
    // A valid interval workout always has at least one interval/recovery cycle.
    repetitions = Math.max(1, Math.min(99, repetitions));

    int intervalType = prefs.getInt(res.getString(R.string.pref_interval_type), 1); // Distance
    long intervalTime =
        SafeParse.parseSeconds(
            prefs.getString(res.getString(R.string.pref_interval_time), "00:04:00"), 4 * 60);
    double intervalDistance =
        SafeParse.parseDouble(
            prefs.getString(res.getString(R.string.pref_interval_distance), "1000"), 1000);
    double intervalPaceMin = SafeParse.parseSeconds(
        prefs.getString(res.getString(R.string.pref_interval_pace_min), "00:04:40"),
        4 * 60 + 40);
    double intervalPaceMax = SafeParse.parseSeconds(
        prefs.getString(res.getString(R.string.pref_interval_pace_max), "00:04:50"),
        4 * 60 + 50);
    int intervalRestType = prefs.getInt(res.getString(R.string.pref_interval_rest_type), 0); // Time
    long intervalRestTime =
        SafeParse.parseSeconds(
            prefs.getString(res.getString(R.string.pref_interval_rest_time), "00:01:00"), 60);
    double intervalRestDistance =
        SafeParse.parseDouble(
            prefs.getString(res.getString(R.string.pref_interval_rest_distance), "200"), 200);

    RepeatStep repeat = new RepeatStep();
    repeat.repeatCount = repetitions;
    {
      Step step = new Step();
      switch (intervalType) {
        case 0: // Time
          step.durationType = Dimension.TIME;
          step.durationValue = intervalTime;
          break;
        case 1: // Distance
          step.durationType = Dimension.DISTANCE;
          step.durationValue = intervalDistance;
          break;
      }
      step.targetType = Dimension.PACE;
      step.targetValue = new Range(intervalPaceMin / 1000.0, intervalPaceMax / 1000.0);
      repeat.steps.add(step);

      Step rest =
          switch (intervalRestType) {
            case 0 -> // Time
                Step.createRestStep(Dimension.TIME, intervalRestTime, convertRestToRecovery);
            case 1 -> // Distance
                Step.createRestStep(
                    Dimension.DISTANCE, intervalRestDistance, convertRestToRecovery);
            default -> null;
          };
      if (rest != null) {
        long restPaceMin = SafeParse.parseSeconds(
            prefs.getString(res.getString(R.string.pref_interval_rest_pace_min),
                prefs.getString(res.getString(R.string.pref_interval_rest_pace), "00:06:10")),
            6 * 60 + 10);
        long restPaceMax = SafeParse.parseSeconds(
            prefs.getString(res.getString(R.string.pref_interval_rest_pace_max),
                prefs.getString(res.getString(R.string.pref_interval_rest_pace), "00:06:30")),
            6 * 60 + 30);
        rest.targetType = Dimension.PACE;
        rest.targetValue = new Range(restPaceMin / 1000.0, restPaceMax / 1000.0);
      }
      repeat.steps.add(rest);
    }
    w.steps.add(repeat);

    // User-configurable cooldown: time or distance + pace target.
    if (cooldown) {
      int cooldownType = prefs.getInt(res.getString(R.string.pref_interval_cooldown_type), 1);
      long cooldownTime = SafeParse.parseSeconds(
          prefs.getString(res.getString(R.string.pref_interval_cooldown_time), "00:05:00"), 5 * 60);
      double cooldownDistance = SafeParse.parseDouble(
          prefs.getString(res.getString(R.string.pref_interval_cooldown_distance), "1000"), 1000);
      Step step = new Step();
      step.intensity = Intensity.COOLDOWN;
      step.durationType = cooldownType == 0 ? Dimension.TIME : Dimension.DISTANCE;
      step.durationValue = cooldownType == 0 ? cooldownTime : cooldownDistance;
      long cooldownPaceMin = SafeParse.parseSeconds(
          prefs.getString(res.getString(R.string.pref_interval_cooldown_pace_min),
              prefs.getString(res.getString(R.string.pref_interval_cooldown_pace), "00:06:20")),
          6 * 60 + 20);
      long cooldownPaceMax = SafeParse.parseSeconds(
          prefs.getString(res.getString(R.string.pref_interval_cooldown_pace_max),
              prefs.getString(res.getString(R.string.pref_interval_cooldown_pace), "00:06:40")),
          6 * 60 + 40);
      step.targetType = Dimension.PACE;
      step.targetValue = new Range(cooldownPaceMin / 1000.0, cooldownPaceMax / 1000.0);
      w.steps.add(step);
    }

    return w;
  }

  public static boolean validateSeconds(String newValue) {
    // TODO move this somewhere
    long seconds = SafeParse.parseSeconds(newValue, -1);
    long seconds2 = SafeParse.parseSeconds(DateUtils.formatElapsedTime(seconds), -1);
    return seconds >= 0 && seconds == seconds2;
  }

  public static SharedPreferences getAudioCuePreferences(
      Context ctx, SharedPreferences pref, String key) {
    return getSubPreferences(
        ctx,
        pref,
        key,
        ctx.getString(org.runnerup.common.R.string.Default),
        AudioCueSettingsActivity.SUFFIX);
  }

  private static SharedPreferences getSubPreferences(
      Context ctx, SharedPreferences pref, String key, String defaultVal, String suffix) {
    String name = pref.getString(key, null);
    if (name == null || name.contentEquals(defaultVal)) {
      return pref;
    }
    try {
      return ctx.getSharedPreferences(name + suffix, Context.MODE_PRIVATE);
    } catch (Exception e) {
      // bad preference names etc
      Log.w("WorkoutBuilder", "Cannot load preferences for " + name);
      return pref;
    }
  }

  public static void addAudioCuesToWorkout(
      Resources res, Workout w, SharedPreferences audioPrefs, SharedPreferences prefs) {
    final boolean muteMusic = audioPrefs.getBoolean(res.getString(R.string.pref_mute_bool), false);
    w.setMute(muteMusic);
    ArrayList<Trigger> globalAudioTriggers = createGlobalAudioTriggers(res, audioPrefs);
    final boolean paceCoachBasic = w.getWorkoutType() == Constants.WORKOUT_TYPE.BASIC;

    // The opening event belongs only to the root workout. Keep it here so the
    // recursive step builder never needs the root Workout reference.
    final boolean eventVoiceEnabled =
        audioPrefs.getBoolean(res.getString(R.string.cueinfo_event_voice_enabled), true);
    if (eventVoiceEnabled) {
      Step firstWorkoutStep = findFirstWorkoutStep(w.steps);
      if (firstWorkoutStep != null) {
        EventTrigger workoutStart = new EventTrigger();
        workoutStart.event = Event.STARTED;
        workoutStart.scope = Scope.STEP;
        workoutStart.maxCounter = 1;
        workoutStart.triggerAction.add(new PaceCoachStartBlockFeedback(firstWorkoutStep));
        firstWorkoutStep.triggers.add(workoutStart);
      }
    }

    addAudioCuesToWorkout(
        res, w.steps, audioPrefs, prefs, globalAudioTriggers, paceCoachBasic);
  }

  private static Step findFirstWorkoutStep(List<Step> steps) {
    for (Step step : steps) {
      if (step.getIntensity() == Intensity.REPEAT) {
        Step nested = findFirstWorkoutStep(((RepeatStep) step).steps);
        if (nested != null) return nested;
        continue;
      }
      // Ignore an optional pre-start REST/countdown step. The first real
      // workout block (Active, Warmup, Recovery, etc.) is the block that
      // should be narrated together with "Treino iniciado".
      if (step.getIntensity() != Intensity.RESTING) return step;
    }
    return null;
  }

  /**
   * Add audio cues to the steps Called recursively for Repeat steps
   *
   * @param res
   * @param steps
   * @param audioPrefs
   * @param prefs
   */
  private static void addAudioCuesToWorkout(
      Resources res,
      ArrayList<Step> steps,
      SharedPreferences audioPrefs,
      SharedPreferences prefs,
      ArrayList<Trigger> globalAudioTriggers,
      boolean paceCoachBasic) {
    // Positive setting: enabled = announce workout start/pause/resume/final summary.
    final boolean eventVoiceEnabled =
        audioPrefs.getBoolean(res.getString(R.string.cueinfo_event_voice_enabled), true);

    Step[] stepArr = new Step[steps.size()];
    steps.toArray(stepArr);

    // The root workout already owns the single ordered opening announcement.
    // Recursive calls only add per-block narration and must never recreate the
    // workout-start event.
    Step firstWorkoutStep = findFirstWorkoutStep(steps);

    // Pace Coach free-run opening instruction is attached to the first actual
    // workout step by the public method above, so optional countdown/rest steps
    // do not delay or duplicate the opening announcement.
    for (int i = 0; i < stepArr.length; i++) {
      Step step = stepArr[i];
      Step next = i + 1 == stepArr.length ? null : stepArr[i + 1];

      if (step.getIntensity() == Intensity.REPEAT) {
        addAudioCuesToWorkout(
            res, ((RepeatStep) step).steps, audioPrefs, prefs, globalAudioTriggers, paceCoachBasic);
        continue;
      }

      // Interval summaries belong to every block, including recovery/rest blocks. End-of-lap
      // is still restricted to active/autolap steps inside createDefaultTriggers().
      boolean endOfLap = step.getIntensity() == Intensity.ACTIVE || step.getAutolap() > 0;
      ArrayList<Trigger> defaultTriggers = createDefaultTriggers(res, audioPrefs, endOfLap);
      step.triggers.addAll(defaultTriggers);

      // General and current audio summaries are driven by activity time/distance and must
      // survive step changes, including recovery blocks. The same trigger instances are shared
      // across all leaf steps.
      step.triggers.addAll(globalAudioTriggers);

      // Pace Coach block narration: announce the current block at the beginning and its
      // result at the end. Because repeat steps are expanded recursively here, every
      // repeated leaf block receives its own initial/final announcement (e.g. 7 x 2 = 14).
      if ("true".equals(audioPrefs.getString("cue_block_cadence", "true"))) {
        // The first block is already announced together with "Treino iniciado".
        // Other blocks keep their normal individual start announcement.
        if (step != firstWorkoutStep) {
          EventTrigger blockStart = new EventTrigger();
          blockStart.event = Event.STARTED;
          blockStart.scope = Scope.STEP;
          blockStart.maxCounter = 1;
          blockStart.triggerAction.add(new PaceCoachBlockFeedback(step, false, null));
          step.triggers.add(blockStart);
        }

        EventTrigger blockEnd = new EventTrigger();
        blockEnd.event = Event.COMPLETED;
        blockEnd.scope = Scope.STEP;
        blockEnd.maxCounter = 1;
        blockEnd.triggerAction.add(new PaceCoachBlockFeedback(step, true, null));
        step.triggers.add(blockEnd);
      }

      if (eventVoiceEnabled) {
        addPauseStopResumeTriggers(step.triggers);
      }

      if (step.durationType != null) {
        // GUI countdown
        IntervalTrigger trigger = new IntervalTrigger();
        trigger.dimension = step.durationType;
        trigger.first = 1;
        trigger.interval = 1;
        trigger.scope = Scope.STEP;
        trigger.triggerAction.add(new CountdownFeedback(Scope.STEP, step.durationType));
        step.triggers.add(trigger);

        // Audio feedback. For Pace Coach Treino Constante, the opening instruction
        // already contains the target duration/distance and pace, so do not repeat
        // only the full duration (for example, just "30 minutos") at startup.
        if (!(paceCoachBasic && step.getIntensity() == Intensity.ACTIVE)) {
          createAudioCountdown(step);
        }
      }

      // Legacy lap/warmup/cooldown event announcements intentionally removed.
      // Block announcements above are now the single source for step/block narration.

      if (audioPrefs.getBoolean(res.getString(R.string.pref_cue_hrm_connection), false)) {
        HRMStateTrigger hrmState = new HRMStateTrigger();
        hrmState.triggerAction.add(new HRMStateChangeFeedback(hrmState));
        step.triggers.add(hrmState);
      }

      final boolean coaching =
          audioPrefs.getBoolean(res.getString(R.string.cueinfo_target_coaching), true);
      // Pace Coach current-rhythm announcements perform the target comparison themselves.
      // Keep the legacy target trigger for non-Pace-Coach workout schemes only, avoiding
      // duplicate accelerate/decelerate announcements.
      final boolean paceCoachAudioModel = "true".equals(audioPrefs.getString("cue_block_cadence", "true"));
      if (coaching && !paceCoachAudioModel && step.getTargetType() != null) {
        final Range range = step.getTargetValue();
        final int averageSeconds =
            SafeParse.parseInt(
                prefs.getString(
                    res.getString(R.string.pref_target_pace_moving_average_seconds), "20"),
                20);
        final int graceSeconds =
            SafeParse.parseInt(
                prefs.getString(res.getString(R.string.pref_target_pace_grace_seconds), "30"), 30);

        TargetTrigger tr = new TargetTrigger(step.getTargetType(), averageSeconds, graceSeconds);
        tr.scope = Scope.STEP;
        tr.range = range;
        tr.triggerAction.add(new CoachFeedback(tr));
        step.triggers.add(tr);
      }

      checkDuplicateTriggers(step);
    }
  }

  interface TriggerFilter {
    boolean match(Trigger trigger);
  }

  private static Trigger hasTrigger(List<Trigger> triggers, TriggerFilter filter) {
    for (Trigger t : triggers) {
      if (filter.match(t)) return t;
    }
    return null;
  }

  private static Trigger hasEndOfLapTrigger(List<Trigger> triggers) {
    return hasTrigger(
        triggers,
        trigger -> {
          if (trigger == null) return false;

          if (!(trigger instanceof EventTrigger et)) return false;
          return (et.event == Event.COMPLETED && et.scope == Scope.LAP);
        });
  }

  private static void checkDuplicateTriggers(Step step) {
    if (hasEndOfLapTrigger(step.triggers) != null) {
      Log.d("WorkoutBuilder", "hasEndOfLapTrigger()");
      /*
       * The end of lap trigger can be a duplicate of a distance based interval trigger
       *  1) in a step with distance duration, that is a multiple of the interval-distance
       * e.g interval-trigger-distance = 100m duration = 1000m, then set max count = 9
       *  2) in a step with autolap 500m and interval-trigger-distance 1000 then remove the
       * trigger
       */
      ArrayList<TriggerSuppression> list = new ArrayList<>();
      if (step.getAutolap() > 0) {
        list.add(new EndOfLapSuppression(step.getAutolap()));
      }

      if (step.getDurationType() == Dimension.DISTANCE) {
        list.add(new EndOfLapSuppression(step.getDurationValue()));
      }
      for (Trigger t : step.triggers) {
        if (!(t instanceof IntervalTrigger it)) continue;
        if (it.dimension != Dimension.DISTANCE) continue;
        it.triggerSuppression.addAll(list);
      }
    }
  }

  /**
   * Add the default triggers, with the configurable feedback (activity/lap etc time/distance etc):
   * * periodic time/distance * end of lap
   *
   * @param res
   * @param prefs
   * @return
   */
  private static ArrayList<Trigger> createDefaultTriggers(
      Resources res, SharedPreferences prefs, boolean endOfLap) {
    ArrayList<Trigger> triggers = new ArrayList<>();

    // INTERVAL / BLOCK: the trigger restarts with every training block because it is attached to
    // each step. It reports the current block (distance, time and average pace) only.
    addConfiguredSummaryTrigger(
        res,
        prefs,
        triggers,
        Scope.STEP,
        "cue_interval_cadence",
        "cue_interval_time_interval",
        "cue_interval_distance_interval",
        "interval");

    // Legacy cue_time/cue_distance are intentionally no longer used. The new three-level audio
    // model (general / interval / current) controls cadence independently.
    return triggers;
  }

  private static ArrayList<Trigger> createGlobalAudioTriggers(
      Resources res, SharedPreferences prefs) {
    ArrayList<Trigger> triggers = new ArrayList<>();

    // GENERAL PER KM: fixed 1 km cadence, with individually selectable data.
    if ("on".equals(prefs.getString("cue_general_km_cadence", "on"))) {
      IntervalTrigger km = new IntervalTrigger();
      km.first = 1000;
      km.interval = 1000;
      km.scope = Scope.ACTIVITY;
      km.dimension = Dimension.DISTANCE;
      km.triggerAction.add(new PaceCoachSummaryFeedback(
          Scope.ACTIVITY, "general",
          prefs.getBoolean("cue_general_km_time", true),
          prefs.getBoolean("cue_general_km_distance", true),
          prefs.getBoolean("cue_general_km_pace", true),
          prefs.getBoolean("cue_general_km_speed", false),
          prefs.getBoolean("cue_general_km_hr", false)));
      triggers.add(km);
    }

    // GENERAL: configurable time/distance cadence with individually selectable data.
    String cadence = prefs.getString("cue_general_cadence", "off");
    if ("time".equals(cadence) || "distance".equals(cadence)) {
      IntervalTrigger t = new IntervalTrigger();
      if ("time".equals(cadence)) {
        long seconds = parsePositiveLong(prefs.getString("cue_general_time_interval", "120"), 120);
        t.first = seconds;
        t.interval = seconds;
        t.dimension = Dimension.TIME;
      } else {
        long meters = parsePositiveLong(prefs.getString("cue_general_distance_interval", "1000"), 1000);
        t.first = meters;
        t.interval = meters;
        t.dimension = Dimension.DISTANCE;
      }
      t.scope = Scope.ACTIVITY;
      t.triggerAction.add(new PaceCoachSummaryFeedback(
          Scope.ACTIVITY, "general",
          prefs.getBoolean("cue_general_time", true),
          prefs.getBoolean("cue_general_distance", true),
          prefs.getBoolean("cue_general_pace", true),
          prefs.getBoolean("cue_general_speed", false),
          prefs.getBoolean("cue_general_hr", false)));
      triggers.add(t);
    }

    // CURRENT: cadence remains configurable, but the spoken value is always the live current pace.
    addConfiguredSummaryTrigger(
        res, prefs, triggers, Scope.CURRENT,
        "cue_current_cadence", "cue_current_time_interval", "cue_current_distance_interval", "current");

    return triggers;
  }

  private static void addConfiguredSummaryTrigger(
      Resources res, SharedPreferences prefs, ArrayList<Trigger> triggers,
      Scope spokenScope, String cadenceKey, String timeIntervalKey, String distanceIntervalKey,
      String kind) {
    String cadence = prefs.getString(cadenceKey, "off");
    if ("time".equals(cadence)) {
      long seconds = parsePositiveLong(prefs.getString(timeIntervalKey, "120"), 120);
      if (seconds > 0) {
        IntervalTrigger t = new IntervalTrigger();
        t.first = seconds; t.interval = seconds;
        t.scope = spokenScope == Scope.STEP ? Scope.STEP : Scope.ACTIVITY;
        t.dimension = Dimension.TIME;
        t.triggerAction.add(createSummaryFeedback(spokenScope, kind, seconds, 0));
        triggers.add(t);
      }
    } else if ("distance".equals(cadence)) {
      long meters = parsePositiveLong(prefs.getString(distanceIntervalKey, "1000"), 1000);
      if (meters > 0) {
        IntervalTrigger t = new IntervalTrigger();
        t.first = meters; t.interval = meters;
        t.scope = spokenScope == Scope.STEP ? Scope.STEP : Scope.ACTIVITY;
        t.dimension = Dimension.DISTANCE;
        t.triggerAction.add(createSummaryFeedback(spokenScope, kind, 0, meters));
        triggers.add(t);
      }
    }
  }

  private static Feedback createSummaryFeedback(Scope spokenScope, String kind, double timeWindowSeconds, double distanceWindowMeters) {
    return new PaceCoachSummaryFeedback(spokenScope, kind, true, true, true, false, false,
        timeWindowSeconds, distanceWindowMeters);
  }

  private static long parsePositiveLong(String value, long fallback) {
    try {
      long parsed = Long.parseLong(value);
      return parsed > 0 ? parsed : fallback;
    } catch (Exception e) {
      return fallback;
    }
  }

  private static void addPauseStopResumeTriggers(ArrayList<Trigger> list) {
    EventTrigger p = new EventTrigger();
    p.event = Event.PAUSED;
    p.scope = Scope.STEP;
    p.triggerAction.add(new AudioFeedback(R.string.cue_activity_paused));
    list.add(p);

    EventTrigger r = new EventTrigger();
    r.event = Event.RESUMED;
    r.scope = Scope.STEP;
    r.triggerAction.add(new AudioFeedback(R.string.cue_activity_resumed));
    list.add(r);

    EventTrigger ev = new EventTrigger();
    ev.event = Event.STOPPED;
    ev.scope = Scope.STEP;
    ev.triggerAction.add(new PaceCoachActivitySummaryFeedback());
    list.add(ev);
  }

  private static void createAudioCountdown(Step step) {
    createAudioCountdown(step, false);
  }

  private static void createAudioCountdown(Step step, boolean suppressInitialValue) {
    if (step.getDurationType() == null) {
      // Only for time/distance
      return;
    }

    ArrayList<Double> list = new ArrayList<>();
    switch (step.getDurationType()) {
      case TIME:
        // seconds
        Double[] tmp0 = {60d, 30d, 10d, 5d, 4d, 3d, 2d, 1d};
        list.addAll(Arrays.asList(tmp0));
        break;
      case DISTANCE:
        // meters
        Double[] tmp1 = {100d, 50d, 20d, 10d};
        list.addAll(Arrays.asList(tmp1));
        break;
      default:
        return;
    }

    // Extent the feedback list with more values for longer countdowns
    while (step.getDurationValue() / 2 > list.get(0)) {
      list.add(0, list.get(0) * 2d);
    }

    // Remove all values in list close to the step
    while (!list.isEmpty() && step.getDurationValue() < list.get(0) * 1.1d) {
      list.remove(0);
    }
    list.add(0, step.getDurationValue());
    if (suppressInitialValue && list.size() > 1) {
      list.remove(0);
    }

    // create a list trigger for the values
    ListTrigger trigger = new ListTrigger(step.getDurationType(), Scope.STEP, list);
    trigger.triggerAction.add(new AudioCountdownFeedback(Scope.STEP, step.getDurationType()));
    step.triggers.add(trigger);
  }

  /**
   * Add autolap, autopause and countdown to workouts
   *
   * @param res
   * @param prefs
   * @param w
   */
  public static void prepareWorkout(Resources res, SharedPreferences prefs, Workout w) {
    List<StepListEntry> steps = w.getStepList();
    boolean basic = w.getWorkoutType() == Constants.WORKOUT_TYPE.BASIC;

    // autolap
    boolean autolap =
        basic
            ? prefs.getBoolean(res.getString(R.string.pref_autolap_active), false)
            : prefs.getBoolean(res.getString(R.string.pref_step_autolap_active), false);
    if (autolap) {
      String vals = prefs.getString(res.getString(R.string.pref_autolap), "1000");
      double val = SafeParse.parseDouble(vals, 0.0);
      Log.d("WorkoutBuilder", "setAutolap(" + val + ")");
      for (StepListEntry s : steps) {
        if (basic
            || s.step().getIntensity() == Intensity.ACTIVE
            ||
            // Also set on the last in the flat list
            s == steps.get(steps.size() - 1)) {
          s.step().setAutolap(val);
        }
      }
    }

    // Autopause
    for (StepListEntry s : steps) {
      if (basic) {
        addAutoPauseTrigger(res, s.step(), prefs);
        continue;
      }
      switch (s.step().getIntensity()) {
        case WARMUP:
        case COOLDOWN:
          addAutoPauseTrigger(res, s.step(), prefs);
          break;
        case ACTIVE:
        case RECOVERY:
        case RESTING:
        case REPEAT:
        default:
          break;
      }
    }

    /*
     * Add countdowns after steps with duration "until pressed"
     * - if next is not a countdown
     * - and current is not rest
     */
    if (prefs.getBoolean(res.getString(R.string.pref_step_countdown_active), true)) {
      final boolean convertRestToRecovery =
          prefs.getBoolean(
              res.getString(R.string.pref_convert_advanced_distance_rest_to_recovery), true);
      long val = 15; // default
      String vals = prefs.getString(res.getString(R.string.pref_step_countdown_time), "15");
      try {
        val = Long.parseLong(vals);
      } catch (NumberFormatException e) {
      }
      if (val > 0) {
        StepListEntry[] stepArr = new StepListEntry[steps.size()];
        steps.toArray(stepArr);
        for (int i = 0; i < stepArr.length; i++) {
          Step step = stepArr[i].step();

          if (step.durationType != null
              || step.intensity == Intensity.REPEAT
              || step.intensity == Intensity.RESTING
              || i + 1 >= stepArr.length) continue;

          Step next = stepArr[i + 1].step();

          if (next.intensity == Intensity.RESTING) continue;

          Step s = Step.createRestStep(Dimension.TIME, val, convertRestToRecovery);
          if (stepArr[i].parent() == null) {
            w.steps.add(i + 1, s);
            Log.d("WorkoutBuilder", "Added step at index: " + (i + 1));
          } else {
            RepeatStep rs = (RepeatStep) stepArr[i].parent();
            int idx = rs.steps.indexOf(step);
            rs.steps.add(idx, s);
            Log.d(
                "WorkoutBuilder",
                "Added step at index: " + (i + 1) + " repeat index: " + (idx + 1));
          }
        }
      }
    }
  }

  public static void addFeedbackFromPreferences(
      SharedPreferences prefs, Resources res, ArrayList<Feedback> feedback) {
    int feedbackStart = feedback.size();

    /* TOTAL */
    if (prefs.getBoolean(res.getString(R.string.cueinfo_total_distance), false)) {
      feedback.add(new AudioFeedback(Scope.ACTIVITY, Dimension.DISTANCE));
    }
    if (prefs.getBoolean(res.getString(R.string.cueinfo_total_time), false)) {
      feedback.add(new AudioFeedback(Scope.ACTIVITY, Dimension.TIME));
    }
    if (Dimension.SPEED_CUE_ENABLED
        && prefs.getBoolean(res.getString(R.string.cueinfo_total_speed), false)) {
      feedback.add(new AudioFeedback(Scope.ACTIVITY, Dimension.SPEED));
    }
    if (prefs.getBoolean(res.getString(R.string.cueinfo_total_pace), false)) {
      feedback.add(new AudioFeedback(Scope.ACTIVITY, Dimension.PACE));
    }
    if (prefs.getBoolean(res.getString(R.string.cueinfo_total_hr), false)) {
      feedback.add(new AudioFeedback(Scope.ACTIVITY, Dimension.HR));
    }
    if (prefs.getBoolean(res.getString(R.string.cueinfo_total_hrz), false)) {
      feedback.add(new AudioFeedback(Scope.ACTIVITY, Dimension.HRZ));
    }

    /* STEP */
    if (prefs.getBoolean(res.getString(R.string.cueinfo_step_distance), false)) {
      feedback.add(new AudioFeedback(Scope.STEP, Dimension.DISTANCE));
    }
    if (prefs.getBoolean(res.getString(R.string.cueinfo_step_time), false)) {
      feedback.add(new AudioFeedback(Scope.STEP, Dimension.TIME));
    }
    if (Dimension.SPEED_CUE_ENABLED
        && prefs.getBoolean(res.getString(R.string.cueinfo_step_speed), false)) {
      feedback.add(new AudioFeedback(Scope.STEP, Dimension.SPEED));
    }
    if (prefs.getBoolean(res.getString(R.string.cueinfo_step_pace), false)) {
      feedback.add(new AudioFeedback(Scope.STEP, Dimension.PACE));
    }
    if (prefs.getBoolean(res.getString(R.string.cueinfo_step_hr), false)) {
      feedback.add(new AudioFeedback(Scope.STEP, Dimension.HR));
    }
    if (prefs.getBoolean(res.getString(R.string.cueinfo_step_hrz), false)) {
      feedback.add(new AudioFeedback(Scope.STEP, Dimension.HRZ));
    }

    // LAP audio feedback intentionally removed. Kilometer announcements use the
    // Pace Coach general-per-kilometer configuration instead of lap cues.

    /* CURRENT */
    // Legacy CURRENT AudioFeedback is intentionally not added here. Pace Coach
    // current-pace announcements are controlled exclusively by the new
    // cue_current_cadence trigger, which uses the live GPS pace source.
    // Keeping the legacy CURRENT feedback active could emit the old
    // "Ritmo indisponível" message in parallel with the new system.

    for (int i = feedbackStart; i < feedback.size(); i++) {
      if (feedback.get(i) instanceof AudioFeedback
          && (i == 0
              || feedback.get(i - 1) == null
              || !(feedback.get(i - 1) instanceof AudioFeedback)
              || ((AudioFeedback) feedback.get(i - 1)).getScope() == null
              || ((AudioFeedback) feedback.get(i - 1)).getScope()
                  != ((AudioFeedback) feedback.get(i)).getScope())) {
        // Insert the Scope (Activity, Lap etc) before the items
        feedback.add(i, new AudioFeedback(((AudioFeedback) feedback.get(i)).getScope()));
        i++;
      }
    }
  }
}
