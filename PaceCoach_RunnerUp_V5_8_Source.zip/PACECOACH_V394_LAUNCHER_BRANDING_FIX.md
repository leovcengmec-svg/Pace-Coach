# Pace Coach v394 — Correção do nome e ícone do launcher

## Base

Revisão v392. Preserva as correções funcionais anteriores.

## Identidade do aplicativo

- Nome exibido no launcher e nos builds Debug/Release: `Pace Coach`.
- Corrigida a sobrescrita de `app_name` do build Debug, que usava `dRunnerUp`.
- Mantido `android:label` do aplicativo apontando para `@string/app_name`.
- Atualizados os ícones legados em todas as densidades (`mdpi` a `xxxhdpi`).
- Atualizado o ícone adaptativo Android 8+ com foreground, fundo azul-marinho e camada monocromática para ícones temáticos.
- Não foram alterados `applicationId`, authorities, namespaces ou nomes internos do projeto.

## Versão

- Revisão interna: v394.
- `versionCode` base: 394 (código Android esperado: 23000394).
- Wear reserva o próximo código ímpar: 23000395.
- `versionName`: 2.11.0.20.
- Artefato GitHub Actions: `pacecoach-apk-v394-launcher-branding-fix`.

## Instalação / atualização

Após instalar o APK atualizado, o Android deve mostrar `Pace Coach` e o novo ícone. Alguns launchers mantêm cache visual; se continuar mostrando o ícone antigo, reinicie o launcher ou o aparelho. Não é necessário alterar o ID do aplicativo nem desinstalar a instalação existente.
