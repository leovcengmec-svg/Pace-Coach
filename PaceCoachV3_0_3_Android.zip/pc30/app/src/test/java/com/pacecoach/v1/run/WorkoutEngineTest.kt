package com.pacecoach.v1.run

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WorkoutEngineTest {
    @Test
    fun intervalBlockAlternatesRunAndRecovery() {
        val workout = ExampleWorkouts.interval4x1k()
        val labels = workout.steps.map { it.label }
        assertEquals("Aquecimento", labels[0])
        assertEquals("1 km forte 1/4", labels[1])
        assertEquals("Recuperação", labels[2])
        assertEquals("1 km forte 2/4", labels[3])
        assertEquals("Recuperação", labels[4])
        assertEquals("1 km forte 3/4", labels[5])
        assertEquals("Recuperação", labels[6])
        assertEquals("1 km forte 4/4", labels[7])
        assertEquals("Desaquecimento", labels[8])
    }

    @Test
    fun engineAdvancesFromRunToRecoveryToNextRun() {
        val workout = ExampleWorkouts.interval4x1k()
        val engine = WorkoutEngine(workout)
        engine.start(0L, 0f)

        assertEquals("Aquecimento", engine.current()!!.step.label)
        engine.update(600_000L, 0f)
        assertEquals("1 km forte 1/4", engine.current()!!.step.label)

        engine.update(700_000L, 1000f)
        assertEquals("Recuperação", engine.current()!!.step.label)

        engine.update(820_000L, 1000f)
        assertEquals("1 km forte 2/4", engine.current()!!.step.label)
        assertFalse(engine.isFinished())
    }
}
