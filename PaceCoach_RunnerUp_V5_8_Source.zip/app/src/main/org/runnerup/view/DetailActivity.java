/*
 * Copyright (C) 2012 - 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.view;

import static org.runnerup.content.ActivityProvider.GPX_MIME;
import static org.runnerup.content.ActivityProvider.TCX_MIME;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;
import android.widget.ScrollView;
import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import org.runnerup.BuildConfig;
import org.runnerup.R;
import org.runnerup.common.util.Constants;
import org.runnerup.content.ActivityProvider;
import org.runnerup.db.ActivityCleaner;
import org.runnerup.db.DBHelper;
import org.runnerup.db.entities.LocationEntity;
import org.runnerup.db.PathSimplifier;
import org.runnerup.export.SyncManager;
import org.runnerup.export.Synchronizer;
import org.runnerup.export.Synchronizer.Feature;
import org.runnerup.util.ActivitySplitTime;
import org.runnerup.util.Bitfield;
import org.runnerup.util.FileNameHelper;
import org.runnerup.util.Formatter;
import org.runnerup.util.GraphWrapper;
import org.runnerup.util.MapWrapper;
import org.runnerup.util.SafeParse;
import org.runnerup.widget.SpinnerInterface.OnSetValueListener;
import org.runnerup.widget.TitleSpinner;
import org.runnerup.widget.WidgetUtil;
import org.runnerup.workout.Intensity;
import org.runnerup.workout.Sport;

public class DetailActivity extends AppCompatActivity implements Constants {

  private long mID = 0;
  private SQLiteDatabase mDB = null;
  private final HashSet<String> pendingSynchronizers = new HashSet<>();
  private final HashSet<String> alreadySynched = new HashSet<>();
  private final Map<String, String> synchedExternalId = new HashMap<>();

  private boolean lapHrPresent = false;
  private boolean lapElevationPresent = false;
  private boolean lapTimeMode = false;
  private TextView lapModeKm = null;
  private TextView lapModeTime = null;
  private TextView lapPrimaryHeader = null;
  private double[] lapElevation = null;
  private int[] lapHrAverage = null;
  private ContentValues[] laps = null;
  // Structured workout blocks grouped independently from GPS/autolap splits.
  private ContentValues[] workoutBlocks = null;
  // Raw LAP rows belonging to each displayed workout block (normally 1 km autolaps).
  private ArrayList<ArrayList<ContentValues>> workoutBlockParts = new ArrayList<>();
  // Voltas are always activity splits (1 km or 1 min), never workout blocks.
  private ContentValues[] distanceSplits = null;
  private ContentValues[] timeSplits = null;
  private double[] splitElevation = null;
  private int[] splitHrAverage = null;
  private boolean splitHrPresent = false;
  private boolean splitElevationPresent = false;
  private final ArrayList<ContentValues> reports = new ArrayList<>();
  private final ArrayList<BaseAdapter> adapters = new ArrayList<>(2);

  private int mode; // 0 == save 1 == details
  private static final int MODE_SAVE = 0;
  private static final int MODE_DETAILS = 1;
  private boolean edit = false;
  private boolean uploading = false;

  private Button saveButton = null;
  private Button uploadButton = null;
  private Button resumeButton = null;
  private TextView activityTime = null;
  private TextView activityPace = null;
  private View activityPaceSeparator = null;
  private TextView activityDistance = null;

  private TitleSpinner sport = null;
  private TitleSpinner manualDistance = null;
  private EditText notes = null;
  private EditText activityNameEdit = null;
  private org.runnerup.widget.TitleSpinner workoutTypeSpinner = null;
  private boolean workoutTypeStored = false;
  private View rootView;
  private View mapTab;
  private View graphTab;
  private View blocksTab;
  private TextView detailDistanceValue;
  private TextView detailTimeValue;
  private TextView detailPaceValue;
  private TextView detailSpeedValue;
  private TextView detailCaloriesValue;
  private TextView detailInfoValue;
  private TextView detailSportValue;
  private TextView detailDateValue;
  private TextView detailDistanceRowValue;
  private TextView detailTimeRowValue;
  private TextView detailPaceRowValue;
  private TextView detailSpeedRowValue;
  private TextView detailElevationValue;
  private TextView detailElevationRowValue;
  private TextView detailCaloriesRowValue;
  private TextView workoutTypeValue;
  private TextView activityNameValue;
  private LinearLayout editControls;
  private LinearLayout blockListContainer;
  private View blockListHeader;
  private LinearLayout blockTableContainer;
  private TextView blockSummary;
  private TextView blockPerformanceValue;
  private TextView blockPerformanceDetail;
  // Workout diagram containers are fields so they remain available to every helper
  // used to build the approved Blocos do treino interface.
  private LinearLayout blockWorkoutDiagram;
  private LinearLayout blockWorkoutLabels;
  private LinearLayout blockWorkoutLegend;
  private TextView mapLapTitle;
  private TextView mapLapDetails;
  private TextView mapLapTime;
  private TextView mapLapPace;
  private TextView mapLapElevation;
  private TextView mapTopKm;
  private TextView mapTopTime;
  private TextView mapTopPace;
  private View mapInfoPanel;
  private View mapTopInfoPanel;
  private View mapToggleInfoButton;
  private boolean mapInfoVisible = true;
  private View mapLapPrev;
  private View mapLapNext;
  private int mapLapIndex = 0;

  private MapWrapper mapWrapper = null;
  private TabHost detailTabHost = null;
  private float swipeDownX = 0f;
  private float swipeDownY = 0f;
  private static final int TAB_SWIPE_MIN_DISTANCE = 100;
  private GraphWrapper graphWrapper = null;

  private SyncManager syncManager = null;
  private Formatter formatter = null;

  private long mStartTime = 0; // activity start time in unix timestamp
  private ContentValues headerData = new ContentValues();
  private static final int EDIT_ACCOUNT_REQUEST = 2;

  /** Called when the activity is first created. */
  @Override
  public void onCreate(Bundle savedInstanceState) {
    EdgeToEdge.enable(this);
    Window window = getWindow();
    WindowCompat.getInsetsController(window, window.getDecorView())
        .setAppearanceLightStatusBars(false);
    super.onCreate(savedInstanceState);
    if (BuildConfig.OSMDROID_ENABLED || BuildConfig.MAPBOX_ENABLED) {
      // MapBox or Osmdroid, set mapWrapper.
      MapWrapper.start(this);
    }
    setContentView(R.layout.detail);
    rootView = findViewById(R.id.detail_view);

    Intent intent = getIntent();
    mID = intent.getLongExtra("ID", -1);
    String intentMode = intent.getStringExtra("mode");

    mDB = DBHelper.getReadableDatabase(this);
    syncManager = new SyncManager(this);
    formatter = new Formatter(this);

    if (intentMode.contentEquals("save")) {
      this.mode = MODE_SAVE;
    } else if (intentMode.contentEquals("details")) {
      this.mode = MODE_DETAILS;
    } else {
      if (BuildConfig.DEBUG) {
        throw new AssertionError();
      }
    }

    saveButton = findViewById(R.id.save_button);
    Button discardButton = findViewById(R.id.discard_button);
    resumeButton = findViewById(R.id.resume_button);
    uploadButton = findViewById(R.id.upload_button);
    Toolbar toolbar = findViewById(R.id.actionbar);
    setSupportActionBar(toolbar);
    if (getSupportActionBar() != null) {
      getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    WidgetUtil.addLegacyOverflowButton(window);

    detailDistanceValue = findViewById(R.id.detail_distance_value);
    detailTimeValue = findViewById(R.id.detail_time_value);
    detailPaceValue = findViewById(R.id.detail_pace_value);
    detailSpeedValue = findViewById(R.id.detail_speed_value);
    detailCaloriesValue = findViewById(R.id.detail_calories_value);
    detailInfoValue = findViewById(R.id.detail_info_value);
    detailSportValue = findViewById(R.id.detail_sport_value);
    detailDateValue = findViewById(R.id.detail_date_value);
    detailDistanceRowValue = findViewById(R.id.detail_distance_row_value);
    detailTimeRowValue = findViewById(R.id.detail_time_row_value);
    detailPaceRowValue = findViewById(R.id.detail_pace_row_value);
    detailSpeedRowValue = findViewById(R.id.detail_speed_row_value);
    detailElevationValue = findViewById(R.id.detail_elevation_value);
    detailElevationRowValue = findViewById(R.id.detail_elevation_row_value);
    detailCaloriesRowValue = findViewById(R.id.detail_calories_row_value);
    // The activity title/type also belonged to the removed large header.
    workoutTypeValue = findViewById(R.id.activity_workout_type);
    activityNameValue = findViewById(R.id.activity_name);
    editControls = findViewById(R.id.edit_controls);
    blockListContainer = findViewById(R.id.block_list_container);
    blockListHeader = findViewById(R.id.block_list_header);
    blockTableContainer = findViewById(R.id.block_table_container);
    blockSummary = findViewById(R.id.block_summary);
    blockPerformanceValue = findViewById(R.id.block_performance_value);
    blockPerformanceDetail = findViewById(R.id.block_performance_detail);
    mapLapTitle = findViewById(R.id.map_lap_title);
    mapLapDetails = null;
    mapLapTime = findViewById(R.id.map_lap_time);
    mapLapPace = findViewById(R.id.map_lap_pace);
    mapLapElevation = findViewById(R.id.map_lap_elevation);
    mapLapPrev = findViewById(R.id.map_lap_prev);
    mapLapNext = findViewById(R.id.map_lap_next);
    mapTopKm = findViewById(R.id.map_top_km);
    mapTopTime = findViewById(R.id.map_top_time);
    mapTopPace = findViewById(R.id.map_top_pace);
    mapInfoPanel = findViewById(R.id.map_info_panel);
    mapTopInfoPanel = findViewById(R.id.map_top_info_panel);
    mapToggleInfoButton = findViewById(R.id.map_toggle_info_button);
    if (mapToggleInfoButton != null) mapToggleInfoButton.setOnClickListener(v -> toggleMapInfo());
    if (mapLapPrev != null) mapLapPrev.setOnClickListener(v -> selectMapLap(mapLapIndex - 1));
    if (mapLapNext != null) mapLapNext.setOnClickListener(v -> selectMapLap(mapLapIndex + 1));
    sport = findViewById(R.id.summary_sport);
    // Pace Coach is exclusively for running. Keep the legacy sport control
    // hidden for database/backward compatibility, but never show it in the UI.
    if (sport != null) {
      sport.setVisibility(View.GONE);
      sport.setOnSetValueListener(
          new OnSetValueListener() {
            @Override
            public String preSetValue(String newValue) throws IllegalArgumentException {
              return newValue;
            }

            @Override
            public int preSetValue(int newValue) throws IllegalArgumentException {
              updateViewForSport(newValue);
              ViewCompat.requestApplyInsets(rootView);
              headerData.put(DB.ACTIVITY.SPORT, newValue);
              return newValue;
            }
          });
      sport.setArrayEntries(Sport.getStringArray(getResources()));
    }

    manualDistance = findViewById(R.id.summary_manual_distance);
    manualDistance.setOnSetValueListener(
        new OnSetValueListener() {
          @Override
          public String preSetValue(String newValue) throws IllegalArgumentException {
            double dist = SafeParse.parseDouble(newValue, 0); // convert to meters
            headerData.put(DB.ACTIVITY.DISTANCE, dist);
            updateHeader(headerData, /* fromManualDistance= */ true);
            return newValue;
          }

          @Override
          public int preSetValue(int newValue) throws IllegalArgumentException {
            return newValue;
          }
        });
    notes = findViewById(R.id.notes_text);
    activityNameEdit = findViewById(R.id.activity_name_edit);
    workoutTypeSpinner = findViewById(R.id.workout_type_spinner);
    if (workoutTypeSpinner != null) {
      workoutTypeSpinner.setArrayEntries(new String[] {"Treino Livre", "Treino Intervalado", "Treino Estruturado"});
    }

    saveButton.setOnClickListener(saveButtonClick);
    uploadButton.setOnClickListener(uploadButtonClick);

    uploadButton.setVisibility(View.GONE);

    TabHost th = findViewById(R.id.tabhost);
    detailTabHost = th;
    th.setup();
    TabSpec tabSpec = th.newTabSpec("notes");
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(this, "Resumo"));
    tabSpec.setContent(R.id.tab_main);
    th.addTab(tabSpec);

    tabSpec = th.newTabSpec("laps");
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(this, getString(org.runnerup.common.R.string.Laps)));
    tabSpec.setContent(R.id.tab_lap);
    th.addTab(tabSpec);

    tabSpec = th.newTabSpec("blocks");
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(this, "Blocos"));
    tabSpec.setContent(R.id.tab_blocks);
    th.addTab(tabSpec);
    blocksTab = th.getTabWidget().getChildTabViewAt(th.getTabWidget().getChildCount() - 1);

    if (BuildConfig.OSMDROID_ENABLED || BuildConfig.MAPBOX_ENABLED) {
      tabSpec = th.newTabSpec("map");
      tabSpec.setIndicator(
          WidgetUtil.createHoloTabIndicator(this, getString(org.runnerup.common.R.string.Map)));
      tabSpec.setContent(R.id.tab_map);
      th.addTab(tabSpec);
      mapTab = th.getTabWidget().getChildTabViewAt(2);
    }

    tabSpec = th.newTabSpec("graph");
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(this, getString(org.runnerup.common.R.string.Graph)));
    tabSpec.setContent(R.id.tab_graph);
    th.addTab(tabSpec);
    // Get graph tab (cannot hardcode index due to optional map tab).
    int graphTabIndex = th.getTabWidget().getChildCount() - 1;
    graphTab = th.getTabWidget().getChildTabViewAt(graphTabIndex);

    tabSpec = th.newTabSpec("share");
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(this, getString(org.runnerup.common.R.string.Upload)));
    tabSpec.setContent(R.id.tab_upload);
    th.addTab(tabSpec);

    // Map and graph are intentionally initialized lazily. GPX imports can contain
    // thousands of GPS points; initializing both renderers while the Summary tab
    // is opening can make the Android main thread unresponsive (ANR).
    // Swipe navigation is handled by SwipeTabHost without changing the approved
    // tab layout or vertical scrolling behavior.

    th.setOnTabChangedListener(
        tabId -> {
          if ("map".equals(tabId)) {
            ensureMapWrapper(savedInstanceState);
            if (mapWrapper != null) mapWrapper.focusLap(mapLapIndex);
          } else if ("graph".equals(tabId)) {
            ensureGraphWrapper();
          }
        });

    View mapCenterButton = findViewById(R.id.map_center_button);
    View mapZoomInButton = findViewById(R.id.map_zoom_in_button);
    View mapZoomOutButton = findViewById(R.id.map_zoom_out_button);
    if (mapCenterButton != null) {
      mapCenterButton.setOnClickListener(v -> {
        ensureMapWrapper(savedInstanceState);
        if (mapWrapper != null) mapWrapper.centerOnRoute();
      });
    }
    if (mapZoomInButton != null) {
      mapZoomInButton.setOnClickListener(v -> {
        ensureMapWrapper(savedInstanceState);
        if (mapWrapper != null) mapWrapper.zoomIn();
      });
    }
    if (mapZoomOutButton != null) {
      mapZoomOutButton.setOnClickListener(v -> {
        ensureMapWrapper(savedInstanceState);
        if (mapWrapper != null) mapWrapper.zoomOut();
      });
    }

    fillHeaderData();
    requery();
    if (!workoutTypeStored && workoutTypeSpinner != null) {
      int inferredType = inferWorkoutTypeFromLaps();
      workoutTypeSpinner.setValue(Math.max(0, Math.min(2, inferredType)));
      updateWorkoutTypeLabel();
    }
    selectMapLap(0);

    lapModeKm = findViewById(R.id.lap_mode_km);
    lapModeTime = findViewById(R.id.lap_mode_time);
    lapPrimaryHeader = findViewById(R.id.lap_list_primary_header);
    if (lapModeKm != null) {
      lapModeKm.setOnClickListener(v -> setLapDisplayMode(false));
    }
    if (lapModeTime != null) {
      lapModeTime.setOnClickListener(v -> setLapDisplayMode(true));
    }
    setLapDisplayMode(false);

    {
      ListView lv = findViewById(R.id.laplist);
      LapListAdapter adapter = new LapListAdapter();
      adapters.add(adapter);
      lv.setAdapter(adapter);
    }
    {
      ListView lv = findViewById(R.id.report_list);
      ReportListAdapter adapter = new ReportListAdapter();
      adapters.add(adapter);
      lv.setAdapter(adapter);
    }

    getOnBackPressedDispatcher()
        .addCallback(
            this,
            new OnBackPressedCallback(true) {
              @Override
              public void handleOnBackPressed() {
                if (uploading) {
                  // Ignore while uploading
                  return;
                }
                if (mode == MODE_SAVE) {
                  resumeButtonClick.onClick(resumeButton);
                } else {
                  finish();
                }
              }
            });

    ViewCompat.setOnApplyWindowInsetsListener(
        rootView,
        new OnApplyWindowInsetsListener() {
          @NonNull
          @Override
          public WindowInsetsCompat onApplyWindowInsets(
              @NonNull View v, @NonNull WindowInsetsCompat windowInsets) {
            Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            int bottomPadding =
                saveButton.getVisibility() == View.VISIBLE
                        || uploadButton.getVisibility() == View.VISIBLE
                    ? insets.bottom
                    : 0;
            v.setPadding(insets.left, 0, insets.right, bottomPadding);

            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) v.getLayoutParams();
            mlp.topMargin = insets.top;

            View graphScroll = findViewById(R.id.tab_graph);
            if (graphScroll != null) {
              graphScroll.setPadding(
                  graphScroll.getPaddingLeft(),
                  graphScroll.getPaddingTop(),
                  graphScroll.getPaddingRight(),
                  Math.max(0, insets.bottom - bottomPadding));
            }
            return WindowInsetsCompat.CONSUMED;
          }
        });

    if (this.mode == MODE_SAVE) {
      resumeButton.setOnClickListener(resumeButtonClick);
      discardButton.setOnClickListener(discardButtonClick);
      setEdit(true);
    } else if (this.mode == MODE_DETAILS) {
      resumeButton.setVisibility(View.GONE);
      discardButton.setVisibility(View.GONE);
      setEdit(false);
    }
  }

  private void ensureMapWrapper(Bundle savedInstanceState) {
    if (mapWrapper != null || !(BuildConfig.OSMDROID_ENABLED || BuildConfig.MAPBOX_ENABLED)) {
      return;
    }
    Object mapView = findViewById(R.id.mapview);
    if (mapView == null) return;
    mapWrapper = new MapWrapper(this, mDB, mID, formatter, mapView, true);
    mapWrapper.onCreate(savedInstanceState);
  }

  private void ensureGraphWrapper() {
    if (graphWrapper != null) return;
    LinearLayout graphTabLayout = findViewById(R.id.graphview);
    LinearLayout hrzonesBarLayout = findViewById(R.id.hrzonesBarLayout);
    if (graphTabLayout == null || hrzonesBarLayout == null) return;
    boolean useDistanceAsX = !Sport.isWithoutGps(sport.getValueInt());
    graphWrapper =
        new GraphWrapper(
            this, graphTabLayout, hrzonesBarLayout, formatter, mDB, mID, useDistanceAsX);
  }

  private void setEdit(boolean value) {
    edit = value;
    if (value) {
      saveButton.setVisibility(View.VISIBLE);
    } else {
      saveButton.setVisibility(View.GONE);
    }
    WidgetUtil.setEditable(notes, value);
    WidgetUtil.setEditable(activityNameEdit, value);
    if (workoutTypeSpinner != null) workoutTypeSpinner.setEnabled(value);
    sport.setEnabled(value);
    View editIdentityControls = findViewById(R.id.edit_identity_controls);
    if (editIdentityControls != null) editIdentityControls.setVisibility(value ? View.VISIBLE : View.GONE);
    if (editControls != null) {
      editControls.setVisibility(value ? View.VISIBLE : View.GONE);
    }
    updateViewForSport(sport.getValueInt());
    ViewCompat.requestApplyInsets(rootView);
  }

  private void updateDetailSummary(double distance, long time) {
    if (detailDistanceValue == null) return;
    detailDistanceValue.setText(formatter.formatDistance(Formatter.Format.TXT_SHORT, (long) distance));
    detailTimeValue.setText(formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, time));
    if (time > 0 && distance > 0) {
      String pace = formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_LONG, distance / time);
      detailPaceValue.setText(pace);
      double kmh = (distance / 1000.0) / (time / 3600.0);
      detailSpeedValue.setText(String.format(Locale.getDefault(), "%.1f km/h\nVelocidade média", kmh));
    } else {
      detailPaceValue.setText("--:--/km");
      detailSpeedValue.setText("—\nVelocidade média");
    }
    detailCaloriesValue.setText("—");
    String dateTime = mStartTime > 0 ? formatter.formatDateTime(mStartTime) : "—";
    String distanceText = formatter.formatDistance(Formatter.Format.TXT_SHORT, (long) distance);
    String timeText = formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, time);
    String paceText = time > 0 && distance > 0
        ? formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_LONG, distance / time)
        : "--:--/km";
    String speedText = time > 0 && distance > 0
        ? String.format(Locale.getDefault(), "%.1f km/h", (distance / 1000.0) / (time / 3600.0))
        : "—";

    if (detailSportValue != null) detailSportValue.setText("Corrida");
    if (detailDateValue != null) detailDateValue.setText(dateTime);
    if (detailDistanceRowValue != null) detailDistanceRowValue.setText(distanceText);
    if (detailTimeRowValue != null) detailTimeRowValue.setText(timeText);
    if (detailPaceRowValue != null) detailPaceRowValue.setText(paceText);
    if (detailSpeedRowValue != null) detailSpeedRowValue.setText(speedText);
    if (detailElevationValue != null) detailElevationValue.setText("—");
    if (detailElevationRowValue != null) detailElevationRowValue.setText("—");
    if (detailCaloriesRowValue != null) detailCaloriesRowValue.setText("—");
    if (detailInfoValue != null) {
      detailInfoValue.setText(
          "Esporte\tCorrida\n" +
          "Data/hora\t" + dateTime + "\n" +
          "Distância\t" + distanceText + "\n" +
          "Duração\t" + timeText + "\n" +
          "Ritmo médio\t" + paceText);
    }
  }

  /**
   * Groups automatic kilometre/time laps back into the real prescribed Steps.
   * New records use PACECOACH_BLOCK_START as an unambiguous boundary. Older
   * records (before schema 34) are grouped by contiguous identical prescription
   * metadata as a best-effort migration for the Blocos screen.
   */
  private ContentValues[] buildWorkoutBlocks(ContentValues[] source) {
    workoutBlockParts = new ArrayList<>();
    if (source == null || source.length == 0) return new ContentValues[0];
    boolean hasExplicitBoundaries = false;
    for (ContentValues row : source) {
      if (row.containsKey(DB.LAP.PACECOACH_BLOCK_START)
          && row.getAsInteger(DB.LAP.PACECOACH_BLOCK_START) != null
          && row.getAsInteger(DB.LAP.PACECOACH_BLOCK_START) == DB.LAP.PACECOACH_SEGMENT_BLOCK_START) {
        hasExplicitBoundaries = true;
        break;
      }
    }

    ArrayList<ContentValues> grouped = new ArrayList<>();
    ContentValues current = null;
    ArrayList<ContentValues> currentParts = null;
    for (ContentValues row : source) {
      int marker = row.containsKey(DB.LAP.PACECOACH_BLOCK_START)
          && row.getAsInteger(DB.LAP.PACECOACH_BLOCK_START) != null
          ? row.getAsInteger(DB.LAP.PACECOACH_BLOCK_START) : 0;
      // Marker 2 is the post-prescription continuation lap. It contributes to
      // the activity total/splits, but it is not part of the planned structure.
      if (marker == DB.LAP.PACECOACH_SEGMENT_CONTINUATION) {
        current = null;
        currentParts = null;
        continue;
      }
      boolean startsBlock = row.containsKey(DB.LAP.PACECOACH_BLOCK_START)
          && row.getAsInteger(DB.LAP.PACECOACH_BLOCK_START) != null
          && row.getAsInteger(DB.LAP.PACECOACH_BLOCK_START) == DB.LAP.PACECOACH_SEGMENT_BLOCK_START;
      boolean sameLegacyBlock = !hasExplicitBoundaries && current != null
          && sameWorkoutPrescription(current, row);
      if (current == null || (hasExplicitBoundaries ? startsBlock : !sameLegacyBlock)) {
        current = new ContentValues(row);
        grouped.add(current);
        currentParts = new ArrayList<>();
        currentParts.add(row);
        workoutBlockParts.add(currentParts);
      } else {
        mergeWorkoutLap(current, row);
        if (currentParts != null) currentParts.add(row);
      }
    }
    return grouped.toArray(new ContentValues[0]);
  }

  private boolean sameWorkoutPrescription(ContentValues a, ContentValues b) {
    String[] keys = { DB.LAP.INTENSITY, DB.LAP.PLANNED_TIME, DB.LAP.PLANNED_DISTANCE,
        DB.LAP.PLANNED_PACE, DB.LAP.PLANNED_PACE_MIN, DB.LAP.PLANNED_PACE_MAX };
    boolean hasPrescription = false;
    for (String key : keys) {
      Object av = a.get(key);
      Object bv = b.get(key);
      if (av == null && bv == null) continue;
      hasPrescription = true;
      if (av == null || bv == null) return false;
      if (av instanceof Number && bv instanceof Number) {
        if (Math.abs(((Number) av).doubleValue() - ((Number) bv).doubleValue()) > 0.000001d) return false;
      } else if (!av.equals(bv)) {
        return false;
      }
    }
    return hasPrescription;
  }

  private double getDoubleOrZero(ContentValues values, String key) {
    if (values == null || !values.containsKey(key)) return 0d;
    Double value = values.getAsDouble(key);
    return value == null ? 0d : value;
  }

  private long getLongOrZero(ContentValues values, String key) {
    if (values == null || !values.containsKey(key)) return 0L;
    Long value = values.getAsLong(key);
    return value == null ? 0L : value;
  }

  private int getIntOrZero(ContentValues values, String key) {
    if (values == null || !values.containsKey(key)) return 0;
    Integer value = values.getAsInteger(key);
    return value == null ? 0 : value;
  }

  private void mergeWorkoutLap(ContentValues target, ContentValues addition) {
    double oldDistance = getDoubleOrZero(target, DB.LAP.DISTANCE);
    double addDistance = getDoubleOrZero(addition, DB.LAP.DISTANCE);
    long oldTime = getLongOrZero(target, DB.LAP.TIME);
    long addTime = getLongOrZero(addition, DB.LAP.TIME);
    target.put(DB.LAP.DISTANCE, oldDistance + addDistance);
    target.put(DB.LAP.TIME, oldTime + addTime);

    int oldHr = target.containsKey(DB.LAP.AVG_HR) ? target.getAsInteger(DB.LAP.AVG_HR) : 0;
    int addHr = addition.containsKey(DB.LAP.AVG_HR) ? addition.getAsInteger(DB.LAP.AVG_HR) : 0;
    if (oldHr > 0 && addHr > 0 && oldTime + addTime > 0) {
      target.put(DB.LAP.AVG_HR, Math.round((oldHr * oldTime + addHr * addTime) / (float) (oldTime + addTime)));
    } else if (addHr > 0) {
      target.put(DB.LAP.AVG_HR, addHr);
    }
    int oldMax = getIntOrZero(target, DB.LAP.MAX_HR);
    int addMax = getIntOrZero(addition, DB.LAP.MAX_HR);
    if (addMax > oldMax) target.put(DB.LAP.MAX_HR, addMax);
  }

  private void populateBlockDetails() {
    if (blockListContainer == null || workoutBlocks == null) return;
    blockListContainer.removeAllViews();
    if (blockTableContainer != null) blockTableContainer.removeAllViews();

    LayoutInflater inflater = LayoutInflater.from(this);
    int number = 1;
    int targetCount = 0;
    int achievedCount = 0;
    int slowerCount = 0;
    int fasterCount = 0;

    for (ContentValues lap : workoutBlocks) {
      double d = getDoubleOrZero(lap, DB.LAP.DISTANCE);
      long t = getLongOrZero(lap, DB.LAP.TIME);
      double actualPaceSecKm = t > 0 && d > 0 ? (t * 1000.0) / d : 0;
      double targetPaceMinSecKm = getDoubleOrZero(lap, DB.LAP.PLANNED_PACE_MIN) * 1000.0;
      double targetPaceMaxSecKm = getDoubleOrZero(lap, DB.LAP.PLANNED_PACE_MAX) * 1000.0;
      // Legacy activities only have PLANNED_PACE. Treat that as an exact target,
      // never as a fake range/midpoint. New Pace Coach laps carry the real range.
      if (targetPaceMinSecKm <= 0 || targetPaceMaxSecKm <= 0) {
        double legacyTarget = getDoubleOrZero(lap, DB.LAP.PLANNED_PACE) * 1000.0;
        targetPaceMinSecKm = legacyTarget;
        targetPaceMaxSecKm = legacyTarget;
      }
      boolean hasTarget = targetPaceMinSecKm > 0 && targetPaceMaxSecKm > 0;
      boolean achieved = hasTarget && actualPaceSecKm > 0
          && actualPaceSecKm >= targetPaceMinSecKm
          && actualPaceSecKm <= targetPaceMaxSecKm;
      boolean slower = hasTarget && actualPaceSecKm > targetPaceMaxSecKm;
      boolean faster = hasTarget && actualPaceSecKm < targetPaceMinSecKm;
      if (hasTarget) {
        targetCount++;
        if (achieved) {
          achievedCount++;
        } else if (slower) {
          slowerCount++;
        } else if (faster) {
          fasterCount++;
        }
      }

      View row = inflater.inflate(R.layout.laplist_row_coach, blockListContainer, false);
      TextView n = row.findViewById(R.id.block_number);
      android.widget.ImageView icon = row.findViewById(R.id.block_icon);
      View statusBar = row.findViewById(R.id.block_status_bar);
      TextView title = row.findViewById(R.id.block_title);
      TextView distance = row.findViewById(R.id.block_distance);
      TextView time = row.findViewById(R.id.block_time);
      TextView pace = row.findViewById(R.id.block_pace);
      TextView targetPace = row.findViewById(R.id.block_target_pace);
      TextView targetStatus = row.findViewById(R.id.block_target_status);
      TextView result = row.findViewById(R.id.block_hr);

      int intensityValue = lap.containsKey(DB.LAP.INTENSITY) ? lap.getAsInteger(DB.LAP.INTENSITY) : Intensity.ACTIVE.ordinal();
      Intensity intensity = Intensity.values()[Math.max(0, Math.min(intensityValue, Intensity.values().length - 1))];
      n.setText(String.valueOf(number));
      // Blocos represents prescription Steps, not the last partial kilometre.
      title.setText(getBlockTitle(intensity, number) + "  ›");
      final int blockIndex = number - 1;
      row.setClickable(true);
      row.setFocusable(true);
      row.setContentDescription("Ver parciais por quilômetro do bloco " + number + ": "
          + getBlockTitle(intensity, number));
      row.setOnClickListener(v -> showWorkoutBlockDetails(blockIndex));

      if (icon != null) {
        int iconRes;
        switch (intensity) {
          case WARMUP: iconRes = R.drawable.step_warmup; break;
          case RECOVERY: iconRes = R.drawable.step_recovery; break;
          case COOLDOWN: iconRes = R.drawable.step_cooldown; break;
          case RESTING: iconRes = R.drawable.step_resting; break;
          case REPEAT: iconRes = R.drawable.step_repeat; break;
          case ACTIVE:
          default: iconRes = R.drawable.step_active; break;
        }
        icon.setImageResource(iconRes);
      }
      distance.setText(formatDistanceKm(d));
      time.setText(formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, t));
      pace.setText(actualPaceSecKm > 0 ? formatPaceSecondsPerKm(actualPaceSecKm) + "/km" : "--:--/km");

      // The left status strip follows the approved visual hierarchy:
      // with a pace target it reports the result; without a target it keeps the
      // block type color so the workout structure remains immediately readable.
      int statusColor = blockTypeColor(intensity);
      String statusLabel = "Sem alvo definido";
      if (hasTarget && actualPaceSecKm > 0) {
        if (achieved) {
          statusColor = ContextCompat.getColor(this, R.color.coachFast);
          statusLabel = "Dentro do alvo";
        } else if (slower) {
          statusColor = ContextCompat.getColor(this, R.color.coachSlower);
          statusLabel = "Mais lento que o alvo";
        } else if (faster) {
          statusColor = ContextCompat.getColor(this, R.color.coachFaster);
          statusLabel = "Mais rápido que o alvo";
        }
      } else if (!hasTarget) {
        statusColor = ContextCompat.getColor(this, android.R.color.darker_gray);
        statusLabel = "Sem alvo definido";
      }

      targetPace.setText(hasTarget
          ? formatPaceRangeSecondsPerKm(targetPaceMinSecKm, targetPaceMaxSecKm)
          : "—");
      targetPace.setTextColor(ContextCompat.getColor(this, R.color.colorTextSecondary));
      targetStatus.setText(statusLabel);
      targetStatus.setTextColor(statusColor);
      if (statusBar != null) statusBar.setBackgroundColor(statusColor);
      if (pace != null) pace.setTextColor(statusColor);
      if (result != null) {
        result.setText(statusLabel);
        result.setTextColor(statusColor);
      }
      blockListContainer.addView(row);

      addBlockTableRow(number, title.getText().toString(), d, t, actualPaceSecKm,
          targetPaceMinSecKm, targetPaceMaxSecKm, hasTarget, achieved, faster, slower);
      number++;
    }

    buildWorkoutDiagram();

    if (blockSummary != null) {
      // Use the same official activity totals shown in the approved header.
      // Do not sum laps here: GPS/lap records may differ slightly from the activity totals.
      double totalDistance = headerData == null ? 0 : getDoubleOrZero(headerData, DB.ACTIVITY.DISTANCE);
      long totalTime = headerData == null ? 0 : getLongOrZero(headerData, DB.ACTIVITY.TIME);
      blockSummary.setText(workoutBlocks.length + " blocos  •  "
          + formatter.formatDistance(Formatter.Format.TXT_SHORT, (long) totalDistance)
          + "  •  " + formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, totalTime));
    }
    if (blockPerformanceValue != null) {
      if (targetCount > 0) {
        int successfulCount = achievedCount + fasterCount;
        int percent = Math.round((successfulCount * 100f) / targetCount);
        blockPerformanceValue.setText(percent + "%");
        if (blockPerformanceDetail != null) {
          blockPerformanceDetail.setText("Dentro ou mais rápido que o alvo");
        }
      } else {
        blockPerformanceValue.setText("—");
        if (blockPerformanceDetail != null) {
          blockPerformanceDetail.setText("Nenhum bloco possui Ritmo Alvo definido");
        }
      }
    }
    setPerformanceStat(R.id.block_perf_inside, targetCount > 0 ? achievedCount : 0,
        "Dentro do alvo");
    setPerformanceStat(R.id.block_perf_slow, targetCount > 0 ? slowerCount : 0,
        "Mais lento que o alvo");
    setPerformanceStat(R.id.block_perf_fast, targetCount > 0 ? fasterCount : 0,
        "Mais rápido que o alvo");
    setPerformanceStat(R.id.block_perf_total, targetCount, "Total de blocos (" + targetCount + " no cálculo)");
    setBlockDisplayMode(false);
  }

  /** Opens the automatic kilometer splits that make up one prescribed workout block. */
  private void showWorkoutBlockDetails(int blockIndex) {
    if (workoutBlocks == null || blockIndex < 0 || blockIndex >= workoutBlocks.length) return;
    ContentValues block = workoutBlocks[blockIndex];
    ArrayList<ContentValues> lapParts = blockIndex < workoutBlockParts.size()
        ? workoutBlockParts.get(blockIndex) : new ArrayList<>();
    ArrayList<ContentValues> gpsSplits = buildGpsSplitsForWorkoutBlock(lapParts, block);
    boolean hasKilometerBreakdown = gpsSplits != null && !gpsSplits.isEmpty();
    ArrayList<ContentValues> parts = hasKilometerBreakdown
        ? gpsSplits : new ArrayList<>(lapParts);
    if (parts.isEmpty()) parts.add(block);

    int intensityValue = getIntOrZero(block, DB.LAP.INTENSITY);
    Intensity intensity = Intensity.values()[Math.max(0,
        Math.min(intensityValue, Intensity.values().length - 1))];
    String title = getBlockTitle(intensity, blockIndex + 1);
    double totalDistance = getDoubleOrZero(block, DB.LAP.DISTANCE);
    long totalTime = getLongOrZero(block, DB.LAP.TIME);

    LinearLayout content = new LinearLayout(this);
    content.setOrientation(LinearLayout.VERTICAL);
    content.setPadding(dp(18), dp(8), dp(18), dp(4));

    TextView summary = new TextView(this);
    summary.setText(formatDistanceKm(totalDistance) + "  •  "
        + formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, totalTime)
        + (hasKilometerBreakdown
            ? "  •  " + parts.size() + (parts.size() == 1 ? " parcial" : " parciais")
            : "  •  detalhamento GPS indisponível"));
    summary.setTextColor(ContextCompat.getColor(this, R.color.colorTextSecondary));
    summary.setTextSize(12);
    summary.setPadding(0, 0, 0, dp(12));
    content.addView(summary);

    ScrollView scroll = new ScrollView(this);
    LinearLayout rows = new LinearLayout(this);
    rows.setOrientation(LinearLayout.VERTICAL);

    for (int i = 0; i < parts.size(); i++) {
      ContentValues part = parts.get(i);
      double distance = getDoubleOrZero(part, DB.LAP.DISTANCE);
      long time = getLongOrZero(part, DB.LAP.TIME);
      double actualPace = distance > 0 && time > 0 ? time * 1000.0d / distance : 0d;

      double[] target = resolveBlockPaceTarget(part, block);
      boolean hasTarget = target[0] > 0d && target[1] > 0d;
      String resultText = "Sem alvo definido";
      int resultColor = ContextCompat.getColor(this, R.color.colorTextSecondary);
      if (hasTarget && actualPace > 0d) {
        if (actualPace < target[0]) {
          resultText = "Mais rápido que o alvo";
          resultColor = ContextCompat.getColor(this, R.color.coachFaster);
        } else if (actualPace > target[1]) {
          resultText = "Mais lento que o alvo";
          resultColor = ContextCompat.getColor(this, R.color.coachSlower);
        } else {
          resultText = "Dentro do alvo";
          resultColor = ContextCompat.getColor(this, R.color.coachFast);
        }
      }

      boolean partial = distance > 0d && distance < 950d;
      String splitTitle;
      if (!hasKilometerBreakdown && parts.size() == 1) {
        splitTitle = "Total do bloco";
      } else {
        splitTitle = partial
            ? "Parcial " + (i + 1) + " · " + formatDistanceKm(distance)
            : "Km " + (i + 1);
      }
      String paceText = actualPace > 0d ? formatPaceSecondsPerKm(actualPace) + "/km" : "—";
      String targetText = hasTarget
          ? "Alvo: " + formatPaceRangeSecondsPerKm(target[0], target[1])
          : "Alvo: não definido";

      LinearLayout card = new LinearLayout(this);
      card.setOrientation(LinearLayout.VERTICAL);
      card.setPadding(dp(12), dp(9), dp(12), dp(9));
      card.setBackgroundResource(R.drawable.bg_coach_card);
      LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
          ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
      cardParams.bottomMargin = dp(8);
      rows.addView(card, cardParams);

      LinearLayout top = new LinearLayout(this);
      top.setGravity(android.view.Gravity.CENTER_VERTICAL);
      TextView label = new TextView(this);
      label.setText(splitTitle);
      label.setTextColor(ContextCompat.getColor(this, R.color.colorText));
      label.setTextSize(13);
      label.setTypeface(label.getTypeface(), android.graphics.Typeface.BOLD);
      top.addView(label, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
      TextView paceView = new TextView(this);
      paceView.setText(paceText);
      paceView.setTextColor(resultColor);
      paceView.setTextSize(14);
      paceView.setTypeface(paceView.getTypeface(), android.graphics.Typeface.BOLD);
      top.addView(paceView);
      card.addView(top);

      TextView metrics = new TextView(this);
      metrics.setText("Tempo: " + formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, time)
          + "    Distância: " + formatDistanceKm(distance));
      metrics.setTextColor(ContextCompat.getColor(this, R.color.colorTextSecondary));
      metrics.setTextSize(11);
      metrics.setPadding(0, dp(5), 0, dp(2));
      card.addView(metrics);

      TextView targetView = new TextView(this);
      targetView.setText(targetText + "  ·  " + resultText);
      targetView.setTextColor(resultColor);
      targetView.setTextSize(10);
      card.addView(targetView);
    }

    scroll.addView(rows);
    content.addView(scroll, new LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, dp(360)));

    new AlertDialog.Builder(this)
        .setTitle(title + " · parciais por km")
        .setView(content)
        .setPositiveButton("Fechar", (dialog, which) -> dialog.dismiss())
        .show();
  }

  /**
   * Rebuilds kilometer splits inside a prescribed block from its persisted GPS
   * samples. A structured step may have only one LAP row even when it spans
   * several kilometers, so the raw LAP rows alone are not a reliable drilldown.
   */
  private ArrayList<ContentValues> buildGpsSplitsForWorkoutBlock(
      ArrayList<ContentValues> lapParts, ContentValues block) {
    if (lapParts == null || lapParts.isEmpty()) return null;

    HashSet<Long> lapNumbers = new HashSet<>();
    for (ContentValues part : lapParts) {
      if (part.containsKey(DB.LAP.LAP) && part.getAsLong(DB.LAP.LAP) != null) {
        lapNumbers.add(part.getAsLong(DB.LAP.LAP));
      }
    }
    if (lapNumbers.isEmpty()) return null;

    // Read through LocationEntity rather than raw nullable columns. This keeps
    // older activities usable too: LocationEntity derives cumulative distance
    // and elapsed time from GPS coordinates when those persisted columns are
    // absent, and it is also the source used by the route map.
    ArrayList<ContentValues> allPoints = new ArrayList<>();
    LocationEntity.LocationList locations =
        new LocationEntity.LocationList(mDB, mID);
    try {
      for (LocationEntity location : locations) {
        ContentValues point = new ContentValues();
        if (location.getLap() != null) point.put(DB.LOCATION.LAP, location.getLap());
        if (location.getDistance() != null) point.put(DB.LOCATION.DISTANCE, location.getDistance());
        if (location.getElapsed() != null) point.put(DB.LOCATION.ELAPSED, location.getElapsed());
        if (location.getTime() != null) point.put(DB.LOCATION.TIME, location.getTime());
        allPoints.add(point);
      }
    } finally {
      locations.close();
    }

    int firstMatch = -1;
    int lastMatch = -1;
    for (int i = 0; i < allPoints.size(); i++) {
      Long lapNumber = allPoints.get(i).getAsLong(DB.LOCATION.LAP);
      if (lapNumber != null && lapNumbers.contains(lapNumber)) {
        if (firstMatch < 0) firstMatch = i;
        lastMatch = i;
      }
    }
    if (firstMatch < 0 || lastMatch <= firstMatch) return null;

    // Include the preceding location as the exact block-start anchor. The first
    // point tagged with the new LAP can arrive a GPS interval after the step
    // boundary, so starting at it would systematically undercount the block.
    int anchorIndex = Math.max(0, firstMatch - 1);
    ContentValues anchor = allPoints.get(anchorIndex);
    if (!anchor.containsKey(DB.LOCATION.DISTANCE)) return null;
    boolean useStoredElapsed = anchor.containsKey(DB.LOCATION.ELAPSED);
    if (useStoredElapsed) {
      for (int i = anchorIndex; i <= lastMatch; i++) {
        if (!allPoints.get(i).containsKey(DB.LOCATION.ELAPSED)) {
          useStoredElapsed = false;
          break;
        }
      }
    }
    String timeKey = useStoredElapsed ? DB.LOCATION.ELAPSED : DB.LOCATION.TIME;
    if (!anchor.containsKey(timeKey)) return null;

    double baseDistance = getDoubleOrZero(anchor, DB.LOCATION.DISTANCE);
    long baseTime = getLongOrZero(anchor, timeKey);
    ArrayList<ContentValues> result = new ArrayList<>();
    double previousDistance = 0d;
    long previousTimeSeconds = 0L;
    double lastBoundaryDistance = 0d;
    long lastBoundaryTimeSeconds = 0L;
    int nextBoundary = 1;

    for (int i = anchorIndex + 1; i <= lastMatch; i++) {
      ContentValues point = allPoints.get(i);
      if (!lapNumbers.contains(point.getAsLong(DB.LOCATION.LAP))) continue;
      if (!point.containsKey(DB.LOCATION.DISTANCE) || !point.containsKey(timeKey)) continue;

      double currentDistance = Math.max(previousDistance,
          getDoubleOrZero(point, DB.LOCATION.DISTANCE) - baseDistance);
      long rawTime = getLongOrZero(point, timeKey);
      long currentTimeSeconds = Math.max(previousTimeSeconds,
          Math.max(0L, rawTime - baseTime) / 1000L);

      while (currentDistance >= nextBoundary * 1000.0d
          && currentDistance > previousDistance) {
        double boundaryDistance = nextBoundary * 1000.0d;
        double fraction = (boundaryDistance - previousDistance)
            / (currentDistance - previousDistance);
        fraction = Math.max(0d, Math.min(1d, fraction));
        long boundaryTime = previousTimeSeconds + Math.round(
            (currentTimeSeconds - previousTimeSeconds) * fraction);
        ContentValues split = new ContentValues();
        split.put(DB.LAP.DISTANCE, 1000.0d);
        split.put(DB.LAP.TIME, Math.max(0L, boundaryTime - lastBoundaryTimeSeconds));
        result.add(split);
        lastBoundaryDistance = boundaryDistance;
        lastBoundaryTimeSeconds = boundaryTime;
        nextBoundary++;
      }
      previousDistance = currentDistance;
      previousTimeSeconds = currentTimeSeconds;
    }

    double remainderDistance = Math.max(0d, previousDistance - lastBoundaryDistance);
    long remainderTime = Math.max(0L, previousTimeSeconds - lastBoundaryTimeSeconds);
    if (remainderDistance > 0.5d && remainderDistance < 1000.0d) {
      ContentValues split = new ContentValues();
      split.put(DB.LAP.DISTANCE, remainderDistance);
      split.put(DB.LAP.TIME, remainderTime);
      result.add(split);
    }
    if (result.isEmpty()) return null;

    // Reconcile small sampling differences against the official LAP totals so
    // the displayed kilometer pieces sum to the block saved in the activity.
    double expectedDistance = getDoubleOrZero(block, DB.LAP.DISTANCE);
    long expectedTime = getLongOrZero(block, DB.LAP.TIME);
    double calculatedDistance = 0d;
    long calculatedTime = 0L;
    for (ContentValues split : result) {
      calculatedDistance += getDoubleOrZero(split, DB.LAP.DISTANCE);
      calculatedTime += getLongOrZero(split, DB.LAP.TIME);
    }
    double distanceDifference = expectedDistance - calculatedDistance;
    long timeDifference = expectedTime - calculatedTime;
    boolean distanceClose = expectedDistance <= 0d
        || Math.abs(distanceDifference) <= Math.max(100d, expectedDistance * 0.10d);
    boolean timeClose = expectedTime <= 0L
        || Math.abs(timeDifference) <= Math.max(30L, Math.round(expectedTime * 0.10d));
    if (!distanceClose || !timeClose) return null;

    ContentValues last = result.get(result.size() - 1);
    if (expectedDistance > 0d) {
      last.put(DB.LAP.DISTANCE, Math.max(0d,
          getDoubleOrZero(last, DB.LAP.DISTANCE) + distanceDifference));
    }
    if (expectedTime > 0L) {
      last.put(DB.LAP.TIME, Math.max(0L,
          getLongOrZero(last, DB.LAP.TIME) + timeDifference));
    }
    return result;
  }

  /** Returns pace target bounds in seconds/km, preferring a lap's own target. */
  private double[] resolveBlockPaceTarget(ContentValues lap, ContentValues block) {
    double min = getDoubleOrZero(lap, DB.LAP.PLANNED_PACE_MIN) * 1000.0d;
    double max = getDoubleOrZero(lap, DB.LAP.PLANNED_PACE_MAX) * 1000.0d;
    if (min <= 0d || max <= 0d) {
      double legacy = getDoubleOrZero(lap, DB.LAP.PLANNED_PACE) * 1000.0d;
      min = legacy;
      max = legacy;
    }
    if (min <= 0d || max <= 0d) {
      min = getDoubleOrZero(block, DB.LAP.PLANNED_PACE_MIN) * 1000.0d;
      max = getDoubleOrZero(block, DB.LAP.PLANNED_PACE_MAX) * 1000.0d;
      if (min <= 0d || max <= 0d) {
        double legacy = getDoubleOrZero(block, DB.LAP.PLANNED_PACE) * 1000.0d;
        min = legacy;
        max = legacy;
      }
    }
    return new double[] {min, max};
  }

  private void buildWorkoutDiagram() {
    // Resolve these views locally so this drawing helper never depends on stale field state.
    blockWorkoutDiagram = findViewById(R.id.block_workout_diagram);
    blockWorkoutLabels = findViewById(R.id.block_workout_labels);
    blockWorkoutLegend = findViewById(R.id.block_workout_legend);
    if (blockWorkoutDiagram == null || blockWorkoutLabels == null || blockWorkoutLegend == null || workoutBlocks == null) return;
    blockWorkoutDiagram.removeAllViews();
    blockWorkoutLabels.removeAllViews();
    blockWorkoutLegend.removeAllViews();

    final int gap = dp(3);
    final int[] colors = new int[workoutBlocks.length];
    final String[] names = new String[workoutBlocks.length];
    final double[] distances = new double[workoutBlocks.length];
    for (int i = 0; i < workoutBlocks.length; i++) {
      int intensityValue = workoutBlocks[i].containsKey(DB.LAP.INTENSITY)
          ? workoutBlocks[i].getAsInteger(DB.LAP.INTENSITY) : Intensity.ACTIVE.ordinal();
      Intensity intensity = Intensity.values()[Math.max(0,
          Math.min(intensityValue, Intensity.values().length - 1))];
      colors[i] = blockTypeColor(intensity);
      names[i] = getBlockTitle(intensity, i + 1);
      distances[i] = workoutBlocks[i].containsKey(DB.LAP.DISTANCE) ? workoutBlocks[i].getAsDouble(DB.LAP.DISTANCE) : 0;

      View bar = new View(this);
      GradientDrawable gd = new GradientDrawable();
      gd.setColor(colors[i]);
      gd.setCornerRadius(dp(4));
      bar.setBackground(gd);
      LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(30), 1f);
      if (i < workoutBlocks.length - 1) bp.rightMargin = gap;
      blockWorkoutDiagram.addView(bar, bp);
    }

    // The approved design keeps the explanatory labels beneath the workout strip.
    addDiagramLabel(blockWorkoutLabels, names.length > 0 ? names[0] : "", distances.length > 0 ? distances[0] : 0, 1f);
    String middle = "";
    double middleDistance = 0;
    int middleCount = 0;
    for (int i = 0; i < names.length; i++) {
      if ("Intervalo".equals(names[i]) || "Recuperação".equals(names[i])) {
        middleDistance += distances[i];
        middleCount++;
      }
    }
    if (middleCount > 0) {
      int repeats = 0;
      for (String n : names) if ("Intervalo".equals(n)) repeats++;
      middle = repeats > 0 ? repeats + " × (Intervalo + Recuperação)" : "Treino principal";
    }
    addDiagramLabel(blockWorkoutLabels, middle, middleDistance, 1.8f);
    addDiagramLabel(blockWorkoutLabels, names.length > 1 ? names[names.length - 1] : "", distances.length > 1 ? distances[distances.length - 1] : 0, 1f);

    addLegendItem(blockWorkoutLegend, "Aquecimento", blockTypeColor(Intensity.WARMUP));
    addLegendItem(blockWorkoutLegend, "Intervalo", blockTypeColor(Intensity.ACTIVE));
    addLegendItem(blockWorkoutLegend, "Recuperação", blockTypeColor(Intensity.RECOVERY));
    addLegendItem(blockWorkoutLegend, "Descanso Off", blockTypeColor(Intensity.RESTING));
    addLegendItem(blockWorkoutLegend, "Desaquecimento", blockTypeColor(Intensity.COOLDOWN));
  }

  private void addDiagramLabel(LinearLayout parent, String title, double meters, float weight) {
    LinearLayout box = new LinearLayout(this);
    box.setOrientation(LinearLayout.VERTICAL);
    box.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
    TextView t = new TextView(this);
    t.setText(title);
    t.setTextColor(android.graphics.Color.WHITE);
    t.setTextSize(10);
    t.setSingleLine(true);
    TextView d = new TextView(this);
    d.setText(formatDistanceKm(meters));
    d.setTextColor(ContextCompat.getColor(this, R.color.colorTextSecondary));
    d.setTextSize(10);
    d.setSingleLine(true);
    box.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    box.addView(d, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    parent.addView(box, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight));
  }

  private void addLegendItem(LinearLayout parent, String label, int color) {
    LinearLayout item = new LinearLayout(this);
    item.setGravity(android.view.Gravity.CENTER_VERTICAL);
    View dot = new View(this);
    GradientDrawable gd = new GradientDrawable();
    gd.setColor(color);
    gd.setCornerRadius(dp(8));
    dot.setBackground(gd);
    TextView text = new TextView(this);
    text.setText(label);
    text.setTextColor(ContextCompat.getColor(this, R.color.colorTextSecondary));
    text.setTextSize(9);
    text.setSingleLine(true);
    item.addView(dot, new LinearLayout.LayoutParams(dp(10), dp(10)));
    LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    tp.leftMargin = dp(4);
    item.addView(text, tp);
    parent.addView(item, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
  }

  private int blockTypeColor(Intensity intensity) {
    // Workout-type colors are structural colors and must never be confused with
    // performance-result colors (green/yellow/red).
    switch (intensity) {
      case WARMUP: return Color.rgb(255, 138, 0);      // orange
      case RECOVERY: return Color.rgb(176, 108, 255);  // purple
      case COOLDOWN: return Color.rgb(92, 107, 192); // indigo
      case RESTING: return Color.rgb(0, 199, 217);    // cyan
      case REPEAT: return Color.rgb(160, 120, 220);   // secondary purple
      case ACTIVE:
      default: return Color.rgb(45, 155, 240);        // blue
    }
  }

  private int dp(int value) {
    return Math.round(value * getResources().getDisplayMetrics().density);
  }

  private String formatDistanceKm(double meters) {
    double km = Math.max(0.0, meters) / 1000.0;
    return String.format(Locale.getDefault(), "%.2f km", km).replace('.', ',');
  }

  private void setPerformanceStat(int id, int value, String label) {
    TextView v = findViewById(id);
    if (v == null) return;
    v.setText(value + "\n" + label);
  }

  private String formatPaceRangeSecondsPerKm(double minSecKm, double maxSecKm) {
    if (minSecKm <= 0 || maxSecKm <= 0) return "—";
    if (Math.abs(minSecKm - maxSecKm) < 0.5) {
      return formatPaceSecondsPerKm(minSecKm) + "/km";
    }
    // The column already identifies the unit as pace; keep the complete range
    // visible on narrow screens instead of spending the last pixels on "/km".
    return formatPaceSecondsPerKm(minSecKm) + " – " + formatPaceSecondsPerKm(maxSecKm);
  }

  private void addBlockTableRow(int number, String title, double distance, long time,
      double actualPaceSecKm, double targetPaceMinSecKm, double targetPaceMaxSecKm,
      boolean hasTarget, boolean achieved, boolean faster, boolean slower) {
    if (blockTableContainer == null) return;
    LinearLayout row = new LinearLayout(this);
    row.setOrientation(LinearLayout.HORIZONTAL);
    row.setGravity(android.view.Gravity.CENTER_VERTICAL);
    row.setPadding(6, 9, 6, 9);
    if (number % 2 == 0) row.setBackgroundResource(R.drawable.bg_coach_list_row);

    addTableCell(row, String.valueOf(number), 0.35f, true);
    addTableCell(row, title, 1.15f, false);
    addTableCell(row, formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, time), 0.8f, false);
    addTableCell(row, formatter.formatDistance(Formatter.Format.TXT_LONG, (long) distance), 0.9f, false);
    addTableCell(row, actualPaceSecKm > 0 ? formatPaceSecondsPerKm(actualPaceSecKm) : "—", 0.9f, false);
    addTableCell(row, hasTarget ? formatPaceRangeSecondsPerKm(targetPaceMinSecKm, targetPaceMaxSecKm) : "—", 1.0f, false);
    addTableCell(row, hasTarget ? (achieved ? "Dentro do alvo" : (faster ? "Mais rápido" : (slower ? "Mais lento" : "—"))) : "Sem alvo", 1.0f, false);
    blockTableContainer.addView(row);
  }

  private void addTableCell(LinearLayout row, String text, float weight, boolean bold) {
    TextView v = new TextView(this);
    v.setText(text);
    v.setTextColor(ContextCompat.getColor(this, bold ? android.R.color.white : R.color.colorTextSecondary));
    v.setTextSize(11);
    if (bold) v.setTypeface(v.getTypeface(), android.graphics.Typeface.BOLD);
    v.setPadding(4, 0, 4, 0);
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
    row.addView(v, lp);
  }

  private void setBlockDisplayMode(boolean table) {
    // The approved Blocks interface is now a single fixed view.
    // Keep the old table container hidden so legacy data/code remains harmless.
    if (blockListContainer != null) blockListContainer.setVisibility(View.VISIBLE);
    if (blockListHeader != null) blockListHeader.setVisibility(View.VISIBLE);
    if (blockTableContainer != null) blockTableContainer.setVisibility(View.GONE);
  }

  private int inferWorkoutTypeFromLaps() {
    boolean interval = false;
    if (laps != null) {
      for (ContentValues lap : laps) {
        if (!lap.containsKey(DB.LAP.INTENSITY)) continue;
        int value = lap.getAsInteger(DB.LAP.INTENSITY);
        if (value == Intensity.WARMUP.ordinal()
            || value == Intensity.COOLDOWN.ordinal()
            || value == Intensity.RECOVERY.ordinal()
            || value == Intensity.REPEAT.ordinal()
            || value == Intensity.RESTING.ordinal()) {
          interval = true;
          break;
        }
      }
      if (laps.length > 1) interval = true;
    }
    return interval ? 1 : 0;
  }

  private String workoutTypeLabel(int type) {
    if (type == 1) return "Treino Intervalado";
    if (type == 2) return "Treino Estruturado";
    return "Treino Livre";
  }

  private void updateWorkoutTypeLabel() {
    if (workoutTypeValue == null) return;
    int type = 0;
    if (workoutTypeSpinner != null) {
      try { type = workoutTypeSpinner.getValueInt(); } catch (Exception ignored) { type = 0; }
    } else {
      type = inferWorkoutTypeFromLaps();
    }
    workoutTypeValue.setText(workoutTypeLabel(type));
  }

  private String formatElapsedTimeShort(long seconds) {
    long safe = Math.max(0L, seconds);
    long hours = safe / 3600L;
    long minutes = (safe % 3600L) / 60L;
    long secs = safe % 60L;
    if (hours > 0) {
      return String.format(Locale.getDefault(), "%dh%02d", hours, minutes);
    }
    return String.format(Locale.getDefault(), "%02d:%02d", minutes, secs);
  }

  private String formatPaceSecondsPerKm(double secondsPerKm) {
    if (secondsPerKm <= 0 || Double.isNaN(secondsPerKm) || Double.isInfinite(secondsPerKm)) {
      return "--:--";
    }
    long totalSeconds = Math.round(secondsPerKm);
    long minutes = totalSeconds / 60;
    long seconds = totalSeconds % 60;
    return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
  }

  private String getBlockTitle(Intensity intensity, int number) {
    switch (intensity) {
      case WARMUP: return "Aquecimento";
      case COOLDOWN: return "Desaquecimento";
      case RECOVERY: return "Recuperação";
      case RESTING: return "Descanso Off";
      case REPEAT: return "Repetição";
      case ACTIVE: return "Intervalo";
      default: return "Bloco " + number;
    }
  }

  private void updateViewForSport(int sportValue) {
    if (edit && Sport.hasManualDistance(sportValue)) {
      manualDistance.setVisibility(View.VISIBLE);
      manualDistance.setEnabled(true);
    } else {
      manualDistance.setVisibility(View.GONE);
    }

    if (mapTab != null) {
      if (Sport.isWithoutGps(sportValue)) {
        mapTab.setVisibility(View.GONE);
      } else {
        mapTab.setVisibility(View.VISIBLE);
      }
    }
    if (graphWrapper != null) {
      boolean use_distance_as_x = !Sport.isWithoutGps(sportValue);
      graphWrapper.setUseDistanceAsX(use_distance_as_x);
    }
  }

  private void setUploadVisibility() {
    boolean enabled = !pendingSynchronizers.isEmpty();
    if (enabled) {
      uploadButton.setVisibility(View.VISIBLE);
    } else {
      uploadButton.setVisibility(View.GONE);
    }
    ViewCompat.requestApplyInsets(rootView);
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.detail_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    int id = item.getItemId();
    if (id == android.R.id.home) {
      finish();
      return true;
    } else if (id == R.id.menu_delete_activity) {
      deleteButtonClick.onClick(null);
    } else if (id == R.id.menu_export_activity) {
      exportActivityFile();
    } else if (id == R.id.menu_edit_activity) {
      if (!edit) {
        setEdit(true);
        notes.requestFocus();
        requery();
      }
    } else if (id == R.id.menu_recompute_activity) {
      new AlertDialog.Builder(this)
          .setTitle(org.runnerup.common.R.string.Recompute_activity)
          .setMessage(org.runnerup.common.R.string.Are_you_sure)
          .setPositiveButton(
              org.runnerup.common.R.string.Yes,
              (dialog, which) -> {
                dialog.dismiss();
                new ActivityCleaner().recompute(mDB, mID);
                requery();
                fillHeaderData();
                finish();
              })
          .setNegativeButton(org.runnerup.common.R.string.No, (dialog, which) -> dialog.dismiss())
          .show();
    } else if (id == R.id.menu_simplify_path) {
      new AlertDialog.Builder(this)
          .setTitle(org.runnerup.common.R.string.path_simplification_menu)
          .setMessage(org.runnerup.common.R.string.Are_you_sure)
          .setPositiveButton(
              org.runnerup.common.R.string.Yes,
              (dialog, which) -> {
                dialog.dismiss();
                PathSimplifier simplifier = new PathSimplifier(this);
                ArrayList<String> ids = simplifier.getNoisyLocationIDsAsStrings(mDB, mID);
                ActivityCleaner.deleteLocations(mDB, ids);
                new ActivityCleaner().recompute(mDB, mID);
                requery();
                fillHeaderData();
                finish();
              })
          .setNegativeButton(org.runnerup.common.R.string.No, (dialog, which) -> dialog.dismiss())
          .show();
    }

    return true;
  }

  @Override
  public void onResume() {
    super.onResume();
    if (mapWrapper != null) {
      mapWrapper.onResume();
    }
  }

  @Override
  public void onStart() {
    super.onStart();
    if (mapWrapper != null) {
      mapWrapper.onStart();
    }
  }

  @Override
  public void onStop() {
    super.onStop();
    if (mapWrapper != null) {
      mapWrapper.onStop();
    }
  }

  @Override
  public void onPause() {
    super.onPause();
    if (mapWrapper != null) {
      mapWrapper.onPause();
    }
  }

  @Override
  public void onSaveInstanceState(@NonNull Bundle outState) {
    super.onSaveInstanceState(outState);
    if (mapWrapper != null) {
      mapWrapper.onSaveInstanceState(outState);
    }
  }

  @Override
  public void onLowMemory() {
    super.onLowMemory();
    if (mapWrapper != null) {
      mapWrapper.onLowMemory();
    }
  }

  @Override
  public void onDestroy() {
    super.onDestroy();
    DBHelper.closeDB(mDB);
    syncManager.close();
    if (graphWrapper != null) {
      graphWrapper.onDestroy();
      graphWrapper = null;
    }
    if (mapWrapper != null) {
      mapWrapper.onDestroy();
    }
  }

  private void requery() {
    {
      /*
       * Laps
       */
      String[] from =
          new String[] {
            "_id",
            DB.LAP.LAP,
            DB.LAP.INTENSITY,
            DB.LAP.TIME,
            DB.LAP.DISTANCE,
            DB.LAP.PLANNED_TIME,
            DB.LAP.PLANNED_DISTANCE,
            DB.LAP.PLANNED_PACE,
            DB.LAP.PLANNED_PACE_MIN,
            DB.LAP.PLANNED_PACE_MAX,
            DB.LAP.PACECOACH_BLOCK_START,
            DB.LAP.AVG_HR
          };

      Cursor c =
          mDB.query(
              DB.LAP.TABLE,
              from,
              DB.LAP.ACTIVITY + " == " + mID + " AND " + DB.LAP.PACECOACH_BLOCK_START + " != " + DB.LAP.PACECOACH_SEGMENT_CONTINUATION,
              null,
              null,
              null,
              "_id",
              null);

      laps = DBHelper.toArray(c);
      c.close();
      workoutBlocks = buildWorkoutBlocks(laps);

      // The GPX importer stores elevation and heart-rate on the GPS points.
      // Build per-lap values here so the Voltas tab can present the same
      // visual information even when the LAP table itself has no HR/elevation.
      lapElevation = new double[laps.length];
      lapHrAverage = new int[laps.length];
      double[] firstElevation = new double[laps.length];
      double[] lastElevation = new double[laps.length];
      boolean[] hasElevation = new boolean[laps.length];
      long[] hrSum = new long[laps.length];
      int[] hrCount = new int[laps.length];

      String[] locationColumns = {
          DB.LOCATION.LAP, DB.LOCATION.ALTITUDE, DB.LOCATION.HR, DB.LOCATION.TIME,
          DB.LOCATION.DISTANCE, DB.LOCATION.ELAPSED, DB.LOCATION.TYPE};
      Cursor locationCursor = mDB.query(
          DB.LOCATION.TABLE,
          locationColumns,
          DB.LOCATION.ACTIVITY + " == " + mID,
          null,
          null,
          null,
          DB.LOCATION.LAP + " asc, " + DB.LOCATION.TIME + " asc",
          null);
      while (locationCursor.moveToNext()) {
        int lapIndex = locationCursor.isNull(0) ? -1 : locationCursor.getInt(0);
        if (lapIndex < 0 || lapIndex >= laps.length) continue;

        if (!locationCursor.isNull(1)) {
          double elevation = locationCursor.getDouble(1);
          if (!hasElevation[lapIndex]) {
            firstElevation[lapIndex] = elevation;
            hasElevation[lapIndex] = true;
          }
          lastElevation[lapIndex] = elevation;
        }
        if (!locationCursor.isNull(2)) {
          int hr = locationCursor.getInt(2);
          if (hr > 0) {
            hrSum[lapIndex] += hr;
            hrCount[lapIndex]++;
          }
        }
      }
      // Build the Voltas tab from GPS/activity points. The LAP table is workout-
      // block based for structured workouts, so using it here would make Voltas
      // show blocks instead of kilometres.
      locationCursor.close();
      buildActivitySplits();
      // The map selector must be populated after the activity kilometer splits
      // are rebuilt; the LAP table may contain structured workout blocks.
      selectMapLap(mapLapIndex);

      lapHrPresent = false;
      lapElevationPresent = false;
      for (int i = 0; i < laps.length; i++) {
        if (hasElevation[i]) {
          lapElevation[i] = lastElevation[i] - firstElevation[i];
          lapElevationPresent = true;
        }
        if (hrCount[i] > 0) {
          lapHrAverage[i] = Math.round((float) hrSum[i] / hrCount[i]);
          lapHrPresent = true;
        } else if (laps[i].containsKey(DB.LAP.AVG_HR) && laps[i].getAsInteger(DB.LAP.AVG_HR) > 0) {
          lapHrAverage[i] = laps[i].getAsInteger(DB.LAP.AVG_HR);
          lapHrPresent = true;
        }
      }

      TextView lapElevationHeader = findViewById(R.id.lap_list_elevation_header);
      TextView lapHrHeader = findViewById(R.id.lap_list_hr_header);
      if (lapElevationHeader != null) lapElevationHeader.setVisibility(splitElevationPresent ? View.VISIBLE : View.GONE);
      if (lapHrHeader != null) lapHrHeader.setVisibility(splitHrPresent ? View.VISIBLE : View.GONE);

      populateBlockDetails();
      updateWorkoutTypeLabel();
    }

    {
      /*
       * Accounts/reports
       */
      String sql =
          "SELECT DISTINCT "
              + "  acc._id, "
              + ("  acc." + DB.ACCOUNT.NAME + ", ")
              + ("  acc." + DB.ACCOUNT.FLAGS + ", ")
              + ("  acc." + DB.ACCOUNT.AUTH_CONFIG + ", ")
              + ("  acc." + DB.ACCOUNT.FORMAT + ", ")
              + ("  rep._id as repid, ")
              + ("  rep." + DB.EXPORT.ACCOUNT + ", ")
              + ("  rep." + DB.EXPORT.ACTIVITY + ", ")
              + ("  rep." + DB.EXPORT.EXTERNAL_ID + ", ")
              + ("  rep." + DB.EXPORT.STATUS)
              + (" FROM " + DB.ACCOUNT.TABLE + " acc ")
              + (" LEFT OUTER JOIN " + DB.EXPORT.TABLE + " rep ")
              + (" ON ( acc._id = rep." + DB.EXPORT.ACCOUNT)
              + ("     AND rep." + DB.EXPORT.ACTIVITY + " = " + mID + " )");

      Cursor c = mDB.rawQuery(sql, null);
      alreadySynched.clear();
      synchedExternalId.clear();
      pendingSynchronizers.clear();
      reports.clear();
      if (c.moveToFirst()) {
        do {
          ContentValues tmp = DBHelper.get(c);
          Synchronizer synchronizer = syncManager.add(tmp);
          // Note: Show all configured accounts (also those are not currently enabled)
          // Uploaded but removed accounts are not displayed
          if (synchronizer == null
              || !synchronizer.checkSupport(Feature.UPLOAD)
              || !synchronizer.isConfigured()) {
            continue;
          }

          String name = tmp.getAsString(DB.ACCOUNT.NAME);
          reports.add(tmp);
          if (tmp.containsKey("repid")) {
            alreadySynched.add(name);
            if (tmp.containsKey(DB.EXPORT.STATUS)
                && tmp.getAsInteger(DB.EXPORT.STATUS)
                    == Synchronizer.ExternalIdStatus.getInt(Synchronizer.ExternalIdStatus.OK)) {
              String url =
                  syncManager
                      .getSynchronizerByName(name)
                      .getActivityUrl(synchedExternalId.get(name));
              if (url != null) {
                synchedExternalId.put(name, tmp.getAsString(DB.EXPORT.EXTERNAL_ID));
              }
            }
          } else if (tmp.containsKey(DB.ACCOUNT.FLAGS)
              && Bitfield.test(tmp.getAsLong(DB.ACCOUNT.FLAGS), DB.ACCOUNT.FLAG_UPLOAD)) {
            pendingSynchronizers.add(name);
          }
        } while (c.moveToNext());
      }
      c.close();
    }

    if (mode == MODE_DETAILS) {
      setUploadVisibility();
    }

    for (BaseAdapter a : adapters) {
      a.notifyDataSetChanged();
    }
  }

  private void fillHeaderData() {
    // Fields from the database (projection)
    // Must include the _id column for the adapter to work
    String[] from =
        new String[] {
          DB.ACTIVITY.START_TIME,
          DB.ACTIVITY.NAME,
          DB.ACTIVITY.DISTANCE,
          DB.ACTIVITY.TIME,
          DB.ACTIVITY.COMMENT,
          DB.ACTIVITY.SPORT,
          DB.ACTIVITY.WORKOUT_TYPE
        };

    Cursor c = mDB.query(DB.ACTIVITY.TABLE, from, "_id == " + mID, null, null, null, null, null);
    c.moveToFirst();
    ContentValues tmp = DBHelper.get(c);
    c.close();

    if (tmp.containsKey(DB.ACTIVITY.NAME) && activityNameValue != null) {
      String activityName = tmp.getAsString(DB.ACTIVITY.NAME);
      String safeName = activityName == null || activityName.trim().isEmpty() ? "Corrida" : activityName.trim();
      activityNameValue.setText(safeName);
      if (activityNameEdit != null) activityNameEdit.setText(safeName);
    }

    int storedWorkoutType = -1;
    workoutTypeStored = tmp.containsKey(DB.ACTIVITY.WORKOUT_TYPE) && tmp.getAsInteger(DB.ACTIVITY.WORKOUT_TYPE) != null;
    if (workoutTypeStored) {
      storedWorkoutType = tmp.getAsInteger(DB.ACTIVITY.WORKOUT_TYPE);
    } else {
      storedWorkoutType = 0;
    }
    if (workoutTypeSpinner != null) {
      workoutTypeSpinner.setValue(Math.max(0, Math.min(2, storedWorkoutType)));
    }
    updateWorkoutTypeLabel();

    if (tmp.containsKey(DB.ACTIVITY.START_TIME)) {
      long st = tmp.getAsLong(DB.ACTIVITY.START_TIME);
      mStartTime = st;
      // Keep the compact activity header with the date/time title.
      if (getSupportActionBar() != null) getSupportActionBar().setTitle(formatter.formatDateTime(st));
    }

    if (tmp.containsKey(DB.ACTIVITY.COMMENT)) {
      notes.setText(tmp.getAsString(DB.ACTIVITY.COMMENT));
    }

    headerData = tmp;
    updateHeader(tmp, /* fromManualDistance= */ false);
  }

  private void updateHeader(ContentValues data, boolean fromManualDistance) {
    double d = 0;
    if (data.containsKey(DB.ACTIVITY.DISTANCE)) {
      d = data.getAsDouble(DB.ACTIVITY.DISTANCE);
      String s = formatter.formatDistance(Formatter.Format.TXT_SHORT, (long) d);
      if (activityDistance != null) activityDistance.setText(s);
      if (!fromManualDistance) {
        /**
         * IF !fromManualDistance (e.g. from database) update the manual distance field in case (if
         * it might be needed) ELSE fromManualDistance=true e.g. from spinner, don't update or else
         * it will recurse
         */
        int distance = (int) d;
        manualDistance.setValue(Long.toString(distance));
        manualDistance.setValue(distance);
      }
    } else {
      if (activityDistance != null) activityDistance.setText("");
    }

    long t = 0;
    if (data.containsKey(DB.ACTIVITY.TIME)) {
      t = data.getAsInteger(DB.ACTIVITY.TIME);
      if (activityTime != null) activityTime.setText(formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, t));
    } else {
      if (activityTime != null) activityTime.setText("");
    }

    if (t != 0) {
      if (activityPace != null) activityPace.setVisibility(View.VISIBLE);
      if (activityPaceSeparator != null) activityPaceSeparator.setVisibility(View.VISIBLE);
      if (activityPace != null) {
        activityPace.setText(
            formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_LONG, d / t));
      }
    } else {
      if (activityPace != null) activityPace.setVisibility(View.GONE);
      if (activityPaceSeparator != null) activityPaceSeparator.setVisibility(View.GONE);
    }

    updateDetailSummary(d, t);
    if (data.containsKey(DB.ACTIVITY.SPORT)) {
      sport.setValue(data.getAsInteger(DB.ACTIVITY.SPORT));
    }
  }

  private void toggleMapInfo() {
    mapInfoVisible = !mapInfoVisible;
    if (mapInfoPanel != null) mapInfoPanel.setVisibility(mapInfoVisible ? View.VISIBLE : View.GONE);
    if (mapTopInfoPanel != null) mapTopInfoPanel.setVisibility(mapInfoVisible ? View.VISIBLE : View.GONE);
    if (mapToggleInfoButton instanceof android.widget.ImageButton) {
      ((android.widget.ImageButton) mapToggleInfoButton).setImageResource(
          mapInfoVisible ? R.drawable.ic_map_info_hide : R.drawable.ic_map_info_show);
    }
  }

  /** Updates the map selector using completed whole kilometers from the GPS split series. */
  private void selectMapLap(int index) {
    int mapLapCount = getCompletedMapKmCount();
    if (mapLapCount <= 0) {
      mapLapIndex = 0;
      if (mapLapTitle != null) mapLapTitle.setText("Percurso");
      if (mapTopKm != null) mapTopKm.setText("Percurso");
      if (mapTopTime != null) mapTopTime.setText("--:--");
      if (mapTopPace != null) mapTopPace.setText("--:-- /km");
      if (mapLapTime != null) mapLapTime.setText("--:--");
      if (mapLapPace != null) mapLapPace.setText("--:-- /km");
      if (mapLapElevation != null) mapLapElevation.setText("—");
      if (mapLapPrev != null) mapLapPrev.setEnabled(false);
      if (mapLapNext != null) mapLapNext.setEnabled(false);
      return;
    }

    mapLapIndex = Math.max(0, Math.min(index, mapLapCount - 1));

    double cumulativeDistance = 0.0;
    long cumulativeTime = 0L;
    ContentValues selectedLap = null;
    for (int i = 0; i <= mapLapIndex && i < mapLapCount; i++) {
      ContentValues lap = distanceSplits[i];
      cumulativeDistance += lap.containsKey(DB.LAP.DISTANCE) ? lap.getAsDouble(DB.LAP.DISTANCE) : 0.0;
      cumulativeTime += lap.containsKey(DB.LAP.TIME) ? lap.getAsLong(DB.LAP.TIME) : 0L;
      if (i == mapLapIndex) selectedLap = lap;
    }

    String distanceText = formatter.formatDistance(Formatter.Format.TXT_SHORT, Math.round(cumulativeDistance));
    String timeText = formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, cumulativeTime);
    String paceText = cumulativeTime > 0 && cumulativeDistance > 0
        ? formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_LONG, cumulativeDistance / cumulativeTime)
        : "--:--/km";

    String kmText = (mapLapIndex + 1) + " km";
    if (mapLapTitle != null) mapLapTitle.setText(kmText);

    // Top card: cumulative values at the selected kilometer.
    if (mapTopKm != null) mapTopKm.setText(kmText);
    if (mapTopTime != null) mapTopTime.setText(timeText);
    if (mapTopPace != null) mapTopPace.setText(paceText);

    // Bottom card: values belonging to the selected kilometer itself.
    String selectedTimeText = "--:--";
    String selectedPaceText = "--:-- /km";
    String selectedElevationText = "—";
    if (distanceSplits != null && mapLapIndex >= 0 && mapLapIndex < mapLapCount) {
      ContentValues lap = distanceSplits[mapLapIndex];
      long lapTime = lap.containsKey(DB.LAP.TIME) ? lap.getAsLong(DB.LAP.TIME) : 0L;
      double lapDistance = lap.containsKey(DB.LAP.DISTANCE) ? lap.getAsDouble(DB.LAP.DISTANCE) : 0.0;
      selectedTimeText = formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, lapTime);
      if (lapTime > 0 && lapDistance > 0) {
        selectedPaceText = formatter.formatVelocityByPreferredUnit(
            Formatter.Format.TXT_LONG, lapDistance / lapTime);
      }
      if (splitElevation != null && mapLapIndex < splitElevation.length) {
        double elevation = splitElevation[mapLapIndex];
        if (Math.abs(elevation) >= 0.5) {
          selectedElevationText = (elevation > 0 ? "+" : "") + Math.round(elevation) + " m";
        } else {
          selectedElevationText = "0 m";
        }
      }
    }
    if (mapLapTime != null) mapLapTime.setText(selectedTimeText);
    if (mapLapPace != null) mapLapPace.setText(selectedPaceText);
    if (mapLapElevation != null) mapLapElevation.setText(selectedElevationText);

    if (mapWrapper != null) {
      mapWrapper.focusLap(mapLapIndex);
      mapWrapper.selectLap(mapLapIndex);
    }
    if (mapLapPrev != null) mapLapPrev.setEnabled(mapLapIndex > 0);
    if (mapLapNext != null) mapLapNext.setEnabled(mapLapIndex < mapLapCount - 1);
  }

  private int getCompletedMapKmCount() {
    if (distanceSplits == null || distanceSplits.length == 0) return 0;
    int count = 0;
    for (ContentValues split : distanceSplits) {
      double distance = getDoubleOrZero(split, DB.LAP.DISTANCE);
      if (distance >= 990.0 && distance <= 1010.0) count++;
      else break; // the final partial split is not a full-kilometer map marker
    }
    return count;
  }

  /**
   * Builds the Voltas tab from the activity GPS track.
   *
   * Structured workouts store DB.LAP rows by workout block. Those rows are
   * correct for the Blocos tab but are not kilometre splits. Voltas therefore
   * has its own derived split series: 1 km per row (and a final partial km),
   * plus a 1-minute series for the Tempo toggle.
   */
  private void buildActivitySplits() {
    ArrayList<ContentValues> points = new ArrayList<>();
    // Use the same normalized point stream as the route map. This supports
    // recordings whose older location rows do not contain stored DISTANCE or
    // ELAPSED values, while new recordings continue to use Tracker's values.
    LocationEntity.LocationList locations =
        new LocationEntity.LocationList(mDB, mID);
    try {
      for (LocationEntity location : locations) {
        Integer typeValue = location.getType();
        int type = typeValue == null ? DB.LOCATION.TYPE_GPS : typeValue;
        if (type != DB.LOCATION.TYPE_GPS && type != DB.LOCATION.TYPE_START
            && type != DB.LOCATION.TYPE_RESUME) continue;
        Double distance = location.getDistance();
        if (distance == null) continue;
        ContentValues point = new ContentValues();
        if (location.getTime() != null) point.put(DB.LOCATION.TIME, location.getTime());
        if (location.getElapsed() != null) point.put(DB.LOCATION.ELAPSED, location.getElapsed());
        point.put(DB.LOCATION.DISTANCE, distance);
        if (location.getAltitude() != null) point.put(DB.LOCATION.ALTITUDE, location.getAltitude());
        if (location.getHr() != null && location.getHr() > 0) {
          point.put(DB.LOCATION.HR, location.getHr());
        }
        points.add(point);
      }
    } finally {
      locations.close();
    }

    if (points.size() < 2) {
      distanceSplits = null;
      timeSplits = null;
      splitElevationPresent = false;
      splitHrPresent = false;
      return;
    }

    // Normalize elapsed time. New activities have ELAPSED; imported GPX files
    // may only have wall-clock TIME, so fall back to timestamp deltas.
    // PersistentGpsLoggerListener stores LOCATION.ELAPSED using Tracker.getTimeMs(),
    // so the database value is milliseconds. Normalize it to seconds before the
    // split builders apply their 60-second and 1-kilometer boundaries.
    long firstElapsedMillis = points.get(0).containsKey(DB.LOCATION.ELAPSED)
        ? getLongOrZero(points.get(0), DB.LOCATION.ELAPSED) : 0L;
    long firstWallTimeMillis = getLongOrZero(points.get(0), DB.LOCATION.TIME);
    double firstDistanceMeters = getDoubleOrZero(points.get(0), DB.LOCATION.DISTANCE);
    double officialDistanceMeters = headerData != null && headerData.containsKey(DB.ACTIVITY.DISTANCE)
        ? Math.max(0d, headerData.getAsDouble(DB.ACTIVITY.DISTANCE)) : 0d;
    long officialTimeSeconds = headerData != null && headerData.containsKey(DB.ACTIVITY.TIME)
        ? Math.max(0L, headerData.getAsLong(DB.ACTIVITY.TIME)) : 0L;
    double lastAcceptedDistance = 0d;
    long lastAcceptedElapsed = 0L;
    for (ContentValues p : points) {
      long elapsedSeconds;
      if (p.containsKey(DB.LOCATION.ELAPSED)) {
        elapsedSeconds = ActivitySplitTime.elapsedSecondsSince(
            p.getAsLong(DB.LOCATION.ELAPSED), firstElapsedMillis);
      } else {
        elapsedSeconds = ActivitySplitTime.elapsedSecondsSince(
            p.getAsLong(DB.LOCATION.TIME), firstWallTimeMillis);
      }
      if (officialTimeSeconds > 0) elapsedSeconds = Math.min(elapsedSeconds, officialTimeSeconds);
      elapsedSeconds = Math.max(lastAcceptedElapsed, elapsedSeconds);
      double cumulativeDistance = Math.max(lastAcceptedDistance,
          getDoubleOrZero(p, DB.LOCATION.DISTANCE) - firstDistanceMeters);
      if (officialDistanceMeters > 0) cumulativeDistance = Math.min(cumulativeDistance, officialDistanceMeters);
      cumulativeDistance = Math.max(lastAcceptedDistance, cumulativeDistance);
      p.put(DB.LOCATION.DISTANCE, cumulativeDistance);
      p.put("_split_elapsed_s", elapsedSeconds);
      lastAcceptedElapsed = elapsedSeconds;
      lastAcceptedDistance = cumulativeDistance;
    }

    distanceSplits = buildDistanceSplitRows(points);
    timeSplits = buildTimeSplitRows(points);

    int max = Math.max(distanceSplits == null ? 0 : distanceSplits.length,
        timeSplits == null ? 0 : timeSplits.length);
    splitElevation = new double[max];
    splitHrAverage = new int[max];
    splitElevationPresent = false;
    splitHrPresent = false;

    // Use the distance split series for the displayed elevation/HR columns;
    // those columns belong to the normal Km view.
    if (distanceSplits != null) {
      for (int i = 0; i < distanceSplits.length; i++) {
        ContentValues r = distanceSplits[i];
        if (r.containsKey("_split_elevation")) {
          splitElevation[i] = r.getAsDouble("_split_elevation");
          splitElevationPresent |= Math.abs(splitElevation[i]) >= 0.5;
        }
        if (r.containsKey("_split_hr")) {
          splitHrAverage[i] = r.getAsInteger("_split_hr");
          splitHrPresent |= splitHrAverage[i] > 0;
        }
      }
    }
  }

  private ContentValues[] buildDistanceSplitRows(ArrayList<ContentValues> points) {
    ArrayList<ContentValues> result = new ArrayList<>();
    ContentValues prev = points.get(0);
    double previousDistance = Math.max(0, prev.getAsDouble(DB.LOCATION.DISTANCE));
    long previousElapsed = prev.getAsLong("_split_elapsed_s");
    double previousElevation = prev.containsKey(DB.LOCATION.ALTITUDE) ? prev.getAsDouble(DB.LOCATION.ALTITUDE) : Double.NaN;
    long hrSum = 0; int hrCount = 0;
    if (prev.containsKey(DB.LOCATION.HR)) { hrSum += prev.getAsInteger(DB.LOCATION.HR); hrCount++; }
    double lastBoundaryDistance = 0;
    long lastBoundaryElapsed = 0;
    double lastBoundaryElevation = previousElevation;
    int targetIndex = 1;

    for (int i = 1; i < points.size(); i++) {
      ContentValues cur = points.get(i);
      double currentDistance = Math.max(previousDistance, cur.getAsDouble(DB.LOCATION.DISTANCE));
      long currentElapsed = Math.max(previousElapsed, cur.getAsLong("_split_elapsed_s"));
      double currentElevation = cur.containsKey(DB.LOCATION.ALTITUDE) ? cur.getAsDouble(DB.LOCATION.ALTITUDE) : Double.NaN;
      if (cur.containsKey(DB.LOCATION.HR)) { hrSum += cur.getAsInteger(DB.LOCATION.HR); hrCount++; }

      while (currentDistance >= targetIndex * 1000.0 && currentDistance > previousDistance) {
        double boundaryDistance = targetIndex * 1000.0;
        double f = (boundaryDistance - previousDistance) / (currentDistance - previousDistance);
        f = Math.max(0, Math.min(1, f));
        long boundaryElapsed = previousElapsed + Math.round((currentElapsed - previousElapsed) * f);
        double boundaryElevation = (!Double.isNaN(previousElevation) && !Double.isNaN(currentElevation))
            ? previousElevation + (currentElevation - previousElevation) * f : Double.NaN;

        ContentValues row = new ContentValues();
        row.put(DB.LAP.DISTANCE, 1000.0);
        row.put(DB.LAP.TIME, Math.max(0L, boundaryElapsed - lastBoundaryElapsed));
        if (!Double.isNaN(boundaryElevation) && !Double.isNaN(lastBoundaryElevation)) {
          row.put("_split_elevation", boundaryElevation - lastBoundaryElevation);
        }
        if (hrCount > 0) row.put("_split_hr", Math.round((float) hrSum / hrCount));
        result.add(row);
        lastBoundaryDistance = boundaryDistance;
        lastBoundaryElapsed = boundaryElapsed;
        lastBoundaryElevation = boundaryElevation;
        targetIndex++;
        hrSum = 0; hrCount = 0;
      }
      previousDistance = currentDistance;
      previousElapsed = currentElapsed;
      previousElevation = currentElevation;
      prev = cur;
    }

    double totalDistance = previousDistance;
    long totalElapsed = previousElapsed;
    double remainder = totalDistance - lastBoundaryDistance;
    long remainderTime = Math.max(0L, totalElapsed - lastBoundaryElapsed);
    if (remainder > 0.5 && remainder < 1000.0) {
      ContentValues row = new ContentValues();
      row.put(DB.LAP.DISTANCE, remainder);
      row.put(DB.LAP.TIME, remainderTime);
      if (!Double.isNaN(previousElevation) && !Double.isNaN(lastBoundaryElevation)) {
        row.put("_split_elevation", previousElevation - lastBoundaryElevation);
      }
      if (hrCount > 0) row.put("_split_hr", Math.round((float) hrSum / hrCount));
      result.add(row);
    }
    return result.toArray(new ContentValues[0]);
  }

  private ContentValues[] buildTimeSplitRows(ArrayList<ContentValues> points) {
    ArrayList<ContentValues> result = new ArrayList<>();
    ContentValues prev = points.get(0);
    double previousDistance = Math.max(0, prev.getAsDouble(DB.LOCATION.DISTANCE));
    long previousElapsed = prev.getAsLong("_split_elapsed_s");
    int targetIndex = 1;
    double lastBoundaryDistance = previousDistance;
    long lastBoundaryElapsed = 0;

    for (int i = 1; i < points.size(); i++) {
      ContentValues cur = points.get(i);
      double currentDistance = Math.max(previousDistance, cur.getAsDouble(DB.LOCATION.DISTANCE));
      long currentElapsed = Math.max(previousElapsed, cur.getAsLong("_split_elapsed_s"));
      while (currentElapsed >= targetIndex * 60L && currentElapsed > previousElapsed) {
        long boundaryElapsed = targetIndex * 60L;
        double f = (boundaryElapsed - previousElapsed) / (double) (currentElapsed - previousElapsed);
        f = Math.max(0, Math.min(1, f));
        double boundaryDistance = previousDistance + (currentDistance - previousDistance) * f;
        ContentValues row = new ContentValues();
        row.put(DB.LAP.DISTANCE, Math.max(0, boundaryDistance - lastBoundaryDistance));
        row.put(DB.LAP.TIME, Math.max(0L, boundaryElapsed - lastBoundaryElapsed));
        result.add(row);
        lastBoundaryDistance = boundaryDistance;
        lastBoundaryElapsed = boundaryElapsed;
        targetIndex++;
      }
      previousDistance = currentDistance;
      previousElapsed = currentElapsed;
      prev = cur;
    }

    double remainderDistance = Math.max(0, previousDistance - lastBoundaryDistance);
    long remainderTime = Math.max(0L, previousElapsed - lastBoundaryElapsed);
    if (remainderTime > 0 && (remainderDistance > 0.5 || result.isEmpty())) {
      ContentValues row = new ContentValues();
      row.put(DB.LAP.DISTANCE, remainderDistance);
      row.put(DB.LAP.TIME, remainderTime);
      result.add(row);
    }
    return result.toArray(new ContentValues[0]);
  }

  private void setLapDisplayMode(boolean timeMode) {
    lapTimeMode = timeMode;
    if (lapPrimaryHeader != null) {
      lapPrimaryHeader.setText(timeMode ? "Tempo" : "Km");
    }
    if (lapModeKm != null) {
      lapModeKm.setBackgroundResource(timeMode ? R.drawable.bg_lap_mode : R.drawable.bg_lap_mode_selected);
      lapModeKm.setTextColor(ContextCompat.getColor(this, timeMode ? R.color.colorTextSecondary : android.R.color.white));
    }
    if (lapModeTime != null) {
      if (timeMode) {
        lapModeTime.setBackgroundResource(R.drawable.bg_lap_mode_selected);
      } else {
        lapModeTime.setBackgroundColor(Color.TRANSPARENT);
      }
      lapModeTime.setTextColor(ContextCompat.getColor(this, timeMode ? android.R.color.white : R.color.colorTextSecondary));
    }
    for (BaseAdapter adapter : adapters) {
      if (adapter instanceof LapListAdapter) {
        adapter.notifyDataSetChanged();
      }
    }
  }

  private class ViewHolderLapList {
    private TextView tv0;
    private TextView tv1;
    private TextView tv2;
    private View bar;
    private TextView tvElevation;
    private TextView tvHr;
    private View row;
    private View barContainer;
  }

  private class LapListAdapter extends BaseAdapter {

    private ContentValues[] getSplitRows() {
      ContentValues[] rows = lapTimeMode ? timeSplits : distanceSplits;
      if (rows != null && rows.length > 0) return rows;
      // If an activity has no GPS points (for example a manual activity), keep
      // the legacy LAP data visible rather than showing an empty Voltas tab.
      return laps == null ? new ContentValues[0] : laps;
    }

    @Override
    public int getCount() {
      return getSplitRows().length;
    }

    @Override
    public Object getItem(int position) {
      return getSplitRows()[position];
    }

    @Override
    public long getItemId(int position) {
      ContentValues[] rows = getSplitRows();
      return position < rows.length ? position : 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      View view = convertView;
      ViewHolderLapList h;
      if (view == null) {
        h = new ViewHolderLapList();
        LayoutInflater inflater = LayoutInflater.from(DetailActivity.this);
        view = inflater.inflate(R.layout.laplist_row, parent, false);
        h.row = view;
        h.tv0 = view.findViewById(R.id.lap_list_id);
        h.tv1 = view.findViewById(R.id.lap_list_pace);
        h.tv2 = view.findViewById(R.id.lap_list_type);
        h.barContainer = view.findViewById(R.id.lap_list_bar_container);
        h.bar = view.findViewById(R.id.lap_list_bar);
        h.tvElevation = view.findViewById(R.id.lap_list_elevation);
        h.tvHr = view.findViewById(R.id.lap_list_hr);
        view.setTag(h);
      } else {
        h = (ViewHolderLapList) view.getTag();
      }

      ContentValues[] rows = getSplitRows();
      ContentValues split = rows[position];
      double d = split.containsKey(DB.LAP.DISTANCE) ? split.getAsDouble(DB.LAP.DISTANCE) : 0;
      long t = split.containsKey(DB.LAP.TIME) ? split.getAsLong(DB.LAP.TIME) : 0;
      double paceSeconds = t > 0 && d > 0 ? (t * 1000.0) / d : 0;
      boolean partial = lapTimeMode
          ? (position == rows.length - 1 && t > 0 && t < 60)
          : (position == rows.length - 1 && d > 0 && d < 950.0);

      if (lapTimeMode) {
        long cumulative = 0;
        for (int i = 0; i <= position; i++) {
          if (rows[i].containsKey(DB.LAP.TIME)) cumulative += Math.max(0L, rows[i].getAsLong(DB.LAP.TIME));
        }
        h.tv0.setSingleLine(true);
        h.tv0.setText(formatElapsedTimeShort(cumulative));
      } else {
        h.tv0.setSingleLine(true);
        h.tv0.setText(partial
            ? (position + 1) + " · " + formatDistanceKm(d)
            : String.valueOf(position + 1));
      }

      h.tv2.setVisibility(partial ? View.VISIBLE : View.GONE);
      h.tv2.setText(partial ? "Parcial" : "");
      h.tv2.setTextColor(ContextCompat.getColor(DetailActivity.this, R.color.colorAccent));
      h.tv1.setSingleLine(true);
      h.tv1.setText(formatPaceSecondsPerKm(paceSeconds));

      if (partial) {
        h.row.setBackgroundResource(R.drawable.bg_lap_partial);
      } else {
        h.row.setBackgroundColor(Color.TRANSPARENT);
      }

      h.tvElevation.setVisibility(splitElevationPresent ? View.VISIBLE : View.GONE);
      if (splitElevationPresent && splitElevation != null && position < splitElevation.length &&
          Math.abs(splitElevation[position]) >= 0.5) {
        int elev = (int) Math.round(splitElevation[position]);
        h.tvElevation.setText(String.format(Locale.getDefault(), "%+d", elev));
      } else if (splitElevationPresent) {
        h.tvElevation.setText("—");
      }

      h.tvHr.setVisibility(splitHrPresent ? View.VISIBLE : View.GONE);
      if (splitHrPresent && splitHrAverage != null && position < splitHrAverage.length && splitHrAverage[position] > 0) {
        h.tvHr.setText(String.valueOf(splitHrAverage[position]));
      } else if (splitHrPresent) {
        h.tvHr.setText("—");
      }

      // Compare only complete splits. The final partial split must never be
      // treated as the fastest/slowest split.
      double minPace = Double.MAX_VALUE;
      double maxPace = 0;
      for (int i = 0; i < rows.length; i++) {
        ContentValues item = rows[i];
        double itemD = item.containsKey(DB.LAP.DISTANCE) ? item.getAsDouble(DB.LAP.DISTANCE) : 0;
        long itemT = item.containsKey(DB.LAP.TIME) ? item.getAsLong(DB.LAP.TIME) : 0;
        boolean itemPartial = lapTimeMode
            ? (i == rows.length - 1 && itemT > 0 && itemT < 60)
            : (i == rows.length - 1 && itemD > 0 && itemD < 950.0);
        if (!itemPartial && itemD > 0 && itemT > 0) {
          double p = itemT * 1000.0 / itemD;
          minPace = Math.min(minPace, p);
          maxPace = Math.max(maxPace, p);
        }
      }
      final double normalized = partial
          ? 0.0
          : (paceSeconds > 0 && maxPace > minPace
              ? 0.08 + 0.84 * ((maxPace - paceSeconds) / (maxPace - minPace))
              : 0.46);
      h.bar.setBackgroundResource(partial ? R.drawable.bg_lap_bar_slow : R.drawable.bg_lap_bar);
      h.barContainer.post(() -> {
        int width = h.barContainer.getWidth();
        if (width > 0) {
          ViewGroup.LayoutParams lp = h.bar.getLayoutParams();
          lp.width = partial ? Math.max(8, (int) (width * 0.05))
              : Math.max(8, (int) (width * Math.max(0.08, Math.min(0.92, normalized))));
          h.bar.setLayoutParams(lp);
        }
      });

      return view;
    }
  }

  private class ReportListAdapter extends BaseAdapter {

    @Override
    public int getCount() {
      return reports.size() + 1;
    }

    @Override
    public Object getItem(int position) {
      if (position < reports.size()) return reports.get(position);
      return this;
    }

    @Override
    public long getItemId(int position) {
      if (position < reports.size()) return reports.get(position).getAsLong("_id");

      return 0;
    }

    private class ViewHolderDetailActivity {
      private TextView tv0;
      private CheckBox cb;
      private TextView tv1;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      if (position == reports.size()) {
        Button b = new Button(DetailActivity.this);
        b.setText(org.runnerup.common.R.string.Configure_accounts);
        b.setBackgroundResource(R.drawable.btn_blue);
        b.setTextColor(
            AppCompatResources.getColorStateList(DetailActivity.this, R.color.btn_text_color));
        b.setOnClickListener(
            v -> {
              Intent i = new Intent(DetailActivity.this, AccountListActivity.class);
              DetailActivity.this.startActivityForResult(i, EDIT_ACCOUNT_REQUEST);
            });
        return b;
      }

      View view = convertView;
      ViewHolderDetailActivity viewHolder;

      // Note: Special ViewHolder support as the Configure button is not in the view
      if (view == null || view.getTag() == null) {
        viewHolder = new ViewHolderDetailActivity();

        LayoutInflater inflater = LayoutInflater.from(DetailActivity.this);
        view = inflater.inflate(R.layout.reportlist_row, parent, false);

        viewHolder.tv0 = view.findViewById(R.id.reportlist_account_id);
        viewHolder.cb = view.findViewById(R.id.reportlist_sent);
        viewHolder.tv1 = view.findViewById(R.id.reportlist_account_name);

        view.setTag(viewHolder);
      } else {
        viewHolder = (ViewHolderDetailActivity) view.getTag();
      }

      ContentValues tmp = reports.get(position);
      String name = tmp.getAsString(DB.ACCOUNT.NAME);
      viewHolder.cb.setOnCheckedChangeListener(null);
      viewHolder.cb.setChecked(false);
      viewHolder.cb.setEnabled(false);
      viewHolder.cb.setTag(name);
      viewHolder.tv1.setTag(name);
      viewHolder.tv1.setTextColor(viewHolder.cb.getTextColors());
      if (alreadySynched.contains(name)) {
        viewHolder.cb.setChecked(true);
        if (synchedExternalId.containsKey(name)) {
          // Indicate Clickable label
          viewHolder.tv1.setTextColor(Color.BLUE);
        }
        viewHolder.cb.setText(org.runnerup.common.R.string.Uploaded);
        viewHolder.cb.setOnLongClickListener(clearUploadClick);
      } else {
        viewHolder.cb.setChecked(pendingSynchronizers.contains(name));
        viewHolder.cb.setText(org.runnerup.common.R.string.Upload);
        viewHolder.cb.setOnLongClickListener(null);
      }
      if (mode == MODE_DETAILS) {
        viewHolder.cb.setEnabled(true);
      } else if (mode == MODE_SAVE) {
        viewHolder.cb.setEnabled(true);
      }
      viewHolder.cb.setOnCheckedChangeListener(onSendChecked);

      viewHolder.tv0.setText(tmp.getAsString("_id"));
      viewHolder.tv1.setText(name);

      return view;
    }
  }

  private void saveActivity() {
    int sportValue = sport.getValueInt();
    ContentValues tmp = headerData;
    tmp.put(DB.ACTIVITY.COMMENT, notes.getText().toString());
    tmp.put(DB.ACTIVITY.SPORT, sportValue);
    if (activityNameEdit != null) {
      String newName = activityNameEdit.getText().toString().trim();
      if (newName.isEmpty()) newName = "Corrida";
      tmp.put(DB.ACTIVITY.NAME, newName);
      if (activityNameValue != null) activityNameValue.setText(newName);
    }
    if (workoutTypeSpinner != null) {
      int selectedType = workoutTypeSpinner.getValueInt();
      tmp.put(DB.ACTIVITY.WORKOUT_TYPE, selectedType);
      if (workoutTypeValue != null) workoutTypeValue.setText(workoutTypeLabel(selectedType));
    }
    String[] whereArgs = {Long.toString(mID)};
    mDB.update(DB.ACTIVITY.TABLE, tmp, "_id = ?", whereArgs);

    // path simplification (reduce resolution of location entries in database)
    try {
      PathSimplifier simplifier = PathSimplifier.getPathSimplifierForSave(this);
      if (simplifier != null) {
        ArrayList<String> ids = simplifier.getNoisyLocationIDsAsStrings(mDB, mID);
        ActivityCleaner.deleteLocations(mDB, ids);
        (new ActivityCleaner()).recompute(mDB, mID);
      }
    } catch (Exception e) {
      Log.e(getClass().getName(), "Failed to simplify path: " + e.getMessage());
    }
  }

  private final OnLongClickListener clearUploadClick =
      arg0 -> {
        final String name = (String) arg0.getTag();
        new AlertDialog.Builder(DetailActivity.this)
            .setTitle("Clear upload for " + name)
            .setMessage(org.runnerup.common.R.string.Are_you_sure)
            .setPositiveButton(
                org.runnerup.common.R.string.Yes,
                (dialog, which) -> {
                  dialog.dismiss();
                  syncManager.clearUpload(name, mID);
                  requery();
                })
            .setNegativeButton(
                org.runnerup.common.R.string.No,
                // Do nothing but close the dialog
                (dialog, which) -> dialog.dismiss())
            .show();
        return false;
      };

  // Note: onClick set in reportlist_row.xml
  public void onClickAccountName(View arg0) {
    final String name = (String) arg0.getTag();
    if (synchedExternalId.containsKey(name) && !TextUtils.isEmpty(synchedExternalId.get(name))) {
      String url =
          syncManager.getSynchronizerByName(name).getActivityUrl(synchedExternalId.get(name));
      if (url != null) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(browserIntent);
      }
    }
  }

  private final OnClickListener saveButtonClick =
      new OnClickListener() {
        public void onClick(View v) {
          saveActivity();
          if (mode == MODE_DETAILS) {
            setEdit(false);
            requery();
            return;
          }
          uploading = true;
          syncManager.startUploading(
              (synchronizerName, status) -> {
                uploading = false;
                final Intent returnIntent = new Intent();
                int sportValue = sport.getValueInt();
                if (Sport.hasManualDistance(sportValue)) {
                  returnIntent.putExtra(
                      "MANUAL_DISTANCE", headerData.getAsDouble(DB.ACTIVITY.DISTANCE));
                }
                DetailActivity.this.setResult(RESULT_OK, returnIntent);
                DetailActivity.this.finish();
              },
              pendingSynchronizers,
              mID);
        }
      };

  private final OnClickListener discardButtonClick =
      v ->
          new AlertDialog.Builder(DetailActivity.this)
              .setTitle(org.runnerup.common.R.string.Discard)
              .setMessage(org.runnerup.common.R.string.Are_you_sure)
              .setPositiveButton(
                  org.runnerup.common.R.string.Yes,
                  (dialog, which) -> {
                    dialog.dismiss();
                    DetailActivity.this.setResult(RESULT_CANCELED);
                    DetailActivity.this.finish();
                  })
              .setNegativeButton(
                  org.runnerup.common.R.string.No,
                  // Do nothing but close the dialog
                  (dialog, which) -> dialog.dismiss())
              .show();

  private final OnClickListener resumeButtonClick =
      v -> {
        DetailActivity.this.setResult(RESULT_FIRST_USER);
        DetailActivity.this.finish();
      };

  private final OnClickListener uploadButtonClick =
      v -> {
        uploading = true;
        syncManager.startUploading(
            (synchronizerName, status) -> {
              uploading = false;
              requery();
            },
            pendingSynchronizers,
            mID);
      };

  private final OnCheckedChangeListener onSendChecked =
      new OnCheckedChangeListener() {

        @Override
        public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
          final String name = (String) arg0.getTag();
          if (alreadySynched.contains(name)) {
            // Only accept long clicks
            arg0.setChecked(true);
          } else {
            if (arg1) {
              pendingSynchronizers.add((String) arg0.getTag());
            } else {
              //noinspection SuspiciousMethodCalls
              pendingSynchronizers.remove(arg0.getTag());
            }
            if (mode == MODE_DETAILS) {
              setUploadVisibility();
            }
          }
        }
      };

  private final OnClickListener deleteButtonClick =
      v ->
          new AlertDialog.Builder(DetailActivity.this)
              .setTitle(org.runnerup.common.R.string.Delete_activity)
              .setMessage(org.runnerup.common.R.string.Are_you_sure)
              .setPositiveButton(
                  org.runnerup.common.R.string.Yes,
                  (dialog, which) -> {
                    DBHelper.deleteActivity(mDB, mID);
                    dialog.dismiss();
                    DetailActivity.this.setResult(RESULT_OK);
                    DetailActivity.this.finish();
                  })
              .setNegativeButton(
                  org.runnerup.common.R.string.No,
                  // Do nothing but close the dialog
                  (dialog, which) -> dialog.dismiss())
              .show();

  @Override
  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == SyncManager.CONFIGURE_REQUEST) {
      syncManager.onActivityResult(requestCode, resultCode, data);
    }
    requery();
  }

  private String getActivityNameForExport() {
    Cursor cursor = null;
    try {
      SQLiteDatabase db = DBHelper.getReadableDatabase(this);
      cursor = db.query(
          Constants.DB.ACTIVITY.TABLE,
          new String[] {Constants.DB.ACTIVITY.NAME},
          "_id = " + mID, null, null, null, null);
      if (cursor.moveToFirst() && !cursor.isNull(0)) {
        String name = cursor.getString(0);
        if (name != null && !name.trim().isEmpty()) return name.trim();
      }
    } catch (Exception ignored) {
      // Fall back to the generic activity filename.
    } finally {
      if (cursor != null) cursor.close();
    }
    return "Corrida";
  }

  private void exportActivityFile() {
    final int[] which = {
      1 // TODO preselect tcx - choice should be remembered
    };
    final CharSequence[] items = {"gpx", "tcx"};
    new AlertDialog.Builder(this)
        .setTitle("Exportar atividade")
        .setPositiveButton(
            org.runnerup.common.R.string.OK,
            (dialog, w) -> {
              if (which[0] == -1) {
                dialog.dismiss();
                return;
              }

              final Context context = DetailActivity.this;
              final CharSequence fmt = items[which[0]];
              final Intent intent = new Intent(Intent.ACTION_SEND);

              if (fmt.equals("tcx")) {
                intent.setType(TCX_MIME);
              } else {
                intent.setType(GPX_MIME);
              }

              // Use of content:// (or STREAM?) instead of file:// is not supported in ES and other
              // apps
              // Solid Explorer File Manager works though
              String actType = Sport.textOf(getResources(), sport.getValueInt());
              String exportFileName = fmt.equals("gpx")
                  ? FileNameHelper.getGpxFileName(getActivityNameForExport(), mStartTime)
                  : FileNameHelper.getExportFileName(mStartTime, actType);
              Uri uri =
                  Uri.parse(
                      "content://"
                          + ActivityProvider.AUTHORITY
                          + "/"
                          + fmt
                          + "/"
                          + mID
                          + "/"
                          + exportFileName
                          + fmt);
              intent.putExtra(Intent.EXTRA_STREAM, uri);
              context.startActivity(
                  Intent.createChooser(
                      intent, "Exportar atividade"));
            })
        .setNegativeButton(
            org.runnerup.common.R.string.Cancel,
            (dialog, which1) -> {
              // Do nothing but close the dialog
              dialog.dismiss();
            })
        .setSingleChoiceItems(items, which[0], (dialog, w) -> which[0] = w)
        .show();
  }
}
