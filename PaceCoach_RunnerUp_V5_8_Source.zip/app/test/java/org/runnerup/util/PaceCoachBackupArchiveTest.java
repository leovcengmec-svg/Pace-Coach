package org.runnerup.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertThrows;

import java.io.IOException;
import org.junit.Test;

public class PaceCoachBackupArchiveTest {
  @Test
  public void acceptsKnownPayloadPaths() throws Exception {
    PaceCoachBackupManager.validateEntryName("database/runnerup.db", false);
    PaceCoachBackupManager.validateEntryName("workouts/tempo/workout.json", false);
    assertTrue(PaceCoachBackupManager.isAllowedEntry("database/runnerup.db"));
    assertTrue(PaceCoachBackupManager.isAllowedEntry("files/export/activity.gpx"));
    assertTrue(PaceCoachBackupManager.isAllowedPayloadFile("shared_prefs/settings.xml"));
  }

  @Test
  public void rejectsParentTraversalAndAbsolutePaths() {
    assertThrows(
        IOException.class,
        () -> PaceCoachBackupManager.validateEntryName("files/../runnerup.db", false));
    assertThrows(
        IOException.class,
        () -> PaceCoachBackupManager.validateEntryName("/database/runnerup.db", false));
    assertThrows(
        IOException.class,
        () -> PaceCoachBackupManager.validateEntryName("files\\..\\runnerup.db", false));
  }

  @Test
  public void rejectsUnrecognizedPayloadRoots() {
    assertFalse(PaceCoachBackupManager.isAllowedEntry("../../outside.txt"));
    assertFalse(PaceCoachBackupManager.isAllowedEntry("cache/private.bin"));
    assertFalse(PaceCoachBackupManager.isAllowedPayloadFile("manifest.json"));
  }

  @Test
  public void trimsOnlyOneDirectoryTerminator() {
    assertEquals("workouts", PaceCoachBackupManager.trimTrailingSlash("workouts/"));
    assertEquals("workouts//", PaceCoachBackupManager.trimTrailingSlash("workouts///"));
  }
}
