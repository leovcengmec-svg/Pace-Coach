/*
 * Copyright (C) 2012 - 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.workout;

import android.content.ContentValues;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.runnerup.BuildConfig;
import org.runnerup.common.util.Constants.DB;

public class Step implements TickComponent {

  private String name = null;

  /** Intensity */
  Intensity intensity = Intensity.ACTIVE;

  /** DurationType Dimension.TIME, Dimension.DISTANCE, null (keypress) */
  Dimension durationType = null;

  double durationValue = 0;

  /** Pace Coach rhythm: 0=Devagar, 1=Constante, 2=Rápido. */
  private int coachRhythm = 1;

  /** Complete prescription carried by the Pace Coach Treino Livre block. */
  private boolean paceCoachFreeRun = false;
  private double paceCoachPlannedTimeSeconds = 0;
  private double paceCoachPlannedDistanceMeters = 0;

  /** Target */
  Dimension targetType = null;

  Range targetValue = null;

  /** Autolap (m) */
  private double autolap = 0;

  /** Triggers */
  final ArrayList<Trigger> triggers = new ArrayList<>();

  /**
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * @param name the name to set
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * @return the durationType
   */
  public Dimension getDurationType() {
    return durationType;
  }

  /**
   * @param durationType the durationType to set
   */
  public void setDurationType(Dimension durationType) {
    this.durationType = durationType;
  }

  /**
   * @return the durationValue
   */
  public double getDurationValue() {
    return durationValue;
  }

  /**
   * @param durationValue the durationValue to set
   */
  public void setDurationValue(double durationValue) {
    this.durationValue = durationValue;
  }

  /**
   * @return the targetType
   */
  public Dimension getTargetType() {
    return targetType;
  }

  /**
   * @param targetType the targetType to set
   */
  public void setTargetType(Dimension targetType) {
    this.targetType = targetType;
  }

  /**
   * @return the targetValue
   */
  public Range getTargetValue() {
    return targetValue;
  }

  /**
   * @param targetValue the targetValue to set
   */
  public void setTargetValue(double targetValue) {
    this.targetValue = new Range(targetValue, targetValue);
  }

  public void setTargetValue(double min, double max) {
    this.targetValue = new Range(min, max);
  }

  public int getCoachRhythm() {
    return coachRhythm;
  }

  public void setCoachRhythm(int coachRhythm) {
    if (coachRhythm < 0 || coachRhythm > 2) {
      coachRhythm = 1;
    }
    this.coachRhythm = coachRhythm;
  }

  public boolean isPaceCoachFreeRun() {
    return paceCoachFreeRun;
  }

  public void setPaceCoachFreeRun(boolean freeRun) {
    this.paceCoachFreeRun = freeRun;
  }

  public double getPaceCoachPlannedTimeSeconds() {
    return paceCoachPlannedTimeSeconds;
  }

  public void setPaceCoachPlannedTimeSeconds(double seconds) {
    this.paceCoachPlannedTimeSeconds = Math.max(0, seconds);
  }

  public double getPaceCoachPlannedDistanceMeters() {
    return paceCoachPlannedDistanceMeters;
  }

  public void setPaceCoachPlannedDistanceMeters(double meters) {
    this.paceCoachPlannedDistanceMeters = Math.max(0, meters);
  }

  public Intensity getIntensity() {
    return intensity;
  }

  public void setIntensity(Intensity intensity) {
    this.intensity = intensity;
  }

  /**
   * @return the autolap distance (may be set in workouts too)
   */
  double getAutolap() {
    return autolap;
  }

  /**
   * @param val the autolap to set
   */
  void setAutolap(double val) {
    this.autolap = val;
  }

  @Override
  public void onInit(Workout s) {
    for (Trigger t : triggers) {
      t.onInit(s);
    }
  }

  @Override
  public void onBind(Workout s, HashMap<String, Object> bindValues) {
    for (Trigger t : triggers) {
      t.onBind(s, bindValues);
    }
  }

  @Override
  public void onEnd(Workout s) {
    for (Trigger t : triggers) {
      t.onEnd(s);
    }
  }

  public void onRepeat(int current, int count) {
    for (Trigger t : triggers) {
      t.onRepeat(current, count);
    }
  }

  private double stepStartTime = 0;
  private double stepStartDistance = 0;
  private double stepStartHeartbeats = 0;
  private double lapStartTime = 0;
  private double lapStartDistance = 0;
  private double lapStartHeartbeats = 0;
  private boolean paceCoachBlockStartPending = false;

  // "Descanso Off" is a timed rest that pauses the workout timer/GPS while
  // its own countdown continues in real time.  The next step resumes the
  // tracker automatically.  This is intentionally based on the RESTING
  // intensity + TIME duration so the editor can use the same Step object
  // without having to replace it with a different subclass.
  private long offRestElapsedMs = 0;
  private long offRestLastTimeMs = 0;

  private boolean isOffRestStep() {
    return intensity == Intensity.RESTING && durationType == Dimension.TIME;
  }

  /** Remaining real-time seconds for the special Descanso Off countdown. */
  public double getPaceCoachOffRestRemainingSeconds() {
    if (!isOffRestStep()) return 0;
    double remaining = durationValue - (offRestElapsedMs / 1000.0d);
    return Math.max(0.0d, remaining);
  }

  public double getPaceCoachOffRestElapsedSeconds() {
    if (!isOffRestStep()) return 0;
    return Math.min(durationValue, Math.max(0.0d, offRestElapsedMs / 1000.0d));
  }

  public boolean isPaceCoachOffRest() {
    return isOffRestStep();
  }

  private void sampleOffRest(boolean frozen) {
    long now = android.os.SystemClock.elapsedRealtime();
    if (offRestLastTimeMs == 0) {
      offRestLastTimeMs = now;
      return;
    }
    long diff = now - offRestLastTimeMs;
    offRestLastTimeMs = now;
    if (!frozen && diff > 0) {
      offRestElapsedMs += diff;
    }
  }

  @Override
  public void onStart(Scope what, Workout s) {
    double time = s.getTime(Scope.ACTIVITY);
    double dist = s.getDistance(Scope.ACTIVITY);
    double beats = s.getHeartbeats(Scope.ACTIVITY);

    if (what == Scope.STEP) {
      paceCoachBlockStartPending = true;
      stepStartTime = time;
      stepStartDistance = dist;
      stepStartHeartbeats = beats;

      if (isOffRestStep()) {
        // Freeze the workout timer/GPS for the rest itself.  The rest countdown
        // is independent and is driven by elapsedRealtime below.
        offRestElapsedMs = 0;
        offRestLastTimeMs = android.os.SystemClock.elapsedRealtime();
        s.tracker.pause();
      } else if (s.isPaused()) {
        s.tracker.pause();
      } else {
        s.tracker.resume();
      }
    } else if (what == Scope.LAP) {
      lapStartTime = time;
      lapStartDistance = dist;
      lapStartHeartbeats = beats;
      ContentValues tmp = new ContentValues();
      tmp.put(DB.LAP.INTENSITY, intensity.getValue());
      tmp.put(DB.LAP.PACECOACH_BLOCK_START, paceCoachBlockStartPending
          ? DB.LAP.PACECOACH_SEGMENT_BLOCK_START : DB.LAP.PACECOACH_SEGMENT_AUTOLAP);
      paceCoachBlockStartPending = false;
      if (durationType != null) {
        switch (durationType) {
          case TIME:
            tmp.put(DB.LAP.PLANNED_TIME, (long) durationValue);
            break;
          case DISTANCE:
            tmp.put(DB.LAP.PLANNED_DISTANCE, (long) durationValue);
            break;
          case PACE:
          case SPEED:
          case HR:
          case HRZ:
          case CAD:
          case TEMPERATURE:
          case PRESSURE:
            break;
        }
      }
      if (targetType != null) {
        switch (targetType) {
          case PACE:
            // Preserve the complete pace range. PLANNED_PACE remains the
            // legacy midpoint/reference value for older consumers.
            tmp.put(DB.LAP.PLANNED_PACE_MIN, targetValue.minValue);
            tmp.put(DB.LAP.PLANNED_PACE_MAX, targetValue.maxValue);
            tmp.put(DB.LAP.PLANNED_PACE, (targetValue.minValue + targetValue.maxValue) / 2.0);
            break;
          case SPEED:
            if (targetValue.minValue != 0 && targetValue.maxValue != 0) {
              double paceMin = 1.0d / targetValue.maxValue;
              double paceMax = 1.0d / targetValue.minValue;
              tmp.put(DB.LAP.PLANNED_PACE_MIN, paceMin);
              tmp.put(DB.LAP.PLANNED_PACE_MAX, paceMax);
              tmp.put(DB.LAP.PLANNED_PACE, (paceMin + paceMax) / 2.0);
            }
            break;
          case DISTANCE:
          case TIME:
          case HR:
          case HRZ:
          case CAD:
          case TEMPERATURE:
          case PRESSURE:
            break;
        }
      }
      s.newLap(tmp);
    }

    for (Trigger t : triggers) {
      t.onStart(what, s);
    }
  }

  @Override
  public void onStop(Workout s) {
    s.tracker.stop();
    for (Trigger t : triggers) {
      t.onStop(s);
    }

    /*
     * Save current lap so that it shows in DetailActivity
     */
    long distance = Math.round(s.getDistance(Scope.LAP));
    long time = Math.round(s.getTime(Scope.LAP));
    long hr = Math.round(s.getHeartRate(Scope.LAP));
    if (distance > 0 || time > 0) {
      ContentValues tmp = new ContentValues();
      tmp.put(DB.LAP.DISTANCE, distance);
      tmp.put(DB.LAP.TIME, time);
      tmp.put(DB.LAP.AVG_HR, Math.round(hr));
      s.saveLap(tmp, /* next lap */ false);
    }
  }

  @Override
  public void onPause(Workout s) {
    if (isOffRestStep()) {
      // Manual pause during Descanso Off freezes only the rest countdown.
      sampleOffRest(true);
    } else {
      s.tracker.pause();
    }
    for (Trigger t : triggers) {
      t.onPause(s);
    }
  }

  private double mPrevTickLapDistance = 0;
  private double mPrevTickStepDistance = 0;
  private double mPrevTickStepTime = 0;

  /**
   * @return true if finished
   */
  public boolean onTick(Workout s) {
    if (isOffRestStep()) {
      sampleOffRest(s.isPaused());
    }

    if (checkFinished(s)) {
      return true;
    }

    for (Trigger t : triggers) {
      t.onTick(s);
    }

    return false;
  }

  private boolean exceedDistance(
      double distance, double prevDistance, double refDist, double time) {
    return distance >= refDist
        ||
        // autolap if this point is closer to the limit then next point
        // (assuming the time/speed is is the same to next tick, but this should even out)
        prevDistance > 0
            && time > mPrevTickStepTime
            && (distance + (distance - prevDistance) / 2) >= refDist;
  }

  private boolean checkFinished(Workout s) {
    // Descanso Off uses an independent wall-clock countdown while the Tracker
    // itself is paused. Therefore Scope.STEP time remains frozen and cannot be
    // used to decide when this block ends.
    if (isOffRestStep()) {
      return getPaceCoachOffRestRemainingSeconds() <= 0.0d;
    }

    if (this.getAutolap() == 0 && durationType == null) {
      return false;
    }

    boolean newStep = false;
    boolean newLap = false;
    double time = s.getTime(Scope.STEP);

    // Special handling for distance targets to end on (likely) closest
    if (durationType == Dimension.DISTANCE) {
      double distance = s.get(Scope.STEP, durationType);
      double lapDist = this.durationValue;
      if (exceedDistance(distance, mPrevTickStepDistance, lapDist, time)) {
        newStep = true;
      }
      mPrevTickStepDistance = distance;
    } else if (durationType == Dimension.TIME) {
      double diff = (time - mPrevTickStepTime) / 2;
      mPrevTickStepTime = time;
      // This point is more likely than next
      newStep = s.get(Scope.STEP, durationType) + diff >= this.durationValue;
    }

    if (!newStep && this.getAutolap() > 0) {
      double distance = s.getDistance(Scope.LAP);
      double lapDist = getAutolap();
      if (exceedDistance(distance, mPrevTickLapDistance, lapDist, time)) {
        newLap = true;
      }
      mPrevTickLapDistance = distance;
    }
    mPrevTickStepTime = time;

    if (newStep) {
      return true;
    }
    if (newLap) {
      s.onNewLap();
    }

    return false;
  }

  public boolean onNextStep(Workout w) {
    return true; // move to next step
  }

  @Override
  public void onResume(Workout s) {
    if (isOffRestStep()) {
      // The tracker remains paused until this rest finishes. Only resume the
      // rest countdown after a manual pause is released.
      sampleOffRest(false);
    }

    for (Trigger t : triggers) {
      t.onResume(s);
    }
    if (!isOffRestStep()) {
      if (s.tracker != null) {
        s.tracker.resume();
      } else {
        android.util.Log.w("Step", "onResume: s.tracker is null");
      }
    }
  }

  @Override
  public void onComplete(Scope scope, Workout s) {
    if (scope == Scope.LAP) {
      double distance = s.getDistance(scope);
      long time = Math.round(s.getTime(scope));
      if (distance > 0 || time > 0) {
        ContentValues tmp = new ContentValues();
        tmp.put(DB.LAP.DISTANCE, distance);
        tmp.put(DB.LAP.TIME, time);
        long hr = Math.round(s.getHeartRate(scope));
        tmp.put(DB.LAP.AVG_HR, hr);
        s.saveLap(tmp, /* next lap */ true);
      }
    }
    for (Trigger t : triggers) {
      t.onComplete(scope, s);
    }

    if (scope == Scope.STEP) {
      for (Trigger t : triggers) {
        t.onEnd(s);
      }
    }
  }

  public double getDistance(Workout w, Scope s) {
    double d = w.getDistance(Scope.ACTIVITY);
    if (s == Scope.STEP) {
      return d - stepStartDistance;
    } else if (s == Scope.LAP) {
      return d - lapStartDistance;
    }
    if (BuildConfig.DEBUG) {
      throw new AssertionError();
    }
    return 0;
  }

  public double getTime(Workout w, Scope s) {
    if (isOffRestStep() && (s == Scope.STEP || s == Scope.LAP)) {
      sampleOffRest(w.isPaused());
      return offRestElapsedMs / 1000.0;
    }

    double t = w.getTime(Scope.ACTIVITY);
    if (s == Scope.STEP) {
      return t - stepStartTime;
    } else if (s == Scope.LAP) {
      return t - lapStartTime;
    }
    if (org.runnerup.BuildConfig.DEBUG) {
      throw new AssertionError();
    }
    return 0;
  }

  public double getSpeed(Workout w, Scope s) {
    double t = getTime(w, s);
    double d = getDistance(w, s);
    if (t != 0) {
      return d / t;
    }
    return 0;
  }

  public double getHeartbeats(Workout w, Scope s) {
    double t = w.getHeartbeats(Scope.ACTIVITY);
    if (s == Scope.STEP) {
      return t - stepStartHeartbeats;
    } else if (s == Scope.LAP) {
      return t - lapStartHeartbeats;
    }
    return 0;
  }

  public double getDuration(Dimension dimension) {
    if (durationType == dimension) return durationValue;
    return 0;
  }

  static Step createRestStep(Dimension dim, double duration, boolean recovery) {
    Step step;
    if (!recovery && (dim == null || dim == Dimension.TIME)) step = new PauseStep();
    else step = new Step();

    step.intensity = recovery ? Intensity.RECOVERY : Intensity.RESTING;
    step.durationType = dim;
    step.durationValue = duration;
    // A timed RESTING step is the Pace Coach "Descanso Off": it pauses the
    // activity/GPS clock while its own countdown runs independently. Give it
    // an explicit name so the shared execution UI and voice engine identify the
    // block correctly in structured workouts.
    if (!recovery && dim == Dimension.TIME) {
      step.setName("Descanso Off");
    }
    return step;
  }

  public void getSteps(Step parent, int i, List<Workout.StepListEntry> list) {
    list.add(new Workout.StepListEntry(list.size(), this, i, parent));
  }

  public Step getCurrentStep() {
    return this;
  }

  public int getRepeatCount() {
    return 0;
  }

  public void setRepeatCount(int val) {}

  public int getCurrentRepeat() {
    return 0;
  }

  public boolean isLastStep() {
    return true;
  }

  public boolean isPauseStep() {
    return false;
  }
}
