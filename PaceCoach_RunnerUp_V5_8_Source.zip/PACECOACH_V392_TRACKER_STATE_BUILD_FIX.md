# Pace Coach v392 — correção de compilação do ciclo final do treino

## Causa

A compilação da v390 falhava em `Workout.java` porque a condição de retomada do Tracker referenciava `org.runnerup.tracker.TrackerState`, mas o enum compartilhado fica no pacote `org.runnerup.common.tracker`.

## Correção

- Importado `org.runnerup.common.tracker.TrackerState` em `Workout.java`.
- A condição de retomada após um bloco final do tipo descanso OFF usa `TrackerState.PAUSED` da API real do Tracker.
- Nenhuma alteração foi feita na lógica de conclusão manual, na persistência dos blocos ou na proteção de recálculo da v390.

## Versão

- Revisão interna do app: `versionCode = 392` (Wear usa 393).
- `versionName = 2.11.0.18`.
- Artefato GitHub Actions: `pacecoach-apk-v392-tracker-state-build-fix`.
- Nome padrão do ZIP preservado: `PaceCoach_RunnerUp_V5_8_Source.zip`.

## Validação

- Referências a `org.runnerup.tracker.TrackerState`: nenhuma restante.
- `Workout.java` importa o enum do pacote compartilhado.
- Compilação Android ainda depende do GitHub Actions, pois este ambiente não tem Android SDK configurado.
