# Pace Coach / RunnerUp — revisão interna v388

## Diagnóstico

Na v386, a aba **Voltas** derivava parciais diretamente dos pontos GPS. O gravador `PersistentGpsLoggerListener` recebe `Tracker.getTimeMs()` e persiste `LOCATION.ELAPSED` em milissegundos. Entretanto, `DetailActivity.buildActivitySplits()` subtraía esse valor e o tratava como segundos.

Como consequência, a duração de cada trecho era inflada em aproximadamente 1.000 vezes. Na visualização por tempo, a lógica também considerava 60 milissegundos como um minuto e gerava uma quantidade excessiva de parciais minúsculas. Isso explica os ritmos como `6927:46` e `7889:20` nas capturas.

## Correção

- Normaliza `LOCATION.ELAPSED` de milissegundos para segundos antes de calcular as parciais.
- Mantém o fallback para GPX sem `ELAPSED`, convertendo a diferença de `LOCATION.TIME` (milissegundos) para segundos pela mesma função.
- Adiciona `ActivitySplitTime` para centralizar a conversão e limitar deltas negativos a zero.
- Adiciona testes unitários para conversão, referência inicial e timestamps fora de ordem.
- Não altera o cálculo de distância GPS, a gravação de posições, o formato do GPX nem o banco existente.

## Identificação

- Revisão interna: `v388`.
- `versionCode`: `388` (código Android esperado para o app: `23000388`, com minSdk 23).
- `versionName`: `2.11.0.14`.
- Artefato GitHub Actions: `pacecoach-apk-v388-split-time-fix`.
- O Wear mantém o `versionCode` seguinte, conforme a convenção já existente.

## Validação pendente

A correção tem testes unitários adicionados, mas é necessário executar o workflow GitHub Actions para confirmar compilação e testes Android. Depois, validar uma atividade existente e uma nova corrida: a aba Km deve mostrar ritmos plausíveis e a aba Tempo deve apresentar intervalos de um minuto, sem linhas de poucos milissegundos.
