package org.runnerup.view;

import android.content.ContentValues;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.TextView;
import android.view.ViewGroup;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import org.runnerup.R;
import org.runnerup.common.util.Constants;
import org.runnerup.content.ShareImageProvider;
import org.runnerup.db.DBHelper;
import org.runnerup.workout.Intensity;

/** Pace Coach visual activity sharing. Generates deterministic PNG cards from stored activity data. */
public class ShareActivity extends AppCompatActivity implements Constants {
  private static final int CARD_W = 1080;
  private static final int CARD_H = 1350;
  private static final int TEMPLATE_SUMMARY = 0;
  private static final int TEMPLATE_MAP = 1;
  private static final int TEMPLATE_STATS = 2;
  private static final int TEMPLATE_PACE = 3;
  private static final int TEMPLATE_BLOCKS = 4;
  private static final int TEMPLATE_MINIMAL = 5;
  private static final int TEMPLATE_SPLITS = 6;
  private static final int TEMPLATE_METRICS = 7;
  private static final int TEMPLATE_HERO = 8;
  private static final int TEMPLATE_OVERLAY = 9;
  private static final int TEMPLATE_ELEVATION = 10;
  private static final int FORMAT_PORTRAIT = 0;
  private static final int FORMAT_STORY = 1;
  private static final int FORMAT_SQUARE = 2;

  private long activityId;
  private ActivityData data;
  private ImageView preview;
  private int template = TEMPLATE_SUMMARY;
  private Bitmap rendered;
  private int format = FORMAT_PORTRAIT;
  private boolean transparentBackground = false;
  private ArrayList<ContentValues> blocks = new ArrayList<>();

  @Override protected void onCreate(Bundle state) {
    super.onCreate(state);
    setContentView(R.layout.share_activity);
    activityId = getIntent().getLongExtra("activity_id", -1L);
    if (activityId < 0) { finish(); return; }
    data = loadActivity(activityId);
    if (data == null) { Toast.makeText(this, "Atividade não encontrada", Toast.LENGTH_SHORT).show(); finish(); return; }
    preview = findViewById(R.id.share_preview);
    buildTemplateButtons();
    buildFormatButtons();
    findViewById(R.id.share_image_button).setOnClickListener(v -> shareImage());
    findViewById(R.id.share_copy_button).setOnClickListener(v -> copyImage());
    android.widget.CheckBox transparent = findViewById(R.id.share_transparent_background);
    transparent.setChecked(false);
    transparent.setOnCheckedChangeListener((button, checked) -> { transparentBackground = checked; render(); });
    render();
  }

  private void buildTemplateButtons() {
    LinearLayout row = findViewById(R.id.share_templates);
    String[] labels = {"Resumo", "Mapa", "Estatísticas", "Ritmo", "Blocos", "Minimal", "Parciais", "Cartões", "Distância", "Sobreposição", "Elevação"};
    for (int i = 0; i < labels.length; i++) {
      final int choice = i;
      Button b = new Button(this);
      b.setText(labels[i]);
      b.setAllCaps(false);
      b.setOnClickListener(v -> { template = choice; render(); });
      row.addView(b, new LinearLayout.LayoutParams(-2, -2));
    }
  }


  private void buildFormatButtons() {
    LinearLayout row = findViewById(R.id.share_formats);
    String[] labels = {"4:5", "9:16", "1:1"};
    for (int i = 0; i < labels.length; i++) {
      final int choice = i;
      Button b = new Button(this);
      b.setText(labels[i]);
      b.setAllCaps(false);
      b.setOnClickListener(v -> { format = choice; render(); });
      row.addView(b, new LinearLayout.LayoutParams(-2, -2));
    }
  }

  private void render() {
    int w = CARD_W;
    int h = format == FORMAT_STORY ? 1920 : (format == FORMAT_SQUARE ? 1080 : CARD_H);
    if (template == TEMPLATE_BLOCKS || template == TEMPLATE_SPLITS) h = Math.max(h, 500 + blocks.size() * 80);
    rendered = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
    Canvas c = new Canvas(rendered);
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
    if (!transparentBackground) c.drawColor(Color.rgb(4, 15, 23));
    // Fit the same design system to each social format instead of cropping metrics.
    if (format == FORMAT_STORY) {
      c.translate(0f, (h - CARD_H) / 2f);
    } else if (format == FORMAT_SQUARE) {
      c.translate(135f, 0f);
      c.scale(0.8f, 0.8f);
    }
    if (template != TEMPLATE_HERO) drawHeader(c, p);
    if (template == TEMPLATE_MAP) drawMap(c, p);
    if (template == TEMPLATE_STATS) drawStats(c, p);
    if (template == TEMPLATE_PACE) drawPace(c, p);
    if (template == TEMPLATE_BLOCKS) drawBlocks(c, p);
    if (template == TEMPLATE_MINIMAL) drawMinimal(c, p);
    if (template == TEMPLATE_SUMMARY) drawSummary(c, p);
    if (template == TEMPLATE_SPLITS) drawSplits(c, p);
    if (template == TEMPLATE_METRICS) drawMetricTiles(c, p);
    if (template == TEMPLATE_HERO) drawHero(c, p);
    if (template == TEMPLATE_OVERLAY) drawOverlay(c, p);
    if (template == TEMPLATE_ELEVATION) drawElevation(c, p);
    preview.setImageBitmap(rendered);
  }

  private void drawHeader(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(62); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("Pace", 70, 105, p); p.setColor(Color.rgb(80,170,255)); c.drawText(" Coach", 220, 105, p);
    p.setTypeface(Typeface.DEFAULT); p.setColor(Color.LTGRAY); p.setTextSize(28);
    c.drawText(data.name, 70, 150, p);
    p.setColor(Color.rgb(30,90,120)); c.drawRoundRect(60, 185, 1020, 190, 3, 3, p);
  }

  private void drawBlocks(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(44); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText(data.name, 70, 270, p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(25); p.setColor(Color.LTGRAY);
    c.drawText(blocks.size() + " blocos  •  " + formatDistance(data.distance) + "  •  " + formatTime(data.time), 70, 315, p);
    int y = 375;
    int target = 0, inside = 0, slower = 0, faster = 0;
    int footerHeight = 150;
    int available = Math.max(1, rendered.getHeight() - y - footerHeight);
    int rowHeight = blocks.isEmpty() ? 80 : Math.max(42, Math.min(100, available / blocks.size()));
    float rowTextSize = rowHeight < 58 ? 17 : (rowHeight < 75 ? 21 : 25);
    for (int i=0; i<blocks.size(); i++) {
      ContentValues b = blocks.get(i);
      double d = getDouble(b, DB.LAP.DISTANCE);
      long t = getLong(b, DB.LAP.TIME);
      double actual = t > 0 && d > 0 ? t * 1000.0 / d : 0;
      double min = getTarget(b, DB.LAP.PLANNED_PACE_MIN, DB.LAP.PLANNED_PACE);
      double max = getTarget(b, DB.LAP.PLANNED_PACE_MAX, DB.LAP.PLANNED_PACE);
      boolean has = min > 0 && max > 0;
      if (has) { target++; if (actual >= min && actual <= max) inside++; else if (actual < min) faster++; else if (actual > max) slower++; }
      int intensity = getInt(b, DB.LAP.INTENSITY, 1);
      int color = blockColor(intensity);
      p.setColor(color); c.drawRoundRect(new RectF(70,y-27,91,y-6), 5,5,p);
      p.setColor(Color.WHITE); p.setTextSize(rowTextSize); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText((i+1)+"  "+blockTitle(intensity), 108,y-5,p);
      p.setTypeface(Typeface.DEFAULT); p.setTextSize(Math.max(14,rowTextSize-4)); p.setColor(Color.LTGRAY);
      String info = formatDistance(d) + "  •  " + formatTime(t) + "  •  " + (actual>0?formatPace(actual):"—");
      c.drawText(info, 108, y+Math.max(15,rowHeight*0.25f), p);
      if (has && rowHeight >= 55) c.drawText("Alvo " + formatRange(min,max), 650, y+Math.max(15,rowHeight*0.25f), p);
      y += rowHeight;
    }
    if (target > 0) {
      int success = inside + faster;
      p.setColor(Color.WHITE); p.setTextSize(30); p.setTypeface(Typeface.DEFAULT_BOLD);
      c.drawText("Desempenho",70,rendered.getHeight()-120,p);
      p.setTypeface(Typeface.DEFAULT); p.setTextSize(25); p.setColor(Color.rgb(90,220,120));
      c.drawText(Math.round(success*100f/target)+"% dentro ou mais rápido que o alvo",70,rendered.getHeight()-78,p);
      p.setColor(Color.LTGRAY); c.drawText(inside+" dentro  •  "+slower+" mais lento  •  "+faster+" mais rápido",70,rendered.getHeight()-42,p);
    }
  }

  private void drawMinimal(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(34); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("PACE COACH",70,220,p);
    p.setColor(Color.rgb(80,170,255)); p.setTextSize(110); c.drawText(formatDistance(data.distance),70,430,p);
    p.setColor(Color.WHITE); p.setTextSize(58); c.drawText(formatPace(data.distance,data.time),70,535,p);
    p.setColor(Color.LTGRAY); p.setTextSize(30); c.drawText(formatTime(data.time),70,595,p);
    p.setColor(Color.rgb(80,170,255)); c.drawRoundRect(70,690,1010,700,5,5,p);
    p.setColor(Color.LTGRAY); p.setTextSize(26); c.drawText(data.name,70,780,p);
  }

  private void drawSplits(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(46); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("Parciais", 70, 270, p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(25); p.setColor(Color.LTGRAY);
    c.drawText("Segmentos registrados nesta atividade", 70, 315, p);
    if (blocks.isEmpty()) { c.drawText("Sem parciais registradas", 70, 410, p); return; }
    int top=380, bottom=rendered.getHeight()-120;
    int rh=Math.max(36,Math.min(88,(bottom-top)/blocks.size()));
    for(int i=0;i<blocks.size();i++) {
      ContentValues b=blocks.get(i); int y=top+i*rh;
      double d=getDouble(b,DB.LAP.DISTANCE); long t=getLong(b,DB.LAP.TIME);
      double pace=d>0&&t>0?t*1000.0/d:0;
      p.setColor(Color.rgb(25,43,55)); c.drawRoundRect(new RectF(65,y,1015,y+rh-5),12,12,p);
      p.setColor(Color.WHITE); p.setTextSize(rh<55?20:27); p.setTypeface(Typeface.DEFAULT_BOLD);
      c.drawText(String.valueOf(i+1),85,y+rh*0.62f,p);
      p.setTypeface(Typeface.DEFAULT); c.drawText(formatDistance(d),155,y+rh*0.62f,p);
      c.drawText(formatTime(t),470,y+rh*0.62f,p);
      c.drawText(pace>0?formatPace(pace):"—",740,y+rh*0.62f,p);
    }
  }

  private void drawMetricTiles(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(46); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(data.name,70,270,p);
    tile(c,p,"DISTÂNCIA",formatDistance(data.distance),70,350,490,570,Color.rgb(35,155,240));
    tile(c,p,"TEMPO TOTAL",formatTime(data.time),535,350,1010,570,Color.rgb(0,190,220));
    tile(c,p,"RITMO MÉDIO",formatPace(data.distance,data.time),70,610,490,830,Color.rgb(30,210,130));
    tile(c,p,"ELEVAÇÃO",data.elevation>0?formatNumber(data.elevation)+" m":"—",535,610,1010,830,Color.rgb(100,190,230));
    tile(c,p,"FC MÉDIA",data.avgHr>0?data.avgHr+" bpm":"—",70,870,490,1090,Color.rgb(245,90,105));
    tile(c,p,"CADÊNCIA",data.avgCadence>0?formatNumber(data.avgCadence)+" ppm":"—",535,870,1010,1090,Color.rgb(170,120,255));
  }

  private void tile(Canvas c,Paint p,String label,String value,float l,float t,float r,float b,int accent) {
    p.setColor(Color.argb(220,13,27,38)); c.drawRoundRect(new RectF(l,t,r,b),28,28,p);
    p.setColor(accent); c.drawRoundRect(l,t,l+9,b,5,5,p);
    p.setColor(Color.LTGRAY); p.setTextSize(23); p.setTypeface(Typeface.DEFAULT); c.drawText(label,l+28,t+52,p);
    p.setColor(Color.WHITE); p.setTextSize(48); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(value,l+28,t+125,p);
  }

  private void drawHero(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(38); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("Pace Coach",70,130,p);
    p.setTextSize(54); c.drawText(data.name,70,245,p);
    p.setColor(Color.rgb(255,145,30)); c.drawRoundRect(70,285,1010,300,7,7,p);
    p.setColor(Color.WHITE); p.setTextSize(160); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(formatDistance(data.distance).replace(" km", ""),70,600,p);
    p.setTextSize(52); c.drawText(data.distance>=1000?"KM":"METROS",80,665,p);
    stat(c,p,"TEMPO",formatTime(data.time),70,870);
    stat(c,p,"RITMO MÉDIO",formatPace(data.distance,data.time),560,870);
    stat(c,p,"ELEVAÇÃO",data.elevation>0?formatNumber(data.elevation)+" m":"—",70,1110);
    p.setColor(Color.LTGRAY); p.setTextSize(22); c.drawText(new SimpleDateFormat("dd MMM yyyy · HH:mm",Locale.getDefault()).format(new Date(data.startTime*1000L)),560,1175,p);
  }

  private void drawElevation(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(46); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("Perfil de elevação",70,270,p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(26); p.setColor(Color.LTGRAY);
    c.drawText(data.elevation>0?"Ganho acumulado: "+formatNumber(data.elevation)+" m":"Dados de altitude indisponíveis",70,325,p);
    float x=75,y=410,w=930,h=590;
    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.rgb(35,75,90));
    for(int i=0;i<5;i++) c.drawLine(x,y+i*h/4f,x+w,y+i*h/4f,p);
    double min=Double.MAX_VALUE,max=-Double.MAX_VALUE; int count=0;
    for(double[] pt:data.route) if(pt.length>2&&!Double.isNaN(pt[2])) {min=Math.min(min,pt[2]);max=Math.max(max,pt[2]);count++;}
    if(count>=2&&max>min) {
      Path path=new Path(); boolean first=true; int valid=0;
      for(int i=0;i<data.route.size();i++){double[] pt=data.route.get(i);if(pt.length<=2||Double.isNaN(pt[2]))continue;float xx=x+(w*valid/(float)Math.max(1,count-1));float yy=y+h-(float)((pt[2]-min)/(max-min))*h;if(first){path.moveTo(xx,yy);first=false;}else path.lineTo(xx,yy);valid++;}
      p.setColor(Color.rgb(40,220,135));p.setStrokeWidth(8);c.drawPath(path,p);
      p.setStyle(Paint.Style.FILL);p.setColor(Color.LTGRAY);p.setTextSize(23);c.drawText(formatNumber(min)+" m",75,1035,p);c.drawText(formatNumber(max)+" m",75,385,p);
    } else {
      p.setStyle(Paint.Style.FILL);p.setColor(Color.LTGRAY);p.setTextSize(28);c.drawText("Esta atividade não possui pontos de altitude suficientes.",70,570,p);
    }
    stat(c,p,"DISTÂNCIA",formatDistance(data.distance),70,1130);
    stat(c,p,"TEMPO",formatTime(data.time),560,1130);
  }

  private void drawOverlay(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(48); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(data.name,70,260,p);
    p.setColor(Color.rgb(80,170,255)); p.setStrokeWidth(8); c.drawRoundRect(70,290,1010,300,5,5,p);
    stat(c,p,"DISTÂNCIA",formatDistance(data.distance),70,430);
    stat(c,p,"TEMPO",formatTime(data.time),560,430);
    stat(c,p,"RITMO MÉDIO",formatPace(data.distance,data.time),70,690);
    stat(c,p,"ELEVAÇÃO",data.elevation>0?formatNumber(data.elevation)+" m":"—",560,690);
    p.setColor(Color.WHITE); p.setTextSize(26); p.setTypeface(Typeface.DEFAULT); c.drawText("Pace Coach",70,1120,p);
  }

  private int blockColor(int intensity) {
    Intensity type = Intensity.valueOf(intensity);
    if (type == Intensity.WARMUP) return Color.rgb(255,138,0);
    if (type == Intensity.RECOVERY) return Color.rgb(176,108,255);
    if (type == Intensity.RESTING) return Color.rgb(0,199,217);
    if (type == Intensity.COOLDOWN) return Color.rgb(92,107,192);
    return Color.rgb(45,155,240);
  }

  private String blockTitle(int intensity) {
    Intensity type = Intensity.valueOf(intensity);
    if (type == Intensity.WARMUP) return "Aquecimento";
    if (type == Intensity.RECOVERY) return "Recuperação";
    if (type == Intensity.RESTING) return "Descanso Off";
    if (type == Intensity.COOLDOWN) return "Desaquecimento";
    return "Intervalo";
  }

  private double getTarget(ContentValues b, String preferred, String legacy) {
    double v = b.containsKey(preferred) ? b.getAsDouble(preferred) * 1000.0 : 0;
    if (v > 0) return v;
    return b.containsKey(legacy) ? b.getAsDouble(legacy) * 1000.0 : 0;
  }

  private double getDouble(ContentValues b, String key) { return b.containsKey(key) ? b.getAsDouble(key) : 0; }
  private long getLong(ContentValues b, String key) { return b.containsKey(key) ? b.getAsLong(key) : 0; }
  private int getInt(ContentValues b, String key, int fallback) { return b.containsKey(key) ? b.getAsInteger(key) : fallback; }
  private String formatPace(double sec) { if (sec<=0) return "—"; long s=Math.round(sec); return String.format(Locale.getDefault(),"%d:%02d/km",s/60,s%60); }
  private String formatRange(double min,double max) { return Math.abs(min-max)<0.5 ? formatPace(min) : formatPace(min).replace("/km","")+" – "+formatPace(max).replace("/km",""); }

  private void drawSummary(Canvas c, Paint p) {
    stat(c,p,"DISTÂNCIA", formatDistance(data.distance), 70, 310);
    stat(c,p,"TEMPO", formatTime(data.time), 560, 310);
    stat(c,p,"RITMO MÉDIO", formatPace(data.distance, data.time), 70, 560);
    stat(c,p,"FC MÉDIA", data.avgHr > 0 ? data.avgHr + " bpm" : "—", 560, 560);
    stat(c,p,"CADÊNCIA", data.avgCadence > 0 ? formatNumber(data.avgCadence) + " ppm" : "—", 70, 810);
    stat(c,p,"DATA", new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date(data.startTime * 1000L)), 560, 810);
    p.setColor(Color.rgb(120,120,120)); p.setTextSize(24); c.drawText("Seu treinador de ritmo", 70, 1240, p);
  }

  private void drawStats(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(42); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("Resumo da atividade", 70, 270, p);
    p.setTypeface(Typeface.DEFAULT);
    stat(c,p,"Distância",formatDistance(data.distance),70,380);
    stat(c,p,"Tempo",formatTime(data.time),560,380);
    stat(c,p,"Ritmo médio",formatPace(data.distance,data.time),70,600);
    stat(c,p,"FC média",data.avgHr > 0 ? data.avgHr + " bpm" : "—",560,600);
    stat(c,p,"Cadência média",data.avgCadence > 0 ? formatNumber(data.avgCadence) + " ppm" : "—",70,820);
    stat(c,p,"Tipo", "Corrida",560,820);
  }

  private void drawPace(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(46); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("Ritmo da corrida", 70, 270, p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(26); p.setColor(Color.LTGRAY); c.drawText("Ritmo médio",70,360,p);
    p.setColor(Color.WHITE); p.setTextSize(88); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(formatPace(data.distance,data.time),70,470,p);
    drawSimplePaceGraph(c,p,70,570,940,430);
  }

  private void drawMap(Canvas c, Paint p) {
    p.setColor(Color.rgb(9,29,39)); c.drawRoundRect(55,220,1025,910,30,30,p);
    if (data.route.size() >= 2) {
      double minLat=Double.MAX_VALUE,maxLat=-Double.MAX_VALUE,minLon=Double.MAX_VALUE,maxLon=-Double.MAX_VALUE;
      for (double[] pt:data.route){minLat=Math.min(minLat,pt[0]);maxLat=Math.max(maxLat,pt[0]);minLon=Math.min(minLon,pt[1]);maxLon=Math.max(maxLon,pt[1]);}
      double latSpan=Math.max(0.00001,maxLat-minLat), lonSpan=Math.max(0.00001,maxLon-minLon);
      Path path=new Path(); boolean first=true;
      p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(9); p.setStrokeCap(Paint.Cap.ROUND); p.setColor(Color.rgb(60,170,255));
      for(double[] pt:data.route){float x=(float)(100+(pt[1]-minLon)/lonSpan*880); float y=(float)(870-(pt[0]-minLat)/latSpan*590); if(first){path.moveTo(x,y);first=false;}else path.lineTo(x,y);}
      c.drawPath(path,p); p.setStyle(Paint.Style.FILL);
    } else { p.setColor(Color.GRAY); p.setTextSize(30); c.drawText("Mapa indisponível para esta atividade",210,570,p); }
    stat(c,p,"DISTÂNCIA",formatDistance(data.distance),70,1020);
    stat(c,p,"TEMPO",formatTime(data.time),560,1020);
    stat(c,p,"RITMO",formatPace(data.distance,data.time),70,1200);
  }

  private void drawSimplePaceGraph(Canvas c, Paint p, float x,float y,float w,float h) {
    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(Color.rgb(30,80,105));
    for(int i=0;i<5;i++){float yy=y+i*h/4f;c.drawLine(x,yy,x+w,yy,p);}
    if(data.route.size()>=2){
      ArrayList<double[]> samples=new ArrayList<>(); double total=0; double[] prev=data.route.get(0);
      for(int i=1;i<data.route.size();i++){double[] cur=data.route.get(i);double meters=distanceMeters(prev[0],prev[1],cur[0],cur[1]);double seconds=(cur[3]-prev[3])/1000d;if(meters>=2&&seconds>0&&seconds<120){total+=meters;samples.add(new double[]{total,seconds*1000d/meters});}prev=cur;}
      if(!samples.isEmpty()&&total>0){p.setColor(Color.rgb(60,190,255));p.setStrokeWidth(8);Path path=new Path();boolean first=true;for(double[] sample:samples){float xx=x+(float)(sample[0]/Math.max(total,data.distance)*w);double pace=Math.max(240,Math.min(600,sample[1]));float yy=y+(float)((pace-240)/360d*h);if(first){path.moveTo(xx,yy);first=false;}else path.lineTo(xx,yy);}c.drawPath(path,p);}
    }
    p.setStyle(Paint.Style.FILL);
  }

  private double distanceMeters(double lat1,double lon1,double lat2,double lon2) {
    double dLat=Math.toRadians(lat2-lat1),dLon=Math.toRadians(lon2-lon1);
    double a=Math.sin(dLat/2)*Math.sin(dLat/2)+Math.cos(Math.toRadians(lat1))*Math.cos(Math.toRadians(lat2))*Math.sin(dLon/2)*Math.sin(dLon/2);
    return 6371000d*2*Math.atan2(Math.sqrt(a),Math.sqrt(Math.max(0,1-a)));
  }

  private void stat(Canvas c, Paint p, String label, String value, float x, float y) {
    p.setColor(Color.rgb(150,160,165)); p.setTextSize(24); p.setTypeface(Typeface.DEFAULT); c.drawText(label.toUpperCase(Locale.getDefault()),x,y,p);
    p.setColor(Color.WHITE); p.setTextSize(56); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(value,x,y+65,p);
  }

  private ActivityData loadActivity(long id) {
    SQLiteDatabase db=DBHelper.getReadableDatabase(this);
    ActivityData d=new ActivityData();
    Cursor c=db.query(DB.ACTIVITY.TABLE,new String[]{DB.ACTIVITY.NAME,DB.ACTIVITY.START_TIME,DB.ACTIVITY.DISTANCE,DB.ACTIVITY.TIME,DB.ACTIVITY.AVG_HR,DB.ACTIVITY.AVG_CADENCE},"_id=?",new String[]{String.valueOf(id)},null,null,null);
    if(!c.moveToFirst()){c.close();return null;}
    d.name=safe(c.getString(0),"Corrida"); d.startTime=c.getLong(1); d.distance=c.isNull(2)?0:c.getDouble(2); d.time=c.isNull(3)?0:c.getLong(3); d.avgHr=c.isNull(4)?0:c.getInt(4); d.avgCadence=c.isNull(5)?0:c.getDouble(5); c.close();
    Cursor l=db.query(DB.LOCATION.TABLE,new String[]{DB.LOCATION.LATITUDE,DB.LOCATION.LONGITUDE,DB.LOCATION.TYPE,DB.LOCATION.ALTITUDE,DB.LOCATION.TIME},DB.LOCATION.ACTIVITY+"=? AND ("+DB.LOCATION.TYPE+"=? OR "+DB.LOCATION.TYPE+"=?)",new String[]{String.valueOf(id),String.valueOf(DB.LOCATION.TYPE_GPS),String.valueOf(DB.LOCATION.TYPE_START)},null,null,DB.LOCATION.TIME+" ASC");
    double previousAltitude=Double.NaN;
    while(l.moveToNext()) { double altitude=l.isNull(3)?Double.NaN:l.getDouble(3); d.route.add(new double[]{l.getDouble(0),l.getDouble(1),altitude,l.getLong(4)}); if(!Double.isNaN(altitude)){if(!Double.isNaN(previousAltitude)&&altitude>previousAltitude&&altitude-previousAltitude<20)d.elevation+=altitude-previousAltitude;previousAltitude=altitude;} } l.close();
    Cursor bcur=db.query(DB.LAP.TABLE,new String[]{DB.LAP.INTENSITY,DB.LAP.TIME,DB.LAP.DISTANCE,DB.LAP.PLANNED_PACE,DB.LAP.PLANNED_PACE_MIN,DB.LAP.PLANNED_PACE_MAX},DB.LAP.ACTIVITY+"=?",new String[]{String.valueOf(id)},null,null,"_id ASC");
    while(bcur.moveToNext()) { ContentValues b=new ContentValues(); b.put(DB.LAP.INTENSITY,bcur.getInt(0)); b.put(DB.LAP.TIME,bcur.getLong(1)); b.put(DB.LAP.DISTANCE,bcur.getDouble(2)); if(!bcur.isNull(3)) b.put(DB.LAP.PLANNED_PACE,bcur.getDouble(3)); if(!bcur.isNull(4)) b.put(DB.LAP.PLANNED_PACE_MIN,bcur.getDouble(4)); if(!bcur.isNull(5)) b.put(DB.LAP.PLANNED_PACE_MAX,bcur.getDouble(5)); blocks.add(b); } bcur.close();
    return d;
  }

  private void shareImage() {
    try {
      File dir=new File(getCacheDir(),"share_cards"); if(!dir.exists()&&!dir.mkdirs()) throw new Exception("cache");
      String name="pacecoach_"+activityId+"_"+template+".png"; File file=new File(dir,name);
      try(FileOutputStream out=new FileOutputStream(file)){rendered.compress(Bitmap.CompressFormat.PNG,100,out);}
      Uri uri=Uri.parse("content://"+ShareImageProvider.AUTHORITY+"/"+name);
      Intent send=new Intent(Intent.ACTION_SEND); send.setType("image/png"); send.putExtra(Intent.EXTRA_STREAM,uri); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
      startActivity(Intent.createChooser(send,"Compartilhar atividade"));
    } catch(Exception e){Toast.makeText(this,"Não foi possível gerar a imagem",Toast.LENGTH_SHORT).show();}
  }

  private void copyImage() {
    try {
      File dir=new File(getCacheDir(),"share_cards"); if(!dir.exists()&&!dir.mkdirs()) throw new Exception("cache");
      String name="pacecoach_"+activityId+"_"+template+"_clipboard.png"; File file=new File(dir,name);
      try(FileOutputStream out=new FileOutputStream(file)){rendered.compress(Bitmap.CompressFormat.PNG,100,out);}
      Uri uri=Uri.parse("content://"+ShareImageProvider.AUTHORITY+"/"+name);
      ClipData clip=ClipData.newUri(getContentResolver(),data.name,uri);
      ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
      if(clipboard==null) throw new Exception("clipboard");
      clipboard.setPrimaryClip(clip);
      Toast.makeText(this,"Imagem copiada. Cole em um app compatível com imagens.",Toast.LENGTH_LONG).show();
    } catch(Exception e){Toast.makeText(this,"Não foi possível copiar a imagem",Toast.LENGTH_SHORT).show();}
  }

  private static String safe(String s,String fallback){return s==null||s.trim().isEmpty()?fallback:s.trim();}
  private static String formatDistance(double meters){return meters>=1000?String.format(Locale.getDefault(),"%.2f km",meters/1000d):String.format(Locale.getDefault(),"%.0f m",meters);}
  private static String formatTime(long seconds){long sec=Math.max(0,seconds);if(sec>=3600)return String.format(Locale.getDefault(),"%02d:%02d:%02d",sec/3600,(sec%3600)/60,sec%60);return String.format(Locale.getDefault(),"%02d:%02d",sec/60,sec%60);}
  private static String formatPace(double meters,long ms){if(meters<=0||ms<=0)return "—";double secPerKm=(ms)/(meters/1000d);int s=(int)Math.round(secPerKm);return String.format(Locale.getDefault(),"%d:%02d/km",s/60,s%60);}
  private static String formatNumber(double v){return String.format(Locale.getDefault(),"%.0f",v);}

  private static class ActivityData {String name;long startTime,time;double distance,avgCadence,elevation;int avgHr;ArrayList<double[]> route=new ArrayList<>();}
}
