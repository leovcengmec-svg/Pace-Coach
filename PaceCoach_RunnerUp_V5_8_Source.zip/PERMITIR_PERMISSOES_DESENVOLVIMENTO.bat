@echo off
setlocal EnableExtensions EnableDelayedExpansion

title Pace Coach - Permissoes de Desenvolvimento

echo ============================================================
echo   Pace Coach - Concessao de permissoes para desenvolvimento
echo ============================================================
echo.

adb version >nul 2>&1
if errorlevel 1 (
  echo ERRO: ADB nao foi encontrado no PATH.
  echo Instale o Android SDK Platform-Tools e adicione a pasta ao PATH.
  echo.
  pause
  exit /b 1
)

set "PACKAGE="
for /f "tokens=1" %%P in ('adb shell pm list packages ^| findstr /r /c:"org\.runnerup\.free" /c:"org\.runnerup$"') do (
  set "LINE=%%P"
  set "PACKAGE=!LINE:package:=!"
  if not defined PACKAGE goto :package_found
)

:package_found
if not defined PACKAGE (
  echo ERRO: Pace Coach nao foi encontrado no dispositivo.
  echo Instale o APK de desenvolvimento primeiro e execute este BAT novamente.
  echo.
  pause
  exit /b 1
)

echo Pacote detectado: %PACKAGE%
echo.

echo Concedendo permissoes de localizacao...
adb shell pm grant %PACKAGE% android.permission.ACCESS_COARSE_LOCATION
adb shell pm grant %PACKAGE% android.permission.ACCESS_FINE_LOCATION
adb shell pm grant %PACKAGE% android.permission.ACCESS_BACKGROUND_LOCATION

echo Concedendo permissao de atividade fisica...
adb shell pm grant %PACKAGE% android.permission.ACTIVITY_RECOGNITION

echo Concedendo permissao de notificacoes...
adb shell pm grant %PACKAGE% android.permission.POST_NOTIFICATIONS
adb shell pm grant %PACKAGE% android.permission.BLUETOOTH_SCAN
adb shell pm grant %PACKAGE% android.permission.BLUETOOTH_CONNECT

echo.
echo Configurando operacao de localizacao em segundo plano quando suportado...
adb shell appops set %PACKAGE% ACCESS_BACKGROUND_LOCATION allow >nul 2>&1

echo.
echo ============================================================
echo Permissoes de desenvolvimento aplicadas.
echo ============================================================
echo.
echo Observacao: o Android pode limitar alguma permissao dependendo
echo da versao do sistema. Nesse caso, conceda somente a permissao
echo indicada pelo proprio Android.
echo.
pause
endlocal
