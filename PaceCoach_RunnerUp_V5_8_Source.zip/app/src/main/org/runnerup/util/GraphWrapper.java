/*
 * Copyright (C) 2012 - 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.FrameLayout;
import android.view.Gravity;
import android.widget.LinearLayout.LayoutParams;
import android.widget.Toast;
import androidx.preference.PreferenceManager;
import com.jjoe64.graphview.DefaultLabelFormatter;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;
import com.jjoe64.graphview.series.PointsGraphSeries;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.runnerup.R;
import org.runnerup.common.util.Constants;
import org.runnerup.db.entities.LocationEntity;
import org.runnerup.view.HRZonesBar;
import org.runnerup.workout.SpeedUnit;

public class GraphWrapper implements Constants {
  private final GraphView velocityGraphView;
  private final GraphView hrGraphView;
  private final GraphView elevationGraphView;
  private final GraphView cadenceGraphView;

  private final LinearLayout graphTab;
  private final HRZonesBar hrzonesBar;
  private final Formatter formatter;
  private final LinearLayout hrzonesBarLayout;
  private final LoadParam loadParam;

  private final ExecutorService executor = Executors.newSingleThreadExecutor();
  private final Handler handler = new Handler(Looper.getMainLooper());
  private final XAxis distanceXAxis;
  private final XAxis timeXAxis;
  private final int chartBlue = Color.rgb(20, 150, 255);
  private final int chartRed = Color.rgb(255, 82, 92);
  private final int chartGreen = Color.rgb(45, 220, 150);
  private final int chartPurple = Color.rgb(190, 70, 255);
  boolean firstLoad = true;
  boolean useDistanceAsX = true;
  private XAxis xAxis;
  private final List<GraphView> interactiveGraphs = new ArrayList<>();
  private final List<TextView> graphTooltips = new ArrayList<>();
  private final List<LineGraphSeries<DataPoint>> cursorLines = new ArrayList<>();
  private final List<PointsGraphSeries<DataPoint>> cursorPoints = new ArrayList<>();
  private double selectedGraphX = Double.NaN;
  private GraphProducer currentGraphData;

  /** Called when the activity is first created. */
  public GraphWrapper(
      Context context,
      LinearLayout graphTab,
      LinearLayout hrzonesBarLayout,
      final Formatter formatter,
      SQLiteDatabase mDB,
      long mID,
      boolean use_distance_as_x) {
    this.graphTab = graphTab;
    this.hrzonesBarLayout = hrzonesBarLayout;
    this.formatter = formatter;

    this.distanceXAxis =
        new XAxis() {
          @Override
          public String label() {
            return context.getString(org.runnerup.common.R.string.Distance);
          }

          public String labelLong() {
            return label() + " " + formatter.getDistanceUnit();
          }

          @Override
          public String formatLongValue(double value) {
            return formatter.getDistanceDisplay(value) + " " + formatter.getDistanceUnit();
          }

          @Override
          public String formatValue(double value) {
            return formatter.getDistanceDisplay(value);
          }

          @Override
          public double getX(double distance, double time_ms) {
            return distance;
          }

          @Override
          public String unit() {
            return formatter.getDistanceUnit();
          }
        };

    this.timeXAxis =
        new XAxis() {
          @Override
          public String label() {
            return context.getString(org.runnerup.common.R.string.Time);
          }

          public String labelLong() {
            return label();
          }

          @Override
          public String formatLongValue(double value) {
            return formatValue(value);
          }

          @Override
          public String formatValue(double value) {
            return formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, (long) value);
          }

          @Override
          public double getX(double distance, double time_ms) {
            return time_ms / 1000;
          }

          @Override
          public String unit() {
            return "";
          }
        };

    this.useDistanceAsX = use_distance_as_x;
    if (use_distance_as_x) {
      this.xAxis = distanceXAxis;
    } else {
      this.xAxis = timeXAxis;
    }

    loadParam = new LoadParam(context, mDB, mID);

    velocityGraphView = new GraphView(context);
    velocityGraphView
        .getGridLabelRenderer()
        .setLabelFormatter(
            new DefaultLabelFormatter() {
              @Override
              public String formatLabel(double value, boolean isValueX) {
                if (isValueX) {
                  return xAxis.formatValue(value);
                } else {
                  return formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_SHORT, value);
                }
              }
            });
    velocityGraphView.getGridLabelRenderer().setVerticalAxisTitle(formatter.getVelocityUnit());
    velocityGraphView.getGridLabelRenderer().setHorizontalAxisTitle(xAxis.labelLong());
    // enable zoom
    velocityGraphView.getViewport().setScalable(false);
    velocityGraphView.getViewport().setScrollable(false);

    hrGraphView = new GraphView(context);
    hrGraphView.getGridLabelRenderer().setVerticalAxisTitle("bpm");
    hrGraphView.getGridLabelRenderer().setHorizontalAxisTitle(xAxis.labelLong());
    hrGraphView
        .getGridLabelRenderer()
        .setLabelFormatter(
            new DefaultLabelFormatter() {
              @Override
              public String formatLabel(double value, boolean isValueX) {
                if (isValueX) {
                  return xAxis.formatValue(value);
                } else {
                  return formatter.formatHeartRate(Formatter.Format.TXT_SHORT, value);
                }
              }
            });
    hrGraphView.getViewport().setScalable(false);
    hrGraphView.getViewport().setScrollable(false);

    elevationGraphView = new GraphView(context);
    elevationGraphView.getGridLabelRenderer().setVerticalAxisTitle(formatter.getElevationUnit());
    elevationGraphView.getGridLabelRenderer().setHorizontalAxisTitle(xAxis.labelLong());
    elevationGraphView
        .getGridLabelRenderer()
        .setLabelFormatter(
            new DefaultLabelFormatter() {
              @Override
              public String formatLabel(double value, boolean isValueX) {
                if (isValueX) {
                  return xAxis.formatValue(value);
                } else {
                  return formatter.formatElevation(Formatter.Format.TXT_SHORT, value);
                }
              }
            });
    elevationGraphView.getViewport().setScalable(false);
    elevationGraphView.getViewport().setScrollable(false);

    cadenceGraphView = new GraphView(context);
    cadenceGraphView.getGridLabelRenderer().setVerticalAxisTitle("ppm");
    cadenceGraphView.getGridLabelRenderer().setHorizontalAxisTitle(xAxis.labelLong());
    cadenceGraphView.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter() {
      @Override public String formatLabel(double value, boolean isValueX) {
        if (isValueX) return xAxis.formatValue(value);
        return String.valueOf(Math.round(value));
      }
    });
    cadenceGraphView.getViewport().setScalable(false);
    cadenceGraphView.getViewport().setScrollable(false);

    styleGraph(velocityGraphView, chartBlue);
    styleGraph(hrGraphView, chartRed);
    styleGraph(elevationGraphView, chartGreen);
    styleGraph(cadenceGraphView, chartPurple);

    hrzonesBar = new HRZonesBar(context);
    loadGraph();
  }

  public void setUseDistanceAsX(boolean val) {
    if (val == useDistanceAsX) {
      return;
    }
    useDistanceAsX = val;
    if (val) {
      xAxis = distanceXAxis;
    } else {
      xAxis = timeXAxis;
    }
    velocityGraphView.removeAllSeries();
    hrGraphView.removeAllSeries();
    elevationGraphView.removeAllSeries();
    cadenceGraphView.removeAllSeries();
    loadGraph();
  }

  private void loadGraph() {
    executor.execute(
        () -> {
          // Background work
          GraphProducer producer = doLoadGraphInBackground(loadParam);
          // Post result to UI thread
          handler.post(() -> onPostExecute(producer));
        });
  }

  private GraphProducer doLoadGraphInBackground(LoadParam params) {
    LocationEntity.LocationList<LocationEntity> ll =
        new LocationEntity.LocationList<>(params.mDB, params.mID);
    GraphProducer graphData = new GraphProducer(params.context, ll.getCount());
    double lastDistance = 0;
    long lastTime = 0;
    int lastLap = -1;
    Double tot_distance = 0.0;
    double tot_time = 0.0;
    for (LocationEntity loc : ll) {
      Long time = loc.getElapsed();
      time = time != null ? time : lastTime;
      tot_time = time.doubleValue();
      Integer lap = loc.getLap();
      lap = lap != null ? lap : 0;
      tot_distance = tot_distance != null ? loc.getDistance() : lastDistance;

      double tot_X = xAxis.getX(tot_distance, time);
      if (lap != lastLap) {
        graphData.clearSmooth(tot_X);
        lastLap = lap;
      }

      graphData.addObservation(time - lastTime, tot_distance - lastDistance, tot_X, loc);
      graphData.totalElapsedMs = time;
      graphData.totalDistance = tot_distance;
      lastTime = time;
      lastDistance = tot_distance;
    }
    graphData.clearSmooth(xAxis.getX(tot_distance, tot_time));

    ll.close();
    return graphData;
  }

  private void onPostExecute(GraphProducer graphData) {
    if (graphData == null) return;

    graphData.complete(velocityGraphView);
    currentGraphData = graphData;
    interactiveGraphs.clear();
    graphTooltips.clear();
    cursorLines.clear();
    cursorPoints.clear();
    selectedGraphX = Double.NaN;
    graphTab.removeAllViews();

    // The approved design uses a continuous vertical analytics page: each chart
    // occupies the full available width and its metrics are listed underneath.
    // No horizontal scrolling or chip/filter row is used here.
    if (graphData.HasPaceInfo()) {
      addChartSection(graphTab, "Ritmo", velocityGraphView, graphData.paceStats(), chartBlue);
    }
    if (graphData.HasHRInfo()) {
      addChartSection(graphTab, "Frequência cardíaca", hrGraphView, graphData.hrStats(), chartRed);
    }
    if (graphData.HasCadenceInfo()) {
      addChartSection(graphTab, "Cadência", cadenceGraphView, graphData.cadenceStats(), chartPurple);
    }
    if (graphData.HasElevationInfo()) {
      addChartSection(graphTab, "Elevação", elevationGraphView, graphData.elevationStats(), chartGreen);
    }

    hrzonesBarLayout.removeView(hrzonesBar);
    if (graphData.HasHRZHist()) {
      hrzonesBarLayout.setVisibility(View.VISIBLE);
      hrzonesBarLayout.addView(hrzonesBar);
    } else {
      hrzonesBarLayout.setVisibility(View.GONE);
    }
    if (!firstLoad) {
      graphTab.invalidate();
    } else {
      firstLoad = false;
    }
  }

  /** Release background work when the owning activity is destroyed. */
  public void onDestroy() {
    executor.shutdownNow();
    handler.removeCallbacksAndMessages(null);
  }

  private int dp(int value) {
    return (int) (value * graphTab.getResources().getDisplayMetrics().density + 0.5f);
  }

  private void styleGraph(GraphView graph, int color) {
    graph.setBackgroundColor(Color.TRANSPARENT);
    graph.getGridLabelRenderer().setGridColor(Color.rgb(70, 78, 88));
    graph.getGridLabelRenderer().setHorizontalLabelsColor(Color.WHITE);
    graph.getGridLabelRenderer().setVerticalLabelsColor(Color.WHITE);
    graph.getGridLabelRenderer().setHorizontalAxisTitleColor(Color.WHITE);
    graph.getGridLabelRenderer().setVerticalAxisTitleColor(Color.WHITE);
    graph.getGridLabelRenderer().setTextSize(15);
    graph.getGridLabelRenderer().setNumHorizontalLabels(6);
    graph.getGridLabelRenderer().setNumVerticalLabels(5);
    graph.getGridLabelRenderer().setPadding(8);
  }

  private void addChip(LinearLayout row, String label, boolean selected, View.OnClickListener listener) {
    TextView chip = new TextView(row.getContext());
    chip.setText(label);
    chip.setTextSize(14);
    chip.setGravity(Gravity.CENTER);
    chip.setTextColor(Color.WHITE);
    chip.setPadding(dp(16), 0, dp(16), 0);
    GradientDrawable bg = new GradientDrawable();
    bg.setCornerRadius(dp(28));
    bg.setColor(selected ? chartBlue : Color.TRANSPARENT);
    bg.setStroke(dp(1), Color.rgb(52, 64, 74));
    chip.setBackground(bg);
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
    lp.setMargins(dp(3), 0, dp(3), 0);
    row.addView(chip, lp);
    chip.setOnClickListener(listener);
  }

  private void showCharts(LinearLayout root) {
    for (int i = 1; i < root.getChildCount(); i++) root.getChildAt(i).setVisibility(View.VISIBLE);
  }

  private void showOnly(LinearLayout root, String key) {
    for (int i = 1; i < root.getChildCount(); i++) {
      View v = root.getChildAt(i);
      Object tag = v.getTag();
      v.setVisibility(key.equals(tag) ? View.VISIBLE : View.GONE);
    }
  }

  private List<DataPoint> dataPointsForTitle(String title) {
    if (currentGraphData == null) return new ArrayList<>();
    if ("Ritmo".equals(title)) return currentGraphData.velocityList;
    if ("Frequência cardíaca".equals(title)) return currentGraphData.hrList;
    if ("Cadência".equals(title)) return currentGraphData.cadenceList;
    if ("Elevação".equals(title)) return currentGraphData.elevationList;
    return new ArrayList<>();
  }

  private void setupInteractiveGraph(
      GraphView graph, List<DataPoint> data, TextView tooltip, int accent) {
    if (data == null || data.isEmpty()) return;
    interactiveGraphs.add(graph);
    graphTooltips.add(tooltip);

    LineGraphSeries<DataPoint> cursor = new LineGraphSeries<>();
    cursor.setColor(Color.WHITE);
    cursor.setThickness(3);
    cursor.setDrawBackground(false);
    cursorLines.add(cursor);
    graph.addSeries(cursor);

    PointsGraphSeries<DataPoint> point = new PointsGraphSeries<>();
    point.setColor(Color.WHITE);
    point.setSize(dp(9));
    cursorPoints.add(point);
    graph.addSeries(point);

    graph.setOnTouchListener((v, event) -> {
      if (event.getAction() == android.view.MotionEvent.ACTION_DOWN
          || event.getAction() == android.view.MotionEvent.ACTION_MOVE) {
        double minX = graph.getViewport().getMinX(true);
        double maxX = graph.getViewport().getMaxX(true);
        if (maxX <= minX) return true;
        float localX = Math.max(0, Math.min(event.getX(), graph.getWidth()));
        double targetX = minX + (localX / Math.max(1, graph.getWidth())) * (maxX - minX);
        DataPoint nearest = data.get(0);
        double best = Math.abs(nearest.getX() - targetX);
        for (DataPoint p : data) {
          double d = Math.abs(p.getX() - targetX);
          if (d < best) { best = d; nearest = p; }
        }
        selectedGraphX = nearest.getX();
        updateSynchronizedCursors(selectedGraphX);
        return true;
      }
      return false;
    });
  }

  private void updateSynchronizedCursors(double x) {
    for (int i = 0; i < interactiveGraphs.size(); i++) {
      GraphView graph = interactiveGraphs.get(i);
      List<DataPoint> data = dataPointsForGraph(graph);
      if (data == null || data.isEmpty()) continue;
      DataPoint nearest = data.get(0);
      double best = Math.abs(nearest.getX() - x);
      double minY = nearest.getY(), maxY = nearest.getY();
      for (DataPoint p : data) {
        minY = Math.min(minY, p.getY());
        maxY = Math.max(maxY, p.getY());
        double d = Math.abs(p.getX() - x);
        if (d < best) { best = d; nearest = p; }
      }
      if (maxY == minY) { maxY += 1; minY -= 1; }
      cursorLines.get(i).resetData(new DataPoint[] {
          new DataPoint(nearest.getX(), minY), new DataPoint(nearest.getX(), maxY)
      });
      cursorPoints.get(i).resetData(new DataPoint[] { nearest });
      TextView tip = graphTooltips.get(i);
      tip.setText(formatSelectedValue(graph, nearest));
      tip.setVisibility(View.VISIBLE);
    }
  }

  private List<DataPoint> dataPointsForGraph(GraphView graph) {
    if (currentGraphData == null) return new ArrayList<>();
    if (graph == velocityGraphView) return currentGraphData.velocityList;
    if (graph == hrGraphView) return currentGraphData.hrList;
    if (graph == cadenceGraphView) return currentGraphData.cadenceList;
    if (graph == elevationGraphView) return currentGraphData.elevationList;
    return new ArrayList<>();
  }

  private String formatSelectedValue(GraphView graph, DataPoint p) {
    String distance = xAxis.formatLongValue(p.getX());
    if (graph == velocityGraphView) {
      return formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_LONG, p.getY()) + "\n" + distance;
    }
    if (graph == hrGraphView) {
      return formatter.formatHeartRate(Formatter.Format.TXT_LONG, p.getY()) + "\n" + distance;
    }
    if (graph == cadenceGraphView) {
      return Math.round(p.getY()) + " ppm\n" + distance;
    }
    return formatter.formatElevation(Formatter.Format.TXT_LONG, p.getY()) + "\n" + distance;
  }

  private void addChartSection(LinearLayout root, String title, GraphView graph, String[] stats, int accent) {
    LinearLayout section = new LinearLayout(root.getContext());
    section.setOrientation(LinearLayout.VERTICAL);
    section.setBackgroundColor(Color.TRANSPARENT);
    section.setPadding(dp(16), dp(14), dp(16), dp(14));

    TextView titleView = new TextView(root.getContext());
    titleView.setText(title);
    titleView.setTextColor(Color.WHITE);
    titleView.setTextSize(25);
    titleView.setTypeface(null, android.graphics.Typeface.BOLD);
    titleView.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
    section.addView(titleView, new LayoutParams(LayoutParams.MATCH_PARENT, dp(42)));

    graph.setBackgroundColor(Color.TRANSPARENT);
    FrameLayout graphFrame = new FrameLayout(root.getContext());
    LayoutParams gp = new LayoutParams(LayoutParams.MATCH_PARENT, dp(390));
    graphFrame.setLayoutParams(gp);
    graphFrame.addView(graph, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, dp(390)));

    TextView tooltip = new TextView(root.getContext());
    tooltip.setTextColor(Color.rgb(20, 25, 30));
    tooltip.setTextSize(16);
    tooltip.setTypeface(null, android.graphics.Typeface.BOLD);
    tooltip.setGravity(Gravity.CENTER);
    tooltip.setPadding(dp(14), dp(7), dp(14), dp(7));
    tooltip.setVisibility(View.GONE);
    GradientDrawable tooltipBg = new GradientDrawable();
    tooltipBg.setColor(accent);
    tooltipBg.setCornerRadius(dp(10));
    tooltip.setBackground(tooltipBg);
    FrameLayout.LayoutParams tipLp = new FrameLayout.LayoutParams(dp(150), dp(62));
    tipLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
    tipLp.topMargin = dp(2);
    graphFrame.addView(tooltip, tipLp);
    section.addView(graphFrame, gp);
    setupInteractiveGraph(graph, dataPointsForTitle(title), tooltip, accent);

    // Metrics are displayed as clean full-width rows below the chart, matching
    // the reference layout instead of using a side panel or a 3-column grid.
    for (String stat : stats) {
      String[] parts = stat.split("\\n", 2);
      LinearLayout row = new LinearLayout(root.getContext());
      row.setOrientation(LinearLayout.HORIZONTAL);
      row.setGravity(Gravity.CENTER_VERTICAL);
      row.setPadding(0, dp(8), 0, dp(8));

      TextView label = new TextView(root.getContext());
      label.setText(parts.length > 0 ? parts[0] : "");
      label.setTextColor(Color.WHITE);
      label.setTextSize(18);
      label.setGravity(Gravity.CENTER_VERTICAL);

      TextView value = new TextView(root.getContext());
      value.setText(parts.length > 1 ? parts[1] : "");
      value.setTextColor(Color.WHITE);
      value.setTextSize(18);
      value.setTypeface(null, android.graphics.Typeface.BOLD);
      value.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);

      row.addView(label, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
      row.addView(value, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
      section.addView(row, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

      View divider = new View(root.getContext());
      divider.setBackgroundColor(Color.rgb(48, 48, 48));
      section.addView(divider, new LayoutParams(LayoutParams.MATCH_PARENT, dp(1)));
    }

    // Thin separator between analytical sections.
    View sectionDivider = new View(root.getContext());
    sectionDivider.setBackgroundColor(Color.rgb(8, 8, 8));
    LinearLayout.LayoutParams dividerLp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, dp(4));
    dividerLp.setMargins(-dp(16), dp(8), -dp(16), -dp(14));
    section.addView(sectionDivider, dividerLp);

    LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
    sp.setMargins(0, 0, 0, 0);
    root.addView(section, sp);
  }

  private double calculateAverageHr(int[] data) {
    int sum = 0;
    int no = 0;

    for (int aData : data) {
      if (aData > 0) {
        sum = sum + aData;
        no++;
      }
    }
    // TODO Average of pointe, not over time
    if (no == 0) {
      return 0;
    } else {
      return (double) sum / no;
    }
  }

  interface XAxis {
    String label();

    String labelLong();

    String formatLongValue(double val);

    String formatValue(double val);

    double getX(double distance, double time_ms);

    String unit();
  }

  record LoadParam(Context context, SQLiteDatabase mDB, long mID) {}

  class GraphProducer {
    final int interval;
    final double[] time;
    final double[] distance;
    final double[] elevation;
    final double[] cadence;
    final int[] hr;
    final List<DataPoint> velocityList;
    final List<DataPoint> hrList;
    final List<DataPoint> elevationList;
    final List<DataPoint> cadenceList;
    final HRZones hrCalc;
    final SpeedUnit preferred_speedunit;
    boolean first = true;
    int pos = 0;
    double sum_time = 0;
    double sum_distance = 0;
    double acc_time = 0;
    double[] hrzHist = null;
    double tot_avg_hr = 0;
    double totalHrSum = 0;
    long totalHrCount = 0;
    int overallMaxHr = 0;
    int overallMinHr = Integer.MAX_VALUE;
    double cadenceSum = 0;
    int cadenceCount = 0;
    double cadenceMin = Double.MAX_VALUE;
    double cadenceMax = Double.MIN_VALUE;
    double avg_velocity = 0;
    double totalElapsedMs = 0;
    double totalDistance = 0;
    double min_velocity = Double.MAX_VALUE;
    double max_velocity = Double.MIN_VALUE;
    boolean showPace = false;
    boolean showElevation = false;
    boolean showHR = false;
    boolean showHRZhist = false;
    boolean showCadence = false;

    public GraphProducer(Context context, int noPoints) {
      final int GRAPH_INTERVAL_SECONDS = 5; // 1 point every 5 sec
      final int GRAPH_AVERAGE_SECONDS = 30; // moving average 30 sec

      final int graphAverageSeconds;
      if (noPoints < 60) {
        // This is short, maybe when testing. Dont bother to check time between points
        graphAverageSeconds = 1;
        this.interval = 2;
      } else {
        graphAverageSeconds = GRAPH_AVERAGE_SECONDS;
        this.interval = GRAPH_INTERVAL_SECONDS;
      }
      this.velocityList = new ArrayList<>();
      this.time = new double[graphAverageSeconds];
      this.distance = new double[graphAverageSeconds];

      this.hrList = new ArrayList<>();
      this.hr = new int[graphAverageSeconds];

      this.elevationList = new ArrayList<>();
      this.elevation = new double[graphAverageSeconds];
      this.cadenceList = new ArrayList<>();
      this.cadence = new double[graphAverageSeconds];

      Resources res = context.getResources();
      Context ctx = context.getApplicationContext();
      SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
      this.hrCalc = new HRZones(res, prefs);
      if (hrCalc.isConfigured()) {
        this.hrzHist = new double[hrCalc.getCount() + 1];
        Arrays.fill(this.hrzHist, 0);
        showHRZhist = true;
      }
      this.preferred_speedunit = formatter.getPreferredSpeedUnit();

      clearSmooth(0);
    }

    void clearSmooth(double tot_X) {
      if (pos >= (this.time.length / 2)
          && (acc_time >= 1000 * (interval / 2.0))
          && xAxis.getX(sum_distance, sum_time) > 0) {
        emit(tot_X);
      }

      for (int i = 0; i < this.distance.length; i++) {
        time[i] = 0;
        distance[i] = 0;
        hr[i] = 0;
        elevation[i] = 0;
        cadence[i] = 0;
      }
      pos = 0;
      sum_time = 0;
      sum_distance = 0;
      acc_time = 0;
    }

    void addObservation(
        double delta_time, double delta_distance, double tot_X, LocationEntity loc) {
      // delta_time is in ms, dist in m
      if (delta_time < 500) return;

      // Update moving average
      int p = pos % this.time.length;
      sum_time -= this.time[p];
      sum_time += delta_time;
      sum_distance -= this.distance[p];
      sum_distance += delta_distance;
      this.time[p] = delta_time;
      this.distance[p] = delta_distance;

      if (loc.getHr() != null) {
        showHR = true;
        int hr = loc.getHr();
        this.hr[p] = hr;

        if (showHRZhist && hr > 0) {
          this.hrzHist[hrCalc.getZoneInt(hr)] += delta_time;
        }
      } else {
        this.hr[p] = 0;
      }

      Double altitude = loc.getAltitude();
      this.elevation[p] = altitude != null ? altitude : 0.0;
      Double cadenceValue = loc.getCadence();
      this.cadence[p] = cadenceValue != null && cadenceValue > 0 ? cadenceValue : 0.0;
      if (this.cadence[p] > 0) {
        showCadence = true;
      }

      if (delta_distance > 0 && delta_time > 0) {
        showPace = true;
        if (altitude != null) showElevation = true;
        ;
      }

      pos += 1;
      acc_time += delta_time;

      if (pos >= this.time.length
          && (acc_time >= 1000 * interval)
          && xAxis.getX(sum_distance, sum_time) > 0) {
        emit(tot_X);
      }
    }

    void emit(double tot_X) {
      double avg_time = sum_time;
      double avg_dist = sum_distance;
      double avg_hr = calculateAverageHr(hr);

      double velocity = avg_time == 0 ? 0.0 : avg_dist * 1000.0 / avg_time;
      final double paceLimit = 1000.0 / 60.0 / 15.0;
      if (this.preferred_speedunit == SpeedUnit.PACE) {
        // Avoid presenting very slow pace (easier than to handle manual y axis scaling)
        velocity = Math.max(velocity, paceLimit);
      }

      double elevation = this.elevation[pos % this.time.length];
      double cadenceValue = 0;
      int cadenceSamples = 0;
      for (double c : this.cadence) { if (c > 0) { cadenceValue += c; cadenceSamples++; } }
      if (cadenceSamples > 0) {
        cadenceValue /= cadenceSamples;
        cadenceList.add(new DataPoint(tot_X, cadenceValue));
        cadenceSum += cadenceValue;
        cadenceCount++;
        cadenceMin = Math.min(cadenceMin, cadenceValue);
        cadenceMax = Math.max(cadenceMax, cadenceValue);
      }

      if (first) {
        if (tot_X > 0) {
          velocityList.add(new DataPoint(0, velocity));
          elevationList.add(new DataPoint(0, elevation));
          if (avg_hr > 0) {
            hrList.add(new DataPoint(0, Math.round(avg_hr)));
          }
        }
        first = false;
      }
      velocityList.add(new DataPoint(tot_X, velocity));
      elevationList.add(new DataPoint(tot_X, elevation));
      if (avg_hr > 0) {
        hrList.add(new DataPoint(tot_X, Math.round(avg_hr)));
      }
      acc_time = 0;

      if (avg_hr > 0) {
        totalHrSum += avg_hr;
        totalHrCount++;
      }
      for (int h : hr) {
        if (h > 0) {
          overallMaxHr = Math.max(overallMaxHr, h);
          overallMinHr = Math.min(overallMinHr, h);
        }
      }
      tot_avg_hr += avg_hr;
      avg_velocity += velocity;
      min_velocity = Math.min(min_velocity, velocity);
      max_velocity = Math.max(max_velocity, velocity);

      if (sum_distance > 0 && sum_time > 0) {
        showPace = true;
      }
    }

    public void complete(final GraphView graphView) {
      // GPX imports can contain only a small number of GPS points. Flush the
      // pending sample so short imported activities still produce a graph.
      if (velocityList.isEmpty() && pos > 0 && acc_time > 0 && sum_distance > 0) {
        emit(xAxis.getX(sum_distance, sum_time));
      } else if (!velocityList.isEmpty() && pos > 0 && acc_time > 0
          && sum_distance > 0 && xAxis.getX(sum_distance, sum_time) > 0) {
        emit(xAxis.getX(sum_distance, sum_time));
      }

      if (velocityList.isEmpty()) {
        avg_velocity = 0;
      } else {
        avg_velocity /= velocityList.size();
      }
      Log.d(getClass().getName(), "graph: " + velocityList.size() + " points");

      boolean smoothData =
          PreferenceManager.getDefaultSharedPreferences(graphView.getContext())
              .getBoolean(
                  graphView
                      .getContext()
                      .getResources()
                      .getString(R.string.pref_pace_graph_smoothing),
                  true);
      if (!velocityList.isEmpty() && smoothData) {
        GraphFilter f = new GraphFilter(velocityList);
        final String defaultFilterList =
            graphView.getContext().getResources().getString(R.string.mm31kz513sg5);
        final String filterList =
            PreferenceManager.getDefaultSharedPreferences(graphView.getContext())
                .getString(
                    graphView
                        .getContext()
                        .getResources()
                        .getString(R.string.pref_pace_graph_smoothing_filters),
                    defaultFilterList);
        final String[] filters = filterList.split(";");
        StringBuilder s =
            new StringBuilder("Applying filters(" + filters.length + ", >" + filterList + "<):");
        for (String filter : filters) {
          int[] args = getArgs(filter);
          if (filter.startsWith("mm")) {
            if (args.length == 1) {
              f.movingMedian(args[0]);
              s.append(" mm(").append(args[0]).append(")");
            }
          } else if (filter.startsWith("ma")) {
            if (args.length == 1) {
              f.movingAvergage(args[0]);
              s.append(" ma(").append(args[0]).append(")");
            }
          } else if (filter.startsWith("kz")) {
            if (args.length == 2) {
              f.KolmogorovZurbenko(args[0], args[1]);
              s.append(" kz(").append(args[0]).append(",").append(args[1]).append(")");
            }
          } else if (filter.startsWith("sg")) {
            if (args.length == 1 && args[0] == 5) {
              f.SavitzkyGolay5();
              s.append(" sg(5)");
            } else if (args.length == 1 && args[0] == 7) {
              f.SavitzkyGolay7();
              s.append(" sg(7)");
            }
          }
        }
        Log.d(getClass().getName(), s.toString());
        f.complete();
      }
      LineGraphSeries<DataPoint> velocityGraphViewData =
          new LineGraphSeries<>(velocityList.toArray(new DataPoint[0]));
      velocityGraphViewData.setColor(chartBlue);
      velocityGraphViewData.setThickness(3);
      velocityGraphViewData.setDrawBackground(true);
      velocityGraphViewData.setBackgroundColor(0x664096F0);
      graphView.addSeries(velocityGraphViewData); // data
      graphView.getViewport().setMinX(graphView.getViewport().getMinX(true));
      graphView.getViewport().setMaxX(graphView.getViewport().getMaxX(true));
      velocityGraphViewData.setOnDataPointTapListener(
          (series, dataPoint) -> {
            String msg =
                String.format(
                    "%s: %s\n%s: %s",
                    xAxis.label(),
                    xAxis.formatLongValue(dataPoint.getX()),
                    formatter.formatVelocityLabel(),
                    formatter.formatVelocityByPreferredUnit(
                        Formatter.Format.TXT_LONG, dataPoint.getY()));
            Toast.makeText(graphView.getContext(), msg, Toast.LENGTH_SHORT).show();
          });
      if (showHR) {
        LineGraphSeries<DataPoint> hrGraphViewData =
            new LineGraphSeries<>(hrList.toArray(new DataPoint[0]));
        hrGraphViewData.setColor(chartRed);
        hrGraphViewData.setThickness(3);
        hrGraphViewData.setDrawBackground(true);
        hrGraphViewData.setBackgroundColor(0x66FF525C);
        hrGraphView.addSeries(hrGraphViewData); // data
        hrGraphView.getViewport().setMinX(hrGraphView.getViewport().getMinX(true));
        hrGraphView.getViewport().setMaxX(hrGraphView.getViewport().getMaxX(true));
        hrGraphViewData.setOnDataPointTapListener(
            (series, dataPoint) -> {
              String msg =
                  String.format(
                      "%s: %s\n%s: %s",
                      xAxis.label(),
                      xAxis.formatLongValue(dataPoint.getX()),
                      graphView.getContext().getString(org.runnerup.common.R.string.Heart_rate),
                      formatter.formatHeartRate(Formatter.Format.TXT_LONG, dataPoint.getY()));
              Toast.makeText(graphView.getContext(), msg, Toast.LENGTH_SHORT).show();
            });

        if (showHRZhist) {
          StringBuilder s = new StringBuilder("HR Zones:");
          double sum = 0;
          for (double aHrzHist : hrzHist) {
            sum += aHrzHist;
          }
          if (sum > 0) {
            for (int i = 0; i < hrzHist.length; i++) {
              hrzHist[i] = hrzHist[i] / sum;
              s.append(" ").append(hrzHist[i]);
            }
          }
          Log.d(getClass().getName(), s.toString());
          hrzonesBar.pushHrzData(hrzHist);
        }
      }
      if (showElevation) {
        LineGraphSeries<DataPoint> elevationGraphViewData =
            new LineGraphSeries<>(elevationList.toArray(new DataPoint[0]));
        elevationGraphViewData.setColor(chartGreen);
        elevationGraphViewData.setThickness(3);
        elevationGraphViewData.setDrawBackground(true);
        elevationGraphViewData.setBackgroundColor(0x6630DFA0);
        elevationGraphView.addSeries(elevationGraphViewData); // data
        elevationGraphView.getViewport().setMinX(elevationGraphView.getViewport().getMinX(true));
        elevationGraphView.getViewport().setMaxX(elevationGraphView.getViewport().getMaxX(true));
        elevationGraphViewData.setOnDataPointTapListener(
            (series, dataPoint) -> {
              String msg =
                  String.format(
                      "%s: %s\n%s: %s",
                      xAxis.label(),
                      xAxis.formatLongValue(dataPoint.getX()),
                      graphView.getContext().getString(org.runnerup.common.R.string.Elevation),
                      formatter.formatElevation(Formatter.Format.TXT_LONG, dataPoint.getY()));
              Toast.makeText(graphView.getContext(), msg, Toast.LENGTH_SHORT).show();
            });
      }
      if (showCadence && !cadenceList.isEmpty()) {
        LineGraphSeries<DataPoint> cadenceGraphViewData =
            new LineGraphSeries<>(cadenceList.toArray(new DataPoint[0]));
        cadenceGraphViewData.setColor(chartPurple);
        cadenceGraphViewData.setThickness(3);
        cadenceGraphViewData.setDrawBackground(true);
        cadenceGraphViewData.setBackgroundColor(0x66BE46FF);
        cadenceGraphView.addSeries(cadenceGraphViewData);
        cadenceGraphView.getViewport().setMinX(cadenceGraphView.getViewport().getMinX(true));
        cadenceGraphView.getViewport().setMaxX(cadenceGraphView.getViewport().getMaxX(true));
        cadenceGraphViewData.setOnDataPointTapListener((series, dataPoint) ->
            Toast.makeText(graphView.getContext(),
                xAxis.labelLong() + ": " + xAxis.formatLongValue(dataPoint.getX()) + "\nCadência: " + Math.round(dataPoint.getY()) + " spm",
                Toast.LENGTH_SHORT).show());
      }
    }

    private int[] getArgs(String s) {
      try {
        s = s.substring(s.indexOf('(') + 1);
        s = s.substring(0, s.indexOf(')'));
        String[] sargs = s.split(",");
        int[] args = new int[sargs.length];
        for (int i = 0; i < args.length; i++) {
          args[i] = Integer.parseInt(sargs[i]);
        }
        return args;
      } catch (Exception e) {
        e.printStackTrace();
        return new int[0];
      }
    }

    String[] paceStats() {
      String avg = formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_LONG, avg_velocity);
      String fast = formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_LONG, max_velocity);
      String slow = formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_LONG, min_velocity);
      return new String[] {
        "Ritmo médio\n" + avg,
        "Tempo de movimentação\n" + formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, Math.round(totalElapsedMs / 1000.0)),
        "Ritmo médio decorrido\n" + avg,
        "Tempo decorrido\n" + formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, Math.round(totalElapsedMs / 1000.0)),
        "Parcial mais rápida\n" + fast
      };
    }

    String[] hrStats() {
      double avg = totalHrCount > 0 ? totalHrSum / totalHrCount : 0;
      int max = overallMaxHr > 0 ? overallMaxHr : maxHr();
      int min = overallMinHr != Integer.MAX_VALUE ? overallMinHr : minHr();
      return new String[] {
        "Freq. cardíaca média\n" + Math.round(avg) + " bpm",
        "Frequência cardíaca máxima\n" + max + " bpm",
        "Frequência cardíaca mínima\n" + min + " bpm"
      };
    }

    String[] elevationStats() {
      double min = Double.MAX_VALUE, max = -Double.MAX_VALUE;
      for (DataPoint point : elevationList) {
        double v = point.getY();
        min = Math.min(min, v);
        max = Math.max(max, v);
      }
      if (min == Double.MAX_VALUE) min = 0;
      if (max == -Double.MAX_VALUE) max = 0;
      return new String[] {
        "Ganho de elevação\n" + Math.round(Math.max(0, max - min)) + " m",
        "Elevação máxima\n" + Math.round(max) + " m"
      };
    }

    String[] cadenceStats() {
      return new String[] {
        "Cadência média\n" + Math.round(cadenceCount > 0 ? cadenceSum / cadenceCount : 0) + " ppm",
        "Cadência máxima\n" + Math.round(cadenceMax) + " ppm"
      };
    }

    private int maxHr() { int m = 0; for (int h : hr) m = Math.max(m, h); return m; }
    private int minHr() { int m = Integer.MAX_VALUE; for (int h : hr) if (h > 0) m = Math.min(m, h); return m == Integer.MAX_VALUE ? 0 : m; }

    public boolean HasCadenceInfo() { return showCadence && !cadenceList.isEmpty(); }

    public boolean HasPaceInfo() {
      return showPace;
    }

    public boolean HasElevationInfo() {
      return showElevation;
    }

    public boolean HasHRInfo() {
      return showHR;
    }

    public boolean HasHRZHist() {
      return showHR && showHRZhist;
    }

    class GraphFilter {

      final double[] data;
      final List<DataPoint> source;

      GraphFilter(List<DataPoint> velocityList) {
        source = velocityList;
        data = new double[velocityList.size()];
        for (int i = 0; i < velocityList.size(); i++) data[i] = velocityList.get(i).getY();
      }

      void complete() {
        for (int i = 0; i < source.size(); i++)
          source.set(i, new DataPoint(source.get(i).getX(), data[i]));
      }

      void init(double[] window, double val) {
        for (int j = 0; j < window.length - 1; j++) window[j] = val;
      }

      void shiftLeft(double[] window, double newVal) {
        System.arraycopy(window, 1, window, 0, window.length - 1);
        window[window.length - 1] = newVal;
      }

      /** Perform in place moving average */
      void movingAvergage(int windowLen) {
        double[] window = new double[windowLen];
        init(window, data[0]);

        final int mid = (window.length - 1) / 2;
        final int last = window.length - 1;
        for (int i = 0; i < data.length && i <= mid; i++) {
          window[i + mid] = data[i];
        }

        double sum = 0;
        for (double aWindow : window) sum += aWindow;

        for (int i = 0; i < data.length; i++) {
          double newY = sum / windowLen;
          data[i] = newY;
          sum -= window[0];
          shiftLeft(window, (i + mid) < data.length ? data[i + mid] : avg_velocity);
          sum += window[last];
        }
      }

      /** Perform in place moving average */
      void movingMedian(int windowLen) {
        double[] window = new double[windowLen];
        init(window, data[0]);

        final int mid = (window.length - 1) / 2;
        for (int i = 0; i < data.length && i <= mid; i++) {
          window[i + mid] = data[i];
        }

        double[] sort = new double[windowLen];
        for (int i = 0; i < data.length; i++) {
          System.arraycopy(window, 0, sort, 0, windowLen);
          Arrays.sort(sort);
          data[i] = sort[mid];
          shiftLeft(window, (i + mid) < data.length ? data[i + mid] : avg_velocity);
        }
      }

      /** Perform in place SavitzkyGolay windowLen = 5 */
      void SavitzkyGolay5() {
        final int len = 5;
        double[] window = new double[len];
        init(window, data[0]);

        final int mid = (window.length - 1) / 2;
        for (int i = 0; i < data.length && i <= mid; i++) {
          window[i + mid] = data[i];
        }
        for (int i = 0; i < data.length; i++) {
          double newY =
              (-3 * window[0] + 12 * window[1] + 17 * window[2] + 12 * window[3] - 3 * window[4])
                  / 35;
          data[i] = newY;
          shiftLeft(window, (i + mid) < data.length ? data[i + mid] : avg_velocity);
        }
      }

      /** Perform in place SavitzkyGolay windowLen = 7 */
      void SavitzkyGolay7() {
        final int len = 7;
        double[] window = new double[len];
        init(window, data[0]);

        final int mid = (window.length - 1) / 2;
        for (int i = 0; i < data.length && i <= mid; i++) {
          window[i + mid] = data[i];
        }
        for (int i = 0; i < data.length; i++) {
          double newY =
              (-2 * window[0]
                      + 3 * window[1]
                      + 6 * window[2]
                      + 7 * window[3]
                      + 6 * window[4]
                      + 3 * window[5]
                      - 2 * window[6])
                  / 21;
          data[i] = newY;
          shiftLeft(window, (i + mid) < data.length ? data[i + mid] : avg_velocity);
        }
      }

      void KolmogorovZurbenko(int n, int len) {
        for (int i = 0; i < n; i++) movingAvergage(len);
      }
    }
  }
}
