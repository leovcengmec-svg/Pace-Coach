package com.pacecoach.v1.run

data class ActiveStep(
    val index: Int,
    val repetition: Int,
    val step: WorkoutStep
)

class WorkoutEngine(private val workout: StructuredWorkout) {

    private var stepIndex = 0
    private var repetition = 1
    private var stepStartTimeMs = 0L
    private var stepStartDistanceM = 0f
    private var started = false
    private var finished = false

    fun start(nowMs: Long, distanceM: Float) {
        stepIndex = 0
        repetition = 1
        stepStartTimeMs = nowMs
        stepStartDistanceM = distanceM
        started = true
        finished = workout.steps.isEmpty()
    }

    fun current(): ActiveStep? {
        if (!started || finished || stepIndex !in workout.steps.indices) return null
        return ActiveStep(stepIndex, repetition, workout.steps[stepIndex])
    }

    fun update(nowMs: Long, distanceM: Float): Boolean {
        if (!started || finished) return false

        val step = workout.steps[stepIndex]
        val elapsed = nowMs - stepStartTimeMs
        val distance = distanceM - stepStartDistanceM

        val completedByTime =
            step.durationSeconds != null && elapsed >= step.durationSeconds * 1000L

        val completedByDistance =
            step.distanceMeters != null && distance >= step.distanceMeters

        if (completedByTime || completedByDistance) {
            advance(nowMs, distanceM, step)
            return true
        }
        return false
    }

    private fun advance(nowMs: Long, distanceM: Float, step: WorkoutStep) {
        if (repetition < step.repeats) {
            repetition++
        } else {
            stepIndex++
            repetition = 1
        }

        if (stepIndex >= workout.steps.size) {
            finished = true
        } else {
            stepStartTimeMs = nowMs
            stepStartDistanceM = distanceM
        }
    }

    fun elapsedStepSeconds(nowMs: Long): Long {
        if (!started || finished) return 0L
        return ((nowMs - stepStartTimeMs).coerceAtLeast(0L)) / 1000L
    }

    fun distanceStepMeters(distanceM: Float): Float {
        if (!started || finished) return 0f
        return (distanceM - stepStartDistanceM).coerceAtLeast(0f)
    }

    fun isFinished(): Boolean = finished
}
