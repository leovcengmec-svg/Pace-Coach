# Pace Coach V1.3 — foco em redução do delay de voz

Alterações principais:
- fala mais curta: `Ritmo 5:02...` em vez de texto longo;
- velocidade de fala ajustada para 1.15x;
- `QUEUE_FLUSH` para descartar uma mensagem anterior pendente;
- tratamento de Audio Focus para fala;
- preservados GPS, tela bloqueada, 20 s / 100 m, pace-alvo e margem.

Importante: esta versão ainda precisa de teste físico no Android.
O atraso final também depende do mecanismo TTS, aparelho e fone Bluetooth.
