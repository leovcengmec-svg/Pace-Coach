package com.pacecoach.v1.run

import org.junit.Assert.assertTrue
import org.junit.Test

class RunServiceCoachAdapterTest {
    @Test
    fun beginProducesStartMessage() {
        val adapter = RunServiceCoachAdapter()
        val workout = StructuredWorkout(
            "Corrida",
            listOf(WorkoutStep(StepKind.RUN, targetPaceSeconds = 300, label = "Corrida"))
        )
        val message = adapter.begin(workout, 1_000L, 0f)
        assertTrue(message?.contains("Iniciando") == true)
    }

    @Test
    fun liveUpdateProducesCoachingMessageOnStateChange() {
        val adapter = RunServiceCoachAdapter()
        val workout = StructuredWorkout(
            "Corrida",
            listOf(WorkoutStep(StepKind.RUN, targetPaceSeconds = 300, label = "Corrida"))
        )
        adapter.begin(workout, 1_000L, 0f)
        val event = adapter.onLiveUpdate(10_000L, 100f, 310, 5f, 5)
        assertTrue(event is CoachEvent.Speak)
    }
}
