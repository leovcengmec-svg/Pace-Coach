package org.runnerup.view;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.preference.PreferenceManager;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import org.runnerup.R;
import org.runnerup.content.WorkoutFileProvider;
import org.runnerup.db.DBHelper;
import org.runnerup.export.SyncManager;
import org.runnerup.util.ViewUtil;
import org.runnerup.workout.Dimension;
import org.runnerup.workout.RepeatStep;
import org.runnerup.workout.Step;
import org.runnerup.workout.Workout;
import org.runnerup.workout.WorkoutSerializer;

/** Pace Coach workout manager. The screen is intentionally kept separate from the legacy
 * RunnerUp expandable-list implementation while preserving the existing create/edit/share/delete
 * actions and the existing workout/category storage. */
public class ManageWorkoutsActivity extends AppCompatActivity {

  private static final String PHONE_STRING = "My phone";
  public static final String WORKOUT_NAME = "";
  public static final String WORKOUT_EDIT_MODE = "workout_edit_mode";
  private static final String CATEGORY_PREFIX = "pacecoach_workout_category_";
  private static final String FAVORITE_PREFIX = "pacecoach_workout_favorite_";

  private static final String CAT_REGEN = "Regenerativo";
  private static final String CAT_RODAGEM = "Rodagem";
  private static final String CAT_INTERVALADO = "Intervalado";
  private static final String CAT_FARTLEK = "Fartlek";
  private static final String CAT_TEMPO = "Corrida de Tempo";
  private static final String CAT_LONGAO = "Longão";
  private static final String[] CATEGORIES = {
      CAT_REGEN, CAT_RODAGEM, CAT_INTERVALADO, CAT_FARTLEK, CAT_TEMPO, CAT_LONGAO
  };

  private final ArrayList<String> allWorkoutNames = new ArrayList<>();
  private String selectedCategory = null;
  private String searchText = "";
  private String selectedWorkoutName = null;
  private SharedPreferences prefs;

  private LinearLayout workoutList;
  private LinearLayout categoryChips;
  private TextView resultTitle;
  private EditText searchInput;
  private Button shareButton;
  private Button editButton;
  private Button deleteButton;
  private Button createButton;

  private int dp(float value) {
    return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
  }

  @Override
  public void onCreate(Bundle savedInstanceState) {
    EdgeToEdge.enable(this);
    super.onCreate(savedInstanceState);
    WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView())
        .setAppearanceLightStatusBars(false);
    setContentView(R.layout.manage_workouts);
    prefs = PreferenceManager.getDefaultSharedPreferences(this);

    ViewUtil.Insets(findViewById(R.id.manage_workouts_view), true);
    bindViews();
    setupActions();
    loadLocalWorkouts();
    render();
  }

  private void bindViews() {
    workoutList = findViewById(R.id.workout_list_container);
    categoryChips = findViewById(R.id.category_chips);
    resultTitle = findViewById(R.id.workout_result_title);
    searchInput = findViewById(R.id.workout_search);
    shareButton = findViewById(R.id.share_workout_button);
    editButton = findViewById(R.id.edit_workout_button);
    createButton = findViewById(R.id.create_workout_button);
    deleteButton = findViewById(R.id.delete_workout_button);
  }

  private void setupActions() {
    findViewById(R.id.manager_back_button).setOnClickListener(v -> finish());
    findViewById(R.id.sort_workouts_button).setOnClickListener(v -> showSortDialog());
    createButton.setOnClickListener(v -> createWorkout());
    editButton.setOnClickListener(v -> editSelected());
    shareButton.setOnClickListener(v -> shareSelected());
    deleteButton.setOnClickListener(v -> deleteSelected());

    searchInput.addTextChangedListener(new TextWatcher() {
      @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
      @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
        searchText = s == null ? "" : s.toString().trim();
        renderList();
      }
      @Override public void afterTextChanged(Editable s) {}
    });
  }

  private void loadLocalWorkouts() {
    allWorkoutNames.clear();
    File dir = getDir(WorkoutSerializer.WORKOUTS_DIR, 0);
    String[] files = dir.list((d, filename) -> filename.endsWith(".json"));
    if (files != null) {
      for (String file : files) {
        int dot = file.lastIndexOf('.');
        allWorkoutNames.add(dot > 0 ? file.substring(0, dot) : file);
      }
    }
    Collections.sort(allWorkoutNames, (a, b) -> Long.compare(lastModified(b), lastModified(a)));
    if (selectedWorkoutName != null && !allWorkoutNames.contains(selectedWorkoutName)) {
      selectedWorkoutName = null;
    }
  }

  private long lastModified(String name) {
    return WorkoutSerializer.getFile(this, name).lastModified();
  }

  private void render() {
    renderCategoryChips();
    renderList();
    updateButtons();
  }

  private String displayCategory(String category) {
    return CAT_REGEN.equals(category) ? "Recuperação" : category;
  }

  private String categoryForWorkout(String name) {
    String stored = prefs.getString(CATEGORY_PREFIX + name, null);
    if (stored != null && !stored.trim().isEmpty()) return stored;
    try {
      Workout workout = WorkoutSerializer.readFile(getApplicationContext(), name);
      for (Step step : workout.getSteps()) {
        if (step instanceof RepeatStep) return CAT_INTERVALADO;
      }
    } catch (Exception ignored) {}
    return CAT_RODAGEM;
  }

  private int categoryColor(String category) {
    if (CAT_INTERVALADO.equals(category)) return Color.rgb(215, 55, 67);
    if (CAT_REGEN.equals(category)) return Color.rgb(204, 166, 20);
    if (CAT_FARTLEK.equals(category)) return Color.rgb(218, 175, 28);
    if (CAT_TEMPO.equals(category)) return Color.rgb(112, 67, 201);
    if (CAT_LONGAO.equals(category)) return Color.rgb(235, 126, 42);
    return Color.rgb(0, 185, 83);
  }

  private int categoryIcon(String category) {
    if (CAT_REGEN.equals(category)) return R.drawable.pc_category_regenerativo;
    if (CAT_INTERVALADO.equals(category)) return R.drawable.pc_category_intervalado;
    if (CAT_FARTLEK.equals(category)) return R.drawable.pc_category_fartlek;
    if (CAT_TEMPO.equals(category)) return R.drawable.pc_category_tempo;
    if (CAT_LONGAO.equals(category)) return R.drawable.pc_category_longao;
    return R.drawable.pc_category_rodagem;
  }

  private void renderCategoryChips() {
    categoryChips.removeAllViews();
    addCategoryChip("Todos", null, allWorkoutNames.size(), true);

    HashMap<String, Integer> counts = new HashMap<>();
    for (String name : allWorkoutNames) {
      String category = categoryForWorkout(name);
      counts.put(category, counts.containsKey(category) ? counts.get(category) + 1 : 1);
    }

    for (String category : CATEGORIES) {
      Integer count = counts.get(category);
      if (count != null && count > 0) {
        addCategoryChip(displayCategory(category), category, count, false);
      }
    }
  }

  private void addCategoryChip(String label, String category, int count, boolean all) {
    LinearLayout chip = new LinearLayout(this);
    chip.setOrientation(LinearLayout.VERTICAL);
    chip.setGravity(Gravity.CENTER);
    chip.setPadding(dp(10), dp(6), dp(10), dp(5));
    chip.setClickable(true);
    chip.setFocusable(true);
    boolean active = (selectedCategory == null && category == null) || (category != null && category.equals(selectedCategory));
    int fill = category == null ? (active ? Color.rgb(0, 104, 220) : Color.rgb(39, 48, 57)) : (active ? categoryColor(category) : Color.rgb(39, 48, 57));
    int stroke = active ? (category == null ? Color.rgb(65, 190, 255) : categoryColor(category)) : Color.rgb(52, 64, 74);
    chip.setBackground(roundBackground(fill, dp(18), stroke));

    ImageView icon = new ImageView(this);
    if (all) {
      TextView shoe = new TextView(this);
      shoe.setText("👟");
      shoe.setTextSize(20);
      shoe.setGravity(Gravity.CENTER);
      chip.addView(shoe, new LinearLayout.LayoutParams(-1, dp(26)));
    } else {
      icon.setImageResource(categoryIcon(category));
      icon.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
      chip.addView(icon, new LinearLayout.LayoutParams(-1, dp(26)));
    }

    TextView title = new TextView(this);
    title.setText(label);
    title.setTextColor(Color.WHITE);
    title.setTextSize(13);
    title.setGravity(Gravity.CENTER);
    chip.addView(title, new LinearLayout.LayoutParams(-1, dp(19)));

    TextView countView = new TextView(this);
    countView.setText("(" + count + ")");
    countView.setTextColor(Color.WHITE);
    countView.setTextSize(11);
    countView.setGravity(Gravity.CENTER);
    chip.addView(countView, new LinearLayout.LayoutParams(-1, dp(16)));

    chip.setOnClickListener(v -> {
      selectedCategory = category;
      renderCategoryChips();
      renderList();
    });

    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(82), dp(78));
    lp.setMargins(dp(4), 0, dp(4), 0);
    categoryChips.addView(chip, lp);
  }

  private GradientDrawable roundBackground(int fill, int radius, int stroke) {
    GradientDrawable bg = new GradientDrawable();
    bg.setColor(fill);
    bg.setCornerRadius(radius);
    bg.setStroke(dp(1), stroke);
    return bg;
  }

  private void renderList() {
    ArrayList<String> filtered = new ArrayList<>();
    String query = searchText.toLowerCase(Locale.getDefault());
    for (String name : allWorkoutNames) {
      String category = categoryForWorkout(name);
      if (selectedCategory != null && !selectedCategory.equals(category)) continue;
      if (!query.isEmpty() && !name.toLowerCase(Locale.getDefault()).contains(query)) continue;
      filtered.add(name);
    }

    resultTitle.setText("Todos os treinos (" + filtered.size() + ")");
    workoutList.removeAllViews();
    if (filtered.isEmpty()) {
      TextView empty = new TextView(this);
      empty.setText("Nenhum treino encontrado.");
      empty.setTextColor(getResources().getColor(R.color.colorTextSecondary));
      empty.setTextSize(16);
      empty.setGravity(Gravity.CENTER);
      empty.setPadding(0, dp(32), 0, dp(32));
      workoutList.addView(empty);
      return;
    }

    for (String name : filtered) addWorkoutCard(name);
  }

  private void addWorkoutCard(String name) {
    String category = categoryForWorkout(name);
    int accent = categoryColor(category);
    boolean selected = name.equals(selectedWorkoutName);

    LinearLayout card = new LinearLayout(this);
    card.setOrientation(LinearLayout.HORIZONTAL);
    card.setGravity(Gravity.CENTER_VERTICAL);
    card.setPadding(dp(12), dp(7), dp(8), dp(7));
    card.setBackground(roundBackground(Color.rgb(27, 38, 48), dp(18),
        selected ? Color.rgb(83, 177, 252) : Color.rgb(52, 64, 74)));
    card.setOnClickListener(v -> {
      selectedWorkoutName = name.equals(selectedWorkoutName) ? null : name;
      renderList();
      updateButtons();
    });

    ImageView categoryIcon = new ImageView(this);
    categoryIcon.setImageResource(categoryIcon(category));
    categoryIcon.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
    categoryIcon.setPadding(dp(11), dp(11), dp(11), dp(11));
    categoryIcon.setBackground(roundBackground(accent, dp(30), accent));
    card.addView(categoryIcon, new LinearLayout.LayoutParams(dp(54), dp(54)));

    LinearLayout info = new LinearLayout(this);
    info.setOrientation(LinearLayout.VERTICAL);
    info.setPadding(dp(12), 0, dp(4), 0);
    LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(0, -1, 1f);
    card.addView(info, infoLp);

    TextView nameView = new TextView(this);
    nameView.setText(name);
    nameView.setTextColor(Color.WHITE);
    nameView.setTextSize(18);
    nameView.setTypeface(null, android.graphics.Typeface.BOLD);
    nameView.setSingleLine(true);
    info.addView(nameView, new LinearLayout.LayoutParams(-1, dp(27)));

    TextView catView = new TextView(this);
    catView.setText(displayCategory(category));
    catView.setTextColor(Color.WHITE);
    catView.setTextSize(11);
    catView.setGravity(Gravity.CENTER_VERTICAL);
    catView.setPadding(dp(10), 0, dp(10), 0);
    catView.setBackground(roundBackground(accent, dp(20), accent));
    info.addView(catView, new LinearLayout.LayoutParams(dp(category == CAT_REGEN ? 78 : 78), dp(22)));

    TextView stats = new TextView(this);
    stats.setText(buildStats(name));
    stats.setTextColor(Color.rgb(190, 207, 224));
    stats.setTextSize(10.5f);
    stats.setSingleLine(true);
    LinearLayout.LayoutParams statsLp = new LinearLayout.LayoutParams(-1, dp(20));
    statsLp.topMargin = dp(3);
    info.addView(stats, statsLp);

    TextView favorite = new TextView(this);
    favorite.setText(isFavorite(name) ? "★" : "☆");
    favorite.setTextColor(isFavorite(name) ? Color.rgb(255, 195, 25) : Color.rgb(215, 225, 240));
    favorite.setTextSize(29);
    favorite.setGravity(Gravity.CENTER);
    favorite.setOnClickListener(v -> {
      setFavorite(name, !isFavorite(name));
      renderList();
    });
    card.addView(favorite, new LinearLayout.LayoutParams(dp(38), dp(54)));

    TextView more = new TextView(this);
    more.setText("⋮");
    more.setTextColor(Color.rgb(190, 210, 235));
    more.setTextSize(28);
    more.setGravity(Gravity.CENTER);
    more.setOnClickListener(v -> showWorkoutMenu(name));
    card.addView(more, new LinearLayout.LayoutParams(dp(30), dp(54)));

    LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, dp(72));
    cardLp.setMargins(0, 0, 0, dp(8));
    workoutList.addView(card, cardLp);
  }

  private String buildStats(String name) {
    try {
      Workout workout = WorkoutSerializer.readFile(getApplicationContext(), name);
      double distance = 0;
      double seconds = 0;
      int blocks = 0;
      for (Step step : workout.getSteps()) {
        distance += estimateDistance(step);
        seconds += estimateTime(step);
        blocks += countBlocks(step);
      }
      String distanceText = distance > 0
          ? String.format(Locale.getDefault(), "⚑  ~ %.1f km", distance / 1000.0)
          : "⚑  ~ -- km";
      String timeText = seconds > 0 ? "◷  ~ " + formatDuration(seconds) : "◷  ~ --";
      return distanceText + "     " + timeText + "     ☷  " + blocks + " bloco" + (blocks == 1 ? "" : "s");
    } catch (Exception e) {
      return "⚑  ~ -- km     ◷  ~ --     ☷  0 blocos";
    }
  }

  private int countBlocks(Step step) {
    if (step instanceof RepeatStep) {
      int count = 0;
      RepeatStep repeat = (RepeatStep) step;
      for (Step child : repeat.getSteps()) count += countBlocks(child);
      return Math.max(1, count * Math.max(1, repeat.getRepeatCount()));
    }
    return 1;
  }

  private double estimateDistance(Step step) {
    if (step instanceof RepeatStep) {
      RepeatStep repeat = (RepeatStep) step;
      double sum = 0;
      for (Step child : repeat.getSteps()) sum += estimateDistance(child);
      return sum * Math.max(0, repeat.getRepeatCount());
    }
    Dimension type = step.getDurationType();
    double value = step.getDurationValue();
    if (type == Dimension.DISTANCE) return Math.max(0, value);
    if (type == Dimension.TIME && step.getTargetType() == Dimension.PACE && step.getTargetValue() != null) {
      double pace = (step.getTargetValue().minValue + step.getTargetValue().maxValue) / 2.0;
      if (pace > 0) return value / pace;
    }
    return 0;
  }

  private double estimateTime(Step step) {
    if (step instanceof RepeatStep) {
      RepeatStep repeat = (RepeatStep) step;
      double sum = 0;
      for (Step child : repeat.getSteps()) sum += estimateTime(child);
      return sum * Math.max(0, repeat.getRepeatCount());
    }
    Dimension type = step.getDurationType();
    double value = step.getDurationValue();
    if (type == Dimension.TIME) return Math.max(0, value);
    if (type == Dimension.DISTANCE && step.getTargetType() == Dimension.PACE && step.getTargetValue() != null) {
      double pace = (step.getTargetValue().minValue + step.getTargetValue().maxValue) / 2.0;
      if (pace > 0) return value * pace;
    }
    return 0;
  }

  private String formatDuration(double seconds) {
    long total = Math.max(0, Math.round(seconds));
    if (total < 3600) return String.format(Locale.getDefault(), "%02d:%02d min", total / 60, total % 60);
    return String.format(Locale.getDefault(), "%dh%02d", total / 3600, (total % 3600) / 60);
  }

  private boolean isFavorite(String name) {
    return prefs.getBoolean(FAVORITE_PREFIX + name, false);
  }

  private void setFavorite(String name, boolean favorite) {
    prefs.edit().putBoolean(FAVORITE_PREFIX + name, favorite).apply();
  }

  private void showWorkoutMenu(String name) {
    String[] items = {"Editar", "Compartilhar", "Excluir"};
    new AlertDialog.Builder(this)
        .setItems(items, (d, which) -> {
          selectedWorkoutName = name;
          if (which == 0) editSelected();
          else if (which == 1) shareSelected();
          else deleteSelected();
        }).show();
  }

  private void updateButtons() {
    boolean enabled = selectedWorkoutName != null;
    shareButton.setEnabled(enabled);
    editButton.setEnabled(enabled);
    deleteButton.setEnabled(enabled);
    createButton.setEnabled(true);
  }

  private void createWorkout() {
    final EditText input = new EditText(this);
    input.setSingleLine(true);
    input.setHint("Digite o nome do treino...");
    new AlertDialog.Builder(this)
        .setTitle("Criar treino")
        .setMessage("Definir nome")
        .setView(input)
        .setNegativeButton("CANCELAR", null)
        .setPositiveButton("CRIAR", (dialog, which) -> {
          String value = input.getText().toString().trim();
          if (value.isEmpty() || value.contains("/") || value.contains("\\") || value.contains("..")) {
            Toast.makeText(this, R.string.Invalid_workout_name, Toast.LENGTH_SHORT).show();
            return;
          }
          if (WorkoutSerializer.getFile(this, value).exists()) {
            Toast.makeText(this, R.string.Workout_name_already_in_use, Toast.LENGTH_SHORT).show();
            return;
          }
          Intent intent = new Intent(this, CreateAdvancedWorkout.class);
          intent.putExtra(WORKOUT_NAME, value);
          intent.putExtra(WORKOUT_EDIT_MODE, false);
          startActivity(intent);
        }).show();
  }

  private void editSelected() {
    if (selectedWorkoutName == null) return;
    Intent intent = new Intent(this, CreateAdvancedWorkout.class);
    intent.putExtra(WORKOUT_NAME, selectedWorkoutName);
    intent.putExtra(WORKOUT_EDIT_MODE, true);
    startActivity(intent);
  }

  private void shareSelected() {
    if (selectedWorkoutName == null) return;
    Intent intent = new Intent(Intent.ACTION_SEND);
    intent.putExtra(Intent.EXTRA_SUBJECT, getString(org.runnerup.common.R.string.RunnerUp_workout) + ": " + selectedWorkoutName);
    intent.putExtra(Intent.EXTRA_TEXT, getString(org.runnerup.common.R.string.HinHere_is_a_workout_I_think_you_might_like));
    intent.setType(WorkoutFileProvider.MIME);
    Uri uri = Uri.parse("content://" + WorkoutFileProvider.AUTHORITY + "/" + selectedWorkoutName + ".json");
    intent.putExtra(Intent.EXTRA_STREAM, uri);
    startActivity(Intent.createChooser(intent, getString(org.runnerup.common.R.string.Share_workout)));
  }

  private void deleteSelected() {
    if (selectedWorkoutName == null) return;
    final String name = selectedWorkoutName;
    new AlertDialog.Builder(this)
        .setTitle(getString(org.runnerup.common.R.string.Delete_workout) + " " + name)
        .setMessage(org.runnerup.common.R.string.Are_you_sure)
        .setNegativeButton(org.runnerup.common.R.string.No, null)
        .setPositiveButton(org.runnerup.common.R.string.Yes, (dialog, which) -> {
          File file = WorkoutSerializer.getFile(this, name);
          //noinspection ResultOfMethodCallIgnored
          file.delete();
          prefs.edit().remove(CATEGORY_PREFIX + name).remove(FAVORITE_PREFIX + name).apply();
          if (name.equals(prefs.getString(getString(R.string.pref_advanced_workout), ""))) {
            prefs.edit().putString(getString(R.string.pref_advanced_workout), "").apply();
          }
          selectedWorkoutName = null;
          loadLocalWorkouts();
          render();
        }).show();
  }

  private void showSortDialog() {
    String[] options = {"Mais recentes", "A–Z", "Z–A"};
    new AlertDialog.Builder(this)
        .setTitle("Ordenar treinos")
        .setItems(options, (dialog, which) -> {
          if (which == 0) {
            Collections.sort(allWorkoutNames, (a, b) -> Long.compare(lastModified(b), lastModified(a)));
          } else if (which == 1) {
            Collections.sort(allWorkoutNames, String.CASE_INSENSITIVE_ORDER);
          } else {
            Collections.sort(allWorkoutNames, Collections.reverseOrder(String.CASE_INSENSITIVE_ORDER));
          }
          renderList();
        }).show();
  }

  @Override
  protected void onResume() {
    super.onResume();
    if (workoutList == null) return;
    loadLocalWorkouts();
    render();
  }
}
