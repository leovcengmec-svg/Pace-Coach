# Pace Coach V2.0

Interface modernization on top of RunnerUp V1.9.

## Changes
- Modernized dark home screen with clear hierarchy and larger action cards.
- Modernized running Coach panel with a single prominent current pace.
- Target and difference grouped into a compact information strip.
- Clarified average pace in the legacy metrics area as `PACE MÉDIO`.
- Hid the redundant empty `Current` row while retaining its ID for compatibility.
- Pace difference now reads `X s/km mais rápido` or `X s/km mais lento`.
- Preserved RunnerUp tracking, workout, GPS, audio, lock-screen and Coach IDs/flows.
- No new runtime UI dependency was introduced.
