/*
 * Copyright (C) 2012 - 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.util;

import static org.runnerup.util.Formatter.Format.TXT_SHORT;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.osmdroid.api.IMapController;
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.CustomZoomButtonsController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Polyline;
import org.runnerup.common.util.Constants;
import org.runnerup.db.entities.LocationEntity;

public class MapWrapper implements Constants {

  private final SQLiteDatabase mDB;
  private final long mID;
  private final Formatter formatter;
  private final MapView mapView;

  private final ExecutorService executor = Executors.newSingleThreadExecutor();
  private volatile Location currentLocation;
  private boolean hasCenteredOnCurrent = false;

  private static final java.lang.String OSMDROID_USER_AGENT = "org.runnerup.free";

  public MapWrapper(
      Context context,
      SQLiteDatabase mDB,
      long mID,
      Formatter formatter,
      java.lang.Object mapView) {
    this.mDB = mDB;
    this.mID = mID;
    this.formatter = formatter;
    this.mapView = (MapView) mapView;
  }

  public static void start(Context context) {}

  public void onCreate(Bundle savedInstanceState) {
    mapView.setTileSource(TileSourceFactory.MAPNIK);
    mapView
        .getZoomController()
        .setVisibility(CustomZoomButtonsController.Visibility.NEVER);
    mapView.setMultiTouchControls(true);

    Configuration.getInstance().setUserAgentValue(OSMDROID_USER_AGENT);

    refresh();
  }

  // The results from the database query
  record Route(Polyline map, List<Marker> markers, GeoPoint firstPoint) {}

  /** Update the live GPS position used by the running route overlay. */
  public void updateCurrentLocation(Location location) {
    if (location == null) return;
    currentLocation = new Location(location);
  }

  public void refresh() {
    executor.execute(
        () -> {
          final Route route = loadRouteData();

          // UI update
          mapView.post(
              () -> {
                IMapController mapController = mapView.getController();

                // Keep the live map focused on the runner. Do not repeatedly reset
                // the zoom to the start point; this makes the map behave like a
                // running-navigation map rather than a static activity preview.
                Location live = currentLocation;
                if (live != null) {
                  mapController.setCenter(new GeoPoint(live.getLatitude(), live.getLongitude()));
                  if (!hasCenteredOnCurrent) {
                    mapController.setZoom(16.0);
                    hasCenteredOnCurrent = true;
                  }
                } else if (!hasCenteredOnCurrent && route.firstPoint != null) {
                  mapController.setZoom(16.0);
                  mapController.setCenter(route.firstPoint);
                  hasCenteredOnCurrent = true;
                }

                // Replace the current live route with the newest valid GPS points.
                mapView.getOverlays().clear();
                for (Marker marker : route.markers) {
                  mapView.getOverlays().add(marker);
                }
                mapView.getOverlays().add(route.map);

                // Draw the current GPS position immediately, even when the latest
                // location has not been persisted to SQLite yet.
                if (live != null && isUsableLiveLocation(live)) {
                  Marker current = new Marker(mapView);
                  current.setPosition(new GeoPoint(live.getLatitude(), live.getLongitude()));
                  current.setIcon(createCurrentLocationIcon());
                  current.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER);
                  current.setInfoWindow(null);
                  mapView.getOverlays().add(current);
                }

                mapView.invalidate();
              });
        });
  }

  /** The long-running database query and data processing logic. */
  private Route loadRouteData() {
    Polyline polyline = new Polyline(mapView, true);
    polyline.setInfoWindow(null);
    polyline.getOutlinePaint().setColor(Color.rgb(20, 166, 255));
    polyline.getOutlinePaint().setStrokeWidth(9.f);
    polyline.getOutlinePaint().setAntiAlias(true);

    java.util.List<Marker> markers = new ArrayList<>();
    java.util.List<GeoPoint> points = new LinkedList<>();

    LocationEntity.LocationList<LocationEntity> ll = new LocationEntity.LocationList<>(mDB, mID);
    int lastLap = -1;
    for (LocationEntity loc : ll) {
      GeoPoint point = new GeoPoint(loc.getLatitude(), loc.getLongitude());
      points.add(point);

      int lap = loc.getLap();
      if (lastLap != lap) {
        Marker marker = new Marker(mapView);
        marker.setPosition(point);
        java.lang.String info =
            "#"
                + loc.getLap()
                + " "
                + formatter.formatDistance(TXT_SHORT, loc.getDistance().longValue())
                + " "
                + formatter.formatElapsedTime(TXT_SHORT, Math.round(loc.getElapsed() / 1000.0));
        lastLap = lap;
        marker.setTextIcon(info);
        marker.setInfoWindow(null);
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        markers.add(marker);
      }
    }
    ll.close();

    // The database writer can lag behind the live GPS callback by a short amount.
    // Add the latest validated position to the visible route so the line grows
    // continuously while the runner is moving instead of waiting for persistence.
    Location live = currentLocation;
    if (live != null && isUsableLiveLocation(live)) {
      GeoPoint livePoint = new GeoPoint(live.getLatitude(), live.getLongitude());
      if (points.isEmpty()) {
        points.add(livePoint);
      } else {
        GeoPoint last = points.get(points.size() - 1);
        float[] result = new float[1];
        Location.distanceBetween(
            last.getLatitude(), last.getLongitude(),
            livePoint.getLatitude(), livePoint.getLongitude(), result);
        // Avoid drawing tiny GPS jitter as extra route geometry.
        if (result[0] >= 2.0f) {
          points.add(livePoint);
        }
      }
    }

    polyline.setPoints(points);

    GeoPoint firstPoint = points.isEmpty() ? null : points.get(0);
    return new Route(polyline, markers, firstPoint);
  }

  private boolean isUsableLiveLocation(Location location) {
    if (location == null || !location.hasAccuracy()) return false;
    return location.getAccuracy() <= 50.0f;
  }

  private GradientDrawable createCurrentLocationIcon() {
    GradientDrawable drawable = new GradientDrawable();
    drawable.setShape(GradientDrawable.OVAL);
    drawable.setColor(Color.rgb(20, 166, 255));
    drawable.setStroke(5, Color.WHITE);
    drawable.setSize(36, 36);
    return drawable;
  }

  public void onResume() {
    mapView.onResume();
  }

  public void onStart() {}

  public void onStop() {}

  public void onPause() {
    mapView.onPause();
  }

  public void onSaveInstanceState(Bundle outState) {}

  public void onLowMemory() {}

  public void onDestroy() {
    executor.shutdown();
  }
}
