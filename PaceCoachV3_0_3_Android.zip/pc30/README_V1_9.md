# Pace Coach V1.9 — Criador de treino

A V1.9 adiciona a primeira camada de criação/validação de treinos estruturados.

O modelo suporta:
- nome do treino;
- etapas por tempo;
- etapas por distância;
- pace-alvo por etapa;
- aquecimento, corrida, recuperação e desaquecimento;
- repetições;
- resumo do treino;
- exemplo pronto de 4 x 1 km.

A interface ainda é deliberadamente simples. O objetivo é validar a estrutura
antes de construir um editor completo.

Observação: a condução do treino pelo RunService e a persistência permanente
ainda precisam de integração/validação em uma próxima etapa.
