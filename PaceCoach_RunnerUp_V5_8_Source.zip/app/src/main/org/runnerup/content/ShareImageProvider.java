package org.runnerup.content;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import androidx.annotation.NonNull;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.runnerup.BuildConfig;

/** Read-only provider for Pace Coach share-card PNG files in the app cache. */
public class ShareImageProvider extends ContentProvider {
  public static final String AUTHORITY = BuildConfig.APPLICATION_ID + ".share.image.provider";
  private static final int IMAGE = 1;
  private UriMatcher matcher;

  @Override public boolean onCreate() {
    matcher = new UriMatcher(UriMatcher.NO_MATCH);
    matcher.addURI(AUTHORITY, "*", IMAGE);
    return true;
  }

  @Override public ParcelFileDescriptor openFile(@NonNull Uri uri, @NonNull String mode)
      throws FileNotFoundException {
    if (matcher.match(uri) != IMAGE) throw new FileNotFoundException("Unsupported uri: " + uri);
    File dir = new File(getContext().getCacheDir(), "share_cards");
    File file = new File(dir, uri.getLastPathSegment());
    try {
      if (!file.getCanonicalFile().getParentFile().equals(dir.getCanonicalFile())) {
        throw new FileNotFoundException("Invalid share file");
      }
    } catch (IOException e) {
      throw new FileNotFoundException("Invalid share file");
    }
    return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
  }

  @Override public String getType(@NonNull Uri uri) { return "image/png"; }
  @Override public Cursor query(@NonNull Uri uri, String[] p, String s, String[] a, String so) { return null; }
  @Override public int delete(@NonNull Uri uri, String s, String[] a) { return 0; }
  @Override public int update(@NonNull Uri uri, ContentValues v, String s, String[] a) { return 0; }
  @Override public Uri insert(@NonNull Uri uri, ContentValues v) { return null; }
}
