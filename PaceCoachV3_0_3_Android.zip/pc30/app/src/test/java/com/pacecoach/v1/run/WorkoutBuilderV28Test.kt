package com.pacecoach.v1.run

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WorkoutBuilderV28Test {
    @Test fun intervalBlockAlternatesAndKeepsFinalRecoveryOut() {
        val w = WorkoutBuilder("teste")
            .addIntervalBlock(
                runDistanceMeters = 1000f,
                runTargetPaceSeconds = 290,
                recoveryDurationSeconds = 120,
                repeats = 4
            ).build()
        assertEquals(7, w.steps.size)
        assertEquals(StepKind.RUN, w.steps[0].kind)
        assertEquals(StepKind.RECOVERY, w.steps[1].kind)
        assertEquals(StepKind.RUN, w.steps[6].kind)
    }

    @Test fun repositoryStoresLatestWorkout() {
        val w = WorkoutBuilder("meu treino").addTimeStep(StepKind.WARMUP, 60).build()
        WorkoutRepository.save(w)
        assertTrue(WorkoutRepository.find("meu treino") != null)
    }
}
