package com.pacecoach.v1.run

enum class CoachState {
    STARTING,
    WARMUP,
    ON_TARGET,
    SLOWER_THAN_TARGET,
    FASTER_THAN_TARGET,
    GPS_UNCERTAIN,
    FINISHED
}
