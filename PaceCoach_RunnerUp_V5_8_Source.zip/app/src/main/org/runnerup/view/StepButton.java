/*
 * Copyright (C) 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import java.util.Locale;
import org.runnerup.R;
import org.runnerup.common.util.Constants.DB.DIMENSION;
import org.runnerup.util.Formatter;
import org.runnerup.util.SafeParse;
import org.runnerup.widget.NumberPicker;
import org.runnerup.widget.TitleSpinner;
import org.runnerup.workout.Dimension;
import org.runnerup.workout.Intensity;
import org.runnerup.workout.Range;
import org.runnerup.workout.Step;

public class StepButton extends LinearLayout {

  private final Context mContext;
  private final ViewGroup mLayout;
  private final ImageView mIntensityIcon;
  private final TextView mDurationValue;
  private final TextView mGoalValue;
  private final Formatter formatter;

  public Step getStep() {
    return step;
  }

  private Step step;
  private Runnable mOnChangedListener = null;

  private static final boolean editRepeatCount = true;
  private static final boolean editStepButton = true;

  public StepButton(Context context, AttributeSet attrs) {
    super(context, attrs);
    mContext = context;

    LayoutInflater inflater =
        (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    inflater.inflate(R.layout.step_button, this);
    formatter = new Formatter(context);
    mLayout = findViewById(R.id.step_button_layout);
    mIntensityIcon = findViewById(R.id.step_icon);
    mDurationValue = findViewById(R.id.step_duration_value);
    mGoalValue = findViewById(R.id.step_goal_value);
  }

  @Override
  public void setEnabled(boolean enabled) {
    super.setEnabled(enabled);
    mLayout.setEnabled(enabled);
    for (int i = 0, j = mLayout.getChildCount(); i < j; i++) {
      mLayout.getChildAt(i).setEnabled(enabled);
    }
  }

  public void setOnChangedListener(Runnable runnable) {
    mOnChangedListener = runnable;
  }

  public void setStep(Step step) {
    this.step = step;

    mDurationValue.setVisibility(VISIBLE);
    switch (step.getIntensity()) {
      case ACTIVE:
        mIntensityIcon.setImageResource(R.drawable.step_active);
        mGoalValue.setTextColor(
            ContextCompat.getColor(mContext, R.color.stepActive)); // todo check if it works
        break;
      case RESTING:
        mIntensityIcon.setImageResource(R.drawable.step_resting);
        mGoalValue.setTextColor(ContextCompat.getColor(mContext, R.color.stepResting));
        break;
      case REPEAT:
        mIntensityIcon.setImageResource(R.drawable.step_repeat);
        mDurationValue.setVisibility(GONE); // todo better wording in string
        mGoalValue.setText(
            String.format(
                Locale.getDefault(),
                getResources().getString(org.runnerup.common.R.string.repeat_times),
                step.getRepeatCount()));
        mGoalValue.setTextColor(ContextCompat.getColor(mContext, R.color.stepRepeat));
        if (editRepeatCount) mLayout.setOnClickListener(onRepeatClickListener);
        return;
      case WARMUP:
        mIntensityIcon.setImageResource(R.drawable.step_warmup);
        mGoalValue.setTextColor(ContextCompat.getColor(mContext, R.color.stepWarmup));
        break;
      case COOLDOWN:
        mIntensityIcon.setImageResource(R.drawable.step_cooldown);
        mGoalValue.setTextColor(ContextCompat.getColor(mContext, R.color.stepCooldown));
        break;
      case RECOVERY:
        mIntensityIcon.setImageResource(R.drawable.step_recovery);
        mGoalValue.setTextColor(ContextCompat.getColor(mContext, R.color.stepRecovery));
        break;
      default:
        mIntensityIcon.setImageResource(0);
    }

    Dimension durationType = step.getDurationType();
    if (durationType == null) {
      mDurationValue.setText(org.runnerup.common.R.string.Until_press);
    } else {
      mDurationValue.setText(
          formatter.format(Formatter.Format.TXT_LONG, durationType, step.getDurationValue()));
    }

    Dimension goalType = step.getTargetType();
    if (goalType == null) {
      mGoalValue.setText(step.getIntensity().getTextId());
    } else {
      String prefix;
      String separator = "–";
      if (goalType == Dimension.HR || goalType == Dimension.HRZ) {
        prefix = "FC ";
      } else if (goalType == Dimension.PACE) {
        prefix = "Ritmo ";
      } else {
        prefix = "";
      }

      String minText = formatter.format(Formatter.Format.TXT_SHORT, goalType, step.getTargetValue().minValue);
      String maxText = formatter.format(Formatter.Format.TXT_SHORT, goalType, step.getTargetValue().maxValue);
      String unitText = goalType == Dimension.PACE ? " min/km" : "";
      mGoalValue.setText(
          String.format(Locale.getDefault(), "%s%s%s%s", prefix, minText, separator, maxText, unitText));
    }
    if (editStepButton) {
      mLayout.setOnClickListener(onStepClickListener);
    }
  }

  private final OnClickListener onRepeatClickListener =
      new OnClickListener() {

        @Override
        public void onClick(View v) {
          final NumberPicker numberPicker = new NumberPicker(mContext, null);
          numberPicker.setOrientation(VERTICAL);
          numberPicker.setDigits(4);
          numberPicker.setRange(0, 9999, true);
          numberPicker.setValue(step.getRepeatCount());

          final LinearLayout layout = new LinearLayout(mContext);
          layout.setLayoutParams(
              new LinearLayout.LayoutParams(
                  LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
          layout.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
          layout.addView(numberPicker);

          new AlertDialog.Builder(mContext)
              .setTitle(org.runnerup.common.R.string.repeat)
              .setView(layout)
              .setPositiveButton(
                  org.runnerup.common.R.string.OK,
                  (dialog, whichButton) -> {
                    step.setRepeatCount(numberPicker.getValue());
                    dialog.dismiss();
                    setStep(step); // redraw
                    if (mOnChangedListener != null) {
                      mOnChangedListener.run();
                    }
                  })
              .setNegativeButton(
                  org.runnerup.common.R.string.Cancel, (dialog, whichButton) -> dialog.dismiss())
              .show();
        }
      };

  private final OnClickListener onStepClickListener =
      new OnClickListener() {

        @Override
        public void onClick(View v) {
          final LayoutInflater inflater = LayoutInflater.from(mContext);
          @SuppressLint("InflateParams")
          final View layout = inflater.inflate(R.layout.step_dialog, null);

          final Runnable save = setupEditStep(inflater, layout);

          AlertDialog dialog =
              new AlertDialog.Builder(mContext)
                  .setTitle(org.runnerup.common.R.string.Edit_step)
                  .setView(layout)
                  .setPositiveButton(
                      org.runnerup.common.R.string.OK,
                      (dialogInterface, whichButton) -> {
                        save.run();
                        dialogInterface.dismiss();
                        setStep(step); // redraw
                        if (mOnChangedListener != null) {
                          mOnChangedListener.run();
                        }
                      })
                  .setNegativeButton(
                      org.runnerup.common.R.string.Cancel,
                      (dialogInterface, whichButton) -> dialogInterface.dismiss())
                  .create();
          dialog.setOnShowListener(
              shown -> {
                if (dialog.getWindow() != null) {
                  dialog.getWindow().setBackgroundDrawable(
                      ContextCompat.getDrawable(mContext, R.drawable.bg_coach_card));
                  android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
                  dialog.getWindow().getWindowManager().getDefaultDisplay().getMetrics(dm);
                  dialog.getWindow().setLayout(
                      (int) (dm.widthPixels * 0.90f),
                      android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
                }
              });
          dialog.show();
        }
      };

  private Runnable setupEditStep(LayoutInflater inflator, View layout) {
    final TitleSpinner stepType = layout.findViewById(R.id.step_dialog_intensity);
    stepType.setValue(step.getIntensity().getValue());

    final TitleSpinner durationType = layout.findViewById(R.id.step_dialog_duration_type);
    final TitleSpinner durationTime = layout.findViewById(R.id.step_dialog_duration_time);
    final TitleSpinner durationDistance = layout.findViewById(R.id.step_dialog_duration_distance);
    final TextView durationTimeHelper = layout.findViewById(R.id.step_dialog_time_helper);
    final TextView durationTimeExample = layout.findViewById(R.id.step_dialog_time_example);
    final TextView durationDistanceHelper = layout.findViewById(R.id.step_dialog_distance_helper);
    final TextView durationDistanceExample = layout.findViewById(R.id.step_dialog_distance_example);
    // Only the editor for the selected duration type is enabled.
    // Switching the mode explicitly updates visibility and editability.
    durationTime.setEnabled(true);
    durationDistance.setEnabled(true);

    TitleSpinner.OnSetValueListener durationTypeListener =
        new TitleSpinner.OnSetValueListener() {
          @Override
          public String preSetValue(String newValue) throws IllegalArgumentException {
            return null;
          }

          @Override
          public int preSetValue(int newValue) throws IllegalArgumentException {
            switch (newValue) {
              case DIMENSION.TIME:
                durationTime.setEnabled(true);
                durationDistance.setEnabled(false);
                durationTime.setVisibility(View.VISIBLE);
                durationTime.setValue(
                    formatter.formatElapsedTime(
                        Formatter.Format.TXT, (long) step.getDurationValue()));
                durationDistance.setVisibility(View.GONE);
                durationTimeHelper.setVisibility(View.VISIBLE);
                durationTimeExample.setVisibility(View.VISIBLE);
                durationDistanceHelper.setVisibility(View.GONE);
                durationDistanceExample.setVisibility(View.GONE);
                break;
              case DIMENSION.DISTANCE:
                durationTime.setEnabled(false);
                durationDistance.setEnabled(true);
                durationTime.setVisibility(View.GONE);
                durationDistance.setVisibility(View.VISIBLE);
                durationDistance.setValue(Long.toString((long) step.getDurationValue()));
                durationTimeHelper.setVisibility(View.GONE);
                durationTimeExample.setVisibility(View.GONE);
                durationDistanceHelper.setVisibility(View.VISIBLE);
                durationDistanceExample.setVisibility(View.VISIBLE);
                break;
              default:
                durationTime.setEnabled(false);
                durationDistance.setEnabled(false);
                durationTime.setVisibility(View.GONE);
                durationDistance.setVisibility(View.GONE);
                durationTimeHelper.setVisibility(View.GONE);
                durationTimeExample.setVisibility(View.GONE);
                durationDistanceHelper.setVisibility(View.GONE);
                durationDistanceExample.setVisibility(View.GONE);
                break;
            }
            return newValue;
          }
        };
    durationType.setOnSetValueListener(durationTypeListener);

    if (step.getDurationType() == null) {
      durationType.setValue(DIMENSION.DISTANCE);
    } else {
      durationType.setValue(step.getDurationType().getValue());
    }
    // Apply the current mode explicitly as well. Android may restore the spinner
    // selection without dispatching a fresh item-selected callback.
    durationTypeListener.preSetValue(durationType.getValueInt());

    final TitleSpinner rhythm = layout.findViewById(R.id.step_dialog_rhythm);
    rhythm.setValue(step.getCoachRhythm());

    final TitleSpinner targetPaceLo = layout.findViewById(R.id.step_dialog_target_pace_lo);
    final TitleSpinner targetPaceHi = layout.findViewById(R.id.step_dialog_target_pace_hi);
    Range target = step.getTargetValue();
    if (target != null && step.getTargetType() == Dimension.PACE) {
      targetPaceLo.setValue(formatPaceMinutesSeconds(target.minValue));
      targetPaceHi.setValue(formatPaceMinutesSeconds(target.maxValue));
    } else {
      targetPaceLo.setValue("00:05:00");
      targetPaceHi.setValue("00:05:30");
    }

    return () -> {
      step.setIntensity(Intensity.valueOf(stepType.getValueInt()));
      step.setCoachRhythm(rhythm.getValueInt());
      step.setDurationType(Dimension.valueOf(durationType.getValueInt()));
      switch (durationType.getValueInt()) {
        case DIMENSION.DISTANCE:
          // The Pace Coach distance picker already returns meters internally.
          // Do not multiply by 1000 again here, otherwise 1 km becomes
          // 1,000,000 meters and is later displayed as 1000 km.
          double distanceMeters =
              SafeParse.parseDouble(durationDistance.getValue().toString(), 1000.0);
          step.setDurationValue(distanceMeters);
          break;
        case DIMENSION.TIME:
          step.setDurationValue(SafeParse.parseSeconds(durationTime.getValue().toString(), 60));
          break;
      }

      // Pace Coach structured steps use the same pace-target model as the
      // Intervalado editor: Ritmo Máx. + Ritmo Mín., with no separate target-type selector.
      step.setTargetType(Dimension.PACE);
      double unitMeters = Formatter.getUnitMeters(mContext);
      double paceLo =
          (double) SafeParse.parseSeconds(targetPaceLo.getValue().toString(), 5 * 60);
      double paceHi =
          (double) SafeParse.parseSeconds(targetPaceHi.getValue().toString(), 5 * 60);
      step.setTargetValue(paceLo / unitMeters, paceHi / unitMeters);
    };
  }
  /** Pace target UI is always MM:SS; the stored value is seconds per meter. */
  private String formatPaceMinutesSeconds(double secondsPerMeter) {
    if (Double.isNaN(secondsPerMeter) || Double.isInfinite(secondsPerMeter) || secondsPerMeter <= 0) {
      return "00:00";
    }
    long totalSeconds = Math.round(secondsPerMeter * 1000.0);
    long minutes = totalSeconds / 60;
    long seconds = totalSeconds % 60;
    return String.format(java.util.Locale.getDefault(), "%02d:%02d", minutes, seconds);
  }

}
