# Pace Coach V3.0.2

## Build fix
- Corrigida a API do PaceCalculator para compatibilidade com RunService.
- addLocation() agora retorna a distância acumulada em metros.
- currentPaceSecondsPerKm() agora expõe o pace suavizado em segundos/km.
- Java/Kotlin permanecem em JVM 17.

## Objetivo
Eliminar os erros de compilação observados no GitHub Actions e permitir a geração do primeiro APK Debug.
