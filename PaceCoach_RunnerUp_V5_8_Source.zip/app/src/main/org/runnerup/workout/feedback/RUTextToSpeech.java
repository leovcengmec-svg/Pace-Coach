/*
 * Copyright (C) 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 */

package org.runnerup.workout.feedback;

import android.content.Context;
import android.media.AudioManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import org.runnerup.util.Formatter;

/**
 * Single-channel, priority-aware speech queue.
 *
 * Android TextToSpeech has no pause/resume API. To provide deterministic
 * pre-emption without overlapping audio, each announcement is divided at
 * sentence boundaries. A higher-priority announcement stops the current
 * sentence, speaks first, then the interrupted sentence is replayed from its
 * beginning and the remaining sentences continue in their original order.
 */
public class RUTextToSpeech {

  private static final String UTTERANCE_ID = "RUTextTospeech";
  private static final int MAX_CHUNK_LENGTH = 180;
  private final boolean mute;
  private volatile boolean voiceEnabled = true;
  private final TextToSpeech textToSpeech;
  private final AudioManager audioManager;
  private final AtomicBoolean hasAudioFocus = new AtomicBoolean(false);
  private long id = System.nanoTime();
  private long sequence = 0;
  private long playbackGeneration = 0;

  private static final class Entry {
    final int prio;
    final String text;
    final HashMap<String, String> params;
    final String id;
    final long sequence;
    final List<String> chunks;
    int nextChunkIndex;

    Entry(String text, UtterancePrio prio, HashMap<String, String> params,
        String id, long sequence) {
      this.text = text;
      this.prio = prio.value;
      this.params = params == null ? null : new HashMap<>(params);
      this.id = id;
      this.sequence = sequence;
      this.chunks = splitSpeech(text);
      this.nextChunkIndex = 0;
    }
  }

  private final HashSet<String> cueSet = new HashSet<>();
  private final ArrayList<Entry> cueList = new ArrayList<>();
  private final ArrayList<Entry> pending = new ArrayList<>();

  private Entry activeEntry;
  private String activeUtteranceId;
  private boolean preemptRequested;

  private static final Comparator<Entry> ENTRY_ORDER =
      (left, right) -> {
        int byPriority = Integer.compare(right.prio, left.prio);
        return byPriority != 0 ? byPriority : Long.compare(left.sequence, right.sequence);
      };

  public RUTextToSpeech(TextToSpeech tts, boolean mute_, Context context) {
    this.textToSpeech = tts;
    this.audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
    this.mute = mute_;
    Locale locale = Formatter.getAudioLocale(context);
    if (tts != null && locale != null) {
      int res;
      switch ((res = tts.isLanguageAvailable(locale))) {
        case TextToSpeech.LANG_AVAILABLE:
        case TextToSpeech.LANG_COUNTRY_AVAILABLE:
        case TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE:
          res = tts.setLanguage(locale);
          Log.d(getClass().getName(), "setLanguage(" + locale.getDisplayLanguage() + ") => " + res);
          break;
        case TextToSpeech.LANG_MISSING_DATA:
        case TextToSpeech.LANG_NOT_SUPPORTED:
          Log.v(getClass().getName(),
              "setLanguage(" + locale.getDisplayLanguage() + ") => MISSING: " + res);
          break;
      }
    }

    // Completion callbacks are required in both mute and normal modes so the
    // internal queue can serialize speech and resume interrupted messages.
    if (tts != null) {
      UtteranceCompletion.setUtteranceCompletedListener(tts, this);
    }
  }

  private synchronized String getId() {
    return UTTERANCE_ID + (id++);
  }

  public Boolean isAvailable() {
    return textToSpeech != null;
  }

  public void setVoiceEnabled(boolean enabled) {
    synchronized (this) {
      voiceEnabled = enabled;
      if (!enabled) {
        cueSet.clear();
        cueList.clear();
        pending.clear();
        preemptRequested = false;
        activeEntry = null;
        activeUtteranceId = null;
        if (textToSpeech != null) {
          try {
            textToSpeech.stop();
          } catch (Exception ignored) {
            // Keep the workout alive even if the TTS engine rejects stop().
          }
        }
        abandonAudioFocusLocked();
      } else {
        pumpNextLocked();
      }
    }
  }

  public boolean isVoiceEnabled() {
    return voiceEnabled;
  }

  /** Speak a Pace Coach closing instruction as workout-status information. */
  public void speakCoach(String text) {
    if (text == null || text.trim().isEmpty()) return;
    speak(text, UtterancePrio.PRIO_STATUS, true, null);
    emit();
  }

  @SuppressWarnings("UnusedReturnValue")
  int speak(String text, UtterancePrio prio, boolean flush, HashMap<String, String> params) {
    if (!isAvailable() || text == null || text.trim().isEmpty() || prio == null) {
      return 0;
    }

    synchronized (this) {
      if (!voiceEnabled) return 0;
      String key = prio.value + "|" + text.trim();
      if (cueSet.add(key)) {
        cueList.add(new Entry(text.trim(), prio, params, getId(), sequence++));
      } else {
        Log.d(getClass().getName(), "skip duplicate buffered speech: " + text);
      }
    }
    return 0;
  }

  /** Move the current event batch into the priority queue and schedule playback. */
  public void emit() {
    synchronized (this) {
      if (!isAvailable() || !voiceEnabled) return;
      if (mute && !requestFocus()) {
        // Keep buffered speech; a later emit() can retry audio focus.
        return;
      }

      if (!cueList.isEmpty()) {
        pending.addAll(cueList);
        cueList.clear();
        cueSet.clear();
        sortPendingLocked();
      }

      if (activeEntry != null && !pending.isEmpty()
          && UtterancePrio.shouldPreempt(pending.get(0).prio, activeEntry.prio) && !preemptRequested) {
        preemptRequested = true;
        String interruptedId = activeUtteranceId;
        try {
          int result = textToSpeech.stop();
          if (result == TextToSpeech.ERROR) {
            // Do not start a second utterance if the engine refused to stop.
            // Keep the pre-emption request pending; completion will schedule
            // the higher-priority message without overlapping audio.
            Log.w(getClass().getName(), "TTS engine refused stop for " + interruptedId);
          }
        } catch (Exception ex) {
          Log.w(getClass().getName(), "Unable to pre-empt current speech", ex);
          // Let the active chunk finish naturally if stop() throws.
          // Its completion callback will still place the higher-priority cue first.
        }
      } else if (activeEntry == null) {
        pumpNextLocked();
      }
    }
  }

  private void sortPendingLocked() {
    Collections.sort(pending, ENTRY_ORDER);
  }

  /** Start exactly one TTS utterance; all queueing is controlled by this class. */
  private void pumpNextLocked() {
    if (!voiceEnabled || activeEntry != null || textToSpeech == null) {
      maybeAbandonAudioFocusLocked();
      return;
    }

    sortPendingLocked();
    while (!pending.isEmpty()) {
      Entry next = pending.remove(0);
      if (next.nextChunkIndex >= next.chunks.size()) continue;

      activeEntry = next;
      activeUtteranceId = next.id + "_" + next.nextChunkIndex + "_" + (++playbackGeneration);
      preemptRequested = false;

      HashMap<String, String> params = next.params == null
          ? new HashMap<>() : new HashMap<>(next.params);
      params.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, activeUtteranceId);
      String chunk = next.chunks.get(next.nextChunkIndex);
      int result;
      try {
        result = textToSpeech.speak(chunk, TextToSpeech.QUEUE_FLUSH, params);
      } catch (Exception ex) {
        Log.w(getClass().getName(), "TTS failed to enqueue: " + chunk, ex);
        result = TextToSpeech.ERROR;
      }

      if (result != TextToSpeech.ERROR) {
        return;
      }

      Log.w(getClass().getName(), "TTS rejected utterance: " + chunk);
      activeEntry = null;
      activeUtteranceId = null;
      next.nextChunkIndex++;
      if (next.nextChunkIndex < next.chunks.size()) {
        pending.add(next);
        sortPendingLocked();
      }
    }

    maybeAbandonAudioFocusLocked();
  }

  private synchronized void utteranceCompleted(String utteranceId) {
    if (activeUtteranceId == null || !activeUtteranceId.equals(utteranceId)) return;

    Entry completed = activeEntry;
    activeEntry = null;
    activeUtteranceId = null;
    preemptRequested = false;
    completed.nextChunkIndex++;
    if (completed.nextChunkIndex < completed.chunks.size()) {
      pending.add(completed);
    }
    pumpNextLocked();
  }

  private synchronized void utteranceFailed(String utteranceId) {
    if (activeUtteranceId == null || !activeUtteranceId.equals(utteranceId)) return;

    Entry failed = activeEntry;
    boolean interruptedForPriority = preemptRequested && voiceEnabled;
    activeEntry = null;
    activeUtteranceId = null;
    preemptRequested = false;
    if (!interruptedForPriority) {
      failed.nextChunkIndex++;
    }
    if (failed.nextChunkIndex < failed.chunks.size()) {
      pending.add(failed);
    }
    pumpNextLocked();
  }

  private synchronized void utteranceStopped(String utteranceId) {
    finishInterruptedLocked(utteranceId);
  }

  private void finishInterruptedLocked(String utteranceId) {
    if (activeUtteranceId == null || !activeUtteranceId.equals(utteranceId)) return;

    Entry interrupted = activeEntry;
    boolean resume = preemptRequested && voiceEnabled;
    activeEntry = null;
    activeUtteranceId = null;
    preemptRequested = false;
    if (resume && interrupted != null) {
      // The interrupted sentence is retried from its beginning after the
      // higher-priority announcement. Later sentences remain in the entry.
      pending.add(interrupted);
    }
    pumpNextLocked();
  }

  private boolean requestFocus() {
    if (hasAudioFocus.get()) return true;
    if (audioManager == null) return true;
    int result = audioManager.requestAudioFocus(
        null,
        AudioManager.STREAM_MUSIC,
        AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
    boolean granted = result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
    hasAudioFocus.set(granted);
    return granted;
  }

  private void maybeAbandonAudioFocusLocked() {
    if (activeEntry != null || !pending.isEmpty() || !cueList.isEmpty()) return;
    abandonAudioFocusLocked();
  }

  private void abandonAudioFocusLocked() {
    if (!hasAudioFocus.get()) return;
    hasAudioFocus.set(false);
    if (audioManager != null) audioManager.abandonAudioFocus(null);
  }

  /** Split at sentence boundaries so higher priorities can interrupt cleanly. */
  private static List<String> splitSpeech(String text) {
    ArrayList<String> chunks = new ArrayList<>();
    if (text == null) return chunks;
    String normalized = text.replace('\n', ' ').trim().replaceAll("\\s+", " ");
    if (normalized.isEmpty()) return chunks;

    String[] sentences = normalized.split("(?<=[.!?;,])\\s+");
    for (String sentence : sentences) {
      String remaining = sentence.trim();
      while (remaining.length() > MAX_CHUNK_LENGTH) {
        int cut = remaining.lastIndexOf(' ', MAX_CHUNK_LENGTH);
        if (cut < MAX_CHUNK_LENGTH / 2) cut = MAX_CHUNK_LENGTH;
        chunks.add(remaining.substring(0, cut).trim());
        remaining = remaining.substring(cut).trim();
      }
      if (!remaining.isEmpty()) chunks.add(remaining);
    }
    return chunks;
  }
}

final class UtteranceCompletion {

  private UtteranceCompletion() {}

  static void setUtteranceCompletedListener(
      TextToSpeech tts, final RUTextToSpeech ruTextToSpeech) {
    tts.setOnUtteranceProgressListener(
        new UtteranceProgressListener() {
          @Override
          public void onStart(String utteranceId) {}

          @Override
          public void onDone(String utteranceId) {
            ruTextToSpeech.utteranceCompleted(utteranceId);
          }

          @Override
          public void onError(String utteranceId) {
            ruTextToSpeech.utteranceFailed(utteranceId);
          }

          @Override
          public void onStop(String utteranceId, boolean interrupted) {
            ruTextToSpeech.utteranceStopped(utteranceId);
          }
        });
  }
}
