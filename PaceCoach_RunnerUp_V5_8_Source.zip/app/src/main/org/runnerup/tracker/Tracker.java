/*
 * Copyright (C) 2012 - 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.tracker;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.preference.PreferenceManager;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import org.runnerup.BuildConfig;
import org.runnerup.R;
import org.runnerup.common.tracker.TrackerState;
import org.runnerup.common.util.Constants;
import org.runnerup.common.util.ValueModel;
import org.runnerup.db.DBHelper;
import org.runnerup.export.SyncManager;
import org.runnerup.hr.HRProvider;
import org.runnerup.notification.ForegroundNotificationDisplayStrategy;
import org.runnerup.notification.NotificationState;
import org.runnerup.notification.NotificationStateManager;
import org.runnerup.notification.OngoingState;
import org.runnerup.tracker.component.TrackerCadence;
import org.runnerup.tracker.component.TrackerComponent;
import org.runnerup.tracker.component.TrackerComponentCollection;
import org.runnerup.tracker.component.TrackerElevation;
import org.runnerup.tracker.component.TrackerGPS;
import org.runnerup.tracker.component.TrackerHRM;
import org.runnerup.tracker.component.TrackerPressure;
import org.runnerup.tracker.component.TrackerReceiver;
import org.runnerup.tracker.component.TrackerTTS;
import org.runnerup.tracker.component.TrackerTemperature;
import org.runnerup.tracker.component.TrackerWear;
import org.runnerup.tracker.filter.PersistentGpsLoggerListener;
import org.runnerup.util.Formatter;
import org.runnerup.util.HRZones;
import org.runnerup.workout.Scope;
import org.runnerup.workout.Workout;

/**
 * GpsTracker - this class tracks Location updates
 *
 * <p>TODO: rename this class into ActivityTracker and factor out Gps stuff into own class that
 * should be handled much like hrm (e.g as a sensor among others)
 *
 * @author jonas.oreland@gmail.com
 */
public class Tracker extends android.app.Service implements LocationListener, Constants {
  // Max age for current data to be considered valid
  private static final int MAX_CURRENT_AGE = 15000;
  // A GPS fix can have excellent signal strength while still having poor
  // positional accuracy. Do not let low-quality fixes contaminate Ritmo Atual.
  // Activity distance keeps its broader acceptance rule; live pace uses this
  // stricter accuracy gate so GPS jitter cannot look like running speed.
  private static final float MAX_LIVE_PACE_ACCURACY_METERS = 15.0f;
  private static final long NANO_IN_MILLI = 1000000;

  private final Handler handler = new Handler();

  private final TrackerComponentCollection components = new TrackerComponentCollection();
  // Some trackers may select separate sensors depending on sport, handled in onBind()
  private final TrackerGPS trackerGPS = (TrackerGPS) components.addComponent(new TrackerGPS(this));
  private final TrackerHRM trackerHRM = (TrackerHRM) components.addComponent(new TrackerHRM());
  TrackerTTS trackerTTS = (TrackerTTS) components.addComponent(new TrackerTTS());
  private final TrackerCadence trackerCadence =
      (TrackerCadence) components.addComponent(new TrackerCadence());
  private final TrackerTemperature trackerTemperature =
      (TrackerTemperature) components.addComponent(new TrackerTemperature());
  private final TrackerPressure trackerPressure =
      (TrackerPressure) components.addComponent(new TrackerPressure());
  private final TrackerElevation trackerElevation =
      (TrackerElevation)
          components.addComponent(new TrackerElevation(this, trackerGPS, trackerPressure));
  TrackerReceiver trackerReceiver =
      (TrackerReceiver) components.addComponent(new TrackerReceiver(this));
  private final TrackerWear trackerWear =
      (TrackerWear) components.addComponent(new TrackerWear(this));

  private boolean mTimeFromGpsPoints = false;
  private boolean mCurrentSpeedFromGpsPoints = false;

  private long mLapId = 0;
  private long mActivityId = 0;
  // Accumulated active workout time. It is intentionally independent of GPS
  // callbacks so a GPS dropout cannot freeze the workout clock.
  private long mElapsedTimeNanos = 0;
  private long mActiveTimeStartNanos = 0;
  private double mElapsedDistance = 0;
  private double mHeartbeats = 0;
  private double mHeartbeatNanos = 0; // since we might loose HRM connectivity...
  private long mMaxHR = 0;
  private double mCurrentSpeed = 0.0;
  // Reference point used exclusively for the point-to-point live pace calculation.
  // This is intentionally separate from mLastLocation because mLastLocation may
  // advance for GPS fixes that are rejected for distance/accuracy purposes.
  private Location mLastPaceLocation = null;
  // Accepted GPS samples used to calculate the live pace over the user-selected
  // announcement period. This is deliberately separate from activity-average pace.
  private final Deque<Location> mPaceSamples = new ArrayDeque<>();

  private TrackerState nextState;
  private final ValueModel<TrackerState> state = new ValueModel<>(TrackerState.INIT);
  private int mLocationType = DB.LOCATION.TYPE_START;

  // Last location given by LocationManager
  private Location mLastLocation = null;
  // Last location given by LocationManager when in state STARTED
  private Location mLastLocationStarted = null;

  private SQLiteDatabase mDB = null;
  private PersistentGpsLoggerListener mDBWriter = null;
  private PowerManager.WakeLock mWakeLock = null;
  private final List<WorkoutObserver> liveLoggers = new ArrayList<>();

  private Workout workout = null;
  private NotificationStateManager notificationStateManager;
  private NotificationState activityOngoingState;

  @Override
  public void onCreate() {
    mDB = DBHelper.getWritableDatabase(this);
    notificationStateManager =
        new NotificationStateManager(new ForegroundNotificationDisplayStrategy(this));

    wakeLock(false);
  }

  @Override
  public int onStartCommand(Intent intent, int flags, int startId) {
    // We want this service to continue running until it is explicitly
    // stopped, so return sticky.
    return START_STICKY;
  }

  @Override
  public void onDestroy() {
    if (mDB != null) {
      DBHelper.closeDB(mDB);
      mDB = null;
    }

    reset();
  }

  public void setup() {
    switch (state.get()) {
      case INIT:
        break;
      case INITIALIZING:
      case INITIALIZED:
        return;
      case CONNECTING:
      case CONNECTED:
      case STARTED:
      case PAUSED:
      case ERROR:
      case STOPPED:
        if (BuildConfig.DEBUG) {
          throw new AssertionError();
        }
        return;
      case CLEANUP:
        // if CLEANUP is in progress, setup will continue once complete
        nextState = TrackerState.INITIALIZING;
        return;
    }

    state.set(TrackerState.INITIALIZING);

    TrackerComponent.ResultCode result = components.onInit(onInitCallback, getApplicationContext());
    if (result != TrackerComponent.ResultCode.RESULT_PENDING) {
      onInitCallback.run(components, result);
    }
  }

  public void setWithoutGps(boolean val) {
    trackerGPS.setWithoutGps(val);
  }

  private final TrackerComponent.Callback onInitCallback =
      new TrackerComponent.Callback() {
        @Override
        public void run(TrackerComponent component, TrackerComponent.ResultCode resultCode) {
          if (resultCode == TrackerComponent.ResultCode.RESULT_ERROR_FATAL) {
            state.set(TrackerState.ERROR);
          } else {
            state.set(TrackerState.INITIALIZED);
          }

          Log.d(getClass().getName(), "state.set(" + getState() + ")");
          handleNextState();
        }
      };

  private void handleNextState() {
    if (nextState == null) return;

    // if last phase ended in error,
    // don't continue with a new
    if (state.get() == TrackerState.ERROR) return;

    if (state.get() == nextState) {
      nextState = null;
      return;
    }

    switch (nextState) {
      case INIT:
        reset();
        break;
      case INITIALIZING:
        break;
      case INITIALIZED:
        setup();
        break;
      case CONNECTING:
        break;
      case CONNECTED:
        connect();
        break;
      case STARTED:
        break;
      case PAUSED:
        break;
      case STOPPED:
        break;
      case CLEANUP:
        break;
      case ERROR:
        break;
    }
  }

  public void connect() {
    Log.d(getClass().getName(), "Tracker.connect() - state: " + state.get());
    switch (state.get()) {
      case INIT:
        setup();
      case INITIALIZING:
      case CLEANUP:
        nextState = TrackerState.CONNECTED;
        Log.d(getClass().getName(), " => nextState: " + nextState);
        return;
      case INITIALIZED:
        break;
      case CONNECTING:
      case CONNECTED:
        return;
      case STARTED:
      case PAUSED:
      case ERROR:
      case STOPPED:
        if (BuildConfig.DEBUG) {
          throw new AssertionError();
        }
        return;
    }

    state.set(TrackerState.CONNECTING);

    wakeLock(true);

    SyncManager u = new SyncManager(getApplicationContext());
    u.loadLiveLoggers(liveLoggers);
    u.close();

    TrackerComponent.ResultCode result =
        components.onConnecting(onConnectCallback, getApplicationContext());
    if (result != TrackerComponent.ResultCode.RESULT_PENDING) {
      onConnectCallback.run(components, result);
    }
  }

  private final TrackerComponent.Callback onConnectCallback =
      (component, resultCode) -> {
        if (resultCode == TrackerComponent.ResultCode.RESULT_ERROR_FATAL) {
          state.set(TrackerState.ERROR);
        } else if (state.get() == TrackerState.CONNECTING) {
          state.set(TrackerState.CONNECTED);
          /* now we're connected */
          components.onConnected();
        }
      };

  @SuppressWarnings("UnusedReturnValue")
  private long createActivity(int sport) {
    Resources res = getResources();
    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
    boolean logGpxAccuracy = prefs.getBoolean(res.getString(R.string.pref_log_gpx_accuracy), false);
    mTimeFromGpsPoints = prefs.getBoolean(res.getString(R.string.pref_time_from_gps_points), false);
    mCurrentSpeedFromGpsPoints =
        prefs.getBoolean(res.getString(R.string.pref_speed_from_gps_points), false);

    // Create an Activity instance
    ContentValues tmp = new ContentValues();
    tmp.put(DB.ACTIVITY.SPORT, sport);
    try {
      mActivityId = mDB.insert(DB.ACTIVITY.TABLE, "nullColumnHack", tmp);

      tmp.clear();
      tmp.put(DB.LOCATION.ACTIVITY, mActivityId);
      tmp.put(DB.LOCATION.LAP, 0); // always start with lap 0
      mDBWriter = new PersistentGpsLoggerListener(mDB, DB.LOCATION.TABLE, tmp, logGpxAccuracy);
    } catch (IllegalStateException ex) {
      Log.i(getClass().getName(), "Query failed:", ex);
    }
    return mActivityId;
  }

  public void setWorkout(Workout workout) {
    this.workout = workout;
  }

  public void start() {
    if (BuildConfig.DEBUG && state.get() != TrackerState.CONNECTED) {
      throw new AssertionError();
    }

    // A workout must survive temporary UI navigation. Tracker used to be only
    // bound to RunActivity, so when VOLTAR unbound that activity the service
    // could be destroyed and the in-memory Workout/TrackerState (PAUSED) was
    // lost. Start the service explicitly at the real workout boundary. The
    // existing foreground-notification path keeps it alive while the workout
    // is paused and while RunActivity is temporarily off-screen.
    try {
      android.content.Intent keepAliveIntent =
          new android.content.Intent(this, Tracker.class);
      if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
        androidx.core.content.ContextCompat.startForegroundService(this, keepAliveIntent);
      } else {
        startService(keepAliveIntent);
      }
    } catch (Throwable ex) {
      // The Tracker is already running in this Service instance, so failure to
      // issue the keep-alive start must never prevent the workout from starting.
      android.util.Log.e("Tracker", "Unable to mark Tracker as started service", ex);
    }

    // connect workout and tracker
    workout.setTracker(this);

    // Add Wear to live loggers if it's active
    if (components.getResultCode(TrackerWear.NAME) == TrackerComponent.ResultCode.RESULT_OK)
      liveLoggers.add(trackerWear);

    // create the DB activity
    createActivity(workout.getSport());

    // do bindings
    doBind();

    // Let workout do initializations
    workout.onInit(workout);

    // Let components know we're starting
    components.onStart();

    mElapsedTimeNanos = 0;
    mActiveTimeStartNanos = SystemClock.elapsedRealtimeNanos();
    mElapsedDistance = 0;
    mHeartbeats = 0;
    mHeartbeatNanos = 0;
    mMaxHR = 0;
    mLastLocationStarted = null;
    // The location loaded while CONNECTING is only a last-known fix. It can
    // be tens of meters away from the first fresh GPS fix even when the user
    // never moved. Do not use that stale point as the first distance segment.
    mLastLocation = null;
    mCurrentSpeed = 0.0d;
    mLastPaceLocation = null;
    mPaceSamples.clear();

    // New location update will be tagged with START
    setNextLocationType(DB.LOCATION.TYPE_START);

    state.set(TrackerState.STARTED);

    activityOngoingState = new OngoingState(new Formatter(this), workout, this);

    // And finally let workout know that we started
    workout.onStart(Scope.ACTIVITY, this.workout);
  }

  private void doBind() {
    // Let components populate bindValues
    HashMap<String, Object> bindValues = new HashMap<>();
    Context ctx = getApplicationContext();
    bindValues.put(TrackerComponent.KEY_CONTEXT, ctx);
    bindValues.put(Workout.KEY_FORMATTER, new Formatter(ctx));
    bindValues.put(Workout.KEY_HRZONES, new HRZones(ctx));
    bindValues.put(Workout.KEY_MUTE, workout.getMute());
    bindValues.put(Workout.KEY_SPORT_TYPE, workout.getSport());
    bindValues.put(Workout.KEY_WORKOUT_TYPE, workout.getWorkoutType());

    components.onBind(bindValues);

    // and then give them to workout
    workout.onBind(workout, bindValues);
  }

  public void newLap(ContentValues tmp) {
    tmp.put(DB.LAP.ACTIVITY, mActivityId);
    mLapId = mDB.insert(DB.LAP.TABLE, null, tmp);
    ContentValues key = mDBWriter.getKey();
    key.put(DB.LOCATION.LAP, tmp.getAsLong(DB.LAP.LAP));
    mDBWriter.setKey(key);
  }

  public void saveLap(ContentValues tmp) {
    tmp.put(DB.LAP.ACTIVITY, mActivityId);
    String[] key = {Long.toString(mLapId)};
    mDB.update(DB.LAP.TABLE, tmp, "_id = ?", key);
  }

  public void pause() {
    switch (state.get()) {
      case INIT:
      case ERROR:
      case INITIALIZING:
      case INITIALIZED:
      case PAUSED:
      case CONNECTING:
      case CONNECTED:
      case CLEANUP:
      case STOPPED:
        return;
      case STARTED:
        break;
    }
    // Freeze the active timer before changing state. The clock must not depend
    // on a GPS callback arriving at the exact moment of pause.
    accumulateActiveTime();
    state.set(TrackerState.PAUSED);
    setNextLocationType(DB.LOCATION.TYPE_PAUSE);
    // This saves a PAUSE location
    internalOnLocationChanged(mLastLocationStarted);

    saveActivity(/* manualDistance= */ null);
    components.onPause();
  }

  /** Refresh the ongoing notification from the workout */
  public void displayNotificationState() {
    notificationStateManager.displayNotificationState(activityOngoingState);
  }

  public void stop() {
    switch (state.get()) {
      case INIT:
      case ERROR:
      case INITIALIZING:
      case INITIALIZED:
      case CONNECTING:
      case CONNECTED:
      case CLEANUP:
      case STOPPED:
        return;
      case PAUSED:
      case STARTED:
        break;
    }
    // Freeze the active timer before changing state.
    accumulateActiveTime();
    state.set(TrackerState.STOPPED);
    setNextLocationType(DB.LOCATION.TYPE_PAUSE);
    // This saves a PAUSE location
    internalOnLocationChanged(mLastLocationStarted);

    saveActivity(/* manualDistance= */ null);
    components.onPause(); // TODO add new callback for this
  }

  private void internalOnLocationChanged(Location arg0) {
    // insert location, set internal time
    if (arg0 != null) {
      onLocationChangedImpl(arg0, true);
    }
  }

  /**
   * Resume a paused/stopped workout without allowing a UI lifecycle race to
   * crash the application. This method is intentionally idempotent: if the
   * tracker is already STARTED, nothing happens. Only PAUSED/STOPPED are
   * resumable states.
   */
  public synchronized void resume() {
    TrackerState current = state.get();
    switch (current) {
      case PAUSED:
      case STOPPED:
        break;
      case STARTED:
        return;
      default:
        Log.w("Tracker", "Ignoring resume in state " + current);
        return;
    }

    state.set(TrackerState.STARTED);
    // Start a new active-time segment. Time spent paused is excluded.
    mActiveTimeStartNanos = SystemClock.elapsedRealtimeNanos();
    setNextLocationType(DB.LOCATION.TYPE_RESUME);
    // Save a resume location when one exists. A paused workout may have no
    // fresh GPS point yet; that must never prevent resuming the workout.
    internalOnLocationChanged(mLastLocation);

    try {
      components.onResume();
    } catch (Throwable ex) {
      // A sensor/TTS/Bluetooth component must never be allowed to terminate
      // the workout activity when the core Tracker can continue. Keep the
      // Tracker STARTED and report the component failure for diagnostics.
      Log.e("Tracker", "Tracker component failed while resuming workout", ex);
    }
  }

  public void reset() {
    switch (state.get()) {
      case INIT:
        return;
      case INITIALIZING:
        // cleanup when INITIALIZE is complete
        nextState = TrackerState.INIT;
        return;
      case INITIALIZED:
      case ERROR:
      case PAUSED:
      case CONNECTING:
      case CONNECTED:
      case STOPPED:
        nextState = TrackerState.INIT;
        // it's ok to "abort" connecting
        break;
      case STARTED:
        if (BuildConfig.DEBUG) {
          throw new AssertionError();
        }
        return;
      case CLEANUP:
        return;
    }

    wakeLock(false);

    if (workout != null) {
      workout.setTracker(null);
      workout = null;
    }

    state.set(TrackerState.CLEANUP);
    liveLoggers.clear();
    TrackerComponent.ResultCode res = components.onEnd(onEndCallback, getApplicationContext());
    if (res != TrackerComponent.ResultCode.RESULT_PENDING) onEndCallback.run(components, res);
  }

  private final TrackerComponent.Callback onEndCallback =
      (component, resultCode) -> {
        if (resultCode == TrackerComponent.ResultCode.RESULT_ERROR_FATAL) {
          state.set(TrackerState.ERROR);
        } else {
          state.set(TrackerState.INIT);
        }

        handleNextState();
      };

  public void completeActivity(boolean save, Double manualDistance) {
    if (BuildConfig.DEBUG
        && state.get() != TrackerState.PAUSED
        && state.get() != TrackerState.STOPPED) {
      throw new AssertionError();
    }

    setNextLocationType(DB.LOCATION.TYPE_END);
    internalOnLocationChanged(mLastLocationStarted);

    if (save) {
      saveActivity(manualDistance);
      liveLog(DB.LOCATION.TYPE_END);
    } else {
      ContentValues tmp = new ContentValues();
      tmp.put("deleted", 1);
      String[] key = {Long.toString(mActivityId)};

      if (mDB == null) {
        android.util.Log.e("Tracker", "completeActivity called but mDB is null");
      } else {
        mDB.update(DB.ACTIVITY.TABLE, tmp, "_id = ?", key);
      }
      liveLog(DB.LOCATION.TYPE_DISCARD);
    }

    components.onComplete(!save);
    notificationStateManager.cancelNotification();
    reset();

    // The explicit started-service ownership exists only for an in-progress
    // workout. Once the activity is saved/discarded, release that ownership.
    // If StartFragment is still bound for the normal home/GPS lifecycle, the
    // bound connection keeps the service alive; otherwise it can stop cleanly.
    try {
      stopSelf();
    } catch (Throwable ex) {
      android.util.Log.w("Tracker", "Unable to stop Tracker after completion", ex);
    }
  }

  private void saveActivity(Double manualDistance) {
    if (mDB == null) {
      android.util.Log.e("Tracker", "saveActivity called but mDB is null");
      return;
    }
    ContentValues tmp = new ContentValues();
    if (mHeartbeatNanos > 0) {
      long avgHR = Math.round(60 * mHeartbeats * 1000 * NANO_IN_MILLI / mHeartbeatNanos); // BPM
      tmp.put(Constants.DB.ACTIVITY.AVG_HR, avgHR);
    }
    if (mMaxHR > 0) tmp.put(Constants.DB.ACTIVITY.MAX_HR, mMaxHR);

    if (TrackerPressure.isAvailable(this)) {
      final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
      boolean enabled =
          prefs.getBoolean(this.getString(org.runnerup.R.string.pref_use_pressure_sensor), false);
      if (enabled) {
        // Save information about barometer usage, used in uploads (like Strava)
        tmp.put(DB.ACTIVITY.META_DATA, DB.ACTIVITY.WITH_BAROMETER);
      }
    }

    if (manualDistance != null) {
      tmp.put(Constants.DB.ACTIVITY.DISTANCE, manualDistance);
    } else {
      tmp.put(Constants.DB.ACTIVITY.DISTANCE, mElapsedDistance);
    }
    tmp.put(
        Constants.DB.ACTIVITY.TIME,
        Math.round(getTimeMs() / 1000.0d)); // time should be updated last for conditionalRecompute

    String[] key = {Long.toString(mActivityId)};
    mDB.update(DB.ACTIVITY.TABLE, tmp, "_id = ?", key);
  }

  private void setNextLocationType(int newType) {
    if (mDBWriter == null) {
      android.util.Log.w(
          "Tracker", "setNextLocationType: mDBWriter is null (newType=" + newType + ")");
      return;
    }
    ContentValues key = mDBWriter.getKey();
    key.put(DB.LOCATION.TYPE, newType);
    mDBWriter.setKey(key);
    mLocationType = newType;
  }

  // public long getTime() {
  //    return getTimeMs() / 1000;
  // }

  public long getTimeMs() {
    long totalNanos = mElapsedTimeNanos;
    if (state.get() == TrackerState.STARTED && mActiveTimeStartNanos > 0) {
      totalNanos += Math.max(0L, SystemClock.elapsedRealtimeNanos() - mActiveTimeStartNanos);
    }
    return totalNanos / NANO_IN_MILLI;
  }

  /** Accumulate the current active segment without relying on GPS updates. */
  private void accumulateActiveTime() {
    if (mActiveTimeStartNanos > 0) {
      mElapsedTimeNanos +=
          Math.max(0L, SystemClock.elapsedRealtimeNanos() - mActiveTimeStartNanos);
      mActiveTimeStartNanos = 0;
    }
  }

  public double getDistance() {
    return mElapsedDistance;
  }

  public Location getLastKnownLocation() {
    return mLastLocation;
  }

  public long getActivityId() {
    return mActivityId;
  }

  @Override
  public void onLocationChanged(@NonNull Location arg0) {
    // Elevation depends on GPS updates
    trackerElevation.onLocationChanged(arg0);
    onLocationChangedImpl(arg0, false);
  }

  private void onLocationChangedImpl(Location arg0, boolean internal) {
    if (!mTimeFromGpsPoints || internal) {
      long elapsedNs = SystemClock.elapsedRealtimeNanos();
      arg0.setElapsedRealtimeNanos(elapsedNs);
      long timeMs = System.currentTimeMillis();
      arg0.setTime(timeMs);
    }

    Integer hrValue = getCurrentHRValueElapsed(arg0.getElapsedRealtimeNanos(), MAX_CURRENT_AGE);
    Double eleValue = getCurrentElevation();
    Float cadValue = getCurrentCadence();
    Float temperatureValue = getCurrentTemperature();
    Float pressureValue = getCurrentPressure();

    if (!internal) {
      // GPS fixes are the continuous source for distance and live pace. Do not
      // advance the reference point for a rejected fix: doing so can leave the
      // activity stuck at a few meters and can also make the live pace remain
      // unavailable indefinitely.
      final float accuracy = arg0.hasAccuracy() ? arg0.getAccuracy() : 0.0f;
      if (arg0.hasAccuracy() && accuracy > 50.0f) {
        return;
      }

      if (mLastLocation != null) {
        final double distDiff = arg0.distanceTo(mLastLocation);
        final long timeDiffNanos =
            arg0.getElapsedRealtimeNanos() - mLastLocation.getElapsedRealtimeNanos();

        if (timeDiffNanos <= 0) {
          return;
        }

        // Reject only physically implausible GPS jumps. Do not use
        // Location.getSpeed() as a rejection criterion: Android providers may
        // report 0 while the runner is moving, especially just after a fix.
        final double dtSeconds = timeDiffNanos / 1_000_000_000.0d;
        final double maxPlausibleSpeed = 7.0d; // 25.2 km/h; rejects GPS jumps without constraining normal running
        final double allowedDistance =
            Math.max(5.0d, maxPlausibleSpeed * dtSeconds + Math.max(0.0d, accuracy * 0.5d));
        if (distDiff > allowedDistance) {
          return;
        }

        // Distance is accumulated from consecutive accepted GPS fixes only.
        if (state.get() == TrackerState.STARTED) {
          mElapsedDistance += Math.max(0.0d, distDiff);
          if (hrValue != null && hrValue > 0) {
            mHeartbeats +=
                (hrValue * timeDiffNanos) / (double) (60 * 1000 * NANO_IN_MILLI);
            mHeartbeatNanos += timeDiffNanos;
            mMaxHR = Math.max(hrValue, mMaxHR);
          }
        }

        // Keep GPS points as the atomic source for live pace, but use a stricter
        // positional-accuracy gate than the activity-distance tracker. A phone can
        // report a strong/"excellent" GPS signal while the coordinate itself still
        // wanders by several meters. Counting those low-quality fixes in Ritmo Atual
        // can turn walking into an artificial 6:00/km or produce huge fluctuations.
        // If accuracy is poor, keep the activity distance intact but do not advance
        // the live-pace reference until the next trustworthy fix arrives.
        final boolean livePaceFix =
            !arg0.hasAccuracy() || arg0.getAccuracy() <= MAX_LIVE_PACE_ACCURACY_METERS;
        if (livePaceFix) {
          if (mLastPaceLocation == null) {
            mPaceSamples.clear();
          }
          if (mLastPaceLocation != null) {
            long segmentNs = arg0.getElapsedRealtimeNanos() - mLastPaceLocation.getElapsedRealtimeNanos();
            double segmentMeters = arg0.distanceTo(mLastPaceLocation);
            if (segmentNs > 0 && segmentMeters > 0) {
              double segmentSpeed = segmentMeters * 1_000_000_000.0d / segmentNs;
              if (segmentSpeed > 0 && Double.isFinite(segmentSpeed)) mCurrentSpeed = segmentSpeed;
            }
          }
          mLastPaceLocation = arg0;
          mPaceSamples.addLast(new Location(arg0));
        }
        while (mPaceSamples.size() > 1) {
          Location first = mPaceSamples.peekFirst();
          Location last = mPaceSamples.peekLast();
          long ageNs = last.getElapsedRealtimeNanos() - first.getElapsedRealtimeNanos();
          // Keep enough consecutive GPS points to reconstruct any configured
          // current-pace window (time or distance). The previous implementation
          // accidentally retained only two points, so a 10-second announcement
          // could become a single noisy GPS segment instead of the full period.
          if (ageNs <= 180L * 1_000_000_000L) break;
          mPaceSamples.removeFirst();
        }
      } else {
        // First fresh GPS fix: establish the live-pace reference only when the
        // coordinate is accurate enough for a live-pace measurement. The normal
        // activity GPS state is still initialized below regardless of accuracy.
        if (!arg0.hasAccuracy() || arg0.getAccuracy() <= MAX_LIVE_PACE_ACCURACY_METERS) {
          mLastPaceLocation = arg0;
          mPaceSamples.clear();
          mPaceSamples.addLast(new Location(arg0));
        }
      }

      mLastLocation = arg0;
      if (state.get() == TrackerState.STARTED) {
        mLastLocationStarted = arg0;
      }
    } else {
      // Internal START/PAUSE/RESUME/END points are control markers and must not
      // alter the live pace reference used by the next real GPS fix.
    }

    if (internal || state.get() == TrackerState.STARTED) {
      mDBWriter.onLocationChanged(
          arg0,
          eleValue,
          getTimeMs(),
          mElapsedDistance,
          hrValue,
          cadValue,
          temperatureValue,
          pressureValue);

      switch (mLocationType) {
        case DB.LOCATION.TYPE_START:
        case DB.LOCATION.TYPE_RESUME:
          setNextLocationType(DB.LOCATION.TYPE_GPS);
          break;
        case DB.LOCATION.TYPE_GPS:
          break;
        case DB.LOCATION.TYPE_PAUSE:
          break;
        case DB.LOCATION.TYPE_END:
          if (!internal && BuildConfig.DEBUG) {
            throw new AssertionError();
          }
          break;
      }
      liveLog(mLocationType);
      notificationStateManager.displayNotificationState(activityOngoingState);
    }
  }

  private void liveLog(int type) {
    for (WorkoutObserver l : liveLoggers) {
      l.workoutEvent(workout, type);
    }
  }

  @Override
  public void onProviderDisabled(@NonNull String arg0) {}

  @Override
  public void onProviderEnabled(@NonNull String arg0) {}

  @Override
  public void onStatusChanged(String arg0, int arg1, Bundle arg2) {}

  public TrackerState getState() {
    return state.get();
  }

  public void registerTrackerStateListener(ValueModel.ChangeListener<TrackerState> listener) {
    state.registerChangeListener(listener);
  }

  public void unregisterTrackerStateListener(ValueModel.ChangeListener<TrackerState> listener) {
    state.unregisterChangeListener(listener);
  }

  // Service interface stuff...
  public class LocalBinder extends android.os.Binder {
    public Tracker getService() {
      return Tracker.this;
    }
  }

  private final IBinder mBinder = new LocalBinder();

  @Override
  public IBinder onBind(Intent intent) {
    return mBinder;
  }

  @SuppressLint("Wakelock")
  private void wakeLock(boolean get) {
    if (mWakeLock != null) {
      if (mWakeLock.isHeld()) {
        mWakeLock.release();
      }
      mWakeLock = null;
    }
    if (get) {
      PowerManager pm = (PowerManager) this.getSystemService(Context.POWER_SERVICE);
      mWakeLock =
          Objects.requireNonNull(pm)
              .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RunnerUp:wakeLock");
      if (mWakeLock != null) {
        // Set a timeout, this is before activity is started
        mWakeLock.acquire(300000);
      }
    }
  }

  public boolean isComponentConfigured(String name) {
    switch (getState()) {
      case INIT: // before onInit we don't know, so say no
      case CLEANUP: // when cleaning, say no
      case ERROR: // on error, say no
        return false;
      case INITIALIZING:
        // If we're initializing...say no
        if (components.getResultCode(name) == TrackerComponent.ResultCode.RESULT_PENDING)
          return false;
      case INITIALIZED:
      case CONNECTING:
      case CONNECTED:
      case STARTED:
      case PAUSED:
      case STOPPED:
        // check component
        break;
    }

    switch (components.getResultCode(name)) {
      case RESULT_OK:
      case RESULT_PENDING:
        return true;
      case RESULT_NOT_SUPPORTED:
      case RESULT_NOT_ENABLED:
      case RESULT_ERROR:
      case RESULT_ERROR_FATAL:
        return false;
    }
    return false;
  }

  public boolean isComponentConnected(String name) {
    TrackerComponent component = components.getComponent(name);
    return (component != null) && component.isConnected();
  }

  public HRProvider getHRProvider() {
    return (trackerHRM.getHrProvider());
  }

  public void setHrDebug(TextView tv) {
    if (trackerHRM != null) {
      trackerHRM.setDebugLog(tv);
    }
  }

  private Integer getCurrentHRValueElapsed(long now, long maxAge) {
    HRProvider hrProvider = trackerHRM.getHrProvider();
    if ((hrProvider == null) || !hrProvider.isConnected()) return null;

    // now is elapsed nanosec, no sensor adjust needed
    if (now > hrProvider.getHRValueElapsedRealtime() + maxAge * NANO_IN_MILLI) return null;

    return hrProvider.getHRValue();
  }

  private Integer getCurrentHRValue(long now, long maxAge) {
    HRProvider hrProvider = trackerHRM.getHrProvider();
    if ((hrProvider == null) || !hrProvider.isConnected()) return null;

    if (now > hrProvider.getHRValueTimestamp() + maxAge) return null;

    return hrProvider.getHRValue();
  }

  public Integer getCurrentHRValue() {
    return getCurrentHRValueElapsed(SystemClock.elapsedRealtimeNanos(), MAX_CURRENT_AGE);
  }

  public double getHeartbeats() {
    return mHeartbeats;
  }

  public Integer getCurrentBatteryLevel() {
    HRProvider hrProvider = trackerHRM.getHrProvider();
    if (hrProvider == null) return HRProvider.BATTERY_LEVEL_UNAVAILABLE;
    return hrProvider.getBatteryLevel();
  }

  public Float getCurrentCadence() {
    return trackerCadence.getValue();
  }

  public Float getCurrentTemperature() {
    return trackerTemperature.getValue();
  }

  public Float getCurrentPressure() {
    return trackerPressure.getValue();
  }

  public Double getCurrentElevation() {
    return trackerElevation.getValue();
  }

  // Live pace over the configured time period. Distance is accumulated from
  // consecutive accepted GPS points, then divided by the elapsed time of the window.
  public Double getCurrentSpeedForTimeWindow(double seconds) {
    if (mPaceSamples.size() < 2 || seconds <= 0) return null;
    Location last = mPaceSamples.peekLast();
    long nowNs = SystemClock.elapsedRealtimeNanos();
    if (nowNs - last.getElapsedRealtimeNanos() > MAX_CURRENT_AGE * NANO_IN_MILLI) return null;
    Location[] a = mPaceSamples.toArray(new Location[0]);
    int end = a.length - 1;
    double distance = 0.0d;
    int start = end;
    for (int i = end; i > 0; i--) {
      long dt = a[i].getElapsedRealtimeNanos() - a[i - 1].getElapsedRealtimeNanos();
      if (dt <= 0) continue;
      distance += Math.max(0.0d, a[i].distanceTo(a[i - 1]));
      start = i - 1;
      if ((a[end].getElapsedRealtimeNanos() - a[start].getElapsedRealtimeNanos())
          >= seconds * 1_000_000_000.0d) break;
    }
    long elapsed = a[end].getElapsedRealtimeNanos() - a[start].getElapsedRealtimeNanos();
    // A time-based Ritmo Atual must represent the complete configured period.
    // Never calculate a shorter partial window (for example 4 s when the user
    // selected 10 s). The window is built only from consecutive high-quality
    // GPS points; if GPS stalls or the complete period is not available yet,
    // return null and let the caller stay silent rather than inventing a pace.
    if (elapsed <= 0 || elapsed < seconds * 1_000_000_000.0d || distance <= 0.5d) return null;
    double speed = distance * 1_000_000_000.0d / elapsed;
    return speed > 0 && Double.isFinite(speed) ? speed : null;
  }

  // Live pace over the configured distance period. The window is made from
  // consecutive accepted GPS segments until the requested distance is reached.
  public Double getCurrentSpeedForDistanceWindow(double meters) {
    if (mPaceSamples.size() < 2 || meters <= 0) return null;
    Location[] a = mPaceSamples.toArray(new Location[0]);
    int end = a.length - 1;
    double distance = 0.0d;
    int start = end;
    for (int i = end; i > 0; i--) {
      double segment = Math.max(0.0d, a[i].distanceTo(a[i - 1]));
      long dt = a[i].getElapsedRealtimeNanos() - a[i - 1].getElapsedRealtimeNanos();
      if (dt <= 0) continue;
      distance += segment;
      start = i - 1;
      if (distance >= meters) break;
    }
    long elapsed = a[end].getElapsedRealtimeNanos() - a[start].getElapsedRealtimeNanos();
    // Distance-based Ritmo Atual is also only valid after the complete requested
    // distance has actually been accumulated. Do not report a partial window.
    if (elapsed <= 0 || distance < meters || distance <= 0.5d) return null;
    double speed = distance * 1_000_000_000.0d / elapsed;
    return speed > 0 && Double.isFinite(speed) ? speed : null;
  }

  /** Pace Coach live speed using the same configured period as the voice/interface. */
  public Double getPaceCoachCurrentSpeed() {
    try {
      android.content.SharedPreferences prefs =
          androidx.preference.PreferenceManager.getDefaultSharedPreferences(this);
      String cadence = prefs.getString("cue_current_cadence", "time");
      if ("distance".equals(cadence)) {
        double meters = Double.parseDouble(prefs.getString("cue_current_distance_interval", "100"));
        return getCurrentSpeedForDistanceWindow(meters > 0 ? meters : 100);
      }
      double seconds = Double.parseDouble(prefs.getString("cue_current_time_interval", "10"));
      return getCurrentSpeedForTimeWindow(seconds > 0 ? seconds : 10);
    } catch (Exception ignored) {
      return getCurrentSpeedForTimeWindow(10);
    }
  }

  // Backward-compatible raw live speed. Other RunnerUp components may use it.
  public Double getCurrentSpeed() {
    if (mLastPaceLocation == null || !(mCurrentSpeed > 0.0d)
        || Double.isNaN(mCurrentSpeed) || Double.isInfinite(mCurrentSpeed)) return null;
    if ((SystemClock.elapsedRealtimeNanos() - mLastPaceLocation.getElapsedRealtimeNanos())
        > MAX_CURRENT_AGE * NANO_IN_MILLI) return null;
    return mCurrentSpeed;
  }

  public Workout getWorkout() {
    return workout;
  }
}
