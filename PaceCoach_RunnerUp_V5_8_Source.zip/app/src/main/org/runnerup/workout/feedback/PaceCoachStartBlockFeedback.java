package org.runnerup.workout.feedback;

import android.content.Context;
import java.util.HashMap;
import org.runnerup.workout.Dimension;
import org.runnerup.workout.Feedback;
import org.runnerup.workout.Range;
import org.runnerup.workout.Step;
import org.runnerup.workout.Workout;

/** Ordered opening announcement: workout started, then the first block prescription. */
public class PaceCoachStartBlockFeedback extends Feedback {
  private final Step step;
  private RUTextToSpeech textToSpeech;

  public PaceCoachStartBlockFeedback(Step step) {
    this.step = step;
  }

  @Override
  public void onBind(Workout w, HashMap<String, Object> bindValues) {
    super.onBind(w, bindValues);
    if (bindValues.containsKey(Workout.KEY_TTS)) {
      textToSpeech = (RUTextToSpeech) bindValues.get(Workout.KEY_TTS);
    }
  }

  @Override
  public boolean equals(Feedback other) {
    return other instanceof PaceCoachStartBlockFeedback
        && ((PaceCoachStartBlockFeedback) other).step == step;
  }

  @Override
  public void emit(Workout w, Context ctx) {
    if (textToSpeech == null || step == null) return;
    StringBuilder msg = new StringBuilder("Treino iniciado. ");
    if (w.isPaceCoachLastStep(step)) {
      msg.append("Último bloco, ");
    }
    if (step.getIntensity() == org.runnerup.workout.Intensity.RESTING
        && step.getDurationType() == Dimension.TIME) {
      msg.append("Descanso Off, ").append(formatTime(step.getDurationValue()));
      textToSpeech.speak(msg.toString(), UtterancePrio.PRIO_COUNTDOWN, true, null);
      return;
    }
    msg.append(blockName()).append(", ").append(rhythmName(step.getCoachRhythm()));
    if (step.getDurationType() == Dimension.TIME) {
      msg.append(", ").append(formatTime(step.getDurationValue()));
    } else if (step.getDurationType() == Dimension.DISTANCE) {
      msg.append(", ").append(formatDistance(step.getDurationValue()));
    }
    Range target = step.getTargetValue();
    if (step.getTargetType() == Dimension.PACE && target != null) {
      msg.append(", Ritmo Alvo, ")
          .append(formatPace(target.minValue * 1000.0))
          .append(" a ")
          .append(formatPace(target.maxValue * 1000.0));
    }
    textToSpeech.speak(msg.toString(), UtterancePrio.PRIO_COUNTDOWN, true, null);
  }

  private String blockName() {
    // Pace Coach has a fixed execution vocabulary. Never expose an internal
    // Step.name (for example the legacy "Ritmo COACH") in spoken feedback.
    switch (step.getIntensity()) {
      case WARMUP: return "Aquecimento";
      case COOLDOWN: return "Desaquecimento";
      case RECOVERY: return "Recuperação";
      case RESTING: return step.getDurationType() == Dimension.TIME ? "Descanso Off" : "Intervalo";
      case ACTIVE: return "Intervalo";
      default: return "Bloco";
    }
  }

  private static String rhythmName(int rhythm) {
    if (rhythm == 0) return "devagar";
    if (rhythm == 2) return "rápido";
    return "constante";
  }

  private static String formatDistance(double meters) {
    double km = Math.max(0, meters) / 1000.0;
    if (Math.abs(km - Math.rint(km)) < 0.0001) return String.format(java.util.Locale.US, "%.0f km", km);
    return String.format(java.util.Locale.US, "%.1f km", km);
  }

  private static String formatTime(double seconds) {
    long total = Math.max(0, Math.round(seconds));
    long hours = total / 3600L;
    long minutes = (total % 3600L) / 60L;
    long secs = total % 60L;
    if (hours > 0) return hours + " horas" + (minutes > 0 ? " e " + minutes + " minutos" : "");
    if (minutes > 0 && secs == 0) return minutes + " minutos";
    if (minutes > 0) return minutes + " minutos e " + secs + " segundos";
    return secs + " segundos";
  }

  private static String formatPace(double secondsPerKm) {
    long total = Math.max(0, Math.round(secondsPerKm));
    return (total / 60L) + " e " + (total % 60L);
  }
}
