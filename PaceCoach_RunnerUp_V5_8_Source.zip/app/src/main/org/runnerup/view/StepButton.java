/*
 * Copyright (C) 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import java.util.Locale;
import org.runnerup.R;
import org.runnerup.common.util.Constants.DB.DIMENSION;
import org.runnerup.util.Formatter;
import org.runnerup.util.SafeParse;
import org.runnerup.widget.NumberPicker;
import org.runnerup.widget.TitleSpinner;
import org.runnerup.workout.Dimension;
import org.runnerup.workout.Intensity;
import org.runnerup.workout.Range;
import org.runnerup.workout.Step;

public class StepButton extends LinearLayout {

  private final Context mContext;
  private final ViewGroup mLayout;
  private final ImageView mIntensityIcon;
  private final TextView mDurationValue;
  private final TextView mGoalValue;
  private final Formatter formatter;

  public Step getStep() {
    return step;
  }

  private Step step;
  private Runnable mOnChangedListener = null;

  private static final boolean editRepeatCount = true;
  private static final boolean editStepButton = true;

  public StepButton(Context context, AttributeSet attrs) {
    super(context, attrs);
    mContext = context;

    LayoutInflater inflater =
        (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    inflater.inflate(R.layout.step_button, this);
    formatter = new Formatter(context);
    mLayout = findViewById(R.id.step_button_layout);
    mIntensityIcon = findViewById(R.id.step_icon);
    mDurationValue = findViewById(R.id.step_duration_value);
    mGoalValue = findViewById(R.id.step_goal_value);
  }

  @Override
  public void setEnabled(boolean enabled) {
    super.setEnabled(enabled);
    mLayout.setEnabled(enabled);
    for (int i = 0, j = mLayout.getChildCount(); i < j; i++) {
      mLayout.getChildAt(i).setEnabled(enabled);
    }
  }

  public void setOnChangedListener(Runnable runnable) {
    mOnChangedListener = runnable;
  }

  public void setStep(Step step) {
    this.step = step;

    mDurationValue.setVisibility(VISIBLE);
    switch (step.getIntensity()) {
      case ACTIVE:
        mIntensityIcon.setImageResource(R.drawable.step_active);
        mGoalValue.setTextColor(
            ContextCompat.getColor(mContext, R.color.stepActive)); // todo check if it works
        break;
      case RESTING:
        mIntensityIcon.setImageResource(R.drawable.step_resting);
        mGoalValue.setTextColor(ContextCompat.getColor(mContext, R.color.stepResting));
        break;
      case REPEAT:
        mIntensityIcon.setImageResource(R.drawable.step_repeat);
        mDurationValue.setVisibility(GONE); // todo better wording in string
        mGoalValue.setText(
            String.format(
                Locale.getDefault(),
                getResources().getString(org.runnerup.common.R.string.repeat_times),
                step.getRepeatCount()));
        mGoalValue.setTextColor(ContextCompat.getColor(mContext, R.color.stepRepeat));
        if (editRepeatCount) mLayout.setOnClickListener(onRepeatClickListener);
        return;
      case WARMUP:
        mIntensityIcon.setImageResource(R.drawable.step_warmup);
        mGoalValue.setTextColor(ContextCompat.getColor(mContext, R.color.stepWarmup));
        break;
      case COOLDOWN:
        mIntensityIcon.setImageResource(R.drawable.step_cooldown);
        mGoalValue.setTextColor(ContextCompat.getColor(mContext, R.color.stepCooldown));
        break;
      case RECOVERY:
        mIntensityIcon.setImageResource(R.drawable.step_recovery);
        mGoalValue.setTextColor(ContextCompat.getColor(mContext, R.color.stepRecovery));
        break;
      default:
        mIntensityIcon.setImageResource(0);
    }

    Dimension durationType = step.getDurationType();
    if (durationType == null) {
      mDurationValue.setText(org.runnerup.common.R.string.Until_press);
    } else {
      mDurationValue.setText(
          formatter.format(Formatter.Format.TXT_LONG, durationType, step.getDurationValue()));
    }

    Dimension goalType = step.getTargetType();
    if (goalType == null) {
      mGoalValue.setText(step.getIntensity().getTextId());
    } else {
      String prefix;
      String separator = "–";
      if (goalType == Dimension.HR || goalType == Dimension.HRZ) {
        prefix = "FC ";
      } else if (goalType == Dimension.PACE) {
        prefix = "Pace ";
      } else {
        prefix = "";
      }

      String minText = formatter.format(Formatter.Format.TXT_SHORT, goalType, step.getTargetValue().minValue);
      String maxText = formatter.format(Formatter.Format.TXT_SHORT, goalType, step.getTargetValue().maxValue);
      String unitText = goalType == Dimension.PACE ? " min/km" : "";
      mGoalValue.setText(
          String.format(Locale.getDefault(), "%s%s%s%s", prefix, minText, separator, maxText, unitText));
    }
    if (editStepButton) {
      mLayout.setOnClickListener(onStepClickListener);
    }
  }

  private final OnClickListener onRepeatClickListener =
      new OnClickListener() {

        @Override
        public void onClick(View v) {
          final NumberPicker numberPicker = new NumberPicker(mContext, null);
          numberPicker.setOrientation(VERTICAL);
          numberPicker.setDigits(4);
          numberPicker.setRange(0, 9999, true);
          numberPicker.setValue(step.getRepeatCount());

          final LinearLayout layout = new LinearLayout(mContext);
          layout.setLayoutParams(
              new LinearLayout.LayoutParams(
                  LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
          layout.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
          layout.addView(numberPicker);

          new AlertDialog.Builder(mContext)
              .setTitle(org.runnerup.common.R.string.repeat)
              .setView(layout)
              .setPositiveButton(
                  org.runnerup.common.R.string.OK,
                  (dialog, whichButton) -> {
                    step.setRepeatCount(numberPicker.getValue());
                    dialog.dismiss();
                    setStep(step); // redraw
                    if (mOnChangedListener != null) {
                      mOnChangedListener.run();
                    }
                  })
              .setNegativeButton(
                  org.runnerup.common.R.string.Cancel, (dialog, whichButton) -> dialog.dismiss())
              .show();
        }
      };

  private final OnClickListener onStepClickListener =
      new OnClickListener() {

        @Override
        public void onClick(View v) {
          final LayoutInflater inflater = LayoutInflater.from(mContext);
          @SuppressLint("InflateParams")
          final View layout = inflater.inflate(R.layout.step_dialog, null);

          final Runnable save = setupEditStep(inflater, layout);

          new AlertDialog.Builder(mContext)
              .setTitle(org.runnerup.common.R.string.Edit_step)
              .setView(layout)
              .setPositiveButton(
                  org.runnerup.common.R.string.OK,
                  (dialog, whichButton) -> {
                    save.run();
                    dialog.dismiss();
                    setStep(step); // redraw
                    if (mOnChangedListener != null) {
                      mOnChangedListener.run();
                    }
                  })
              .setNegativeButton(
                  org.runnerup.common.R.string.Cancel, (dialog, whichButton) -> dialog.dismiss())
              .show();
        }
      };

  private Runnable setupEditStep(LayoutInflater inflator, View layout) {
    final TextView section = layout.findViewById(R.id.step_dialog_section);
    final TextView description = layout.findViewById(R.id.step_dialog_description);
    final TitleSpinner durationType = layout.findViewById(R.id.step_dialog_duration_type);
    final TitleSpinner durationTime = layout.findViewById(R.id.step_dialog_duration_time);
    final TitleSpinner durationDistance = layout.findViewById(R.id.step_dialog_duration_distance);
    final TitleSpinner rhythm = layout.findViewById(R.id.step_dialog_rhythm);
    final TitleSpinner targetPaceLo = layout.findViewById(R.id.step_dialog_target_pace_lo);
    final TitleSpinner targetPaceHi = layout.findViewById(R.id.step_dialog_target_pace_hi);
    final TitleSpinner targetType = layout.findViewById(R.id.step_dialog_target_type);

    int intensity = step.getIntensity().getValue();
    String sectionName;
    String sectionDescription;
    switch (step.getIntensity()) {
      case WARMUP:
        sectionName = "1  •  AQUECIMENTO";
        sectionDescription = "Bloco inicial para preparar o corpo antes do treino.";
        break;
      case REPEAT:
        sectionName = "2  •  REPETIÇÕES";
        sectionDescription = "Define quantas vezes o bloco de esforço + recuperação será executado.";
        break;
      case ACTIVE:
        sectionName = "3  •  INTERVALO";
        sectionDescription = "Bloco de esforço que será repetido conforme o número definido acima.";
        break;
      case RESTING:
      case RECOVERY:
        sectionName = "4  •  RECUPERAÇÃO";
        sectionDescription = "Bloco de recuperação entre os esforços.";
        break;
      case COOLDOWN:
        sectionName = "5  •  DESAQUECIMENTO";
        sectionDescription = "Bloco final para reduzir gradualmente a intensidade.";
        break;
      default:
        sectionName = "ETAPA";
        sectionDescription = "Configure a etapa do treino.";
        break;
    }
    section.setText(sectionName);
    description.setText(sectionDescription);

    // The approved editor uses "Medir por" with Time/Distance and keeps the
    // corresponding editor visible below it. The underlying RunnerUp model
    // remains unchanged (seconds/meters).
    durationType.setOnSetValueListener(new TitleSpinner.OnSetValueListener() {
      @Override public String preSetValue(String newValue) { return newValue; }
      @Override public int preSetValue(int newValue) {
        boolean time = newValue == DIMENSION.TIME;
        durationTime.setVisibility(time ? VISIBLE : GONE);
        durationDistance.setVisibility(newValue == DIMENSION.DISTANCE ? VISIBLE : GONE);
        return newValue;
      }
    });

    if (step.getDurationType() == null) {
      // Preserve "Até ser pressionado" as a valid model state. The UI spinner
      // still exposes it as the first choice, exactly as the approved editor.
      durationType.setValue(-1);
      durationTime.setVisibility(GONE);
      durationDistance.setVisibility(GONE);
    } else {
      durationType.setValue(step.getDurationType().getValue());
    }

    // Pace is the primary target language in Pace Coach. The rhythm selector
    // is a friendly presentation layer while pace values remain editable.
    double paceLo = 4 * 60 + 40;
    double paceHi = 4 * 60 + 50;
    Range existing = step.getTargetValue();
    if (existing != null && step.getTargetType() == Dimension.PACE) {
      paceLo = existing.minValue * 1000.0;
      paceHi = existing.maxValue * 1000.0;
      if (paceLo <= 0 || paceHi <= 0) { paceLo = 280; paceHi = 290; }
    } else if (step.getIntensity() == Intensity.WARMUP || step.getIntensity() == Intensity.COOLDOWN) {
      paceLo = 6 * 60 + 20;
      paceHi = 6 * 60 + 40;
    } else if (step.getIntensity() == Intensity.RESTING || step.getIntensity() == Intensity.RECOVERY) {
      paceLo = 6 * 60 + 10;
      paceHi = 6 * 60 + 30;
    }
    targetPaceLo.setValue(formatPaceMinutesSeconds(paceLo / 1000.0));
    targetPaceHi.setValue(formatPaceMinutesSeconds(paceHi / 1000.0));

    int rhythmValue = 2; // Rápido
    if (step.getIntensity() == Intensity.WARMUP || step.getIntensity() == Intensity.COOLDOWN) rhythmValue = 1;
    if (step.getIntensity() == Intensity.RESTING || step.getIntensity() == Intensity.RECOVERY) rhythmValue = 0;
    rhythm.setValue(rhythmValue);

    // Keep the legacy target type hidden but synchronized to PACE when saving.
    targetType.setValue(DIMENSION.PACE);

    return () -> {
      step.setIntensity(Intensity.valueOf(intensity));
      int duration = durationType.getValueInt();
      if (duration == -1) {
        step.setDurationType(null);
        step.setDurationValue(0);
      } else {
        step.setDurationType(Dimension.valueOf(duration));
        if (duration == DIMENSION.DISTANCE) {
          step.setDurationValue(SafeParse.parseDouble(durationDistance.getValue().toString(), 1000));
        } else if (duration == DIMENSION.TIME) {
          step.setDurationValue(SafeParse.parseSeconds(durationTime.getValue().toString(), 60));
        }
      }

      double unitMeters = Formatter.getUnitMeters(mContext);
      double saveLo = SafeParse.parseSeconds(targetPaceLo.getValue().toString(), 4 * 60 + 40);
      double saveHi = SafeParse.parseSeconds(targetPaceHi.getValue().toString(), 4 * 60 + 50);
      if (saveHi < saveLo) { double t = saveLo; saveLo = saveHi; saveHi = t; }
      step.setTargetType(Dimension.PACE);
      step.setTargetValue(saveLo / unitMeters, saveHi / unitMeters);
    };
  }

  /** Pace target UI is always MM:SS; the stored value is seconds per meter. */
  private String formatPaceMinutesSeconds(double secondsPerMeter) {
    if (Double.isNaN(secondsPerMeter) || Double.isInfinite(secondsPerMeter) || secondsPerMeter <= 0) {
      return "00:00";
    }
    long totalSeconds = Math.round(secondsPerMeter * 1000.0);
    long minutes = totalSeconds / 60;
    long seconds = totalSeconds % 60;
    return String.format(java.util.Locale.getDefault(), "%02d:%02d", minutes, seconds);
  }

}
