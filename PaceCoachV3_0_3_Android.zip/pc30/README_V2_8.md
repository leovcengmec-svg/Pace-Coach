# Pace Coach V2.8

## Objetivo
Transformar o criador de treino estruturado em uma configuração utilizável dentro do app.

## Novidades
- Editor simples de treino: nome, aquecimento, distância do tiro, repetições, pace do tiro, recuperação e desaquecimento.
- Botão para montar e salvar o treino.
- Repositório compartilhado em memória entre Activity e RunService.
- RunService executa o último treino salvo.
- Tela recebe atualizações da etapa ativa.
- Correção do contrato de `CoachEvent.Finished`.
- Testes do builder e do repositório.

## Limitação
Ainda não foi feita compilação Android neste ambiente e não foi realizado teste físico no telefone.
