# Pace Coach V2.9

## Execução robusta do treino estruturado

- Treinos estruturados avançam por tempo ou distância independentemente da disponibilidade do pace.
- Aquecimento, recuperação e desaquecimento por tempo continuam progredindo quando o GPS ainda não fornece pace válido.
- Corrida livre não inicializa mais o coach de treino estruturado.
- Anúncios periódicos em treino estruturado usam o alvo da etapa ativa quando existir.
- GPS incerto fica separado de uma mensagem normal do coach.
- Foram adicionados testes para transição por tempo e por distância.

Esta versão é código-fonte. A compilação Android completa e o teste em dispositivo ainda não foram realizados neste ambiente.
