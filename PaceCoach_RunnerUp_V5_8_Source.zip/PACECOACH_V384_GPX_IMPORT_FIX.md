# Pace Coach / RunnerUp — revisão interna v384

## Vistoria do erro de importação GPX observado na v382

A captura do aplicativo mostra o aviso genérico "Não foi possível importar o GPX". O arquivo `.gpx` selecionado e o Logcat da falha não foram fornecidos, então não é possível afirmar qual exceção específica ocorreu naquele arquivo.

A inspeção do importador `GPXImporter` da v382 encontrou limitações concretas:

- Só reconhecia pontos `<trkpt>` de trilhas. Arquivos GPX cujo percurso está em `<rtept>` (rota) eram rejeitados com "O GPX não contém pontos de corrida".
- Forçava a leitura do XML como UTF-8, ignorando a codificação declarada pelo próprio arquivo/BOM.
- O parser assumia que o texto XML chegava em um único evento `TEXT`, e não acumulava blocos de texto/CDATA.
- Falhas de leitura, coordenadas ou gravação eram todas apresentadas ao usuário com o mesmo toast genérico.
- O retorno das inserções de pontos/voltas no banco não era verificado, permitindo que a gravação de dados incompletos não fosse detectada imediatamente.

## Correções na v384

- Aceitar `<trkpt>` e `<rtept>` como pontos de percurso importáveis; waypoints isolados (`<wpt>`) continuam sem virar atividade, pois não representam uma trilha/rota contínua.
- Deixar o parser XML detectar a codificação declarada no arquivo.
- Normalizar nomes locais de elementos XML, incluindo elementos com namespace.
- Acumular conteúdo textual fragmentado e CDATA dos elementos de ponto.
- Validar latitude e longitude (presença, valor numérico, finitude e intervalo geográfico) antes de iniciar a gravação.
- Verificar os resultados de inserção da atividade, dos pontos e das voltas. Como a importação é transacional, erro na gravação cancela a operação inteira.
- Exibir na mensagem de erro a causa informada pela exceção, em vez de sempre mostrar o texto genérico.
- Aplicar a mensagem diagnóstica também quando o GPX é aberto/compartilhado por outro aplicativo.

## Identificação

- Revisão interna: `v384`.
- `versionCode`: `384` (código Android final esperado: `23000384`, com minSdk 23).
- `versionName`: `2.11.0.10`.
- Artefato GitHub Actions: `pacecoach-apk-v384-gpx-import-fix`.
- Nome externo do projeto e nome original do ZIP preservados.

## Validações realizadas neste ambiente

- Análise sintática Java com Javac: 187 arquivos analisados (app, common e wear), sem erro sintático.
- XML: 311 arquivos parseados com sucesso.
- Workflow GitHub Actions: YAML válido.
- Versão e nome do artefato conferidos.
- ZIP integralmente testado após empacotamento.

## Validação pendente

Não havia Gradle/Android SDK disponível neste ambiente; a compilação Android real ainda precisa ser confirmada pelo GitHub Actions. O GPX exato que falhou na captura também não foi fornecido, portanto a correção cobre limitações reais encontradas no importador, mas ainda precisa ser validada com o arquivo original e com um GPX de trilha/rota conhecido.
