package org.runnerup.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListView;

/**
 * ListView that expands to the height of all adapter rows when placed inside a
 * ScrollView. This keeps the editor's outer page as the only scroll container,
 * so every workout block remains visible and the page grows naturally with the
 * number of blocks.
 */
public class ExpandableHeightListView extends ListView {
  public ExpandableHeightListView(Context context) {
    super(context);
  }

  public ExpandableHeightListView(Context context, AttributeSet attrs) {
    super(context, attrs);
  }

  public ExpandableHeightListView(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
  }

  @Override
  protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    int expandedHeight = MeasureSpec.makeMeasureSpec(Integer.MAX_VALUE >> 2, MeasureSpec.AT_MOST);
    super.onMeasure(widthMeasureSpec, expandedHeight);
  }
}
