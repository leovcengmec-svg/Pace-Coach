package org.runnerup.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.TabHost;

/**
 * TabHost that keeps the existing tab layout/indicators but also supports
 * horizontal swipe navigation between tabs. Vertical gestures are left to
 * the currently displayed tab content (for example ScrollView scrolling).
 */
public class SwipeTabHost extends TabHost {
  private float downX;
  private float downY;
  private boolean horizontalSwipe;
  private final int touchSlop;

  public SwipeTabHost(Context context) {
    super(context);
    touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
  }

  public SwipeTabHost(Context context, AttributeSet attrs) {
    super(context, attrs);
    touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
  }

  public SwipeTabHost(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
  }

  @Override
  public boolean onInterceptTouchEvent(MotionEvent event) {
    switch (event.getActionMasked()) {
      case MotionEvent.ACTION_DOWN:
        downX = event.getX();
        downY = event.getY();
        horizontalSwipe = false;
        break;

      case MotionEvent.ACTION_MOVE:
        float dx = event.getX() - downX;
        float dy = event.getY() - downY;
        if (!horizontalSwipe
            && Math.abs(dx) > touchSlop
            && Math.abs(dx) > Math.abs(dy) * 1.35f) {
          horizontalSwipe = true;
          return true;
        }
        break;

      case MotionEvent.ACTION_UP:
      case MotionEvent.ACTION_CANCEL:
        break;
    }

    return super.onInterceptTouchEvent(event);
  }

  @Override
  public boolean onTouchEvent(MotionEvent event) {
    if (horizontalSwipe) {
      if (event.getActionMasked() == MotionEvent.ACTION_UP) {
        float dx = event.getX() - downX;
        int current = getCurrentTab();
        int count = getTabWidget().getTabCount();
        int target = dx < 0 ? current + 1 : current - 1;

        horizontalSwipe = false;
        if (Math.abs(dx) >= Math.max(80, touchSlop * 3)
            && target >= 0
            && target < count) {
          setCurrentTab(target);
        }
        return true;
      }

      if (event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
        horizontalSwipe = false;
      }
      return true;
    }

    return super.onTouchEvent(event);
  }
}
