package org.runnerup.view;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.view.WindowCompat;
import androidx.preference.PreferenceManager;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import org.runnerup.R;
import org.runnerup.tracker.GpsStatus;
import org.runnerup.util.ViewUtil;
import org.runnerup.widget.TitleSpinner;
import org.runnerup.workout.RepeatStep;
import org.runnerup.workout.Step;
import org.runnerup.workout.Workout;
import org.runnerup.workout.WorkoutSerializer;

public class CreateAdvancedWorkout extends AppCompatActivity {

  private Workout advancedWorkout = null;
  private TitleSpinner advancedWorkoutSpinner = null;
  private final WorkoutStepsAdapter advancedWorkoutStepsAdapter = new WorkoutStepsAdapter();
  private boolean dontAskAgain = false;
  private GpsStatus editorGpsStatus;
  private TextView editorGpsDot;
  private TextView editorGpsLevel;
  private ViewGroup editorGpsBars;
  private final Handler editorGpsHandler = new Handler(Looper.getMainLooper());
  private final Runnable editorGpsRefresh = new Runnable() {
    @Override
    public void run() {
      updateEditorGpsHeader();
      editorGpsHandler.postDelayed(this, 1000L);
    }
  };

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    EdgeToEdge.enable(this);
    Window window = getWindow();
    WindowCompat.getInsetsController(window, window.getDecorView())
        .setAppearanceLightStatusBars(false);
    super.onCreate(savedInstanceState);

    AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);

    setContentView(R.layout.create_advanced_workout);

    editorGpsDot = findViewById(R.id.advanced_gps_header_dot);
    editorGpsLevel = findViewById(R.id.advanced_gps_header_level);
    editorGpsBars = findViewById(R.id.advanced_gps_header_bars);
    findViewById(R.id.advanced_gps_header_status).setOnClickListener(v -> {
      try {
        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
      } catch (Exception ignored) {
      }
    });

    findViewById(R.id.advanced_editor_back_button).setOnClickListener(v -> {
      persistCurrentWorkoutName();
      finish();
    });

    Intent intent = getIntent();
    String advWorkoutName = intent.getStringExtra(ManageWorkoutsActivity.WORKOUT_NAME);
    boolean workoutEditMode =
        intent.getBooleanExtra(ManageWorkoutsActivity.WORKOUT_EDIT_MODE, false);

    advancedWorkoutSpinner = findViewById(R.id.new_workout_spinner);
    advancedWorkoutSpinner.setValue(advWorkoutName);
    advancedWorkoutSpinner.setEnabled(false);

    dontAskAgain = false;

    ListView advancedStepList = findViewById(R.id.new_advnced_workout_steps);
    advancedStepList.setDividerHeight(0);
    advancedStepList.setAdapter(advancedWorkoutStepsAdapter);

    Button addStepButton = findViewById(R.id.add_step_button);
    addStepButton.setOnClickListener(addStepButtonClick);

    Button addRepeatButton = findViewById(R.id.add_repeat_button);
    addRepeatButton.setOnClickListener(addRepeatStepButtonClick);

    Button saveWorkoutButton = findViewById(R.id.workout_save_button);
    saveWorkoutButton.setOnClickListener(saveWorkoutButtonClick);

    Button discardWorkoutButton = findViewById(R.id.workout_discard_button);
    discardWorkoutButton.setOnClickListener(discardWorkoutButtonClick);

    Button renameWorkoutButton = findViewById(R.id.workout_rename_button);
    renameWorkoutButton.setVisibility(View.GONE);

    if (workoutEditMode) {
      // Avoid users inadvertently deleting existing workouts while editing:
      // (discard button should only be available when creating a workout)
      discardWorkoutButton.setVisibility(View.GONE);
      renameWorkoutButton.setVisibility(View.VISIBLE);
      renameWorkoutButton.setOnClickListener(renameWorkoutButtonClick);
    }

    try {
      createAdvancedWorkout(advWorkoutName, workoutEditMode);
    } catch (Exception e) {
      handleWorkoutFileException(e);
    }

    // Persist the currently displayed workout name when leaving via the back button so that
    // StartFragment's advanced tab points at (and shows) this workout when we return.
    getOnBackPressedDispatcher()
        .addCallback(
            this,
            new OnBackPressedCallback(true) {
              @Override
              public void handleOnBackPressed() {
                persistCurrentWorkoutName();
                finish();
              }
            });

    ViewUtil.Insets(findViewById(R.id.create_advanced_workout_view), true);
  }

  @Override
  protected void onResume() {
    super.onResume();
    startEditorGps();
    editorGpsHandler.removeCallbacks(editorGpsRefresh);
    editorGpsHandler.post(editorGpsRefresh);
  }

  @Override
  protected void onPause() {
    editorGpsHandler.removeCallbacks(editorGpsRefresh);
    stopEditorGps();
    super.onPause();
  }

  private void startEditorGps() {
    if (editorGpsStatus == null) {
      editorGpsStatus = new GpsStatus(getApplicationContext());
    }
    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
        != PackageManager.PERMISSION_GRANTED) {
      updateEditorGpsHeader();
      return;
    }
    try {
      if (editorGpsStatus.isEnabled() && !editorGpsStatus.isLogging()) {
        editorGpsStatus.start(() -> runOnUiThread(this::updateEditorGpsHeader));
      }
    } catch (Exception ignored) {
    }
    updateEditorGpsHeader();
  }

  private void stopEditorGps() {
    if (editorGpsStatus != null && editorGpsStatus.isLogging()) {
      try {
        editorGpsStatus.stop(() -> {});
      } catch (Exception ignored) {
      }
    }
  }

  private void updateEditorGpsHeader() {
    if (editorGpsDot == null || editorGpsLevel == null || editorGpsBars == null) {
      return;
    }
    int color = 0xFFF44336;
    String label = "Ruim";
    boolean enabled = editorGpsStatus != null && editorGpsStatus.isEnabled();
    boolean fixed = editorGpsStatus != null && editorGpsStatus.isFixed();
    int sats = editorGpsStatus == null ? 0 : editorGpsStatus.getSatellitesFixed();
    float accuracy = -1f;
    if (enabled && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
        == PackageManager.PERMISSION_GRANTED) {
      try {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Location last = lm == null ? null : lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (last != null) accuracy = last.getAccuracy();
      } catch (Exception ignored) {
      }
    }
    if (fixed && accuracy > 0 && accuracy <= 7f && sats > 7) {
      label = "Excelente";
      color = 0xFF00E676;
    } else if (fixed && accuracy > 0 && accuracy <= 15f && sats > 4) {
      label = "Bom";
      color = 0xFFFFB300;
    }
    editorGpsLevel.setText(label);
    editorGpsLevel.setTextColor(color);
    editorGpsDot.setTextColor(color);
    for (int i = 0; i < editorGpsBars.getChildCount(); i++) {
      View bar = editorGpsBars.getChildAt(i);
      android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
      bg.setColor(color);
      bg.setCornerRadius(2f);
      bar.setBackground(bg);
    }
  }

  private void persistCurrentWorkoutName() {
    if (advancedWorkoutSpinner == null) {
      return;
    }
    try {
      String curName = advancedWorkoutSpinner.getValue().toString();
      SharedPreferences prefs =
          PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
      prefs.edit().putString(getString(R.string.pref_advanced_workout), curName).apply();
    } catch (Exception ignored) {
      // If the spinner value can't be read, fall back to the default back behaviour.
    }
  }

  private void createAdvancedWorkout(String name, boolean workoutEditMode)
      throws JSONException, IOException {
    if (workoutEditMode) {
      advancedWorkout = WorkoutSerializer.readFile(getApplicationContext(), name);
    } else {
      advancedWorkout = new Workout();
      WorkoutSerializer.writeFile(getApplicationContext(), name, advancedWorkout);
    }
    advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
    advancedWorkoutStepsAdapter.notifyDataSetChanged();
  }

  final class WorkoutStepsAdapter extends BaseAdapter {

    List<Workout.StepListEntry> steps = new ArrayList<>();

    @Override
    public int getCount() {
      return steps.size();
    }

    @Override
    public Object getItem(int position) {
      return steps.get(position);
    }

    @Override
    public long getItemId(int position) {
      return 0;
    }

    private class ViewHolderWorkoutStepsAdapter {
      private TextView number;
      private StepButton button;
      private Button add;
      private Button del;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      View view = convertView;
      ViewHolderWorkoutStepsAdapter viewHolder;

      if (view == null) {
        viewHolder = new ViewHolderWorkoutStepsAdapter();

        LayoutInflater inflater = getLayoutInflater();
        view = inflater.inflate(R.layout.advanced_workout_row, parent, false);

        viewHolder.number = view.findViewById(R.id.step_number);
        viewHolder.button = view.findViewById(R.id.workout_step_button);
        viewHolder.button.setOnChangedListener(onWorkoutChanged);

        viewHolder.add = view.findViewById(R.id.add_button);
        viewHolder.add.setOnClickListener(onAddButtonClick);

        viewHolder.del = view.findViewById(R.id.del_button);
        viewHolder.del.setOnClickListener(onDeleteButtonClick);

        view.setTag(viewHolder);
      } else {
        viewHolder = (ViewHolderWorkoutStepsAdapter) view.getTag();
      }

      Workout.StepListEntry entry = steps.get(position);
      viewHolder.number.setText(String.valueOf(position + 1));
      viewHolder.button.setStep(entry.step());
      float pxToDp = getResources().getDisplayMetrics().density;
      viewHolder.button.setPadding((int) (entry.level() * 8 * pxToDp + 0.5f), 0, 0, 0);

      return view;
    }
  }

  private final View.OnClickListener onAddButtonClick =
      view -> {
        // The + button is inside the trailing action container, so its direct parent
        // is NOT the row. Walk up to the actual row before looking up the StepButton.
        View row = (View) view.getParent();
        if (row != null) row = (View) row.getParent();
        final StepButton stepButton = row == null ? null : row.findViewById(R.id.workout_step_button);

        if (stepButton == null || stepButton.getStep() == null || advancedWorkout == null) {
          return;
        }

        Step currentStep = stepButton.getStep();
        if (currentStep instanceof RepeatStep rs) {
          rs.getSteps().add(new Step());
        } else {

          int index = advancedWorkout.getSteps().indexOf(currentStep);
          if (index >= 0) {
            advancedWorkout.getSteps().add(index + 1, new Step());
          } else {
            // The displayed list is flattened, so the selected step may belong
            // to a RepeatStep. Insert only in the RepeatStep that actually owns it.
            boolean inserted = false;
            for (Step se : advancedWorkout.getSteps()) {
              if (se instanceof RepeatStep rs) {
                int nestedIndex = rs.getSteps().indexOf(currentStep);
                if (nestedIndex >= 0) {
                  rs.getSteps().add(nestedIndex + 1, new Step());
                  inserted = true;
                  break;
                }
              }
            }
            if (!inserted) {
              return;
            }
          }
        }
        advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
        advancedWorkoutStepsAdapter.notifyDataSetChanged();
      };

  private final View.OnClickListener onDeleteButtonClick =
      new View.OnClickListener() {

        @Override
        public void onClick(View view) {
          // The × button is inside the trailing action container; its direct parent
          // is one level below the ListView row.
          View row = (View) view.getParent();
          if (row != null) row = (View) row.getParent();
          final StepButton stepButton = row == null ? null : row.findViewById(R.id.workout_step_button);

          if (stepButton == null || stepButton.getStep() == null || advancedWorkout == null) {
            return;
          }

          if (!dontAskAgain) {
            new AlertDialog.Builder(CreateAdvancedWorkout.this)
                .setMultiChoiceItems(
                    new String[] {"Don't ask again"},
                    new boolean[] {dontAskAgain},
                    (dialog, indexSelected, isChecked) -> dontAskAgain = isChecked)
                .setTitle(org.runnerup.common.R.string.Are_you_sure)
                .setPositiveButton(
                    org.runnerup.common.R.string.Yes,
                    (dialog, which) -> {
                      dialog.dismiss();
                      deleteStep(stepButton);
                    })
                .setNegativeButton(
                    org.runnerup.common.R.string.No, (dialog, which) -> dialog.dismiss())
                .show();
          } else {
            deleteStep(stepButton);
          }
        }

        private void deleteStep(StepButton button) {
          Step s = button.getStep();
          for (Step se : advancedWorkout.getSteps()) {
            if (se instanceof RepeatStep) {
              for (Step subStep : ((RepeatStep) se).getSteps()) {
                if (subStep.equals(s)) {
                  ((RepeatStep) se).getSteps().remove(s);
                  break;
                }
              }
            }
            if (se.equals(s)) {
              advancedWorkout.getSteps().remove(se);
              break;
            }
          }

          advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
          advancedWorkoutStepsAdapter.notifyDataSetChanged();
        }
      };

  private final Runnable onWorkoutChanged =
      () -> {
        String advWorkoutName = advancedWorkoutSpinner.getValue().toString();
        if (advancedWorkout != null) {
          Context ctx = getApplicationContext();
          try {
            WorkoutSerializer.writeFile(ctx, advWorkoutName, advancedWorkout);
          } catch (Exception ex) {
            new AlertDialog.Builder(CreateAdvancedWorkout.this)
                .setTitle(org.runnerup.common.R.string.Failed_to_load_workout)
                .setMessage("" + ex)
                .setPositiveButton(
                    org.runnerup.common.R.string.OK, (dialog, which) -> dialog.dismiss())
                .show();
          }
        }
      };

  private final View.OnClickListener addStepButtonClick =
      v -> {
        advancedWorkout.addStep(new Step());
        advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
        advancedWorkoutStepsAdapter.notifyDataSetChanged();
      };

  private final View.OnClickListener addRepeatStepButtonClick =
      view -> {
        advancedWorkout.addStep(new RepeatStep());
        advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
        advancedWorkoutStepsAdapter.notifyDataSetChanged();
      };

  private final View.OnClickListener saveWorkoutButtonClick =
      v -> {
        try {
          String advWorkoutName = advancedWorkoutSpinner.getValue().toString();
          WorkoutSerializer.writeFile(getApplicationContext(), advWorkoutName, advancedWorkout);
          // Keep StartFragment's structured preview linked to the workout that was
          // actually edited/saved. Returning to Treino Estruturado must render this
          // exact serialized workout, not a stale/default selection.
          PreferenceManager.getDefaultSharedPreferences(getApplicationContext())
              .edit()
              .putString(getString(R.string.pref_advanced_workout), advWorkoutName)
              .apply();
          Intent result = new Intent();
          result.putExtra(ManageWorkoutsActivity.WORKOUT_NAME, advWorkoutName);
          setResult(RESULT_OK, result);
          finish();
        } catch (Exception e) {
          handleWorkoutFileException(e);
        }
      };

  private void handleWorkoutFileException(Exception e) {
    new AlertDialog.Builder(CreateAdvancedWorkout.this)
        .setTitle(getString(org.runnerup.common.R.string.Failed_to_create_workout))
        .setMessage(e.toString())
        .setPositiveButton(org.runnerup.common.R.string.OK, (dialog, which) -> dialog.dismiss())
        .show();
  }

  private final View.OnClickListener discardWorkoutButtonClick =
      view ->
          new AlertDialog.Builder(CreateAdvancedWorkout.this)
              .setTitle(org.runnerup.common.R.string.Delete_workout)
              .setMessage(org.runnerup.common.R.string.Are_you_sure)
              .setPositiveButton(
                  org.runnerup.common.R.string.Yes,
                  (dialog, which) -> {
                    dialog.dismiss();
                    String name = advancedWorkoutSpinner.getValue().toString();
                    File f = WorkoutSerializer.getFile(getApplicationContext(), name);
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                    finish();
                  })
              .setNegativeButton(
                  org.runnerup.common.R.string.No, (dialog, which) -> dialog.dismiss())
              .show();

  private final View.OnClickListener renameWorkoutButtonClick =
      view -> {
        final EditText newWorkoutNameEditText = new EditText(CreateAdvancedWorkout.this);
        newWorkoutNameEditText.setHint(org.runnerup.common.R.string.Enter_new_workout_name);
        newWorkoutNameEditText.setInputType(InputType.TYPE_CLASS_TEXT);
        newWorkoutNameEditText.setSingleLine(true);
        newWorkoutNameEditText.setMaxLines(1);
        newWorkoutNameEditText.setText(advancedWorkoutSpinner.getValue().toString());

        new AlertDialog.Builder(CreateAdvancedWorkout.this)
            .setView(newWorkoutNameEditText)
            .setPositiveButton(
                org.runnerup.common.R.string.OK,
                (dialog, which) -> {
                  String newWorkoutName = newWorkoutNameEditText.getText().toString().trim();
                  String oldWorkoutName = advancedWorkoutSpinner.getValue().toString().trim();
                  if (newWorkoutName.isEmpty()
                      || newWorkoutName.contains("/")
                      || newWorkoutName.contains("\\")
                      || newWorkoutName.contains("..")) {
                    Toast.makeText(
                            CreateAdvancedWorkout.this,
                            org.runnerup.common.R.string.Invalid_workout_name,
                            Toast.LENGTH_SHORT)
                        .show();
                    return;
                  }
                  if (newWorkoutName.equals(oldWorkoutName)) {
                    Toast.makeText(
                            CreateAdvancedWorkout.this,
                            org.runnerup.common.R.string
                                .New_workout_name_is_the_same_as_the_old_one,
                            Toast.LENGTH_SHORT)
                        .show();
                    return;
                  }
                  File f = WorkoutSerializer.getFile(getApplicationContext(), newWorkoutName);
                  if (f.exists()) {
                    Toast.makeText(
                            CreateAdvancedWorkout.this,
                            org.runnerup.common.R.string.Workout_name_already_in_use,
                            Toast.LENGTH_SHORT)
                        .show();
                    return;
                  }
                  try {
                    WorkoutSerializer.writeFile(
                        getApplicationContext(), newWorkoutName, advancedWorkout);
                    File oldFile =
                        WorkoutSerializer.getFile(getApplicationContext(), oldWorkoutName);
                    if (!oldFile.delete())
                      throw new IOException("Failed to delete old workout file");
                    SharedPreferences prefs =
                        PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    String key = getString(R.string.pref_advanced_workout);
                    if (oldWorkoutName.contentEquals(prefs.getString(key, ""))) {
                      prefs.edit().putString(key, newWorkoutName).apply();
                    }
                    advancedWorkoutSpinner.setValue(newWorkoutName);
                    dialog.dismiss();
                    finish();
                  } catch (Exception e) {
                    handleWorkoutFileException(e);
                  }
                })
            .setNegativeButton(
                org.runnerup.common.R.string.Cancel, (dialog, which) -> dialog.dismiss())
            .show();
      };
}
