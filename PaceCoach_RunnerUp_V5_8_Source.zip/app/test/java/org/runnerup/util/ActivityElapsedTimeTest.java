package org.runnerup.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ActivityElapsedTimeTest {
  @Test
  public void prefersTrackerActiveTimeOverWallClockGap() {
    assertEquals(1500L,
        ActivityElapsedTime.segmentDurationMillis(2500L, 1000L, 900000L, 1000L));
  }

  @Test
  public void fallsBackToWallClockForGpxAndLegacyPoints() {
    assertEquals(60000L,
        ActivityElapsedTime.segmentDurationMillis(-1L, -1L, 61000L, 1000L));
  }

  @Test
  public void fallsBackWhenElapsedClockMovesBackwards() {
    assertEquals(5000L,
        ActivityElapsedTime.segmentDurationMillis(900L, 1200L, 6000L, 1000L));
  }
}
