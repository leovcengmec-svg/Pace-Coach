package com.pacecoach.v1.run

import android.location.Location

/**
 * Pace calculator with GPS quality checks and a rolling time window.
 * Returns cumulative distance from addLocation() and exposes the smoothed pace.
 */
class PaceCalculator(
    private val windowSeconds: Long = 20L
) {
    data class Sample(val timestampMs: Long, val cumulativeDistanceM: Double)

    private val samples = ArrayDeque<Sample>()
    private var totalDistanceM = 0.0
    private var lastLocation: Location? = null

    fun reset() {
        samples.clear()
        totalDistanceM = 0.0
        lastLocation = null
    }

    /** Adds a GPS sample and returns cumulative distance in meters. */
    fun addLocation(location: Location): Double {
        val accuracy = location.accuracy
        if (accuracy.isNaN() || accuracy > 30f) return totalDistanceM

        val previous = lastLocation
        if (previous != null) {
            val dtMs = (location.time - previous.time).coerceAtLeast(1L)
            val d = previous.distanceTo(location)

            // Ignore tiny GPS noise.
            if (d < 2f) {
                lastLocation = location
                return totalDistanceM
            }

            // Reject implausible movement for a running watch interval.
            val speedMps = d / (dtMs / 1000f)
            if (d > 60f || speedMps > 12f) return totalDistanceM

            totalDistanceM += d.toDouble()
        }

        lastLocation = location

        val now = location.time
        samples.addLast(Sample(now, totalDistanceM))

        val cutoff = now - windowSeconds * 1000L
        while (samples.size > 2 && samples.first().timestampMs < cutoff) {
            samples.removeFirst()
        }

        return totalDistanceM
    }

    fun distanceMeters(): Double = totalDistanceM

    /** Smoothed pace in seconds per kilometer. */
    fun currentPaceSecondsPerKm(): Double? {
        if (samples.size < 2) return null

        val first = samples.first()
        val last = samples.last()
        val distance = last.cumulativeDistanceM - first.cumulativeDistanceM
        val elapsedS = (last.timestampMs - first.timestampMs) / 1000.0

        if (distance < 10.0 || elapsedS < 3.0) return null

        val pace = elapsedS / distance * 1000.0

        // Running pace sanity bounds: 2:30/km to 15:00/km.
        if (pace < 150.0 || pace > 900.0) return null

        return pace
    }
}
