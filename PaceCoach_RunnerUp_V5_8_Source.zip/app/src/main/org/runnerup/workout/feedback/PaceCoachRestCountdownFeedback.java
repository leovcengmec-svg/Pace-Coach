package org.runnerup.workout.feedback;

import android.content.Context;
import java.util.HashMap;
import org.runnerup.workout.Feedback;
import org.runnerup.workout.Step;
import org.runnerup.workout.Workout;

/** Spoken countdown for Descanso Off, based on its independent wall-clock timer. */
public class PaceCoachRestCountdownFeedback extends Feedback {
  private RUTextToSpeech textToSpeech;

  @Override public void onBind(Workout w, HashMap<String, Object> bindValues) {
    super.onBind(w, bindValues);
    if (bindValues.containsKey(Workout.KEY_TTS)) {
      textToSpeech = (RUTextToSpeech) bindValues.get(Workout.KEY_TTS);
    }
  }

  @Override public boolean equals(Feedback other) {
    return other instanceof PaceCoachRestCountdownFeedback;
  }

  @Override public void emit(Workout w, Context ctx) {
    if (textToSpeech == null) return;
    Step step = w.getCurrentStep();
    if (step == null) return;
    long seconds = Math.max(0L, Math.round(step.getPaceCoachOffRestRemainingSeconds()));
    if (seconds >= 60 && seconds % 60 == 0) {
      long minutes = seconds / 60;
      textToSpeech.speak(minutes + (minutes == 1 ? " minuto" : " minutos"),
          UtterancePrio.PRIO_COUNTDOWN, true, null);
    } else {
      textToSpeech.speak(seconds + " segundos", UtterancePrio.PRIO_COUNTDOWN, true, null);
    }
  }
}
