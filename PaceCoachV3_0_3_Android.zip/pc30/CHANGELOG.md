
## V1.4
- Coach de alvo: visualização do alvo e da margem.
- Mantida a lógica de voz curta e controle de Audio Focus.

## V1.5
- Política de anúncios inteligentes.
- Controle de repetição por estado e variação de pace.
- Controle de intervalo mínimo entre falas.

## V1.6
- Reescrito o núcleo do cálculo de pace com validações GPS.
- Rejeição de ruído, saltos e velocidades implausíveis.
- Janela móvel de 20 s preservada.
- Adicionada classificação de qualidade GPS.

## V1.7
- Formatter centralizado para mensagens do coach.
- Máquina de estados inicial do coach.
- Mensagens de voz padronizadas e curtas.

## V1.8
- Modelo de treino estruturado.
- Motor de progressão por tempo/distância.
- Repetições de blocos.
- Mensagens de transição por voz.
- Preparação para condução automática da sessão.

## V1.9
- Criador básico de treino estruturado.
- Builder com validação de etapas.
- Repositório em memória.
- Exemplo de 4 x 1 km.
- Resumo visual do treino.

## V2.0
- Executor inicial de treino estruturado.
- Estado da etapa ativa.
- Comandos de execução.
- Controles de início e status na interface.

## V2.1
- Ponte CoachRuntime entre treino, pace e GPS.
- Estados de orientação em tempo real.
- Teste unitário determinístico dos estados.

## V2.2
- CoachController centralizado.
- Decisões de voz baseadas em etapa, estado e GPS.
- Evita repetição de orientação.
- Testes do controlador.

## V2.3
- RunCoachIntegration para unir GPS, pace, treino e decisão do coach.
- Teste do fluxo de pace ao alvo.

## V2.4
- Adapter para integração do coach com RunService.
- Eventos de coach definidos.
- Teste do adapter com atualização de pace.

## V2.8
- Editor de treino estruturado na interface.
- Persistência em memória do treino selecionado.
- RunService usa o treino configurado.
- Atualização de etapa na interface.
- Correção de CoachEvent/adapter.
- Testes adicionais.

## V2.9
- Robust structured workout execution in RunService.
- Time/distance transitions no longer depend on a valid instantaneous pace.
- Free run and structured run coach paths separated.
- Active step target used for structured pace announcements.
- Added tests for time and distance step boundaries.
