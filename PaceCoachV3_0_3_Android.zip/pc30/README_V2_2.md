# Pace Coach V2.2 — Decisão em tempo real

A V2.2 cria o CoachController, responsável por ligar:
- etapa ativa;
- pace atual;
- qualidade GPS;
- estado do coach;
- mensagem de orientação.

O controlador evita repetir a mesma orientação e prioriza:
1. mudança de etapa;
2. GPS incerto;
3. mudança relevante do estado em relação ao alvo.

Também foram adicionados testes determinísticos do controlador.

Próxima etapa: integrar o controlador diretamente ao RunService para usar
dados reais do PaceCalculator e emitir as mensagens pelo VoiceCoach.
