package com.pacecoach.v1.run

/**
 * Connects live GPS pace information to the structured workout coach.
 * The host service supplies location time/distance and current GPS accuracy.
 */
class RunCoachIntegration(
    private val coachController: CoachController = CoachController()
) {
    private var executor: WorkoutExecutor? = null
    private var activeWorkout: StructuredWorkout? = null

    fun startWorkout(workout: StructuredWorkout, nowMs: Long, distanceM: Float) {
        activeWorkout = workout
        executor = WorkoutExecutor(WorkoutEngine(workout))
        executor?.start(nowMs, distanceM)
        coachController.reset()
    }

    fun update(
        nowMs: Long,
        distanceM: Float,
        paceSeconds: Int?,
        gpsAccuracyMeters: Float,
        targetMarginSeconds: Int
    ): CoachController.Decision {
        val exec = executor ?: return CoachController.Decision(
            CoachRuntimeState(null, paceSeconds, null, CoachState.FINISHED),
            null
        )

        val snapshot = exec.update(nowMs, distanceM)
        val quality = GpsQuality.fromAccuracy(gpsAccuracyMeters)

        val decision = coachController.evaluate(
            snapshot.activeStep,
            paceSeconds,
            quality,
            targetMarginSeconds
        )

        if (snapshot.finished) {
            executor = null
            activeWorkout = null
            return decision.copy(
                state = decision.state.copy(state = CoachState.FINISHED),
                message = WorkoutVoice.finish()
            )
        }
        return decision
    }

    fun currentStep(): ActiveStep? = executor?.currentStep()

    fun isRunning(): Boolean = executor != null && !executor!!.isFinished()

    fun clear() {
        executor = null
        activeWorkout = null
        coachController.reset()
    }
}
