/*
 * Copyright (C) 2012 - 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.tracker;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.preference.PreferenceManager;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.runnerup.BuildConfig;
import org.runnerup.R;
import org.runnerup.common.tracker.TrackerState;
import org.runnerup.common.util.Constants;
import org.runnerup.common.util.ValueModel;
import org.runnerup.db.DBHelper;
import org.runnerup.export.SyncManager;
import org.runnerup.hr.HRProvider;
import org.runnerup.notification.ForegroundNotificationDisplayStrategy;
import org.runnerup.notification.NotificationState;
import org.runnerup.notification.NotificationStateManager;
import org.runnerup.notification.OngoingState;
import org.runnerup.tracker.component.TrackerCadence;
import org.runnerup.tracker.component.TrackerComponent;
import org.runnerup.tracker.component.TrackerComponentCollection;
import org.runnerup.tracker.component.TrackerElevation;
import org.runnerup.tracker.component.TrackerGPS;
import org.runnerup.tracker.component.TrackerHRM;
import org.runnerup.tracker.component.TrackerPressure;
import org.runnerup.tracker.component.TrackerReceiver;
import org.runnerup.tracker.component.TrackerTTS;
import org.runnerup.tracker.component.TrackerTemperature;
import org.runnerup.tracker.component.TrackerWear;
import org.runnerup.tracker.filter.PersistentGpsLoggerListener;
import org.runnerup.util.Formatter;
import org.runnerup.util.HRZones;
import org.runnerup.workout.Dimension;
import org.runnerup.workout.Intensity;
import org.runnerup.workout.Scope;
import org.runnerup.workout.WorkoutInfo;
import org.runnerup.workout.Workout;

/**
 * GpsTracker - this class tracks Location updates
 *
 * <p>TODO: rename this class into ActivityTracker and factor out Gps stuff into own class that
 * should be handled much like hrm (e.g as a sensor among others)
 *
 * @author jonas.oreland@gmail.com
 */
public class Tracker extends android.app.Service implements LocationListener, Constants {
  private static volatile Tracker serviceInstance;
  // Max age for current data to be considered valid
  private static final int MAX_CURRENT_AGE = 15000;
  // A GPS fix can have excellent signal strength while still having poor
  // positional accuracy. Do not let low-quality fixes contaminate Ritmo Atual.
  // Activity distance keeps its broader acceptance rule; live pace uses this
  // stricter accuracy gate so GPS jitter cannot look like running speed.
  private static final float MAX_LIVE_PACE_ACCURACY_METERS = 15.0f;
  private static final long NANO_IN_MILLI = 1000000;

  private final Handler handler = new Handler(Looper.getMainLooper());
  private final ThreadPoolExecutor observerExecutor =
      new ThreadPoolExecutor(
          1,
          1,
          0L,
          TimeUnit.MILLISECONDS,
          new ArrayBlockingQueue<>(128),
          runnable -> {
            Thread thread = new Thread(runnable, "RunnerUp-OptionalObservers");
            thread.setDaemon(true);
            return thread;
          },
          new ThreadPoolExecutor.AbortPolicy());
  private volatile long lastObserverGpsDispatchElapsedRealtimeMs;
  private volatile long lastNotificationDispatchElapsedRealtimeMs;
  private volatile NotificationState pendingNotificationState;
  private final Runnable notificationUpdateRunnable = this::runNotificationUpdate;
  // Location callbacks are serialized away from the main/UI thread. The same Looper is
  // shared by TrackerGPS and GpsStatus to preserve ordering between satellite and fix events.
  private HandlerThread locationThread;
  private Handler locationHandler;

  private final TrackerComponentCollection components = new TrackerComponentCollection();
  // Some trackers may select separate sensors depending on sport, handled in onBind()
  private final TrackerGPS trackerGPS = (TrackerGPS) components.addComponent(new TrackerGPS(this));
  private final TrackerHRM trackerHRM = (TrackerHRM) components.addComponent(new TrackerHRM());
  TrackerTTS trackerTTS = (TrackerTTS) components.addComponent(new TrackerTTS());
  private final TrackerCadence trackerCadence =
      (TrackerCadence) components.addComponent(new TrackerCadence());
  private final TrackerTemperature trackerTemperature =
      (TrackerTemperature) components.addComponent(new TrackerTemperature());
  private final TrackerPressure trackerPressure =
      (TrackerPressure) components.addComponent(new TrackerPressure());
  private final TrackerElevation trackerElevation =
      (TrackerElevation)
          components.addComponent(new TrackerElevation(this, trackerGPS, trackerPressure));
  TrackerReceiver trackerReceiver =
      (TrackerReceiver) components.addComponent(new TrackerReceiver(this));
  private final TrackerWear trackerWear =
      (TrackerWear) components.addComponent(new TrackerWear(this));

  private boolean mTimeFromGpsPoints = false;
  private boolean mCurrentSpeedFromGpsPoints = false;

  private long mLapId = 0;
  private long mActivityId = 0;
  // Accumulated active workout time. It is intentionally independent of GPS
  // callbacks so a GPS dropout cannot freeze the workout clock.
  private long mElapsedTimeNanos = 0;
  private long mActiveTimeStartNanos = 0;
  private double mElapsedDistance = 0;
  private double mHeartbeats = 0;
  private double mHeartbeatNanos = 0; // since we might loose HRM connectivity...
  private long mMaxHR = 0;
  private double mCurrentSpeed = 0.0;
  // Reference point used exclusively for the point-to-point live pace calculation.
  // This is intentionally separate from mLastLocation because mLastLocation may
  // advance for GPS fixes that are rejected for distance/accuracy purposes.
  private Location mLastPaceLocation = null;
  // Accepted GPS samples used to calculate the live pace over the user-selected
  // announcement period. This is deliberately separate from activity-average pace.
  private final Deque<Location> mPaceSamples = new ArrayDeque<>();

  private TrackerState nextState;
  private final ValueModel<TrackerState> state = new ValueModel<>(TrackerState.INIT);
  private int mLocationType = DB.LOCATION.TYPE_START;

  // Last location given by LocationManager
  private Location mLastLocation = null;
  // Last location given by LocationManager when in state STARTED
  private Location mLastLocationStarted = null;

  private SQLiteDatabase mDB = null;
  private volatile boolean databaseMaintenanceInProgress;
  private PersistentGpsLoggerListener mDBWriter = null;
  private PowerManager.WakeLock mWakeLock = null;
  private final List<WorkoutObserver> liveLoggers = new ArrayList<>();
  private final CopyOnWriteArrayList<org.runnerup.util.TickListener> gpsStatusListeners =
      new CopyOnWriteArrayList<>();
  private volatile long lastGpsStatusUiDispatchElapsedRealtimeMs;

  private Workout workout = null;
  private NotificationStateManager notificationStateManager;
  private volatile NotificationState activityOngoingState;

  @Override
  public void onCreate() {
    super.onCreate();
    serviceInstance = this;
    locationThread = new HandlerThread("RunnerUp-LocationEvents");
    locationThread.start();
    locationHandler = new Handler(locationThread.getLooper());

    mDB = DBHelper.getWritableDatabase(this);
    notificationStateManager =
        new NotificationStateManager(new ForegroundNotificationDisplayStrategy(this));

    wakeLock(false);
  }

  /** Handler used by LocationManager so all GPS callbacks are serialized off the UI thread. */
  public Handler getLocationHandler() {
    return locationHandler;
  }

  /** Looper used by sensor/status callbacks that must share the GPS event queue. */
  public Looper getLocationLooper() {
    Handler current = locationHandler;
    return current == null ? Looper.getMainLooper() : current.getLooper();
  }

  @Override
  public int onStartCommand(Intent intent, int flags, int startId) {
    // We want this service to continue running until it is explicitly
    // stopped, so return sticky.
    return START_STICKY;
  }

  @Override
  public void onDestroy() {
    // Release the provider before stopping the callback Looper. LocationManager may still have
    // callbacks queued; removing the listener prevents new work from entering the queue.
    trackerGPS.shutdown();
    synchronized (this) {
      state.set(TrackerState.CLEANUP);
      closeLocationWriter();
    }
    gpsStatusListeners.clear();
    handler.removeCallbacks(notificationUpdateRunnable);
    pendingNotificationState = null;
    observerExecutor.shutdown();
    try {
      if (!observerExecutor.awaitTermination(1000L, TimeUnit.MILLISECONDS)) {
        Log.w("Tracker", "Optional observer executor did not stop before service destruction");
      }
    } catch (InterruptedException ex) {
      Thread.currentThread().interrupt();
      Log.w("Tracker", "Interrupted while stopping optional observers", ex);
    }
    wakeLock(false);

    HandlerThread thread = locationThread;
    locationHandler = null;
    locationThread = null;
    if (thread != null) {
      thread.quitSafely();
      try {
        thread.join(2000L);
      } catch (InterruptedException ex) {
        Thread.currentThread().interrupt();
        Log.w("Tracker", "Interrupted while stopping location callback thread", ex);
      }
    }

    if (mDB != null) {
      DBHelper.closeDB(mDB);
      mDB = null;
    }
    if (serviceInstance == this) {
      serviceInstance = null;
    }
    super.onDestroy();
  }

  private synchronized boolean closeLocationWriter() {
    PersistentGpsLoggerListener writer = mDBWriter;
    if (writer == null) return true;
    boolean stopped = writer.closeAndWait();
    if (stopped && mDBWriter == writer) {
      mDBWriter = null;
    }
    return stopped;
  }

  private synchronized void flushLocationWriter(String operation) {
    PersistentGpsLoggerListener writer = mDBWriter;
    if (writer != null && !writer.flush()) {
      Log.e("Tracker", "GPS sample queue did not flush before " + operation);
    }
  }

  public void setup() {
    switch (state.get()) {
      case INIT:
        break;
      case INITIALIZING:
      case INITIALIZED:
        return;
      case CONNECTING:
      case CONNECTED:
      case STARTED:
      case PAUSED:
      case ERROR:
      case STOPPED:
        if (BuildConfig.DEBUG) {
          throw new AssertionError();
        }
        return;
      case CLEANUP:
        // if CLEANUP is in progress, setup will continue once complete
        nextState = TrackerState.INITIALIZING;
        return;
    }

    state.set(TrackerState.INITIALIZING);

    TrackerComponent.ResultCode result = components.onInit(onInitCallback, getApplicationContext());
    if (result != TrackerComponent.ResultCode.RESULT_PENDING) {
      onInitCallback.run(components, result);
    }
  }

  public void setWithoutGps(boolean val) {
    trackerGPS.setWithoutGps(val);
  }

  private final TrackerComponent.Callback onInitCallback =
      new TrackerComponent.Callback() {
        @Override
        public void run(TrackerComponent component, TrackerComponent.ResultCode resultCode) {
          if (resultCode == TrackerComponent.ResultCode.RESULT_ERROR_FATAL) {
            state.set(TrackerState.ERROR);
          } else {
            state.set(TrackerState.INITIALIZED);
          }

          Log.d(getClass().getName(), "state.set(" + getState() + ")");
          handleNextState();
        }
      };

  private void handleNextState() {
    if (nextState == null) return;

    // if last phase ended in error,
    // don't continue with a new
    if (state.get() == TrackerState.ERROR) return;

    if (state.get() == nextState) {
      nextState = null;
      return;
    }

    switch (nextState) {
      case INIT:
        reset();
        break;
      case INITIALIZING:
        break;
      case INITIALIZED:
        setup();
        break;
      case CONNECTING:
        break;
      case CONNECTED:
        connect();
        break;
      case STARTED:
        break;
      case PAUSED:
        break;
      case STOPPED:
        break;
      case CLEANUP:
        break;
      case ERROR:
        break;
    }
  }

  public void connect() {
    Log.d(getClass().getName(), "Tracker.connect() - state: " + state.get());
    switch (state.get()) {
      case INIT:
        setup();
      case INITIALIZING:
      case CLEANUP:
        nextState = TrackerState.CONNECTED;
        Log.d(getClass().getName(), " => nextState: " + nextState);
        return;
      case INITIALIZED:
        break;
      case CONNECTING:
      case CONNECTED:
        return;
      case ERROR:
        // A previous connection attempt may have failed because GPS was disabled or a
        // permission was revoked. Re-run component cleanup, then honor the new connect request.
        reset();
        if (state.get() == TrackerState.INIT) {
          connect();
        } else if (state.get() == TrackerState.CLEANUP) {
          nextState = TrackerState.CONNECTED;
        } else {
          Log.e("Tracker", "Unable to recover from connection error; state=" + state.get());
        }
        return;
      case STARTED:
      case PAUSED:
      case STOPPED:
        if (BuildConfig.DEBUG) {
          throw new AssertionError();
        }
        return;
    }

    state.set(TrackerState.CONNECTING);

    wakeLock(true);

    SyncManager u = new SyncManager(getApplicationContext());
    u.loadLiveLoggers(liveLoggers);
    u.close();

    TrackerComponent.ResultCode result =
        components.onConnecting(onConnectCallback, getApplicationContext());
    if (result != TrackerComponent.ResultCode.RESULT_PENDING) {
      onConnectCallback.run(components, result);
    }
  }

  private final TrackerComponent.Callback onConnectCallback =
      (component, resultCode) -> {
        // A delayed sensor/GPS callback must not move a tracker that has already been reset or
        // stopped into ERROR/CONNECTED. Only the outstanding CONNECTING transition may consume
        // this result.
        if (state.get() != TrackerState.CONNECTING) {
          Log.w("Tracker", "Ignoring stale connection callback in state " + state.get());
          return;
        }
        if (resultCode == TrackerComponent.ResultCode.RESULT_ERROR_FATAL) {
          state.set(TrackerState.ERROR);
          wakeLock(false);
        } else {
          state.set(TrackerState.CONNECTED);
          /* now we're connected */
          components.onConnected();
        }
      };

  @SuppressWarnings("UnusedReturnValue")
  private long createActivity(int sport) {
    closeLocationWriter();
    Resources res = getResources();
    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
    boolean logGpxAccuracy = prefs.getBoolean(res.getString(R.string.pref_log_gpx_accuracy), false);
    mTimeFromGpsPoints = prefs.getBoolean(res.getString(R.string.pref_time_from_gps_points), false);
    mCurrentSpeedFromGpsPoints =
        prefs.getBoolean(res.getString(R.string.pref_speed_from_gps_points), false);

    // Create an Activity instance
    ContentValues tmp = new ContentValues();
    tmp.put(DB.ACTIVITY.SPORT, sport);
    try {
      mActivityId = mDB.insert(DB.ACTIVITY.TABLE, "nullColumnHack", tmp);

      tmp.clear();
      tmp.put(DB.LOCATION.ACTIVITY, mActivityId);
      tmp.put(DB.LOCATION.LAP, 0); // always start with lap 0
      mDBWriter = new PersistentGpsLoggerListener(mDB, DB.LOCATION.TABLE, tmp, logGpxAccuracy);
    } catch (IllegalStateException ex) {
      Log.i(getClass().getName(), "Query failed:", ex);
    }
    return mActivityId;
  }

  public void setWorkout(Workout workout) {
    this.workout = workout;
  }

  public synchronized void start() {
    if (databaseMaintenanceInProgress) {
      Log.w("Tracker", "Ignoring workout start while the database is being restored");
      return;
    }
    if (BuildConfig.DEBUG && state.get() != TrackerState.CONNECTED) {
      throw new AssertionError();
    }

    // connect workout and tracker
    workout.setTracker(this);

    // Add Wear to live loggers if it's active
    if (components.getResultCode(TrackerWear.NAME) == TrackerComponent.ResultCode.RESULT_OK)
      liveLoggers.add(trackerWear);

    // create the DB activity
    createActivity(workout.getSport());

    // do bindings
    doBind();

    // Let workout do initializations
    workout.onInit(workout);

    // Let components know we're starting
    components.onStart();

    mElapsedTimeNanos = 0;
    mActiveTimeStartNanos = SystemClock.elapsedRealtimeNanos();
    mElapsedDistance = 0;
    mHeartbeats = 0;
    mHeartbeatNanos = 0;
    mMaxHR = 0;
    mLastLocationStarted = null;
    // The location loaded while CONNECTING is only a last-known fix. It can
    // be tens of meters away from the first fresh GPS fix even when the user
    // never moved. Do not use that stale point as the first distance segment.
    mLastLocation = null;
    mCurrentSpeed = 0.0d;
    mLastPaceLocation = null;
    mPaceSamples.clear();

    // New location update will be tagged with START
    setNextLocationType(DB.LOCATION.TYPE_START);

    state.set(TrackerState.STARTED);

    activityOngoingState = new OngoingState(new Formatter(this), workout, this);
    lastNotificationDispatchElapsedRealtimeMs = 0L;

    // And finally let workout know that we started
    workout.onStart(Scope.ACTIVITY, this.workout);
  }

  private void doBind() {
    // Let components populate bindValues
    HashMap<String, Object> bindValues = new HashMap<>();
    Context ctx = getApplicationContext();
    bindValues.put(TrackerComponent.KEY_CONTEXT, ctx);
    bindValues.put(Workout.KEY_FORMATTER, new Formatter(ctx));
    bindValues.put(Workout.KEY_HRZONES, new HRZones(ctx));
    bindValues.put(Workout.KEY_MUTE, workout.getMute());
    bindValues.put(Workout.KEY_SPORT_TYPE, workout.getSport());
    bindValues.put(Workout.KEY_WORKOUT_TYPE, workout.getWorkoutType());

    components.onBind(bindValues);

    // and then give them to workout
    workout.onBind(workout, bindValues);
  }

  public synchronized void newLap(ContentValues tmp) {
    tmp.put(DB.LAP.ACTIVITY, mActivityId);
    mLapId = mDB.insert(DB.LAP.TABLE, null, tmp);
    ContentValues key = mDBWriter.getKey();
    key.put(DB.LOCATION.LAP, tmp.getAsLong(DB.LAP.LAP));
    mDBWriter.setKey(key);
  }

  public synchronized void saveLap(ContentValues tmp) {
    tmp.put(DB.LAP.ACTIVITY, mActivityId);
    String[] key = {Long.toString(mLapId)};
    mDB.update(DB.LAP.TABLE, tmp, "_id = ?", key);
  }

  public synchronized void pause() {
    switch (state.get()) {
      case INIT:
      case ERROR:
      case INITIALIZING:
      case INITIALIZED:
      case PAUSED:
      case CONNECTING:
      case CONNECTED:
      case CLEANUP:
      case STOPPED:
        return;
      case STARTED:
        break;
    }
    // Freeze the active timer before changing state. The clock must not depend
    // on a GPS callback arriving at the exact moment of pause.
    accumulateActiveTime();
    state.set(TrackerState.PAUSED);
    setNextLocationType(DB.LOCATION.TYPE_PAUSE);
    // This saves a PAUSE location
    internalOnLocationChanged(mLastLocationStarted);
    flushLocationWriter("pause");

    saveActivity(/* manualDistance= */ null);
    components.onPause();
  }

  /** Refresh the ongoing notification from the workout */
  public void displayNotificationState() {
    NotificationState current = activityOngoingState;
    if (current != null) {
      notificationStateManager.displayNotificationState(current);
    }
  }

  /** Throttle notification refreshes and move their work off the GPS callback Looper. */
  private void requestNotificationStateUpdate() {
    NotificationState current = activityOngoingState;
    if (current == null) return;
    long now = SystemClock.elapsedRealtime();
    if (now - lastNotificationDispatchElapsedRealtimeMs < 1000L) return;
    lastNotificationDispatchElapsedRealtimeMs = now;
    pendingNotificationState = current;
    handler.removeCallbacks(notificationUpdateRunnable);
    handler.post(notificationUpdateRunnable);
  }

  private void runNotificationUpdate() {
    NotificationState expected = pendingNotificationState;
    if (expected == null || expected != activityOngoingState) return;
    try {
      notificationStateManager.displayNotificationState(expected);
    } catch (RuntimeException ex) {
      Log.e("Tracker", "Unable to refresh ongoing notification; tracking continues", ex);
    }
  }

  public synchronized void stop() {
    switch (state.get()) {
      case INIT:
      case ERROR:
      case INITIALIZING:
      case INITIALIZED:
      case CONNECTING:
      case CONNECTED:
      case CLEANUP:
      case STOPPED:
        return;
      case PAUSED:
      case STARTED:
        break;
    }
    // Freeze the active timer before changing state.
    accumulateActiveTime();
    state.set(TrackerState.STOPPED);
    setNextLocationType(DB.LOCATION.TYPE_PAUSE);
    // This saves a PAUSE location
    internalOnLocationChanged(mLastLocationStarted);
    flushLocationWriter("stop");

    saveActivity(/* manualDistance= */ null);
    components.onPause(); // TODO add new callback for this
  }

  private void internalOnLocationChanged(Location arg0) {
    // insert location, set internal time
    if (arg0 != null) {
      onLocationChangedImpl(arg0, true);
    }
  }

  /**
   * Resume a paused/stopped workout without allowing a UI lifecycle race to
   * crash the application. This method is intentionally idempotent: if the
   * tracker is already STARTED, nothing happens. Only PAUSED/STOPPED are
   * resumable states.
   */
  public synchronized void resume() {
    TrackerState current = state.get();
    switch (current) {
      case PAUSED:
      case STOPPED:
        break;
      case STARTED:
        return;
      default:
        Log.w("Tracker", "Ignoring resume in state " + current);
        return;
    }

    state.set(TrackerState.STARTED);
    // Start a new active-time segment. Time spent paused is excluded.
    mActiveTimeStartNanos = SystemClock.elapsedRealtimeNanos();
    setNextLocationType(DB.LOCATION.TYPE_RESUME);
    // Save a resume location when one exists. A paused workout may have no
    // fresh GPS point yet; that must never prevent resuming the workout.
    internalOnLocationChanged(mLastLocation);

    try {
      components.onResume();
    } catch (Throwable ex) {
      // A sensor/TTS/Bluetooth component must never be allowed to terminate
      // the workout activity when the core Tracker can continue. Keep the
      // Tracker STARTED and report the component failure for diagnostics.
      Log.e("Tracker", "Tracker component failed while resuming workout", ex);
    }
  }

  public synchronized void reset() {
    switch (state.get()) {
      case INIT:
        return;
      case INITIALIZING:
        // cleanup when INITIALIZE is complete
        nextState = TrackerState.INIT;
        return;
      case INITIALIZED:
      case ERROR:
      case PAUSED:
      case CONNECTING:
      case CONNECTED:
      case STOPPED:
        nextState = TrackerState.INIT;
        // it's ok to "abort" connecting
        break;
      case STARTED:
        if (BuildConfig.DEBUG) {
          throw new AssertionError();
        }
        return;
      case CLEANUP:
        return;
    }

    wakeLock(false);

    if (workout != null) {
      workout.setTracker(null);
      workout = null;
    }

    state.set(TrackerState.CLEANUP);
    liveLoggers.clear();
    TrackerComponent.ResultCode res = components.onEnd(onEndCallback, getApplicationContext());
    if (res != TrackerComponent.ResultCode.RESULT_PENDING) onEndCallback.run(components, res);
  }

  private final TrackerComponent.Callback onEndCallback =
      (component, resultCode) -> {
        closeLocationWriter();
        if (resultCode == TrackerComponent.ResultCode.RESULT_ERROR_FATAL) {
          state.set(TrackerState.ERROR);
        } else {
          state.set(TrackerState.INIT);
        }

        handleNextState();
      };

  public synchronized void completeActivity(boolean save, Double manualDistance) {
    if (BuildConfig.DEBUG
        && state.get() != TrackerState.PAUSED
        && state.get() != TrackerState.STOPPED) {
      throw new AssertionError();
    }

    setNextLocationType(DB.LOCATION.TYPE_END);
    internalOnLocationChanged(mLastLocationStarted);
    flushLocationWriter("activity completion");

    if (save) {
      saveActivity(manualDistance);
      liveLog(DB.LOCATION.TYPE_END);
    } else {
      ContentValues tmp = new ContentValues();
      tmp.put("deleted", 1);
      String[] key = {Long.toString(mActivityId)};

      if (mDB == null) {
        android.util.Log.e("Tracker", "completeActivity called but mDB is null");
      } else {
        mDB.update(DB.ACTIVITY.TABLE, tmp, "_id = ?", key);
      }
      liveLog(DB.LOCATION.TYPE_DISCARD);
    }

    components.onComplete(!save);
    pendingNotificationState = null;
    activityOngoingState = null;
    handler.removeCallbacks(notificationUpdateRunnable);
    notificationStateManager.cancelNotification();
    reset();
  }

  private void saveActivity(Double manualDistance) {
    if (mDB == null) {
      android.util.Log.e("Tracker", "saveActivity called but mDB is null");
      return;
    }
    ContentValues tmp = new ContentValues();
    if (mHeartbeatNanos > 0) {
      long avgHR = Math.round(60 * mHeartbeats * 1000 * NANO_IN_MILLI / mHeartbeatNanos); // BPM
      tmp.put(Constants.DB.ACTIVITY.AVG_HR, avgHR);
    }
    if (mMaxHR > 0) tmp.put(Constants.DB.ACTIVITY.MAX_HR, mMaxHR);

    if (TrackerPressure.isAvailable(this)) {
      final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
      boolean enabled =
          prefs.getBoolean(this.getString(org.runnerup.R.string.pref_use_pressure_sensor), false);
      if (enabled) {
        // Save information about barometer usage, used in uploads (like Strava)
        tmp.put(DB.ACTIVITY.META_DATA, DB.ACTIVITY.WITH_BAROMETER);
      }
    }

    if (manualDistance != null) {
      tmp.put(Constants.DB.ACTIVITY.DISTANCE, manualDistance);
    } else {
      tmp.put(Constants.DB.ACTIVITY.DISTANCE, mElapsedDistance);
    }
    tmp.put(
        Constants.DB.ACTIVITY.TIME,
        Math.round(getTimeMs() / 1000.0d)); // time should be updated last for conditionalRecompute

    String[] key = {Long.toString(mActivityId)};
    mDB.update(DB.ACTIVITY.TABLE, tmp, "_id = ?", key);
  }

  private void setNextLocationType(int newType) {
    if (mDBWriter == null) {
      android.util.Log.w(
          "Tracker", "setNextLocationType: mDBWriter is null (newType=" + newType + ")");
      return;
    }
    ContentValues key = mDBWriter.getKey();
    key.put(DB.LOCATION.TYPE, newType);
    mDBWriter.setKey(key);
    mLocationType = newType;
  }

  // public long getTime() {
  //    return getTimeMs() / 1000;
  // }

  public synchronized long getTimeMs() {
    long totalNanos = mElapsedTimeNanos;
    if (state.get() == TrackerState.STARTED && mActiveTimeStartNanos > 0) {
      totalNanos += Math.max(0L, SystemClock.elapsedRealtimeNanos() - mActiveTimeStartNanos);
    }
    return totalNanos / NANO_IN_MILLI;
  }

  /** Accumulate the current active segment without relying on GPS updates. */
  private void accumulateActiveTime() {
    if (mActiveTimeStartNanos > 0) {
      mElapsedTimeNanos +=
          Math.max(0L, SystemClock.elapsedRealtimeNanos() - mActiveTimeStartNanos);
      mActiveTimeStartNanos = 0;
    }
  }

  public synchronized double getDistance() {
    return mElapsedDistance;
  }

  public synchronized Location getLastKnownLocation() {
    return mLastLocation == null ? null : new Location(mLastLocation);
  }

  public synchronized long getActivityId() {
    return mActivityId;
  }

  /** Read-only GPS quality monitor shared by the home and execution screens. */
  public GpsStatus getGpsStatus() {
    return trackerGPS.getGpsStatus();
  }

  public boolean isGpsProviderEnabled() {
    return trackerGPS.isGpsProviderEnabled();
  }

  public boolean isGpsConnected() {
    return trackerGPS.isConnected();
  }

  public void registerGpsStatusListener(org.runnerup.util.TickListener listener) {
    if (listener != null) gpsStatusListeners.addIfAbsent(listener);
  }

  public void unregisterGpsStatusListener(org.runnerup.util.TickListener listener) {
    if (listener != null) gpsStatusListeners.remove(listener);
  }

  /** Dispatch lightweight GPS UI refreshes on the main thread, throttled to 2 Hz. */
  public void notifyGpsStatusChanged() {
    long now = SystemClock.elapsedRealtime();
    long previous = lastGpsStatusUiDispatchElapsedRealtimeMs;
    if (now - previous < 500L) return;
    lastGpsStatusUiDispatchElapsedRealtimeMs = now;
    handler.post(
        () -> {
          for (org.runnerup.util.TickListener listener : gpsStatusListeners) {
            try {
              listener.onTick();
            } catch (RuntimeException ex) {
              Log.e("Tracker", "GPS status observer failed", ex);
            }
          }
        });
  }

  @Override
  public synchronized void onLocationChanged(@NonNull Location arg0) {
    // The quality monitor consumes the same sample as the tracker. This avoids a second
    // LocationManager subscription and keeps quality/fix calculations in the same event order.
    Location sample = new Location(arg0);
    trackerGPS.onLocationUpdate(sample);
    trackerElevation.onLocationChanged(sample);
    onLocationChangedImpl(sample, false);
  }

  private void onLocationChangedImpl(Location arg0, boolean internal) {
    if (!mTimeFromGpsPoints || internal) {
      long elapsedNs = SystemClock.elapsedRealtimeNanos();
      arg0.setElapsedRealtimeNanos(elapsedNs);
      long timeMs = System.currentTimeMillis();
      arg0.setTime(timeMs);
    }

    Integer hrValue = getCurrentHRValueElapsed(arg0.getElapsedRealtimeNanos(), MAX_CURRENT_AGE);
    Double eleValue = getCurrentElevation();
    Float cadValue = getCurrentCadence();
    Float temperatureValue = getCurrentTemperature();
    Float pressureValue = getCurrentPressure();

    if (!internal) {
      // GPS fixes are the continuous source for distance and live pace. Do not
      // advance the reference point for a rejected fix: doing so can leave the
      // activity stuck at a few meters and can also make the live pace remain
      // unavailable indefinitely.
      final float accuracy = arg0.hasAccuracy() ? arg0.getAccuracy() : 0.0f;
      if (arg0.hasAccuracy() && accuracy > 50.0f) {
        return;
      }

      if (mLastLocation != null) {
        final double distDiff = arg0.distanceTo(mLastLocation);
        final long timeDiffNanos =
            arg0.getElapsedRealtimeNanos() - mLastLocation.getElapsedRealtimeNanos();

        if (timeDiffNanos <= 0) {
          return;
        }

        // Reject only physically implausible GPS jumps. Do not use
        // Location.getSpeed() as a rejection criterion: Android providers may
        // report 0 while the runner is moving, especially just after a fix.
        final double dtSeconds = timeDiffNanos / 1_000_000_000.0d;
        final double maxPlausibleSpeed = 7.0d; // 25.2 km/h; rejects GPS jumps without constraining normal running
        final double allowedDistance =
            Math.max(5.0d, maxPlausibleSpeed * dtSeconds + Math.max(0.0d, accuracy * 0.5d));
        if (distDiff > allowedDistance) {
          return;
        }

        // Distance is accumulated from consecutive accepted GPS fixes only.
        if (state.get() == TrackerState.STARTED) {
          mElapsedDistance += Math.max(0.0d, distDiff);
          if (hrValue != null && hrValue > 0) {
            mHeartbeats +=
                (hrValue * timeDiffNanos) / (double) (60 * 1000 * NANO_IN_MILLI);
            mHeartbeatNanos += timeDiffNanos;
            mMaxHR = Math.max(hrValue, mMaxHR);
          }
        }

        // Keep GPS points as the atomic source for live pace, but use a stricter
        // positional-accuracy gate than the activity-distance tracker. A phone can
        // report a strong/"excellent" GPS signal while the coordinate itself still
        // wanders by several meters. Counting those low-quality fixes in Ritmo Atual
        // can turn walking into an artificial 6:00/km or produce huge fluctuations.
        // If accuracy is poor, keep the activity distance intact but do not advance
        // the live-pace reference until the next trustworthy fix arrives.
        final boolean livePaceFix =
            !arg0.hasAccuracy() || arg0.getAccuracy() <= MAX_LIVE_PACE_ACCURACY_METERS;
        if (livePaceFix) {
          if (mLastPaceLocation == null) {
            mPaceSamples.clear();
          }
          if (mLastPaceLocation != null) {
            long segmentNs = arg0.getElapsedRealtimeNanos() - mLastPaceLocation.getElapsedRealtimeNanos();
            double segmentMeters = arg0.distanceTo(mLastPaceLocation);
            if (segmentNs > 0 && segmentMeters > 0) {
              double segmentSpeed = segmentMeters * 1_000_000_000.0d / segmentNs;
              if (segmentSpeed > 0 && Double.isFinite(segmentSpeed)) mCurrentSpeed = segmentSpeed;
            }
          }
          mLastPaceLocation = arg0;
          mPaceSamples.addLast(new Location(arg0));
        }
        while (mPaceSamples.size() > 1) {
          Location first = mPaceSamples.peekFirst();
          Location last = mPaceSamples.peekLast();
          long ageNs = last.getElapsedRealtimeNanos() - first.getElapsedRealtimeNanos();
          // Keep enough consecutive GPS points to reconstruct any configured
          // current-pace window (time or distance). The previous implementation
          // accidentally retained only two points, so a 10-second announcement
          // could become a single noisy GPS segment instead of the full period.
          if (ageNs <= 180L * 1_000_000_000L) break;
          mPaceSamples.removeFirst();
        }
      } else {
        // First fresh GPS fix: establish the live-pace reference only when the
        // coordinate is accurate enough for a live-pace measurement. The normal
        // activity GPS state is still initialized below regardless of accuracy.
        if (!arg0.hasAccuracy() || arg0.getAccuracy() <= MAX_LIVE_PACE_ACCURACY_METERS) {
          mLastPaceLocation = arg0;
          mPaceSamples.clear();
          mPaceSamples.addLast(new Location(arg0));
        }
      }

      mLastLocation = arg0;
      if (state.get() == TrackerState.STARTED) {
        mLastLocationStarted = arg0;
      }
    } else {
      // Internal START/PAUSE/RESUME/END points are control markers and must not
      // alter the live pace reference used by the next real GPS fix.
    }

    if (internal || state.get() == TrackerState.STARTED) {
      PersistentGpsLoggerListener writer = mDBWriter;
      if (writer != null) {
        writer.onLocationChanged(
            arg0,
            eleValue,
            getTimeMs(),
            mElapsedDistance,
            hrValue,
            cadValue,
            temperatureValue,
            pressureValue);
      } else {
        Log.e("Tracker", "GPS sample was not queued because the activity writer is unavailable");
      }

      switch (mLocationType) {
        case DB.LOCATION.TYPE_START:
        case DB.LOCATION.TYPE_RESUME:
          setNextLocationType(DB.LOCATION.TYPE_GPS);
          break;
        case DB.LOCATION.TYPE_GPS:
          break;
        case DB.LOCATION.TYPE_PAUSE:
          break;
        case DB.LOCATION.TYPE_END:
          if (!internal && BuildConfig.DEBUG) {
            throw new AssertionError();
          }
          break;
      }
      liveLog(mLocationType);
      requestNotificationStateUpdate();
    }
  }

  private void liveLog(int type) {
    // Live synchronization is an optional side channel. Build an immutable snapshot and deliver
    // it on a bounded worker so starting a remote service cannot delay location processing.
    Workout currentWorkout = workout;
    List<WorkoutObserver> observers = new ArrayList<>(liveLoggers);
    if (currentWorkout == null || observers.isEmpty()) return;

    if (type == DB.LOCATION.TYPE_GPS) {
      long now = SystemClock.elapsedRealtime();
      if (now - lastObserverGpsDispatchElapsedRealtimeMs < 5000L) return;
      lastObserverGpsDispatchElapsedRealtimeMs = now;
    }

    final WorkoutInfo snapshot;
    try {
      snapshot = new WorkoutInfoSnapshot(currentWorkout);
    } catch (RuntimeException | AssertionError ex) {
      Log.e("Tracker", "Unable to snapshot optional live-sync event", ex);
      return;
    }
    for (WorkoutObserver observer : observers) {
      try {
        observerExecutor.execute(
            () -> {
              try {
                observer.workoutEvent(snapshot, type);
              } catch (RuntimeException ex) {
                Log.e("Tracker", "Live observer failed; workout tracking continues", ex);
              }
            });
      } catch (RejectedExecutionException ex) {
        // Local SQLite recording is authoritative; a busy optional remote observer must not
        // back-pressure GPS or grow an unbounded queue.
        Log.w("Tracker", "Dropping optional live-sync event because its queue is full", ex);
      }
    }
  }

  /** Immutable values for asynchronous WorkoutObserver callbacks. */
  private static final class WorkoutInfoSnapshot implements WorkoutInfo {
    private final double[][] values = new double[Scope.values().length][Dimension.values().length];
    private final double[][] durations = new double[Scope.values().length][Dimension.values().length];
    private final double[][] remaining = new double[Scope.values().length][Dimension.values().length];
    private final boolean[][] enabled = new boolean[Scope.values().length][Dimension.values().length];
    private final int sport;
    private final Intensity intensity;
    private final boolean paused;
    private final Location lastLocation;

    WorkoutInfoSnapshot(WorkoutInfo source) {
      sport = source.getSport();
      intensity = source.getIntensity();
      paused = source.isPaused();
      Location location = source.getLastKnownLocation();
      lastLocation = location == null ? null : new Location(location);
      for (Scope scope : Scope.values()) {
        for (Dimension dimension : Dimension.values()) {
          int s = scope.ordinal();
          int d = dimension.ordinal();
          try {
            values[s][d] = source.get(scope, dimension);
          } catch (RuntimeException | AssertionError ex) {
            values[s][d] = 0.0d;
          }
          try {
            durations[s][d] = source.getDuration(scope, dimension);
          } catch (RuntimeException | AssertionError ex) {
            durations[s][d] = 0.0d;
          }
          try {
            remaining[s][d] = source.getRemaining(scope, dimension);
          } catch (RuntimeException | AssertionError ex) {
            remaining[s][d] = 0.0d;
          }
          try {
            enabled[s][d] = source.isEnabled(dimension, scope);
          } catch (RuntimeException | AssertionError ex) {
            enabled[s][d] = false;
          }
        }
      }
    }

    @Override
    public double get(Scope scope, Dimension dimension) {
      return dimension == null ? 0.0d : values[scope.ordinal()][dimension.ordinal()];
    }

    @Override public double getDistance(Scope scope) { return get(scope, Dimension.DISTANCE); }
    @Override public double getTime(Scope scope) { return get(scope, Dimension.TIME); }
    @Override public double getSpeed(Scope scope) { return get(scope, Dimension.SPEED); }
    @Override public double getPace(Scope scope) { return get(scope, Dimension.PACE); }
    @Override public double getDuration(Scope scope, Dimension dimension) {
      return dimension == null ? 0.0d : durations[scope.ordinal()][dimension.ordinal()];
    }
    @Override public double getRemaining(Scope scope, Dimension dimension) {
      return dimension == null ? 0.0d : remaining[scope.ordinal()][dimension.ordinal()];
    }
    @Override public double getHeartRate(Scope scope) { return get(scope, Dimension.HR); }
    @Override public double getHeartRateZone(Scope scope) { return get(scope, Dimension.HRZ); }
    @Override public double getCadence(Scope scope) { return get(scope, Dimension.CAD); }
    @Override public double getTemperature(Scope scope) { return get(scope, Dimension.TEMPERATURE); }
    @Override public double getPressure(Scope scope) { return get(scope, Dimension.PRESSURE); }
    @Override public int getSport() { return sport; }
    @Override public Intensity getIntensity() { return intensity; }
    @Override public boolean isPaused() { return paused; }
    @Override public boolean isEnabled(Dimension dimension, Scope scope) {
      return dimension != null && enabled[scope.ordinal()][dimension.ordinal()];
    }
    @Override public Location getLastKnownLocation() {
      return lastLocation == null ? null : new Location(lastLocation);
    }
  }

  @Override
  public void onProviderDisabled(@NonNull String arg0) {}

  @Override
  public void onProviderEnabled(@NonNull String arg0) {}

  @Override
  public void onStatusChanged(String arg0, int arg1, Bundle arg2) {}

  /** Returns true while a workout is recording or paused and its database is still active. */
  public static boolean isWorkoutActive() {
    Tracker current = serviceInstance;
    if (current == null) return false;
    TrackerState currentState = current.state.get();
    return currentState == TrackerState.STARTED || currentState == TrackerState.PAUSED;
  }

  /**
   * Flushes pending samples and detaches the service from the shared database before a full
   * restore. A live or paused workout must never be replaced by a backup.
   */
  public static boolean prepareForDatabaseMaintenance() {
    Tracker current = serviceInstance;
    if (current == null) return true;
    synchronized (current) {
      TrackerState currentState = current.state.get();
      if (currentState == TrackerState.STARTED
          || currentState == TrackerState.PAUSED
          || currentState == TrackerState.CONNECTING
          || currentState == TrackerState.CLEANUP
          || current.databaseMaintenanceInProgress) {
        return false;
      }
      current.databaseMaintenanceInProgress = true;
      PersistentGpsLoggerListener writer = current.mDBWriter;
      if (writer != null && !writer.flush()) {
        current.databaseMaintenanceInProgress = false;
        Log.e("Tracker", "Refusing database maintenance because GPS samples are still queued");
        return false;
      }
      if (!current.closeLocationWriter()) {
        current.databaseMaintenanceInProgress = false;
        Log.e("Tracker", "Refusing database maintenance because the GPS writer is still active");
        return false;
      }
      current.mDB = null;
      return true;
    }
  }

  /** Reattaches the service to the database after restore commit or rollback. */
  public static void reopenDatabaseAfterMaintenance() {
    Tracker current = serviceInstance;
    if (current == null) return;
    synchronized (current) {
      if (current.mDB == null) {
        current.mDB = DBHelper.getWritableDatabase(current.getApplicationContext());
      }
      current.databaseMaintenanceInProgress = false;
    }
  }

  public TrackerState getState() {
    return state.get();
  }

  public void registerTrackerStateListener(ValueModel.ChangeListener<TrackerState> listener) {
    state.registerChangeListener(listener);
  }

  public void unregisterTrackerStateListener(ValueModel.ChangeListener<TrackerState> listener) {
    state.unregisterChangeListener(listener);
  }

  // Service interface stuff...
  public class LocalBinder extends android.os.Binder {
    public Tracker getService() {
      return Tracker.this;
    }
  }

  private final IBinder mBinder = new LocalBinder();

  @Override
  public IBinder onBind(Intent intent) {
    return mBinder;
  }

  @SuppressLint("Wakelock")
  private void wakeLock(boolean get) {
    if (mWakeLock != null) {
      if (mWakeLock.isHeld()) {
        mWakeLock.release();
      }
      mWakeLock = null;
    }
    if (get) {
      PowerManager pm = (PowerManager) this.getSystemService(Context.POWER_SERVICE);
      mWakeLock =
          Objects.requireNonNull(pm)
              .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RunnerUp:wakeLock");
      if (mWakeLock != null) {
        // Set a timeout, this is before activity is started
        mWakeLock.acquire(300000);
      }
    }
  }

  public boolean isComponentConfigured(String name) {
    switch (getState()) {
      case INIT: // before onInit we don't know, so say no
      case CLEANUP: // when cleaning, say no
      case ERROR: // on error, say no
        return false;
      case INITIALIZING:
        // If we're initializing...say no
        if (components.getResultCode(name) == TrackerComponent.ResultCode.RESULT_PENDING)
          return false;
      case INITIALIZED:
      case CONNECTING:
      case CONNECTED:
      case STARTED:
      case PAUSED:
      case STOPPED:
        // check component
        break;
    }

    switch (components.getResultCode(name)) {
      case RESULT_OK:
      case RESULT_PENDING:
        return true;
      case RESULT_NOT_SUPPORTED:
      case RESULT_NOT_ENABLED:
      case RESULT_ERROR:
      case RESULT_ERROR_FATAL:
        return false;
    }
    return false;
  }

  public boolean isComponentConnected(String name) {
    TrackerComponent component = components.getComponent(name);
    return (component != null) && component.isConnected();
  }

  public HRProvider getHRProvider() {
    return (trackerHRM.getHrProvider());
  }

  public void setHrDebug(TextView tv) {
    if (trackerHRM != null) {
      trackerHRM.setDebugLog(tv);
    }
  }

  private Integer getCurrentHRValueElapsed(long now, long maxAge) {
    HRProvider hrProvider = trackerHRM.getHrProvider();
    if ((hrProvider == null) || !hrProvider.isConnected()) return null;

    // now is elapsed nanosec, no sensor adjust needed
    if (now > hrProvider.getHRValueElapsedRealtime() + maxAge * NANO_IN_MILLI) return null;

    return hrProvider.getHRValue();
  }

  private Integer getCurrentHRValue(long now, long maxAge) {
    HRProvider hrProvider = trackerHRM.getHrProvider();
    if ((hrProvider == null) || !hrProvider.isConnected()) return null;

    if (now > hrProvider.getHRValueTimestamp() + maxAge) return null;

    return hrProvider.getHRValue();
  }

  public Integer getCurrentHRValue() {
    return getCurrentHRValueElapsed(SystemClock.elapsedRealtimeNanos(), MAX_CURRENT_AGE);
  }

  public double getHeartbeats() {
    return mHeartbeats;
  }

  public Integer getCurrentBatteryLevel() {
    HRProvider hrProvider = trackerHRM.getHrProvider();
    if (hrProvider == null) return HRProvider.BATTERY_LEVEL_UNAVAILABLE;
    return hrProvider.getBatteryLevel();
  }

  public Float getCurrentCadence() {
    return trackerCadence.getValue();
  }

  public Float getCurrentTemperature() {
    return trackerTemperature.getValue();
  }

  public Float getCurrentPressure() {
    return trackerPressure.getValue();
  }

  public Double getCurrentElevation() {
    return trackerElevation.getValue();
  }

  // Live pace over the configured time period. Distance is accumulated from
  // consecutive accepted GPS points, then divided by the elapsed time of the window.
  public Double getCurrentSpeedForTimeWindow(double seconds) {
    if (mPaceSamples.size() < 2 || seconds <= 0) return null;
    Location last = mPaceSamples.peekLast();
    long nowNs = SystemClock.elapsedRealtimeNanos();
    if (nowNs - last.getElapsedRealtimeNanos() > MAX_CURRENT_AGE * NANO_IN_MILLI) return null;
    Location[] a = mPaceSamples.toArray(new Location[0]);
    int end = a.length - 1;
    double distance = 0.0d;
    int start = end;
    for (int i = end; i > 0; i--) {
      long dt = a[i].getElapsedRealtimeNanos() - a[i - 1].getElapsedRealtimeNanos();
      if (dt <= 0) continue;
      distance += Math.max(0.0d, a[i].distanceTo(a[i - 1]));
      start = i - 1;
      if ((a[end].getElapsedRealtimeNanos() - a[start].getElapsedRealtimeNanos())
          >= seconds * 1_000_000_000.0d) break;
    }
    long elapsed = a[end].getElapsedRealtimeNanos() - a[start].getElapsedRealtimeNanos();
    // A time-based Ritmo Atual must represent the complete configured period.
    // Never calculate a shorter partial window (for example 4 s when the user
    // selected 10 s). The window is built only from consecutive high-quality
    // GPS points; if GPS stalls or the complete period is not available yet,
    // return null and let the caller stay silent rather than inventing a pace.
    if (elapsed <= 0 || elapsed < seconds * 1_000_000_000.0d || distance <= 0.5d) return null;
    double speed = distance * 1_000_000_000.0d / elapsed;
    return speed > 0 && Double.isFinite(speed) ? speed : null;
  }

  // Live pace over the configured distance period. The window is made from
  // consecutive accepted GPS segments until the requested distance is reached.
  public Double getCurrentSpeedForDistanceWindow(double meters) {
    if (mPaceSamples.size() < 2 || meters <= 0) return null;
    Location[] a = mPaceSamples.toArray(new Location[0]);
    int end = a.length - 1;
    double distance = 0.0d;
    int start = end;
    for (int i = end; i > 0; i--) {
      double segment = Math.max(0.0d, a[i].distanceTo(a[i - 1]));
      long dt = a[i].getElapsedRealtimeNanos() - a[i - 1].getElapsedRealtimeNanos();
      if (dt <= 0) continue;
      distance += segment;
      start = i - 1;
      if (distance >= meters) break;
    }
    long elapsed = a[end].getElapsedRealtimeNanos() - a[start].getElapsedRealtimeNanos();
    // Distance-based Ritmo Atual is also only valid after the complete requested
    // distance has actually been accumulated. Do not report a partial window.
    if (elapsed <= 0 || distance < meters || distance <= 0.5d) return null;
    double speed = distance * 1_000_000_000.0d / elapsed;
    return speed > 0 && Double.isFinite(speed) ? speed : null;
  }

  /** Pace Coach live speed using the same configured period as the voice/interface. */
  public Double getPaceCoachCurrentSpeed() {
    try {
      android.content.SharedPreferences prefs =
          androidx.preference.PreferenceManager.getDefaultSharedPreferences(this);
      String cadence = prefs.getString("cue_current_cadence", "time");
      if ("distance".equals(cadence)) {
        double meters = Double.parseDouble(prefs.getString("cue_current_distance_interval", "100"));
        return getCurrentSpeedForDistanceWindow(meters > 0 ? meters : 100);
      }
      double seconds = Double.parseDouble(prefs.getString("cue_current_time_interval", "10"));
      return getCurrentSpeedForTimeWindow(seconds > 0 ? seconds : 10);
    } catch (Exception ignored) {
      return getCurrentSpeedForTimeWindow(10);
    }
  }

  // Backward-compatible raw live speed. Other RunnerUp components may use it.
  public Double getCurrentSpeed() {
    if (mLastPaceLocation == null || !(mCurrentSpeed > 0.0d)
        || Double.isNaN(mCurrentSpeed) || Double.isInfinite(mCurrentSpeed)) return null;
    if ((SystemClock.elapsedRealtimeNanos() - mLastPaceLocation.getElapsedRealtimeNanos())
        > MAX_CURRENT_AGE * NANO_IN_MILLI) return null;
    return mCurrentSpeed;
  }

  public Workout getWorkout() {
    return workout;
  }
}
