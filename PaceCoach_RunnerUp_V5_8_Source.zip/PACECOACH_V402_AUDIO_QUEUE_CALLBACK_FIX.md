# Pace Coach v402 — correção de compilação da fila de áudio

Base: v400.

## Problema identificado

O GitHub Actions reportou três erros em `RUTextToSpeech.java`: os callbacks `utteranceCompleted`, `utteranceFailed` e `utteranceStopped` eram declarados como `private`, mas a classe auxiliar `UtteranceCompletion`, no mesmo pacote, os invocava no listener do Android TextToSpeech.

## Correção

- Os três métodos passaram a ter visibilidade de pacote, sem ficarem públicos para todo o aplicativo.
- Mantida a sincronização dos callbacks para proteger o estado da fila.
- Mantida a fila única, o escalonamento por prioridade e a retomada do trecho interrompido.
- Nenhuma alteração na ordem de prioridade definida na v400.

## Versão

- Revisão: v402
- versionCode interno: 402 (APK Android esperado: 23000402)
- Wear: 23000403
- versionName: 2.11.0.28
- Artefato GitHub Actions: `pacecoach-apk-v402-audio-priority-queue-access-fix`
