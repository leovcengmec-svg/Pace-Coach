/*
 * Copyright (C) 2026 Pace Coach contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */
package org.runnerup.workout.feedback;

import android.content.Context;
import java.util.HashMap;
import org.runnerup.workout.Dimension;
import org.runnerup.workout.Feedback;
import org.runnerup.workout.Scope;
import org.runnerup.workout.Workout;

/** Final Pace Coach workout announcement: status plus complete activity summary. */
public class PaceCoachActivitySummaryFeedback extends Feedback {
  private RUTextToSpeech textToSpeech;
  private org.runnerup.util.Formatter formatter;

  @Override
  public void onBind(Workout w, HashMap<String, Object> bindValues) {
    super.onBind(w, bindValues);
    if (bindValues.containsKey(Workout.KEY_TTS)) {
      textToSpeech = (RUTextToSpeech) bindValues.get(Workout.KEY_TTS);
    }
    if (bindValues.containsKey(Workout.KEY_FORMATTER)) {
      formatter = (org.runnerup.util.Formatter) bindValues.get(Workout.KEY_FORMATTER);
    }
  }

  @Override
  public boolean equals(Feedback other) {
    return other instanceof PaceCoachActivitySummaryFeedback;
  }

  public String buildMessage(Workout w) {
    if (formatter == null) return null;
    StringBuilder msg = new StringBuilder("Treino finalizado. ");
    msg.append("Tempo total: ")
        .append(formatter.format(org.runnerup.util.Formatter.Format.CUE_LONG,
            Dimension.TIME, w.get(Scope.ACTIVITY, Dimension.TIME)))
        .append(". Distância total: ")
        .append(formatter.format(org.runnerup.util.Formatter.Format.CUE_LONG,
            Dimension.DISTANCE, w.get(Scope.ACTIVITY, Dimension.DISTANCE)))
        .append(". Ritmo médio: ")
        .append(formatPace(w.get(Scope.ACTIVITY, Dimension.PACE)))
        .append(". Velocidade média: ")
        .append(formatter.format(org.runnerup.util.Formatter.Format.CUE_LONG,
            Dimension.SPEED, w.get(Scope.ACTIVITY, Dimension.SPEED)));
    return msg.toString();
  }

  @Override
  public void emit(Workout w, Context ctx) {
    if (textToSpeech == null || formatter == null) return;
    String msg = buildMessage(w);
    if (msg == null) return;
    textToSpeech.speakCoach(msg);
  }

  private static String formatPace(double secondsPerMeter) {
    if (Double.isNaN(secondsPerMeter) || Double.isInfinite(secondsPerMeter)
        || secondsPerMeter <= 0) {
      return "indisponível";
    }
    int totalSeconds = (int) Math.round(secondsPerMeter * 1000.0);
    if (totalSeconds > 30 * 60) return "indisponível";
    return (totalSeconds / 60) + " e " + (totalSeconds % 60);
  }
}
