# Pace Coach V2.7

## Execução estruturada real

O botão **Iniciar treino estruturado** agora inicia o `RunService` em modo de treino estruturado. O serviço usa o GPS real e executa o treino 4 x 1 km, com transições automáticas entre aquecimento, tiros, recuperações e desaquecimento.

Fluxo: UI → Foreground Service → GPS → PaceCalculator → RunServiceCoachAdapter → RunCoachIntegration → CoachController → TTS.

A corrida livre continua disponível no botão principal.

Esta versão é código-fonte e não um APK compilado. A compilação Android real ainda precisa ser feita em ambiente com Android SDK/Gradle, posteriormente via GitHub Actions.
