@echo off
setlocal EnableExtensions EnableDelayedExpansion

title Pace Coach - Permissoes de Desenvolvimento

echo ============================================================
echo   Pace Coach - Concessao de permissoes para desenvolvimento
echo ============================================================
echo.

set "ADB="
where adb >nul 2>&1
if not errorlevel 1 set "ADB=adb"
if not defined ADB if defined ANDROID_HOME if exist "%ANDROID_HOME%\platform-tools\adb.exe" set "ADB=%ANDROID_HOME%\platform-tools\adb.exe"
if not defined ADB if defined ANDROID_SDK_ROOT if exist "%ANDROID_SDK_ROOT%\platform-tools\adb.exe" set "ADB=%ANDROID_SDK_ROOT%\platform-tools\adb.exe"
if not defined ADB if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"

if not defined ADB (
  echo ERRO: ADB nao foi encontrado.
  echo Instale o Android SDK Platform-Tools ou adicione adb ao PATH.
  echo.
  pause
  exit /b 1
)

echo ADB: %ADB%
"%ADB%" start-server
if errorlevel 1 (
  echo ERRO: nao foi possivel iniciar o ADB.
  pause
  exit /b 1
)

echo.
echo Verificando dispositivo...
"%ADB%" get-state 2>nul | findstr /i "device" >nul
if errorlevel 1 (
  echo ERRO: nenhum dispositivo ADB autorizado foi encontrado.
  echo Ative a Depuracao USB e aceite a autorizacao no celular.
  echo.
  "%ADB%" devices
  pause
  exit /b 1
)

echo.
echo Pacotes Pace Coach/RunnerUp encontrados:
set "FOUND=0"
for /f "tokens=2 delims=:" %%P in ('"%ADB%" shell pm list packages ^| findstr /i "org.runnerup"') do (
  set "PACKAGE=%%P"
  set "FOUND=1"
  echo.
  echo ============================================================
  echo Pacote: !PACKAGE!
  echo ============================================================
  call :grant android.permission.ACCESS_COARSE_LOCATION
  call :grant android.permission.ACCESS_FINE_LOCATION
  call :grant android.permission.ACCESS_BACKGROUND_LOCATION
  call :grant android.permission.ACTIVITY_RECOGNITION
  call :grant android.permission.POST_NOTIFICATIONS
  call :grant android.permission.BLUETOOTH_SCAN
  call :grant android.permission.BLUETOOTH_CONNECT

  rem AppOps complementares para localizacao em segundo plano e atividade.
  "%ADB%" shell cmd appops set !PACKAGE! ACCESS_BACKGROUND_LOCATION allow >nul 2>&1
  "%ADB%" shell cmd appops set !PACKAGE! ACTIVITY_RECOGNITION allow >nul 2>&1
  "%ADB%" shell cmd appops set !PACKAGE! POST_NOTIFICATION allow >nul 2>&1
  "%ADB%" shell cmd appops set !PACKAGE! BLUETOOTH_SCAN allow >nul 2>&1
  "%ADB%" shell cmd appops set !PACKAGE! BLUETOOTH_CONNECT allow >nul 2>&1

  echo.
  echo Permissoes declaradas/concedidas:
  "%ADB%" shell dumpsys package !PACKAGE! | findstr /i "ACCESS_COARSE_LOCATION ACCESS_FINE_LOCATION ACCESS_BACKGROUND_LOCATION ACTIVITY_RECOGNITION POST_NOTIFICATIONS BLUETOOTH_SCAN BLUETOOTH_CONNECT"
)

if "%FOUND%"=="0" (
  echo.
  echo ERRO: nenhum pacote org.runnerup foi encontrado.
  echo.
  "%ADB%" shell pm list packages | findstr /i "runnerup"
  echo.
  pause
  exit /b 1
)

echo.
echo ============================================================
echo CONCLUIDO
 echo ============================================================
echo.
echo Se alguma permissao continuar como negada, o Android bloqueou a
 echo concessao automatica daquela permissao nesta versao do sistema.
echo Nesse caso, somente essa permissao precisara de autorizacao manual.
echo.
pause
endlocal
exit /b 0

:grant
"%ADB%" shell pm grant !PACKAGE! %1 >nul 2>&1
if errorlevel 1 (
  echo [AVISO] %1 nao pode ser concedida automaticamente.
) else (
  echo [OK] %1
)
exit /b 0
