package org.runnerup.util;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ActivityRecomputeGuardTest {
  @Test
  public void acceptsSmallDifferencesFromGpsRecomputation() {
    assertTrue(ActivityRecomputeGuard.isSafe(5260d, 2921L, 5380d, 2960L));
  }

  @Test
  public void rejectsLargeDistanceAndTimeOutliers() {
    assertFalse(ActivityRecomputeGuard.isSafe(5260d, 2921L, 8100d, 2921L));
    assertFalse(ActivityRecomputeGuard.isSafe(5260d, 2921L, 5260d, 9000L));
  }

  @Test
  public void allowsFirstTimeAggregationWithoutSavedSummary() {
    assertTrue(ActivityRecomputeGuard.isSafe(-1d, -1L, 5260d, 2921L));
  }
}
