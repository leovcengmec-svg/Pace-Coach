package org.runnerup.view;

import static android.content.Context.MODE_PRIVATE;
import static org.runnerup.view.AudioCueSettingsActivity.SUFFIX;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.preference.Preference;
import androidx.preference.Preference.OnPreferenceClickListener;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.PreferenceGroup;
import androidx.preference.PreferenceManager;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import org.runnerup.R;
import org.runnerup.common.util.Constants;
import org.runnerup.db.DBHelper;
import org.runnerup.util.Formatter;
import org.runnerup.util.HRZones;
import org.runnerup.widget.SpinnerInterface.OnSetValueListener;
import org.runnerup.widget.TitleSpinner;
import org.runnerup.workout.Feedback;
import org.runnerup.workout.Workout;
import org.runnerup.workout.WorkoutBuilder;
import org.runnerup.workout.feedback.RUTextToSpeech;

public class AudioCueSettingsFragment extends PreferenceFragmentCompat {
  private boolean started = false;
  private String settingsName = null;
  private AudioSchemeListAdapter adapter = null;
  private SQLiteDatabase mDB = null;
  private MenuItem newSettings;

  private String DEFAULT = "Default";
  private static final String PREFS_DIR = "shared_prefs";

  @Override
  public void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    mDB = DBHelper.getWritableDatabase(requireContext());
    DEFAULT = getString(org.runnerup.common.R.string.Default);
    setHasOptionsMenu(true); // this fragment has menu items
  }

  private String sanitizeSettingsName(String name) {
    if (name == null) return null;
    return name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_");
  }

  @Override
  public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
    String optionName = requireArguments().getString("name");
    settingsName = sanitizeSettingsName(optionName);

    if (settingsName != null) {
      if (!settingsName.equals(optionName)) {
        // illegal names could previously be created, raised exceptions
        Log.d(getClass().getName(), "Audio cue name contains illegal characters: " + optionName);
        settingsName = optionName;
        new AlertDialog.Builder(requireContext())
            .setMessage(org.runnerup.common.R.string.Delete_audio_cue)
            .setPositiveButton(
                org.runnerup.common.R.string.Yes,
                (dialog, which) -> {
                  dialog.dismiss();
                  deleteAudioScheme();
                })
            .setNegativeButton(
                org.runnerup.common.R.string.No,
                (dialog, which) -> {
                  // Do nothing but close the dialog
                  dialog.dismiss();
                })
            .show();
        return;
      }

      PreferenceManager prefMgr = getPreferenceManager();
      prefMgr.setSharedPreferencesName(settingsName + SUFFIX);
      prefMgr.setSharedPreferencesMode(MODE_PRIVATE);
    }

    setPreferencesFromResource(R.xml.audio_cue_settings, rootKey);

    setupAnnouncementSelectors();

    {
      Preference btn = findPreference("test_cueinfo");
      if (btn != null) btn.setOnPreferenceClickListener(onTestCueinfoClick);
    }

    HRZones hrZones = new HRZones(requireContext());
    boolean hasHR = SettingsSensorsFragment.hasHR(requireContext());
    boolean hasHRZones = hrZones.isConfigured();

    if (!hasHR || !hasHRZones) {
      final int[] remove = {
        R.string.cueinfo_total_hrz,
        R.string.cueinfo_step_hrz,
        R.string.cueinfo_lap_hrz,
        R.string.cueinfo_current_hrz
      };
      removePrefs(remove);
    }

    if (!hasHR) {
      final int[] remove = {
        R.string.cueinfo_total_hr,
        R.string.cueinfo_step_hr,
        R.string.cueinfo_lap_hr,
        R.string.cueinfo_current_hr
      };
      removePrefs(remove);
    }

    {
      Preference btn = findPreference("tts_settings");
      btn.setOnPreferenceClickListener(
          preference -> {
            Intent intent1 = new Intent().setAction("com.android.settings.TTS_SETTINGS");
            startActivity(intent1);
            return false;
          });
    }
  }

  @NonNull
  @Override
  public View onCreateView(
      @NonNull LayoutInflater inflater,
      @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    // Inflate our custom layout for the audio cue settings (a TitleSpinner above the list of
    // preferences)
    View layout = inflater.inflate(R.layout.settings_wrapper, container, false);
    ViewGroup settingsContainerView = layout.findViewById(R.id.settings_container_view);

    // Add preferences to our container
    View settingsView = super.onCreateView(inflater, settingsContainerView, savedInstanceState);
    settingsContainerView.addView(settingsView);

    final boolean createNewItem = true;
    adapter = new AudioSchemeListAdapter(mDB, inflater, createNewItem);
    adapter.reload();

    return layout;
  }

  @Override
  public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);

    {
      TitleSpinner spinner = view.findViewById(R.id.settings_spinner);
      spinner.setVisibility(View.VISIBLE);
      spinner.setAdapter(adapter);

      if (settingsName == null) {
        spinner.setValue(0);
      } else {
        int idx = adapter.find(settingsName);
        spinner.setValue(idx);
      }
      spinner.setOnSetValueListener(onSetValueListener);
    }
  }

  /** Keep each announcement mode mutually exclusive: time OR distance. */
  private void setupAnnouncementSelectors() {
    setupGeneralAnnouncementSelector();
    setupAnnouncementSelector("cue_current_cadence", "cue_current_time_interval", "cue_current_distance_interval");
    setupEnabledDataSelector("cue_general_km_cadence", new String[] {
      "cue_general_km_time", "cue_general_km_distance", "cue_general_km_pace",
      "cue_general_km_speed", "cue_general_km_hr"
    });
  }

  private void setupGeneralAnnouncementSelector() {
    Preference cadence = findPreference("cue_general_cadence");
    Preference time = findPreference("cue_general_time_interval");
    Preference distance = findPreference("cue_general_distance_interval");
    if (!(cadence instanceof androidx.preference.ListPreference) || time == null || distance == null) return;
    Runnable sync = () -> {
      String mode = String.valueOf(((androidx.preference.ListPreference) cadence).getValue());
      time.setVisible("time".equals(mode));
      distance.setVisible("distance".equals(mode));
      boolean dataVisible = "time".equals(mode) || "distance".equals(mode);
      String[] keys = {"cue_general_time", "cue_general_distance", "cue_general_pace", "cue_general_speed", "cue_general_hr"};
      for (String key : keys) {
        Preference option = findPreference(key);
        if (option != null) option.setVisible(dataVisible);
      }
    };
    cadence.setOnPreferenceChangeListener((preference, newValue) -> {
      String mode = String.valueOf(newValue);
      time.setVisible("time".equals(mode));
      distance.setVisible("distance".equals(mode));
      boolean dataVisible = "time".equals(mode) || "distance".equals(mode);
      String[] keys = {"cue_general_time", "cue_general_distance", "cue_general_pace", "cue_general_speed", "cue_general_hr"};
      for (String key : keys) {
        Preference option = findPreference(key);
        if (option != null) option.setVisible(dataVisible);
      }
      return true;
    });
    sync.run();
  }

  private void setupEnabledDataSelector(String cadenceKey, String[] optionKeys) {
    Preference cadence = findPreference(cadenceKey);
    if (!(cadence instanceof androidx.preference.ListPreference)) return;
    Runnable sync = () -> {
      String mode = String.valueOf(((androidx.preference.ListPreference) cadence).getValue());
      boolean enabled = "on".equals(mode);
      for (String key : optionKeys) {
        Preference option = findPreference(key);
        if (option != null) option.setVisible(enabled);
      }
    };
    cadence.setOnPreferenceChangeListener((preference, newValue) -> {
      boolean enabled = "on".equals(String.valueOf(newValue));
      for (String key : optionKeys) {
        Preference option = findPreference(key);
        if (option != null) option.setVisible(enabled);
      }
      return true;
    });
    sync.run();
  }

  private void setupAnnouncementSelector(String cadenceKey, String timeKey, String distanceKey) {
    Preference cadence = findPreference(cadenceKey);
    Preference time = findPreference(timeKey);
    Preference distance = findPreference(distanceKey);
    if (cadence == null || time == null || distance == null) return;

    Runnable sync = () -> {
      String mode = String.valueOf(((androidx.preference.ListPreference) cadence).getValue());
      boolean byTime = "time".equals(mode);
      boolean byDistance = "distance".equals(mode);
      time.setVisible(byTime);
      distance.setVisible(byDistance);
    };
    cadence.setOnPreferenceChangeListener((preference, newValue) -> {
      String mode = String.valueOf(newValue);
      time.setVisible("time".equals(mode));
      distance.setVisible("distance".equals(mode));
      return true;
    });
    sync.run();
  }

  private void removePrefs(int[] remove) {
    Resources res = getResources();
    PreferenceGroup group = findPreference("cueinfo");
    if (group == null) return;
    for (int aRemove : remove) {
      String s = res.getString(aRemove);
      Preference pref = findPreference(s);
      group.removePreference(pref);
    }
  }

  @Override
  public void onDestroy() {
    super.onDestroy();
    DBHelper.closeDB(mDB);
  }

  @Override
  public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
    newSettings = menu.add("New settings");
    MenuItem deleteMenuItem = menu.add("Delete settings");
    if (settingsName == null) deleteMenuItem.setEnabled(false);
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item == newSettings) {
      createNewAudioSchemeDialog();
      return true;
    }
    // deleteMenuItem selected
    new AlertDialog.Builder(requireContext())
        .setMessage(org.runnerup.common.R.string.Delete_audio_cue)
        .setPositiveButton(
            org.runnerup.common.R.string.Yes,
            (dialog, which) -> {
              dialog.dismiss();
              deleteAudioScheme();
            })
        .setNegativeButton(
            org.runnerup.common.R.string.No,
            (dialog, which) -> {
              // Do nothing but close the dialog
              dialog.dismiss();
            })
        .show();
    return true;
  }

  private void createNewAudioScheme(String scheme) {
    ContentValues tmp = new ContentValues();
    tmp.put(Constants.DB.AUDIO_SCHEMES.NAME, scheme);
    tmp.put(Constants.DB.AUDIO_SCHEMES.SORT_ORDER, 0);
    mDB.insert(Constants.DB.AUDIO_SCHEMES.TABLE, null, tmp);
  }

  private void deleteAudioScheme() {
    deleteAudioSchemeImpl(settingsName);
    switchTo(null);
  }

  private void deleteAudioSchemeImpl(String name) {
    /*
     * Start by deleting file...then delete from table...so we don't get
     * stray files
     */
    File a =
        new File(
            requireContext().getFilesDir().getParent()
                + File.separator
                + PREFS_DIR
                + "/"
                + sanitizeSettingsName(name)
                + SUFFIX
                + ".xml");
    //noinspection ResultOfMethodCallIgnored
    a.delete();

    String[] args = {name};
    mDB.delete(Constants.DB.AUDIO_SCHEMES.TABLE, Constants.DB.AUDIO_SCHEMES.NAME + "= ?", args);
  }

  private void updateSortOrder(String name) {
    mDB.execSQL(
        "UPDATE "
            + Constants.DB.AUDIO_SCHEMES.TABLE
            + " set "
            + Constants.DB.AUDIO_SCHEMES.SORT_ORDER
            + " = (SELECT MAX("
            + Constants.DB.AUDIO_SCHEMES.SORT_ORDER
            + ") + 1 FROM "
            + Constants.DB.AUDIO_SCHEMES.TABLE
            + ") "
            + " WHERE "
            + Constants.DB.AUDIO_SCHEMES.NAME
            + " = '"
            + name
            + "'");
  }

  private final OnSetValueListener onSetValueListener =
      new OnSetValueListener() {

        @Override
        public String preSetValue(String newValue) throws IllegalArgumentException {
          return newValue;
        }

        @Override
        public int preSetValue(int newValueId) throws IllegalArgumentException {
          String newValue = (String) adapter.getItem(newValueId);
          PreferenceManager prefMgr = getPreferenceManager();
          if (newValue.contentEquals(DEFAULT)) {
            prefMgr.getSharedPreferences().edit().apply();
            switchTo(null);
          } else if (newValue.contentEquals(
              getString(org.runnerup.common.R.string.New_audio_scheme))) {
            createNewAudioSchemeDialog();
          } else {
            prefMgr.getSharedPreferences().edit().apply();
            updateSortOrder(newValue);
            switchTo(newValue);
          }
          throw new IllegalArgumentException();
        }
      };

  private void switchTo(String name) {

    if (!started) {
      // TODO investigate "spurious" onItemSelected during start
      started = true;
      return;
    }

    if (name == null && settingsName == null) {
      return;
    }

    if (name != null && settingsName != null && name.contentEquals(settingsName)) {
      Log.e(getClass().getName(), "Settings name: " + settingsName + " do not match: " + name);
      return;
    }

    Bundle bundle = new Bundle();
    if (name != null) {
      bundle.putString("name", name);
    }

    requireActivity()
        .getSupportFragmentManager()
        .beginTransaction()
        .setReorderingAllowed(true)
        .replace(R.id.settings_fragment_container, AudioCueSettingsFragment.class, bundle)
        .commit();
  }

  private void createNewAudioSchemeDialog() {
    final EditText editText = new EditText(requireContext());
    editText.setMinimumHeight(48);
    editText.setMinimumWidth(48);

    new AlertDialog.Builder(requireContext())
        .setTitle(org.runnerup.common.R.string.Create_new_audio_cue_scheme)
        // Get the layout inflater
        .setView(editText)
        .setPositiveButton(
            org.runnerup.common.R.string.OK,
            (dialog, which) -> {
              String scheme = editText.getText().toString();
              if (!scheme.equals(sanitizeSettingsName(scheme))
                  || scheme.isEmpty()
                  || scheme.contains("/")
                  || scheme.contains("\\")
                  || scheme.contains("..")) {
                Log.d(
                    getClass().getName(), "Audio cue name contains illegal characters: " + scheme);
                return;
              }
              createNewAudioScheme(scheme);
              updateSortOrder(scheme);
              switchTo(scheme);
            })
        .setNegativeButton(org.runnerup.common.R.string.Cancel, (dialog, which) -> {})
        .show();
  }

  private void CreateNewNoTtsAvailableDialog() {
    new AlertDialog.Builder(requireContext())
        .setTitle(org.runnerup.common.R.string.tts_not_available_title)
        .setMessage(org.runnerup.common.R.string.tts_not_available)
        .setPositiveButton(org.runnerup.common.R.string.OK, null)
        .show();
  }

  private final OnPreferenceClickListener onTestCueinfoClick =
      new OnPreferenceClickListener() {
        private TextToSpeech tts;

        @Override
        public boolean onPreferenceClick(Preference arg0) {
          final Context ctx = requireContext();
          if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
          }

          tts = new TextToSpeech(ctx, status -> {
            if (status != TextToSpeech.SUCCESS || tts == null) {
              CreateNewNoTtsAvailableDialog();
              return;
            }

            int lang = tts.setLanguage(java.util.Locale.getDefault());
            if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
              lang = tts.setLanguage(new java.util.Locale("pt", "BR"));
            }
            if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
              CreateNewNoTtsAvailableDialog();
              return;
            }

            // The test button must be independent of workout-feedback state.
            tts.speak("Pace Coach. Teste de áudio funcionando.", TextToSpeech.QUEUE_FLUSH, null, "pacecoach_audio_test");
          });
          return true;
        }
      };

}
