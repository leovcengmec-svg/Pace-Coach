/*
 * Copyright (C) 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.runnerup.util.Formatter;

public class DistancePicker extends LinearLayout {

  private final long baseUnitMeters;
  private final long fractionBase; // (10 ^ digits)

  private final NumberPicker unitMeters; // e.g km or mi
  private final TextView unitString;
  private final NumberPicker fraction;

  public DistancePicker(Context context, AttributeSet attrs) {
    super(context);

    Formatter f = new Formatter(context);

    unitMeters = new NumberPicker(context, attrs);
    LinearLayout unitStringLayout = new LinearLayout(context);
    unitStringLayout.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
    unitStringLayout.setLayoutParams(
        new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT));
    unitString = new TextView(context);
    unitString.setTextSize(25);
    unitString.setMinimumHeight(48);
    unitString.setMinimumWidth(48);
    unitStringLayout.addView(unitString);
    unitString.setText(f.getUnitString());
    unitMeters.setDigits(1);
    unitMeters.setRange(0, 999, true);
    unitMeters.setOrientation(VERTICAL);

    baseUnitMeters = (long) f.getUnitMeters();
    int digits = 2;
    if (baseUnitMeters == 1000) {
      // Pace Coach uses kilometers with one decimal (e.g. 5,5 km).
      digits = 1;
    }
    int fb = 1;
    for (int i = 0; i < digits; i++) {
      fb *= 10;
    }
    fractionBase = fb;

    fraction = new NumberPicker(context, attrs);
    fraction.setRange(0, fb - 1, true);
    fraction.setDigits(digits);
    fraction.setOrientation(VERTICAL);

    setOrientation(HORIZONTAL);
    setLayoutParams(
        new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
    addView(unitMeters);
    addView(unitStringLayout);
    addView(fraction);
  }

  public long getDistance() {
    double val = fraction.getValue();
    val *= baseUnitMeters;
    val = (val + fractionBase / 2) / fractionBase;
    val += unitMeters.getValue() * baseUnitMeters;
    return (long) val;
  }

  public void setDistance(long s) {
    long h = s / baseUnitMeters;
    s -= h * baseUnitMeters;
    double f = s * fractionBase;
    f = (f + baseUnitMeters / 2) / baseUnitMeters;
    unitMeters.setValue((int) h);
    fraction.setValue((int) f);
  }

  @Override
  public void setEnabled(boolean enabled) {
    super.setEnabled(enabled);
    unitMeters.setEnabled(enabled);
    fraction.setEnabled(enabled);
  }
}
