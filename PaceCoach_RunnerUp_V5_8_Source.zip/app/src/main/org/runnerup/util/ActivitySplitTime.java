/*
 * Copyright (C) 2026 Pace Coach contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package org.runnerup.util;

/** Helpers for normalizing location timestamps used to derive activity splits. */
public final class ActivitySplitTime {
  private ActivitySplitTime() {}

  /**
   * Converts a monotonic or wall-clock millisecond timestamp to elapsed whole seconds
   * relative to the first sample. Negative deltas are clamped to zero.
   */
  public static long elapsedSecondsSince(long timestampMillis, long firstTimestampMillis) {
    long deltaMillis = Math.max(0L, timestampMillis - firstTimestampMillis);
    return deltaMillis / 1000L;
  }
}
