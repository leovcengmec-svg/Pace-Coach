package com.pacecoach.v1.run

class WorkoutBuilder(private val name: String) {

    private val steps = mutableListOf<WorkoutStep>()

    fun addTimeStep(
        kind: StepKind,
        durationSeconds: Long,
        targetPaceSeconds: Int? = null,
        label: String = "",
        repeats: Int = 1
    ): WorkoutBuilder {
        require(durationSeconds > 0)
        require(repeats > 0)
        steps += WorkoutStep(
            kind = kind,
            durationSeconds = durationSeconds,
            targetPaceSeconds = targetPaceSeconds,
            label = label,
            repeats = repeats
        )
        return this
    }

    fun addDistanceStep(
        kind: StepKind,
        distanceMeters: Float,
        targetPaceSeconds: Int? = null,
        label: String = "",
        repeats: Int = 1
    ): WorkoutBuilder {
        require(distanceMeters > 0f)
        require(repeats > 0)
        steps += WorkoutStep(
            kind = kind,
            distanceMeters = distanceMeters,
            targetPaceSeconds = targetPaceSeconds,
            label = label,
            repeats = repeats
        )
        return this
    }

    /** Adds a repeated run/recovery pattern as alternating concrete steps.
     *  For 4 repetitions this creates RUN, RECOVERY, RUN, RECOVERY, RUN, RECOVERY, RUN.
     */
    fun addIntervalBlock(
        runKind: StepKind = StepKind.RUN,
        runDistanceMeters: Float? = null,
        runDurationSeconds: Long? = null,
        runTargetPaceSeconds: Int? = null,
        runLabel: String = "Tiro",
        recoveryDurationSeconds: Long? = null,
        recoveryDistanceMeters: Float? = null,
        recoveryTargetPaceSeconds: Int? = null,
        recoveryLabel: String = "Recuperação",
        repeats: Int
    ): WorkoutBuilder {
        require(repeats > 0)
        require((runDistanceMeters != null) xor (runDurationSeconds != null))
        require((recoveryDurationSeconds != null) xor (recoveryDistanceMeters != null))

        repeat(repeats) { index ->
            val n = index + 1
            steps += WorkoutStep(
                kind = runKind,
                durationSeconds = runDurationSeconds,
                distanceMeters = runDistanceMeters,
                targetPaceSeconds = runTargetPaceSeconds,
                label = "$runLabel $n/$repeats"
            )
            if (index < repeats - 1) {
                steps += WorkoutStep(
                    kind = StepKind.RECOVERY,
                    durationSeconds = recoveryDurationSeconds,
                    distanceMeters = recoveryDistanceMeters,
                    targetPaceSeconds = recoveryTargetPaceSeconds,
                    label = recoveryLabel
                )
            }
        }
        return this
    }

    fun build(): StructuredWorkout {
        require(name.isNotBlank())
        require(steps.isNotEmpty())
        return StructuredWorkout(name.trim(), steps.toList())
    }
}
