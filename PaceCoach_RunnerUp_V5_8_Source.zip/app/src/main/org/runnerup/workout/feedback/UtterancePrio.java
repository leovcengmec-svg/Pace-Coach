/*
 * Copyright (C) 2025 jonas.oreland@gmail.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */
package org.runnerup.workout.feedback;

/**
 * Spoken announcement priority. Higher values interrupt lower-priority speech.
 * Required Pace Coach order: rhythm, block, workout status, general data.
 */
enum UtterancePrio {
  PRIO_GENERAL(1),
  PRIO_STATUS(2),
  PRIO_BLOCK(3),
  PRIO_RHYTHM(4),

  // Compatibility aliases for older feedback implementations.
  PRIO_CUE(1),
  PRIO_COACH(2),
  PRIO_COUNTDOWN(3);

  UtterancePrio(int val) {
    value = val;
  }

  final int value;

  static boolean shouldPreempt(int incomingPriority, int activePriority) {
    return incomingPriority > activePriority;
  }
}
