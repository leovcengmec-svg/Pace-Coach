/*
 * Copyright (C) 2026 Pace Coach contributors
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 */

package org.runnerup.workout.feedback;

import android.content.Context;
import java.util.HashMap;
import org.runnerup.workout.Dimension;
import org.runnerup.workout.Feedback;
import org.runnerup.workout.Scope;
import org.runnerup.workout.Workout;

/**
 * Pace Coach audio summary for the three independent announcement levels:
 * GENERAL (whole workout), INTERVAL (current step), and CURRENT (pace only).
 */
public class PaceCoachSummaryFeedback extends Feedback {
  private final Scope scope;
  private final String kind;
  private RUTextToSpeech textToSpeech;
  private org.runnerup.util.Formatter formatter;

  public PaceCoachSummaryFeedback(Scope scope, String kind) {
    this.scope = scope;
    this.kind = kind;
  }

  @Override
  public void onBind(Workout s, HashMap<String, Object> bindValues) {
    super.onBind(s, bindValues);
    if (bindValues.containsKey(Workout.KEY_TTS)) {
      textToSpeech = (RUTextToSpeech) bindValues.get(Workout.KEY_TTS);
    }
    if (bindValues.containsKey(Workout.KEY_FORMATTER)) {
      formatter = (org.runnerup.util.Formatter) bindValues.get(Workout.KEY_FORMATTER);
    }
  }

  @Override
  public boolean equals(Feedback other) {
    if (!(other instanceof PaceCoachSummaryFeedback that)) return false;
    return scope == that.scope && kind.equals(that.kind);
  }

  @Override
  public void emit(Workout w, Context ctx) {
    if (textToSpeech == null || formatter == null) return;

    if (scope == Scope.CURRENT || "current".equals(kind)) {
      double pace = w.get(Scope.CURRENT, Dimension.PACE);
      textToSpeech.speak(
          "Pace: " + formatPace(pace),
          UtterancePrio.PRIO_COACH,
          /* flush= */ true,
          null);
      return;
    }

    double distance = w.get(scope, Dimension.DISTANCE);
    double time = w.get(scope, Dimension.TIME);
    double pace = w.get(scope, Dimension.PACE);

    StringBuilder msg = new StringBuilder();
    if (scope == Scope.ACTIVITY) {
      msg.append("Distância total: ");
    } else {
      msg.append("Distância: ");
    }
    msg.append(formatter.format(org.runnerup.util.Formatter.Format.CUE_LONG, Dimension.DISTANCE, distance));

    msg.append(". ");
    msg.append(scope == Scope.ACTIVITY ? "Tempo total: " : "Tempo: ");
    msg.append(formatter.format(org.runnerup.util.Formatter.Format.CUE_LONG, Dimension.TIME, time));

    msg.append(". ");
    msg.append(scope == Scope.ACTIVITY ? "Pace médio: " : "Pace médio do intervalo: ");
    msg.append(formatPace(pace));

    textToSpeech.speak(
        msg.toString(),
        UtterancePrio.PRIO_CUE,
        /* flush= */ false,
        null);
  }

  private String formatPace(double metersPerSecond) {
    if (Double.isNaN(metersPerSecond) || metersPerSecond <= 0) return "indisponível";
    int totalSeconds = (int) Math.round(1000.0 / metersPerSecond);
    int minutes = totalSeconds / 60;
    int seconds = totalSeconds % 60;
    return minutes + " e " + seconds;
  }
}
