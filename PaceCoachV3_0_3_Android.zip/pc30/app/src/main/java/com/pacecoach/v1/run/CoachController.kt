package com.pacecoach.v1.run

class CoachController(
    private val runtime: CoachRuntime = CoachRuntime()
) {
    private var lastState: CoachState? = null
    private var lastStepKey: Pair<Int, Int>? = null

    data class Decision(
        val state: CoachRuntimeState,
        val message: String?
    )

    fun evaluate(
        step: ActiveStep?,
        paceSeconds: Int?,
        gpsQuality: GpsQuality,
        targetMarginSeconds: Int
    ): Decision {
        val state = runtime.evaluate(
            step,
            paceSeconds,
            gpsQuality,
            targetMarginSeconds
        )

        val stepKey = step?.let { it.index to it.repetition }
        val stepChanged = stepKey != lastStepKey
        val stateChanged = state.state != lastState

        val message = when {
            stepChanged && step != null -> WorkoutVoice.next(step)
            state.state == CoachState.GPS_UNCERTAIN && stateChanged ->
                "GPS instável. Aguarde alguns segundos."
            state.state == CoachState.ON_TARGET && stateChanged && paceSeconds != null ->
                CoachMessageFormatter.targetMessage(
                    paceSeconds,
                    state.targetPaceSeconds ?: paceSeconds,
                    targetMarginSeconds
                )
            state.state == CoachState.SLOWER_THAN_TARGET && stateChanged && paceSeconds != null ->
                CoachMessageFormatter.targetMessage(
                    paceSeconds,
                    state.targetPaceSeconds ?: paceSeconds,
                    targetMarginSeconds
                )
            state.state == CoachState.FASTER_THAN_TARGET && stateChanged && paceSeconds != null ->
                CoachMessageFormatter.targetMessage(
                    paceSeconds,
                    state.targetPaceSeconds ?: paceSeconds,
                    targetMarginSeconds
                )
            else -> null
        }

        lastState = state.state
        lastStepKey = stepKey
        return Decision(state, message)
    }

    fun reset() {
        lastState = null
        lastStepKey = null
    }
}
