package org.runnerup.notification;

import android.Manifest;
import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;

public class ForegroundNotificationDisplayStrategy implements NotificationDisplayStrategy {
  private final Service service;

  public ForegroundNotificationDisplayStrategy(Service service) {
    this.service = service;
  }

  private boolean isForeground = false;

  @Override
  public void notify(int notificationId, Notification notification) {
    if (!isForeground) {
      int type = 0;
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        if (ContextCompat.checkSelfPermission(service, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED) {
          type = ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE
            && ContextCompat.checkSelfPermission(service, Manifest.permission.ACTIVITY_RECOGNITION)
                == PackageManager.PERMISSION_GRANTED) {
          type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH;
        }
      }
      ServiceCompat.startForeground(service, notificationId, notification, type);
      isForeground = true;
    } else {
      android.app.NotificationManager notificationManager =
          (android.app.NotificationManager) service.getSystemService(Context.NOTIFICATION_SERVICE);
      notificationManager.notify(notificationId, notification);
    }
  }

  @Override
  public void cancel(int notificationId) {
    isForeground = false;
    ServiceCompat.stopForeground(service, ServiceCompat.STOP_FOREGROUND_REMOVE);
  }
}
