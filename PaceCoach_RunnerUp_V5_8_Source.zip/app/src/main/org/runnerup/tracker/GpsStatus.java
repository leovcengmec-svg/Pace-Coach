/*
 * Copyright (C) 2012 jonas.oreland@gmail.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.tracker;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.GnssStatus;
import android.location.GpsSatellite;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import org.runnerup.util.TickListener;

/** Helper class that reports whether GPS quality is sufficient to begin tracking. */
public class GpsStatus implements LocationListener {
  private static final String TAG = "GpsStatus";
  private static final int HIST_LEN = 3;
  private static final float FIX_ACCURACY_METERS = 10.0f;
  private static final float MAX_ACCURACY_WITH_SATELLITE_FIX_METERS = 50.0f;
  private static final int MIN_SATELLITES_USED_IN_FIX = 2;

  private volatile boolean fixed;
  private volatile boolean started;
  private final Context context;
  private final Location[] history;
  private LocationManager locationManager;
  private volatile TickListener listener;
  private boolean locationUpdatesRegistered;
  private volatile long lastLocationUpdateElapsedRealtimeMs;
  private volatile float lastAccuracyMeters = -1.0f;

  private volatile int knownSatellites;
  private volatile int usedInLastFixSatellites;
  private GnssStatus.Callback gnssStatusCallback;
  private gpsStatusListener legacyGpsStatusListener;

  public GpsStatus(Context context) {
    this.context = context.getApplicationContext();
    this.history = new Location[HIST_LEN];
  }

  /** Start a complete status monitor using the caller's Looper (normally the UI Looper). */
  public boolean start(TickListener listener) {
    Looper looper = Looper.myLooper();
    if (looper == null) {
      looper = Looper.getMainLooper();
    }
    return start(listener, true, new Handler(looper));
  }

  /**
   * Start GPS quality monitoring.
   *
   * @param registerLocationUpdates false when the central Tracker already supplies location
   *     samples; true for standalone status displays such as the start screen.
   * @param callbackHandler Handler/Looper on which location and GNSS callbacks should be delivered.
   */
  public synchronized boolean start(
      TickListener listener, boolean registerLocationUpdates, Handler callbackHandler) {
    stop(null);
    clear(true);

    if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
        != PackageManager.PERMISSION_GRANTED) {
      Log.w(TAG, "Cannot start GPS status monitoring: precise location permission missing");
      return false;
    }
    if (callbackHandler == null) {
      Log.e(TAG, "Cannot start GPS status monitoring without a callback Handler");
      return false;
    }

    LocationManager manager =
        (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
    if (manager == null) {
      Log.e(TAG, "Cannot start GPS status monitoring: LocationManager unavailable");
      return false;
    }

    try {
      if (registerLocationUpdates) {
        manager.requestLocationUpdates(
            LocationManager.GPS_PROVIDER, 1000L, 0.0f, this, callbackHandler.getLooper());
        locationUpdatesRegistered = true;
      }
      locationManager = manager;
      this.listener = listener;
      started = true;
    } catch (SecurityException ex) {
      Log.e(TAG, "Permission was revoked while registering GPS updates", ex);
      cleanupAfterFailedStart(manager);
      return false;
    } catch (RuntimeException ex) {
      Log.e(TAG, "Unable to register GPS updates", ex);
      cleanupAfterFailedStart(manager);
      return false;
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
      gnssStatusCallback =
          new GnssStatus.Callback() {
            @Override
            public void onSatelliteStatusChanged(@NonNull GnssStatus status) {
              updateSatelliteCounts(status.getSatelliteCount(), status::usedInFix);
            }
          };
      try {
        if (!manager.registerGnssStatusCallback(
            gnssStatusCallback, callbackHandler)) {
          Log.w(TAG, "GNSS satellite callback was not registered; accuracy-based fix remains active");
          gnssStatusCallback = null;
        }
      } catch (RuntimeException ex) {
        Log.w(TAG, "GNSS satellite callback unavailable; continuing with location accuracy", ex);
        gnssStatusCallback = null;
      }
    } else {
      legacyGpsStatusListener = new gpsStatusListener();
      try {
        if (!manager.addGpsStatusListener(legacyGpsStatusListener)) {
          Log.w(TAG, "Legacy GPS status listener was not registered");
          legacyGpsStatusListener = null;
        }
      } catch (RuntimeException ex) {
        Log.w(TAG, "Legacy GPS status listener unavailable", ex);
        legacyGpsStatusListener = null;
      }
    }

    Log.d(TAG, "GPS status monitoring started; standaloneLocationUpdates=" + registerLocationUpdates);
    return true;
  }

  private interface SatelliteFixReader {
    boolean usedInFix(int index);
  }

  private void updateSatelliteCounts(int count, SatelliteFixReader reader) {
    knownSatellites = count;
    int used = 0;
    for (int i = 0; i < count; i++) {
      if (reader.usedInFix(i)) {
        used++;
      }
    }
    usedInLastFixSatellites = used;
    TickListener currentListener = listener;
    if (currentListener != null) {
      currentListener.onTick();
    }
  }

  private void cleanupAfterFailedStart(LocationManager manager) {
    listener = null;
    started = false;
    if (locationUpdatesRegistered) {
      try {
        manager.removeUpdates(this);
      } catch (RuntimeException cleanupError) {
        Log.w(TAG, "Unable to remove partially registered location updates", cleanupError);
      }
    }
    locationUpdatesRegistered = false;
    locationManager = null;
    gnssStatusCallback = null;
    legacyGpsStatusListener = null;
  }

  public synchronized void stop(TickListener ignoredListener) {
    listener = null;
    started = false;

    LocationManager manager = locationManager;
    locationManager = null;
    if (manager == null) {
      locationUpdatesRegistered = false;
      gnssStatusCallback = null;
      legacyGpsStatusListener = null;
      return;
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && gnssStatusCallback != null) {
      try {
        manager.unregisterGnssStatusCallback(gnssStatusCallback);
      } catch (RuntimeException ex) {
        Log.w(TAG, "Unable to unregister GNSS status callback", ex);
      }
    } else if (legacyGpsStatusListener != null) {
      try {
        manager.removeGpsStatusListener(legacyGpsStatusListener);
      } catch (RuntimeException ex) {
        Log.w(TAG, "Unable to unregister legacy GPS status listener", ex);
      }
    }

    if (locationUpdatesRegistered) {
      try {
        manager.removeUpdates(this);
      } catch (RuntimeException ex) {
        Log.d(TAG, "GPS location updates were already stopped", ex);
      }
    }
    locationUpdatesRegistered = false;
    gnssStatusCallback = null;
    legacyGpsStatusListener = null;
  }

  public boolean isStarted() {
    return started;
  }

  public long getLastLocationUpdateElapsedRealtimeMs() {
    return lastLocationUpdateElapsedRealtimeMs;
  }

  public float getLastAccuracyMeters() {
    return lastAccuracyMeters;
  }

  @Override
  public void onLocationChanged(@NonNull Location location) {
    if (!started) {
      return;
    }

    lastLocationUpdateElapsedRealtimeMs = SystemClock.elapsedRealtime();
    lastAccuracyMeters = location.hasAccuracy() ? location.getAccuracy() : -1.0f;
    System.arraycopy(history, 0, history, 1, HIST_LEN - 1);
    history[0] = new Location(location);

    // Recompute rather than only ever setting true: a previously good fix must not remain
    // reported as fixed after the provider starts delivering inaccurate positions.
    fixed =
        location.hasAccuracy()
            && (location.getAccuracy() <= FIX_ACCURACY_METERS
                || (usedInLastFixSatellites >= MIN_SATELLITES_USED_IN_FIX
                    && location.getAccuracy() <= MAX_ACCURACY_WITH_SATELLITE_FIX_METERS));

    TickListener currentListener = listener;
    if (currentListener != null) {
      currentListener.onTick();
    }
  }

  @Override
  public void onProviderDisabled(@NonNull String provider) {
    if (LocationManager.GPS_PROVIDER.equalsIgnoreCase(provider)) {
      clear(true);
      TickListener currentListener = listener;
      if (currentListener != null) currentListener.onTick();
    }
  }

  @Override
  public void onProviderEnabled(@NonNull String provider) {
    if (LocationManager.GPS_PROVIDER.equalsIgnoreCase(provider)) {
      clear(false);
      TickListener currentListener = listener;
      if (currentListener != null) currentListener.onTick();
    }
  }

  @Override
  public void onStatusChanged(String provider, int status, Bundle extras) {
    if (LocationManager.GPS_PROVIDER.equalsIgnoreCase(provider)) {
      if (status == LocationProvider.OUT_OF_SERVICE
          || status == LocationProvider.TEMPORARILY_UNAVAILABLE) {
        clear(true);
      }
      TickListener currentListener = listener;
      if (currentListener != null) currentListener.onTick();
    }
  }

  private class gpsStatusListener implements android.location.GpsStatus.Listener {
    @Override
    public void onGpsStatusChanged(int event) {
      LocationManager manager = locationManager;
      if (manager == null || !started) return;

      android.location.GpsStatus status;
      try {
        status = manager.getGpsStatus(null);
      } catch (SecurityException ex) {
        Log.w(TAG, "Unable to read legacy GPS status", ex);
        return;
      }
      if (status == null) return;

      int available = 0;
      int used = 0;
      Iterable<GpsSatellite> satellites = status.getSatellites();
      for (GpsSatellite satellite : satellites) {
        available++;
        if (satellite.usedInFix()) used++;
      }
      knownSatellites = available;
      usedInLastFixSatellites = used;

      TickListener currentListener = listener;
      if (currentListener != null) currentListener.onTick();
    }
  }

  private void clear(boolean resetFixed) {
    if (resetFixed) fixed = false;
    knownSatellites = 0;
    usedInLastFixSatellites = 0;
    lastLocationUpdateElapsedRealtimeMs = 0L;
    lastAccuracyMeters = -1.0f;
    for (int i = 0; i < HIST_LEN; i++) history[i] = null;
  }

  public boolean isLogging() {
    return locationManager != null;
  }

  public boolean isFixed() {
    return fixed;
  }

  public int getSatellitesAvailable() {
    return knownSatellites;
  }

  public int getSatellitesFixed() {
    return usedInLastFixSatellites;
  }

  @SuppressWarnings("BooleanMethodIsAlwaysInverted")
  public boolean isEnabled() {
    LocationManager manager =
        (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
    if (manager == null) return false;
    try {
      return manager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    } catch (RuntimeException ex) {
      Log.w(TAG, "Unable to inspect GPS provider state", ex);
      return false;
    }
  }
}
