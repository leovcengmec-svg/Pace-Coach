# Pace Coach v398 — Correção de tipo do LocationList

## Base

Revisão v396. Esta revisão corrige o erro de compilação identificado no GitHub Actions em `LocationEntity.java`.

## Causa

`LocationList<E>` implementava um iterador genérico `Iterator<E>`, mas cada linha do cursor sempre cria uma instância de `LocationEntity`. O campo `prev` estava declarado como `E`, portanto a atribuição `prev = current` falhava na compilação (`LocationEntity cannot be converted to E`).

## Correção

- Removido o parâmetro genérico desnecessário de `LocationList`.
- `LocationList` agora implementa `Iterable<LocationEntity>`.
- `LocationIterator` agora implementa `Iterator<LocationEntity>`.
- O ponto anterior é armazenado como `LocationEntity`, e o construtor recebe esse tipo diretamente.
- Removido o cast não verificado no retorno de `next()`.
- Atualizados os cinco consumidores existentes em `GraphWrapper`, `DetailActivity`, `MapWrapper` Mapbox e `MapWrapper` OSMDroid.

O comportamento de consulta e a ordem dos pontos GPS não foram alterados por esta correção. Permanecem as melhorias da v396 para mapa, parciais, detalhamento dos blocos e resumo semanal/mensal/anual.

## Versão

- Revisão interna: v398.
- `versionName`: `2.11.0.24`.
- `versionCode` base: 398 (código Android esperado: 23000398 com minSdk 23).
- Wear reserva o código seguinte: 23000399.
- Artefato GitHub Actions: `pacecoach-apk-v398-location-list-type-fix`.

## Validação

- Análise sintática: 220 arquivos Java, sem erros do parser.
- XML: 215 arquivos sob `app/res`, todos analisados com sucesso.
- Verificação estática da API: nenhuma referência genérica `LocationList<...>` restante.
- Sincronização da versão e do artefato do workflow verificada.
- ZIP testado quanto à integridade.
- A compilação Android completa não foi executada neste ambiente: o `gradle-wrapper.jar` presente no pacote é apenas um ponteiro Git LFS e não há Gradle global nem Android SDK configurado. A confirmação de compilação continua dependendo do GitHub Actions.
