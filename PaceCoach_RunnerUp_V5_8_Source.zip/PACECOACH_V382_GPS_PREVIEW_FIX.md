# Pace Coach / RunnerUp — revisão interna v382

## Correção GPS da tela de prévia do treino

- Corrigida a divergência entre o painel inicial e a tela de prévia (`PREVIEW_ONLY`).
- A prévia não conecta uma segunda instância do `Tracker`, por projeto. Antes, `RunActivity.updateRunGpsHeader()` tratava a ausência de `mTracker` local como GPS não iniciado e sem fix, sobrescrevendo o snapshot compartilhado válido com valores falsos/zerados.
- O componente de serviço `TrackerGPS` agora publica o snapshot em `GpsSignalState` a cada evento de localização/satélite e nas transições de conexão, recuperação e liberação do monitor.
- A prévia reutiliza o snapshot compartilhado quando não possui referência local ao Tracker, desde que o estado tenha sido atualizado nos últimos 15 segundos. Dados antigos não são apresentados como sinal atual.
- Quando há um `Tracker` disponível na `RunActivity`, a tela continua lendo o estado do serviço central.
- Corrigida também a remoção do observador GPS do `StartFragment` antes de liberar a conexão do serviço ao abrir uma atividade já existente. Antes, a referência era apagada antes da remoção e o serviço podia reter o Fragment como listener.
- Nenhum segundo `LocationManager` listener foi criado e a prévia não inicia uma corrida automaticamente.

## Identificação

- `versionCode = 382` (código final esperado no APK Android: `23000382`, com `minSdk 23`).
- `versionName = 2.11.0.8`.
- Artefato do workflow: `pacecoach-apk-v382-gps-preview-fix`.
- Wear continua usando o próximo código, conforme a configuração existente.
- Nome externo do projeto e do arquivo ZIP preservado.

## Vistoria da v380

Inspecionados o vídeo enviado e os fluxos de `StartFragment`, `RunActivity`, `GpsSignalState`, `GpsStatus`, `Tracker` e `TrackerGPS`, além das alterações de manutenção/backup da Fase 2 e do workflow Android.

A diferença verde/vermelho observada é explicada pelo caminho `PREVIEW_ONLY`: o painel inicial já tinha recebido uma leitura excelente, mas a prévia não tem referência local ao Tracker e convertia essa ausência em um estado falso de GPS não iniciado. O serviço continua sendo o dono do GPS; a correção faz a informação compartilhada acompanhar o serviço e evita que a tela de prévia destrua o estado verdadeiro.

## Validações realizadas neste ambiente

- 172 arquivos Java analisados sintaticamente: sem erros de sintaxe.
- 311 arquivos XML analisados: sem erros de parsing.
- Workflow GitHub Actions analisado como YAML: válido estruturalmente.
- `versionCode`, `versionName` e nome do artefato v382 conferidos.
- ZIP testado integralmente após empacotamento.

## Validação pendente

A compilação Android completa não foi executada neste ambiente porque não há Gradle/Android SDK instalados. A compilação real deve ser confirmada pelo GitHub Actions; os testes em dispositivo continuam pendentes, especialmente no POCO X7 Pro com Android 16.
