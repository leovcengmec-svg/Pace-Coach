package org.runnerup.util;

/** Resolves the active duration between two stored GPS samples, in milliseconds. */
public final class ActivityElapsedTime {
  private ActivityElapsedTime() {}

  /**
   * Uses Tracker's monotonic active-time values whenever both samples have them.
   * Wall-clock timestamps are a compatibility fallback for GPX imports and old
   * records. A malformed/reset elapsed value also falls back for that segment.
   */
  public static long segmentDurationMillis(
      long currentElapsedMs,
      long previousElapsedMs,
      long currentWallTimeMs,
      long previousWallTimeMs) {
    if (currentElapsedMs >= 0L && previousElapsedMs >= 0L) {
      long elapsedDifference = currentElapsedMs - previousElapsedMs;
      if (elapsedDifference >= 0L) return elapsedDifference;
    }
    return currentWallTimeMs - previousWallTimeMs;
  }
}
