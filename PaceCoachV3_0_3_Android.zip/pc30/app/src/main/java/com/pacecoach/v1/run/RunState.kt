package com.pacecoach.v1.run

data class RunState(
    val elapsedSeconds: Long = 0,
    val distanceMeters: Double = 0.0,
    val paceSecondsPerKm: Double? = null,
    val targetPaceSecondsPerKm: Int = 300
)
