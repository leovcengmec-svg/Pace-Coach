# Pace Coach V5.0

V5.0 fecha a primeira camada visual do fluxo de treino estruturado sobre o motor RunnerUp.

## Fluxo visual
Dashboard → Treino estruturado → Visualização do treino → Edição → Áudio → Iniciar → Tela de corrida.

## Preservado
- Motor RunnerUp para GPS, distância, tempo, pace, áudio e execução.
- Preview do treino antes de iniciar.
- Edição dos blocos existente.
- Configuração de áudio existente.
- Pace mínimo/máximo por bloco da V4.2/V4.3.
- Camadas de áudio Geral / Intervalo / Atual da V4.3.
- Compatibilidade de build do ambiente GitHub Actions já ajustado.

## V5.0 visual
- Sequência vertical em cartões de largura total.
- Cabeçalho orientado à visualização do treino.
- Resumo de etapas, distância e guia de pace.
- Ações Editar e Iniciar com hierarquia clara.
- Editor com linguagem de blocos/sequência.

V5.0 é uma evolução visual sobre V4.3; não substitui o motor de execução.

## Compartilhamento dinâmico (29/09/2026)
- Galeria com 11 modelos de cards gerados a partir dos dados da atividade selecionada; não usa imagens prontas como resultado final.
- Formatos 4:5, 9:16 e 1:1 com ajuste de escala/posicionamento para reduzir cortes.
- Compartilhar PNG ou copiar a imagem gerada para a área de transferência, para colar em aplicativos compatíveis.
- Fundo sólido escuro como padrão; transparência opcional para sobrepor o card em uma foto.
- Correção da apresentação de duração: o banco guarda duração em segundos, então os cards agora mostram MM:SS ou HH:MM:SS conforme necessário.
