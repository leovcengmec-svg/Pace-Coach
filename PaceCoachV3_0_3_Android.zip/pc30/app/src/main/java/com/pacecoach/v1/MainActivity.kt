package com.pacecoach.v1

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.pacecoach.v1.run.*

class MainActivity : ComponentActivity() {
    private lateinit var paceTarget: EditText
    private lateinit var mode: Spinner
    private lateinit var interval: EditText
    private lateinit var margin: EditText
    private lateinit var intervalLabel: TextView
    private lateinit var status: TextView
    private lateinit var pace: TextView
    private lateinit var distance: TextView
    private lateinit var time: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var workoutName: EditText
    private lateinit var warmupMin: EditText
    private lateinit var runDistance: EditText
    private lateinit var repetitions: EditText
    private lateinit var runPace: EditText
    private lateinit var recoverySec: EditText
    private lateinit var cooldownMin: EditText
    private lateinit var workoutSummary: TextView
    private lateinit var activeStep: TextView
    private lateinit var executionStatus: TextView

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                RunService.ACTION_STATE -> {
                    val running = intent.getBooleanExtra(RunService.EXTRA_RUNNING, false)
                    startButton.isEnabled = !running
                    stopButton.isEnabled = running
                    status.text = if (running) "Corrida em andamento" else "Pronto para iniciar"
                }
                RunService.ACTION_UPDATE -> {
                    val paceSeconds = intent.getDoubleExtra(RunService.EXTRA_PACE_SECONDS, -1.0)
                    val distanceMeters = intent.getDoubleExtra(RunService.EXTRA_DISTANCE_METERS, 0.0)
                    val elapsed = intent.getLongExtra(RunService.EXTRA_ELAPSED_SECONDS, 0L)
                    if (paceSeconds > 0) pace.text = formatPace(paceSeconds) + " /km"
                    distance.text = if (distanceMeters < 1000) "${distanceMeters.toInt()} m" else String.format("%.2f km", distanceMeters / 1000.0)
                    time.text = formatTime(elapsed)
                }
                RunService.ACTION_WORKOUT_UPDATE -> {
                    val label = intent.getStringExtra(RunService.EXTRA_WORKOUT_LABEL).orEmpty()
                    val rep = intent.getIntExtra(RunService.EXTRA_WORKOUT_REPETITION, 1)
                    activeStep.text = "Etapa ativa: $label"
                    executionStatus.text = "Repetição $rep"
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        paceTarget = findViewById(R.id.paceTarget)
        mode = findViewById(R.id.announcementMode)
        interval = findViewById(R.id.announcementInterval)
        margin = findViewById(R.id.targetMargin)
        intervalLabel = findViewById(R.id.intervalLabel)
        status = findViewById(R.id.status)
        pace = findViewById(R.id.pace)
        distance = findViewById(R.id.distance)
        time = findViewById(R.id.time)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)
        workoutName = findViewById(R.id.workoutName)
        warmupMin = findViewById(R.id.warmupMin)
        runDistance = findViewById(R.id.runDistance)
        repetitions = findViewById(R.id.repetitions)
        runPace = findViewById(R.id.runPace)
        recoverySec = findViewById(R.id.recoverySec)
        cooldownMin = findViewById(R.id.cooldownMin)
        workoutSummary = findViewById(R.id.workoutSummary)
        activeStep = findViewById(R.id.activeStep)
        executionStatus = findViewById(R.id.executionStatus)

        mode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("Distância", "Tempo"))
        mode.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                intervalLabel.text = if (position == 0) "Intervalo (metros)" else "Intervalo (segundos)"
                interval.setText(if (position == 0) "100" else "20")
            }
        }
        findViewById<Button>(R.id.buildWorkout).setOnClickListener { buildWorkout() }
        findViewById<Button>(R.id.exampleWorkout).setOnClickListener { loadExample() }
        startButton.setOnClickListener { startRun() }
        stopButton.setOnClickListener { stopRun() }
        findViewById<Button>(R.id.startWorkout).setOnClickListener { startStructuredWorkout() }
    }

    private fun loadExample() {
        val w = ExampleWorkouts.interval4x1k()
        workoutName.setText(w.name)
        warmupMin.setText("10")
        runDistance.setText("1000")
        repetitions.setText("4")
        runPace.setText("4:50")
        recoverySec.setText("120")
        cooldownMin.setText("10")
        showWorkout(w)
    }

    private fun buildWorkout() {
        try {
            val name = workoutName.text.toString().ifBlank { "Meu treino" }
            val warm = warmupMin.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
            val dist = runDistance.text.toString().toFloatOrNull()?.coerceAtLeast(1f) ?: throw IllegalArgumentException("Distância inválida")
            val reps = repetitions.text.toString().toIntOrNull()?.coerceIn(1, 20) ?: throw IllegalArgumentException("Repetições inválidas")
            val pace = parsePace(runPace.text.toString()) ?: throw IllegalArgumentException("Pace do tiro inválido")
            val recovery = recoverySec.text.toString().toLongOrNull()?.coerceAtLeast(1) ?: throw IllegalArgumentException("Recuperação inválida")
            val cooldown = cooldownMin.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 0
            val builder = WorkoutBuilder(name)
            if (warm > 0) builder.addTimeStep(StepKind.WARMUP, warm * 60, label = "Aquecimento")
            builder.addIntervalBlock(runDistanceMeters = dist, runTargetPaceSeconds = pace, runLabel = "Tiro", recoveryDurationSeconds = recovery, recoveryLabel = "Recuperação", repeats = reps)
            if (cooldown > 0) builder.addTimeStep(StepKind.COOLDOWN, cooldown * 60, label = "Desaquecimento")
            val workout = builder.build()
            WorkoutRepository.save(workout)
            showWorkout(workout)
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "Não foi possível montar o treino", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showWorkout(w: StructuredWorkout) {
        WorkoutRepository.save(w)
        workoutSummary.text = w.steps.joinToString("\n") { s ->
            val target = s.targetPaceSeconds?.let { " @ ${CoachMessageFormatter.formatPace(it)}/km" } ?: ""
            "${s.kind}: ${s.label}$target"
        }
    }

    private fun startRun() {
        if (!hasLocationPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQUEST_LOCATION)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
        }
        val target = parsePace(paceTarget.text.toString()) ?: run { status.text = "Pace inválido. Use, por exemplo, 5:00."; return }
        val intervalValue = interval.text.toString().toDoubleOrNull()?.coerceIn(5.0, 5000.0) ?: 100.0
        val marginValue = margin.text.toString().toIntOrNull()?.coerceIn(0, 60) ?: 5
        ContextCompat.startForegroundService(this, Intent(this, RunService::class.java).apply {
            action = RunService.ACTION_START
            putExtra(RunService.EXTRA_TARGET_PACE_SECONDS, target)
            putExtra(RunService.EXTRA_ANNOUNCE_MODE, if (mode.selectedItemPosition == 0) RunService.MODE_DISTANCE else RunService.MODE_TIME)
            putExtra(RunService.EXTRA_ANNOUNCE_INTERVAL, intervalValue)
            putExtra(RunService.EXTRA_TARGET_MARGIN, marginValue)
        })
    }

    private fun startStructuredWorkout() {
        if (!hasLocationPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQUEST_LOCATION)
            return
        }
        if (WorkoutRepository.all().isEmpty()) buildWorkout()
        val target = parsePace(paceTarget.text.toString()) ?: 300
        val intervalValue = interval.text.toString().toDoubleOrNull()?.coerceIn(5.0, 5000.0) ?: 100.0
        val marginValue = margin.text.toString().toIntOrNull()?.coerceIn(0, 60) ?: 5
        ContextCompat.startForegroundService(this, Intent(this, RunService::class.java).apply {
            action = RunService.ACTION_START_WORKOUT
            putExtra(RunService.EXTRA_TARGET_PACE_SECONDS, target)
            putExtra(RunService.EXTRA_ANNOUNCE_MODE, if (mode.selectedItemPosition == 0) RunService.MODE_DISTANCE else RunService.MODE_TIME)
            putExtra(RunService.EXTRA_ANNOUNCE_INTERVAL, intervalValue)
            putExtra(RunService.EXTRA_TARGET_MARGIN, marginValue)
        })
    }

    private fun stopRun() { stopService(Intent(this, RunService::class.java)) }
    private fun hasLocationPermission() = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    private fun parsePace(value: String): Int? {
        val clean = value.trim()
        if (clean.contains(":")) {
            val p = clean.split(":")
            if (p.size != 2) return null
            val m = p[0].toIntOrNull() ?: return null
            val s = p[1].toIntOrNull() ?: return null
            if (m < 1 || s !in 0..59) return null
            return m * 60 + s
        }
        val decimal = clean.replace(",", ".").toDoubleOrNull() ?: return null
        return (decimal * 60).toInt().takeIf { it in 180..900 }
    }
    private fun formatPace(sec: Double) = String.format("%02d:%02d", sec.toInt() / 60, sec.toInt() % 60)
    private fun formatTime(total: Long) = String.format("%02d:%02d", total / 60, total % 60)
    override fun onStart() { super.onStart(); ContextCompat.registerReceiver(this, receiver, IntentFilter().apply { addAction(RunService.ACTION_UPDATE); addAction(RunService.ACTION_STATE); addAction(RunService.ACTION_WORKOUT_UPDATE) }, ContextCompat.RECEIVER_NOT_EXPORTED) }
    override fun onStop() { unregisterReceiver(receiver); super.onStop() }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) { super.onRequestPermissionsResult(requestCode, permissions, grantResults); if (requestCode == REQUEST_LOCATION && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) startRun() }
    companion object { private const val REQUEST_LOCATION = 100; private const val REQUEST_NOTIFICATIONS = 101 }
}
