# Pace Coach V2.5

Integração real do coach estruturado ao `RunService`.

## O que foi conectado
- GPS real -> PaceCalculator -> RunServiceCoachAdapter -> CoachController -> VoiceCoach.
- A corrida livre passa a ser representada internamente como um bloco `RUN` com o alvo informado pelo usuário.
- Mudanças de estado do alvo e mensagens de GPS instável podem ser faladas pelo coach.
- Mantidos os anúncios periódicos por distância ou tempo.
- `WorkoutExecutor` agora expõe tempo/distância do bloco.
- Corrigido o cálculo de estado de execução e um erro de referência em `WorkoutVoice`.

## Limitação importante
Ainda não foi gerado APK neste ambiente. A validação feita aqui é de inspeção/edição do código e testes unitários preparados; a compilação Android precisa ser feita em ambiente com Android SDK/Gradle, por exemplo via GitHub Actions na próxima etapa.
