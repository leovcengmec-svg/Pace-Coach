@echo off
setlocal EnableExtensions EnableDelayedExpansion

title Pace Coach - Permissoes de Desenvolvimento

echo ============================================================
echo   Pace Coach - Concessao de permissoes para desenvolvimento
echo ============================================================
echo.

where adb >nul 2>&1
if errorlevel 1 (
  echo ERRO: ADB nao foi encontrado no PATH.
  echo Instale o Android SDK Platform-Tools e adicione a pasta ao PATH.
  echo.
  pause
  exit /b 1
)

adb start-server >nul 2>&1

set "FOUND=0"
for /f "tokens=2 delims=:" %%P in ('adb shell pm list packages ^| findstr /i "org.runnerup"') do (
  set "PACKAGE=%%P"
  set "FOUND=1"
  echo ============================================================
  echo Aplicando permissoes em: !PACKAGE!
  echo ============================================================
  adb shell pm grant !PACKAGE! android.permission.ACCESS_COARSE_LOCATION
  adb shell pm grant !PACKAGE! android.permission.ACCESS_FINE_LOCATION
  adb shell pm grant !PACKAGE! android.permission.ACCESS_BACKGROUND_LOCATION
  adb shell appops set !PACKAGE! ACCESS_BACKGROUND_LOCATION allow >nul 2>&1
  adb shell pm grant !PACKAGE! android.permission.ACTIVITY_RECOGNITION
  adb shell appops set !PACKAGE! ACTIVITY_RECOGNITION allow >nul 2>&1
  adb shell pm grant !PACKAGE! android.permission.POST_NOTIFICATIONS
  adb shell appops set !PACKAGE! POST_NOTIFICATION allow >nul 2>&1
  adb shell pm grant !PACKAGE! android.permission.BLUETOOTH_SCAN
  adb shell pm grant !PACKAGE! android.permission.BLUETOOTH_CONNECT
  adb shell appops set !PACKAGE! BLUETOOTH_SCAN allow >nul 2>&1
  adb shell appops set !PACKAGE! BLUETOOTH_CONNECT allow >nul 2>&1
  echo.
  echo Resultado das permissoes de !PACKAGE!:
  adb shell dumpsys package !PACKAGE! | findstr /i "ACCESS_COARSE_LOCATION ACCESS_FINE_LOCATION ACCESS_BACKGROUND_LOCATION ACTIVITY_RECOGNITION POST_NOTIFICATIONS BLUETOOTH_SCAN BLUETOOTH_CONNECT"
  echo.
)

if "%FOUND%"=="0" (
  echo ERRO: nenhum pacote org.runnerup foi encontrado no dispositivo.
  echo.
  echo Pacotes instalados que contenham RunnerUp:
  adb shell pm list packages | findstr /i "runnerup"
  echo.
  echo Instale o APK de desenvolvimento primeiro e execute este BAT novamente.
  echo.
  pause
  exit /b 1
)

echo.
echo ============================================================
echo Processo concluido para: %PACKAGE%
echo ============================================================
echo.
echo Se alguma permissao continuar negada, o Android informou que ela
echo nao pode ser concedida automaticamente por ADB nesta versao.
echo Nesse caso, somente essa permissao precisa ser autorizada manualmente.
echo.
pause
endlocal
