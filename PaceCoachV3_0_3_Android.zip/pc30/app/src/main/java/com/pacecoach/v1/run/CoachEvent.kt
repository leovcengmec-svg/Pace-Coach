package com.pacecoach.v1.run

sealed class CoachEvent {
    data class Speak(val text: String) : CoachEvent()
    data class StepChanged(val step: ActiveStep) : CoachEvent()
    data class Finished(val message: String? = null) : CoachEvent()
    data object GpsUncertain : CoachEvent()
    data object None : CoachEvent()
}
