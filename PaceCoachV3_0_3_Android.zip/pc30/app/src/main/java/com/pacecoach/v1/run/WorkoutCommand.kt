package com.pacecoach.v1.run

sealed class WorkoutCommand {
    data class Speak(val text: String) : WorkoutCommand()
    data class TargetPace(val secondsPerKm: Int) : WorkoutCommand()
    data object Finish : WorkoutCommand()
}
