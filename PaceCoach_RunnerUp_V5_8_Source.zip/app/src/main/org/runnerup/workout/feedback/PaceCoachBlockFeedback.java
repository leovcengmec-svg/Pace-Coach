/*
 * Copyright (C) 2026 Pace Coach contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */
package org.runnerup.workout.feedback;

import android.content.Context;
import java.util.HashMap;
import org.runnerup.workout.Dimension;
import org.runnerup.workout.Feedback;
import org.runnerup.workout.Range;
import org.runnerup.workout.Scope;
import org.runnerup.workout.Step;
import org.runnerup.workout.Workout;

/** Spoken block information/result for Pace Coach structured workouts. */
public class PaceCoachBlockFeedback extends Feedback {
  private final Step step;
  private final boolean finalAnnouncement;
  private RUTextToSpeech textToSpeech;

  public PaceCoachBlockFeedback(Step step, boolean finalAnnouncement, Step previousStep) {
    this.step = step;
    this.finalAnnouncement = finalAnnouncement;
  }

  @Override
  public void onBind(Workout w, HashMap<String, Object> bindValues) {
    super.onBind(w, bindValues);
    if (bindValues.containsKey(Workout.KEY_TTS)) {
      textToSpeech = (RUTextToSpeech) bindValues.get(Workout.KEY_TTS);
    }
  }

  @Override
  public boolean equals(Feedback other) {
    if (!(other instanceof PaceCoachBlockFeedback that)) return false;
    return step == that.step && finalAnnouncement == that.finalAnnouncement;
  }

  @Override
  public void emit(Workout w, Context ctx) {
    if (textToSpeech == null || step == null) return;

    if (!finalAnnouncement) {
      StringBuilder msg = new StringBuilder();
      appendBlockDescription(msg);
      String previous = w.getPaceCoachLastBlockResult();
      if (previous != null && !previous.isEmpty()) {
        msg.append(", ").append(previous);
      }
      textToSpeech.speak(msg.toString(), UtterancePrio.PRIO_COUNTDOWN, true, null);
      return;
    }

    String result = evaluateResult(w);
    if (result == null) return;
    w.setPaceCoachLastBlockResult(blockName() + " " + result);
    textToSpeech.speak(blockName() + " " + result, UtterancePrio.PRIO_COACH, true, null);
  }

  private void appendBlockDescription(StringBuilder msg) {
    msg.append(blockName()).append(", ").append(rhythmName(step.getCoachRhythm()));
    if (step.getDurationType() == Dimension.TIME) {
      msg.append(", ").append(formatTime(step.getDurationValue()));
    } else if (step.getDurationType() == Dimension.DISTANCE) {
      msg.append(", ").append(formatDistance(step.getDurationValue()));
    }
    Range target = step.getTargetValue();
    if (step.getTargetType() == Dimension.PACE && target != null) {
      msg.append(", Ritmo Alvo, ")
          .append(formatPace(target.minValue * 1000.0))
          .append(" a ")
          .append(formatPace(target.maxValue * 1000.0));
    }
  }

  private String evaluateResult(Workout w) {
    if (step.getTargetType() != Dimension.PACE || step.getTargetValue() == null) return null;
    double pace = w.get(Scope.STEP, Dimension.PACE);
    if (!(pace > 0) || Double.isNaN(pace) || Double.isInfinite(pace)) return null;
    Range target = step.getTargetValue();
    double fast = Math.min(target.minValue, target.maxValue);
    double slow = Math.max(target.minValue, target.maxValue);
    if (pace >= fast && pace <= slow) return "no alvo";
    if (pace < fast) return "acima do alvo";
    return "fora do alvo";
  }

  private String blockName() {
    if (step.getName() != null && !step.getName().trim().isEmpty()) return step.getName().trim();
    switch (step.getIntensity()) {
      case WARMUP: return "Aquecimento";
      case COOLDOWN: return "Desaquecimento";
      case RECOVERY: return "Recuperação";
      case RESTING: return "Intervalo";
      case ACTIVE: return "Intervalo";
      default: return "Bloco";
    }
  }

  private static String rhythmName(int rhythm) {
    if (rhythm == 0) return "devagar";
    if (rhythm == 2) return "rápido";
    return "constante";
  }

  private static String formatDistance(double meters) {
    double km = Math.max(0, meters) / 1000.0;
    if (Math.abs(km - Math.rint(km)) < 0.0001) return String.format(java.util.Locale.US, "%.0f km", km);
    return String.format(java.util.Locale.US, "%.1f km", km);
  }

  private static String formatTime(double seconds) {
    long total = Math.max(0, Math.round(seconds));
    long hours = total / 3600L;
    long minutes = (total % 3600L) / 60L;
    long secs = total % 60L;
    if (hours > 0) return hours + " horas" + (minutes > 0 ? " e " + minutes + " minutos" : "");
    if (minutes > 0 && secs == 0) return minutes + " minutos";
    if (minutes > 0) return minutes + " minutos e " + secs + " segundos";
    return secs + " segundos";
  }

  private static String formatPace(double secondsPerKm) {
    long total = Math.max(0, Math.round(secondsPerKm));
    return (total / 60L) + " e " + (total % 60L);
  }
}
