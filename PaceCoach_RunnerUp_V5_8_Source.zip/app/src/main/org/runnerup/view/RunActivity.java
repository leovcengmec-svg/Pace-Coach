/*
 * Copyright (C) 2012 - 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.view;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.location.Location;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.preference.PreferenceManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import org.runnerup.BuildConfig;
import org.runnerup.R;
import org.runnerup.common.tracker.TrackerState;
import org.runnerup.common.util.Constants;
import org.runnerup.db.DBHelper;
import org.runnerup.tracker.Tracker;
import org.runnerup.tracker.GpsStatus;
import org.runnerup.tracker.GpsSignalState;
import org.runnerup.tracker.component.TrackerHRM;
import org.runnerup.util.Formatter;
import org.runnerup.util.MapWrapper;
import org.runnerup.util.TickListener;
import org.runnerup.util.ViewUtil;
import org.runnerup.workout.Dimension;
import org.runnerup.workout.Intensity;
import org.runnerup.workout.Scope;
import org.runnerup.workout.Step;
import org.runnerup.workout.Workout;
import org.runnerup.workout.WorkoutStepListener;
import org.runnerup.workout.WorkoutBuilder;
import org.runnerup.workout.WorkoutSerializer;

public class RunActivity extends AppCompatActivity implements TickListener {
  private Workout workout = null;
  private boolean previewOnly = false;
  private boolean previewStartPending = false;
  // True when this RunActivity is reopening a workout that was intentionally
  // left PAUSED by the Pace Coach review screen. This path has a stricter
  // binding sequence than a normal first-time execution.
  private boolean reopeningExistingWorkout = false;
  // Stable callback instance so delayed preview-start retries can always be cancelled.
  private final Runnable previewStartRunnable = () -> attemptStartPreviewWorkout();
  private Tracker mTracker = null;
  private GpsStatus runGpsStatus = null;
  private TextView runGpsHeaderDot = null;
  private TextView runGpsHeaderLevel = null;
  private android.widget.LinearLayout runGpsHeaderBars = null;
  private final Handler handler = new Handler();

  private android.widget.ImageButton pauseButton = null;
  private android.widget.ImageButton newLapButton = null;
  private android.widget.ImageButton voiceButton = null;
  private TextView voiceLabel = null;
  private boolean voiceEnabled = true;
  private TextView activityTime = null;
  private TextView activityDistance = null;
  private TextView activityPace = null;
  private TextView lapTime = null;
  private TextView lapDistance = null;
  private TextView lapPace = null;
  private TextView intervalTime = null;
  private TextView intervalDistance = null;
  private TextView intervalPace = null;
  private TextView coachRunPace = null;
  private TextView coachRunTarget = null;
  private TextView coachRunState = null;
  private TextView coachRunDifference = null;
  private TextView coachRunIndicatorFast = null;
  private TextView coachRunIndicatorTarget = null;
  private TextView coachRunIndicatorSlow = null;
  private View coachRunBarFast = null;
  private View coachRunBarTarget = null;
  private View coachRunBarSlow = null;
  private TextView coachRunStep = null;
  private TextView coachRunStepEffort = null;
  private TextView coachRunStepProgress = null;
  private android.widget.ProgressBar coachRunFreeProgress = null;
  private TextView coachRunNextStep = null;
  private TextView coachRunNextTarget = null;
  private TextView coachRunRemainingTime = null;
  private TextView coachRunRemainingDistance = null;
  private TextView coachRunTargetSummary = null;
  private TextView coachRunActivityHrVisible = null;
  private TextView coachRunIntervalDistanceVisible = null;
  private TextView coachRunIntervalTimeVisible = null;
  private TextView countdownView = null;
  private ListView workoutList = null;
  private View tableRowInterval = null;
  private org.runnerup.workout.Step currentStep = null;

  private Formatter formatter = null;
  private TextView activityHr;
  private TextView lapHr;
  private TextView intervalHr;
  private TextView activityHeaderHr;
  private TextView hrDebug;
  private MapWrapper mapWrapper = null;
  private SQLiteDatabase mapDb = null;
  private long lastMapRefresh = 0L;
  // A circular buffer for tap events
  private final long[] mTapArray = {0, 0, 0, 0};
  private int mTapIndex = 0;

  class WorkoutRow {
    org.runnerup.workout.Step step = null;
    ContentValues lap = null;
    public int level;
  }

  private final ArrayList<WorkoutRow> workoutRows = new ArrayList<>();

  // The execution UI observes the Workout's authoritative current-step state.
  // This listener is shared by Livre/Intervalado/Estruturado and guarantees
  // that the block cards are refreshed at the exact transition, instead of
  // waiting for a later timer tick.
  private final WorkoutStepListener coachWorkoutStepListener =
      (oldStep, newStep) ->
          handler.post(
              () -> {
                if (isFinishing() || isDestroyed() || workout == null) return;
                // The Workout is the single source of truth. Let the normal UI
                // refresh path render the new current/next block and selection.
                currentStep = newStep;
                updateView();
              });

  @Override
  public void onCreate(Bundle savedInstanceState) {
    EdgeToEdge.enable(this);
    Window window = getWindow();
    WindowCompat.getInsetsController(window, window.getDecorView())
        .setAppearanceLightStatusBars(false);
    super.onCreate(savedInstanceState);
    getWindow().setStatusBarColor(android.graphics.Color.parseColor("#020C16"));
    getWindow().setNavigationBarColor(android.graphics.Color.parseColor("#020C16"));
    previewOnly = getIntent().getBooleanExtra("PREVIEW_ONLY", false);
    reopeningExistingWorkout = getIntent().getBooleanExtra("REOPEN_EXISTING_WORKOUT", false);
    if (getSupportActionBar() != null) {
      getSupportActionBar().hide();
    }
    if (!isLargeScreen()) {
      setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }
    if (BuildConfig.OSMDROID_ENABLED || BuildConfig.MAPBOX_ENABLED) {
      MapWrapper.start(this);
    }
    setContentView(R.layout.run);
    final View runScroll = findViewById(R.id.run_scroll);
    ViewCompat.setOnApplyWindowInsetsListener(runScroll, (view, insets) -> {
      // start_view already receives the status-bar inset as a top margin.
      // Keep only the intentional design padding here to avoid double top spacing.
      int topInset = insets.getInsets(WindowInsetsCompat.Type.systemBars()).top;
      int bottomInset = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom;
      view.setPadding(view.getPaddingLeft(), topInset + 6, view.getPaddingRight(), 6);
      View controls = findViewById(R.id.run_controls);
      if (controls != null) {
        controls.setPadding(controls.getPaddingLeft(), controls.getPaddingTop(), controls.getPaddingRight(), Math.max(4, bottomInset + 4));
      }
      return insets;
    });
    ViewCompat.requestApplyInsets(runScroll);
    formatter = new Formatter(this);
    runGpsHeaderDot = findViewById(R.id.run_gps_header_dot);
    runGpsHeaderLevel = findViewById(R.id.run_gps_header_level);
    runGpsHeaderBars = findViewById(R.id.run_gps_header_bars);
    runGpsStatus = new GpsStatus(this);
    updateRunGpsHeader();
    // HRZones hrZones = new HRZones(this);
    TextView velocity = findViewById(R.id.velocity_label);
    velocity.setText(formatter.formatVelocityLabel());

    final android.widget.ImageButton stopButton = findViewById(R.id.stop_button);
    stopButton.setOnClickListener(stopButtonClick);
    pauseButton = findViewById(R.id.pause_button);
    pauseButton.setOnClickListener(pauseButtonClick);
    voiceButton = findViewById(R.id.run_voice_button);
    voiceLabel = findViewById(R.id.run_voice_label);
    voiceButton.setOnClickListener(v -> setVoiceEnabled(!voiceEnabled));
    setVoiceEnabled(true);
    newLapButton = findViewById(R.id.new_lap_button);
    newLapButton.setOnClickListener(newLapButtonClick);
    android.view.View runSettingsButton = findViewById(R.id.run_settings_button);
    // The CONFIG. button in the execution screen opens the audio-announcement
    // settings directly. It must not leave the workout execution flow or open
    // the application's general settings.
    runSettingsButton.setOnClickListener(v -> {
      Intent intent = new Intent(RunActivity.this, AudioCueSettingsActivity.class);
      startActivity(intent);
    });
    activityHeaderHr = findViewById(R.id.activity_header_hr);
    activityTime = findViewById(R.id.run_activity_time);
    activityDistance = findViewById(R.id.run_activity_distance);
    activityPace = findViewById(R.id.run_activity_pace);
    activityHr = findViewById(R.id.activity_hr);
    lapTime = findViewById(R.id.lap_time);
    lapDistance = findViewById(R.id.lap_distance);
    lapPace = findViewById(R.id.lap_pace);
    lapHr = findViewById(R.id.lap_hr);
    intervalTime = findViewById(R.id.run_interval_time);
    intervalDistance = findViewById(R.id.intervall_distance);
    tableRowInterval = findViewById(R.id.table_row_interval);
    intervalPace = findViewById(R.id.interval_pace);
    intervalHr = findViewById(R.id.interval_hr);
    coachRunPace = findViewById(R.id.coach_run_pace);
    coachRunTarget = findViewById(R.id.coach_run_target);
    coachRunState = findViewById(R.id.coach_run_state);
    coachRunDifference = findViewById(R.id.coach_run_difference);
    coachRunIndicatorFast = findViewById(R.id.coach_run_indicator_fast);
    coachRunIndicatorTarget = findViewById(R.id.coach_run_indicator_target);
    coachRunIndicatorSlow = findViewById(R.id.coach_run_indicator_slow);
    coachRunBarFast = findViewById(R.id.coach_run_bar_fast);
    coachRunBarTarget = findViewById(R.id.coach_run_bar_target);
    coachRunBarSlow = findViewById(R.id.coach_run_bar_slow);
    coachRunStep = findViewById(R.id.coach_run_step_label);
    coachRunStepEffort = findViewById(R.id.coach_run_step_effort);
    coachRunStepProgress = findViewById(R.id.coach_run_step_progress);
    coachRunFreeProgress = findViewById(R.id.coach_run_free_progress);
    coachRunNextStep = findViewById(R.id.coach_run_next_step);
    coachRunNextTarget = findViewById(R.id.coach_run_next_target);
    coachRunRemainingTime = findViewById(R.id.coach_run_remaining_time);
    coachRunRemainingDistance = findViewById(R.id.coach_run_remaining_distance);
    coachRunTargetSummary = findViewById(R.id.coach_run_target_summary);
    coachRunActivityHrVisible = findViewById(R.id.activity_hr_visible);
    coachRunIntervalDistanceVisible = findViewById(R.id.run_interval_distance_visible);
    coachRunIntervalTimeVisible = findViewById(R.id.run_interval_time_visible);
    countdownView = findViewById(R.id.countdown_text_view);
    workoutList = findViewById(R.id.workout_list);
    hrDebug = findViewById(R.id.hr_debug);
    if (BuildConfig.OSMDROID_ENABLED || BuildConfig.MAPBOX_ENABLED) {
      mapDb = DBHelper.getReadableDatabase(this);
    }
    WorkoutAdapter adapter = new WorkoutAdapter(workoutRows);
    workoutList.setAdapter(adapter);

    final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);

    // Preview mode is deliberately isolated from the Tracker service.
    // "Corrida" only displays the configured Treino Livre; it must not start
    // GPS, bind the tracker, run timers, or execute workout callbacks.
    if (previewOnly) {
      Dimension previewTarget = Dimension.TIME;
      String targetName = getIntent().getStringExtra("PREVIEW_TARGET");
      if (targetName != null) {
        try {
          Dimension requested = Dimension.valueOf(targetName);
          if (requested == Dimension.TIME || requested == Dimension.DISTANCE) {
            previewTarget = requested;
          }
        } catch (IllegalArgumentException ignored) {
          // Keep TIME as the safe default.
        }
      }

      String previewKind = getIntent().getStringExtra("PREVIEW_KIND");
      if ("interval".equals(previewKind)) {
        workout = WorkoutBuilder.createDefaultIntervalWorkout(getResources(), prefs);
      } else if ("advanced".equals(previewKind)) {
        // Treino Estruturado is loaded from the exact saved workout selected
        // in the structured-workout workspace. It must use the same execution
        // engine as Livre and Intervalado; only the prescription source differs.
        String workoutName = getIntent().getStringExtra("PREVIEW_ADVANCED_NAME");
        try {
          workout = workoutName == null ? null : WorkoutSerializer.readFile(this, workoutName);
        } catch (Exception ignored) {
          workout = null;
        }
      } else {
        workout = WorkoutBuilder.createDefaultWorkout(getResources(), prefs, previewTarget);
        applyPreviewWorkoutConfiguration(workout, previewTarget);
      }
      if (workout == null) {
        Toast.makeText(this, "Não foi possível carregar o treino", Toast.LENGTH_SHORT).show();
        finish();
        return;
      }
      WorkoutBuilder.prepareWorkout(getResources(), prefs, workout);
      // The preview reconstructs the workout locally, so its audio triggers must
      // be attached here as well. Without this, the execution screen has the
      // visual prescription but no voice announcements when PLAY is pressed.
      // The execution engine is shared by all three workout types, but each
      // workspace keeps its own audio configuration. In particular, structured
      // workouts must not silently inherit Treino Livre voice preferences.
      String audioKey = getString(R.string.pref_basic_audio);
      if ("interval".equals(previewKind)) {
        audioKey = getString(R.string.pref_interval_audio);
      } else if ("advanced".equals(previewKind)) {
        audioKey = getString(R.string.pref_advanced_audio);
      }
      SharedPreferences audioPrefs =
          WorkoutBuilder.getAudioCuePreferences(this, prefs, audioKey);
      WorkoutBuilder.addAudioCuesToWorkout(getResources(), workout, audioPrefs, prefs);
      populateWorkoutList();
      currentStep = workout.getCurrentStep();
      // In the pre-start Treino Livre preview there is no tracker-bound current
      // step yet. Rule 1 requires the cards to be populated immediately from
      // the first (and in this case complete) prescription block.
      if (currentStep == null && !workout.getStepList().isEmpty()) {
        currentStep = workout.getStepList().get(0).step();
      }

      // Do not call Workout.onBind() in preview. The countdown binding belongs
      // to an executing workout and is unnecessary for a screen-only preview.
      newLapButton.setOnClickListener(v -> finish());
      newLapButton.setImageResource(R.drawable.ic_coach_back_double);
      newLapButton.setScaleType(android.widget.ImageView.ScaleType.CENTER);
      newLapButton.setPadding(0, 0, 0, 0);

      // The approved layout always shows all three controls, even before the
      // workout starts. In preview, Finish simply leaves the preview.
      stopButton.setVisibility(View.VISIBLE);
      stopButton.setImageResource(org.runnerup.common.R.drawable.ic_av_stop);
      stopButton.setScaleType(android.widget.ImageView.ScaleType.CENTER);
      stopButton.setPadding(0, 0, 0, 0);
      stopButton.setOnClickListener(v -> finish());
      pauseButton.setImageResource(R.drawable.ic_run_play_centered);
      pauseButton.setScaleType(android.widget.ImageView.ScaleType.CENTER);
      pauseButton.setPadding(0, 0, 0, 0);
      pauseButton.setOnClickListener(v -> startPreviewWorkout());

      // Populate only the static values needed by the interface. No tracker
      // state, GPS, map, timer or notification is touched in preview mode.
      activityTime.setText(formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, 0));
      activityDistance.setText(formatter.formatDistance(Formatter.Format.TXT_SHORT, 0));
      activityPace.setText(formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_SHORT, 0));
      lapTime.setText(formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, 0));
      lapDistance.setText(formatter.formatDistance(Formatter.Format.TXT_LONG, 0));
      lapPace.setText(formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_SHORT, 0));
      if (tableRowInterval != null) tableRowInterval.setVisibility(View.GONE);
      activityHr.setVisibility(View.GONE);
      lapHr.setVisibility(View.GONE);
      intervalHr.setVisibility(View.GONE);
      activityHeaderHr.setVisibility(View.GONE);
      updateCoachRunPanel(0);
      // Populate the Bloco Atual and Próximo Bloco cards immediately in the
      // pre-start preview. They must never depend on tracker execution state.
      updateCoachRunExtraPanel();

      // Do not execute the normal Tracker/lock-screen initialization below.
      return;
    }
    final Resources res = this.getResources();
    final KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
    final boolean active = prefs.getBoolean(res.getString(R.string.pref_lock_run), false);
    final boolean showOnLockScreen =
        prefs.getBoolean(res.getString(R.string.pref_show_on_lock_screen), true);
    final boolean keepScreenOn =
        prefs.getBoolean(res.getString(R.string.pref_keep_screen_on), false);

    if (!prefs.getBoolean(res.getString(R.string.pref_bt_debug), false)) {
      hrDebug = null;
    }

    TableLayout t = findViewById(R.id.table_layout1);
    t.setOnTouchListener(
        (v, event) -> {
          // Detect tapping on the header
          int action = event.getAction();
          if (active && action == MotionEvent.ACTION_DOWN) {
            final int maxTapTime = 1000;
            long time = event.getEventTime();
            if (mTapArray[mTapIndex] != 0 && time - mTapArray[mTapIndex] < maxTapTime) {
              boolean enabled = !pauseButton.isEnabled();
              pauseButton.setEnabled(enabled);
              stopButton.setEnabled(enabled);
              Arrays.fill(mTapArray, 0);
            } else {
              if (mTapIndex == 0) {
                Toast.makeText(
                        getApplicationContext(),
                        res.getString(org.runnerup.common.R.string.Lock_activity_buttons_message),
                        Toast.LENGTH_SHORT)
                    .show();
              }
              mTapArray[mTapIndex] = time;
              mTapIndex = (mTapIndex + 1) % mTapArray.length;
            }
          }
          return false;
        });
    if (!previewOnly) {
      bindGpsTracker();
    }

    getOnBackPressedDispatcher()
        .addCallback(
            this,
            new OnBackPressedCallback(true) {
              @Override
              public void handleOnBackPressed() {
                // Back follows the same safe path as the on-screen VOLTAR button:
                // running -> pause automatically, paused -> keep paused, then
                // return to the main Pace Coach screen without saving/discarding.
                if (km.isKeyguardLocked()) {
                  showOnLockScreen(false);
                  return;
                }
                returnToWorkoutReview();
              }
            });
    ViewUtil.Insets(findViewById(R.id.start_view), true);

    showOnLockScreen(showOnLockScreen);
    if (keepScreenOn) {
      window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    } else {
      window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
  }

  private boolean isLargeScreen() {
    int screenSize =
        getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK;
    return screenSize >= Configuration.SCREENLAYOUT_SIZE_LARGE;
  }

  @Override
  public void onConfigurationChanged(@NonNull Configuration newConfig) {
    super.onConfigurationChanged(newConfig);
    Log.d(getClass().getName(), "onConfigurationChange => do NOTHING!!");
  }

  @Override
  public void onPause() {
    super.onPause();
  }

  @Override
  public void onResume() {
    final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
    final Resources res = this.getResources();
    final boolean showOnLockScreen =
        prefs.getBoolean(res.getString(R.string.pref_show_on_lock_screen), true);

    super.onResume();
    showOnLockScreen(showOnLockScreen);
  }

  @Override
  public void onDestroy() {
    super.onDestroy();
    if (mapWrapper != null) {
      mapWrapper.onDestroy();
      mapWrapper = null;
    }
    if (mapDb != null) {
      DBHelper.closeDB(mapDb);
      mapDb = null;
    }
    stopRunGpsStatus();
    handler.removeCallbacks(previewStartRunnable);
    unregisterCoachWorkoutStepListener();
    unbindGpsTracker();
    stopTimer();
  }

  /**
   * Rebind an already-created workout without replaying the normal startup
   * lifecycle. The Tracker is intentionally PAUSED when RETOMAR TREINO opens
   * this screen. Re-running the generic startup path here was allowing
   * Tracker/Workout callbacks and UI lifecycle callbacks to race, which could
   * terminate the process on resume.
   */
  private void registerCoachWorkoutStepListener() {
    if (workout == null) return;
    try {
      workout.unregisterWorkoutStepListener(coachWorkoutStepListener);
      workout.registerWorkoutStepListener(coachWorkoutStepListener);
    } catch (Throwable ex) {
      Log.w(getClass().getName(), "Unable to register workout step listener", ex);
    }
  }

  private void unregisterCoachWorkoutStepListener() {
    if (workout == null) return;
    try {
      workout.unregisterWorkoutStepListener(coachWorkoutStepListener);
    } catch (Throwable ex) {
      Log.w(getClass().getName(), "Unable to unregister workout step listener", ex);
    }
  }

  private void onExistingWorkoutTrackerBound() {
    if (mTracker == null) {
      Log.e(getClass().getName(), "Existing workout bind returned a null Tracker");
      return;
    }

    workout = mTracker.getWorkout();
    if (workout == null) {
      Log.e(getClass().getName(), "Existing workout bind returned a null Workout");
      return;
    }

    try {
      HashMap<String, Object> bindValues = new HashMap<>();
      bindValues.put(Workout.KEY_COUNTER_VIEW, countdownView);
      workout.onBind(workout, bindValues);
      registerCoachWorkoutStepListener();
      workoutRows.clear();
      populateWorkoutList();
      currentStep = workout.getCurrentStep();

      TrackerState state = mTracker.getState();
      stopTimer();
      setPauseButtonEnabled(state == TrackerState.STARTED && !workout.isPaused());

      // The live Tracker remains the sole owner of GPS. The execution UI only
      // observes it here; it does not reconnect or reset the GPS service.
      startRunGpsStatus();
      updateView();

      // Map initialization is deliberately isolated from the critical resume
      // path. A map/database rendering problem must never close the workout UI.
      try {
        initLiveMap();
      } catch (Throwable mapEx) {
        Log.e(getClass().getName(), "Live map rebind failed", mapEx);
      }

      if (state == TrackerState.STARTED) {
        startTimer();
      }
    } catch (Throwable ex) {
      Log.e(getClass().getName(), "Failed to rebind existing workout", ex);
      // Keep the Tracker alive and leave the activity in a safe paused state
      // instead of allowing an execution-screen binding exception to crash the
      // whole application.
      try {
        if (mTracker.getState() == TrackerState.STARTED) {
          mTracker.pause();
        }
      } catch (Throwable pauseEx) {
        Log.e(getClass().getName(), "Failed to safety-pause Tracker", pauseEx);
      }
      stopTimer();
      setPauseButtonEnabled(false);
    }
  }

  private void onGpsTrackerBound() {
    if (mTracker == null) {
      // should not happen
      return;
    }

    workout = mTracker.getWorkout();
    if (workout == null) {
      // should not happen
      return;
    }

    {
      /*
       * Countdown view can't be bound until RunActivity is started
       *   since it's not created until then
       */
      HashMap<String, Object> bindValues = new HashMap<>();
      bindValues.put(Workout.KEY_COUNTER_VIEW, countdownView);
      workout.onBind(workout, bindValues);
    }

    registerCoachWorkoutStepListener();
    populateWorkoutList();
    newLapButton.setOnClickListener(newLapButtonClick);

    if (!previewOnly) {
      // Normal entry: the tracker has already been started by StartFragment.
      startTimer();
      // Re-opening a workout from the review screen must restore the exact
      // execution state. A paused Tracker means the execution button must be
      // shown as RETOMAR, not PAUSAR.
      TrackerState reboundState = mTracker.getState();
      setPauseButtonEnabled(reboundState == TrackerState.STARTED);
      mTracker.displayNotificationState();
      initLiveMap();
    } else {
      // Preview mode is initialized locally in onCreate. This callback is not
      // used in preview mode because no Tracker service is required.
      updateView();
    }
  }

  /**
   * Applies the exact Treino Livre values that were visible in StartFragment
   * when the user tapped Corrida. This keeps the preview synchronized with
   * the configured free-run screen instead of relying only on persisted prefs.
   */
  private void applyPreviewWorkoutConfiguration(Workout w, Dimension target) {
    if (w == null || w.getSteps().isEmpty()) return;

    Step active = w.getSteps().get(w.getSteps().size() - 1);
    String paceMinText = getIntent().getStringExtra("PREVIEW_PACE_MIN");
    String paceMaxText = getIntent().getStringExtra("PREVIEW_PACE_MAX");
    String timeText = getIntent().getStringExtra("PREVIEW_TIME");
    String distanceText = getIntent().getStringExtra("PREVIEW_DISTANCE");

    double paceMin = org.runnerup.util.SafeParse.parseSeconds(
        paceMinText == null ? "00:05:10" : paceMinText, 5 * 60 + 10);
    double paceMax = org.runnerup.util.SafeParse.parseSeconds(
        paceMaxText == null ? "00:06:40" : paceMaxText, 6 * 60 + 40);
    if (paceMin <= 0) paceMin = 5 * 60 + 10;
    if (paceMax <= 0) paceMax = 6 * 60 + 40;
    if (paceMax < paceMin) {
      double tmp = paceMin; paceMin = paceMax; paceMax = tmp;
    }

    active.setTargetType(Dimension.PACE);
    active.setTargetValue(paceMin / 1000.0, paceMax / 1000.0);

    double plannedTimeSeconds;
    double plannedDistanceMeters;
    if (target == Dimension.TIME) {
      plannedTimeSeconds = org.runnerup.util.SafeParse.parseSeconds(
          timeText == null ? "00:30:00" : timeText, 30 * 60);
      double averagePaceSecKm = (paceMin + paceMax) / 2.0;
      plannedDistanceMeters = (plannedTimeSeconds / averagePaceSecKm) * 1000.0;
    } else {
      plannedDistanceMeters = org.runnerup.util.SafeParse.parseDouble(
          distanceText == null ? "5000" : distanceText, 5000);
      double averagePaceSecKm = (paceMin + paceMax) / 2.0;
      plannedTimeSeconds = (plannedDistanceMeters / 1000.0) * averagePaceSecKm;
    }

    // Rule 1: the active block carries the complete free-run prescription and
    // completion is governed by the prescribed distance.
    active.setDurationType(Dimension.DISTANCE);
    active.setDurationValue(Math.max(0, plannedDistanceMeters));
    active.setPaceCoachFreeRun(true);
    active.setPaceCoachPlannedTimeSeconds(plannedTimeSeconds);
    active.setPaceCoachPlannedDistanceMeters(plannedDistanceMeters);
    active.setCoachRhythm(getIntent().getIntExtra("PREVIEW_RHYTHM", 1));
    active.setName("Treino Livre");
  }

  private void populateWorkoutList() {
    List<Workout.StepListEntry> list = workout.getStepList();
    for (Workout.StepListEntry aList : list) {
      WorkoutRow row = new WorkoutRow();
      row.level = aList.level();
      row.step = aList.step();
      row.lap = null;
      workoutRows.add(row);
    }
  }

  private void startPreviewWorkout() {
    if (!previewOnly || previewStartPending) return;

    // PLAY must start this exact workout in this exact execution screen.
    // The previous implementation returned to StartFragment, which could
    // race the Tracker lifecycle and immediately save a zero-length activity.
    previewStartPending = true;
    pauseButton.setEnabled(false);
    Toast.makeText(this, "Iniciando treino...", Toast.LENGTH_SHORT).show();

    if (!mIsBound) {
      bindGpsTracker();
    } else {
      attemptStartPreviewWorkout();
    }
  }

  private void attemptStartPreviewWorkout() {
    if (!previewStartPending || mTracker == null || workout == null) return;

    TrackerState state = mTracker.getState();

    // A delayed retry from the GPS connection can arrive after Tracker.start()
    // has already succeeded.  In that case the workout is already running;
    // never show the "Não foi possível iniciar o treino" error and never try
    // to start it a second time.  This was the source of the misleading toast
    // seen while the timer/distance were already advancing.
    if (state == TrackerState.STARTED || state == TrackerState.PAUSED) {
      previewStartPending = false;
      previewOnly = false;
      // The preview screen initially uses VOLTAR only to leave the preview.
      // Once PLAY has converted this same RunActivity into a real execution,
      // the button MUST switch to the shared execution return path so it pauses
      // (when necessary) and returns the result to StartFragment. Leaving the
      // preview listener attached was another independent reason for VOLTAR to
      // close RunActivity without preserving the workout state.
      newLapButton.setOnClickListener(newLapButtonClick);
      if (workout != null) workout.setVoiceEnabled(voiceEnabled);
      pauseButton.setEnabled(true);
      setPauseButtonEnabled(state == TrackerState.STARTED && !workout.isPaused());
      startRunGpsStatus();
      return;
    }

    if (state == TrackerState.CONNECTED) {
      // Only the actual Tracker.start() operation is allowed to produce the
      // "Não foi possível iniciar o treino" error.  UI/GPS/voice setup after a
      // successful start must not be reported as a failed start. This was the
      // source of the misleading toast while time/distance were already moving.
      try {
        // The preview already contains the exact prescription shown to the
        // user. Use that object directly so no second reconstruction can lose
        // its distance, time or pace range.
        mTracker.setWorkout(workout);
        mTracker.start();
      } catch (RuntimeException ex) {
        previewStartPending = false;
        pauseButton.setEnabled(true);
        Log.e(getClass().getName(), "Unable to start preview workout", ex);
        Toast.makeText(this, "Não foi possível iniciar o treino", Toast.LENGTH_LONG).show();
        return;
      }

      previewStartPending = false;
      previewOnly = false;
      // Cancel the exact delayed retry runnable. A method-reference created
      // inline is a different Runnable instance and cannot reliably be removed.
      handler.removeCallbacks(previewStartRunnable);
      pauseButton.setOnClickListener(pauseButtonClick);
      stopButtonForExecution().setOnClickListener(stopButtonClick);
      // Apply the execution-screen voice switch after Tracker binds TTS to
      // the workout. This makes the button state authoritative for all
      // announcements generated by the workout.
      workout.setVoiceEnabled(voiceEnabled);
      pauseButton.setEnabled(true);
      setPauseButtonEnabled(true);
      newLapButton.setOnClickListener(newLapButtonClick);
      try {
        startTimer();
        startRunGpsStatus();
        mTracker.displayNotificationState();
        initLiveMap();
        updateView();
      } catch (RuntimeException ex) {
        // The activity is already running. Keep the workout alive and log only
        // the auxiliary UI/GPS setup problem instead of showing a start error.
        Log.e(getClass().getName(), "Execution-screen setup failed after workout start", ex);
      }
      return;
    }

    // GPS/Tracker may still be connecting. Ask it to connect and retry without
    // creating or saving any activity until Tracker.start() actually succeeds.
    try {
      switch (state) {
        case INIT:
          mTracker.setup();
          break;
        case INITIALIZED:
          mTracker.connect();
          break;
        case INITIALIZING:
        case CONNECTING:
        case CLEANUP:
          break;
        default:
          previewStartPending = false;
          pauseButton.setEnabled(true);
          Toast.makeText(this, "GPS não está pronto para iniciar", Toast.LENGTH_LONG).show();
          return;
      }
    } catch (RuntimeException ex) {
      Log.w(getClass().getName(), "Tracker is not ready yet", ex);
    }

    handler.removeCallbacks(previewStartRunnable);
    handler.postDelayed(previewStartRunnable, 300);
  }

  // The stop button is initialized inside the preview branch, so keep a direct
  // reference lookup here when transitioning from preview to execution.
  private android.widget.ImageButton stopButtonForExecution() {
    return findViewById(R.id.stop_button);
  }

  private void startRunGpsStatus() {
    if (runGpsStatus == null || previewOnly) return;
    try {
      runGpsStatus.start(this);
      updateRunGpsHeader();
    } catch (RuntimeException ex) {
      Log.w(getClass().getName(), "Unable to start execution GPS status", ex);
    }
  }

  private void stopRunGpsStatus() {
    if (runGpsStatus == null) return;
    try {
      runGpsStatus.stop(this);
    } catch (RuntimeException ex) {
      Log.w(getClass().getName(), "Unable to stop execution GPS status", ex);
    }
    updateRunGpsHeader();
  }

  private void updateRunGpsHeader() {
    if (runGpsHeaderDot == null || runGpsHeaderLevel == null || runGpsHeaderBars == null) return;

    // The home screen and execution screen use one process-wide GPS snapshot.
    // This prevents the execution screen from briefly resetting to "Ruim" while
    // its own GPS listener is still warming up after the home screen already has
    // an excellent fix.
    GpsSignalState shared = GpsSignalState.get();
    boolean enabled = shared.isEnabled();
    boolean started = shared.isStarted();
    boolean fixed = shared.isFixed();
    float accuracy = shared.getAccuracy();
    int fixedSats = shared.getSatellitesFixed();

    // During execution, refresh the shared snapshot from the execution listener
    // when it has newer information, then render from that same snapshot.
    if (runGpsStatus != null && runGpsStatus.isStarted()) {
      boolean localFixed = runGpsStatus.isFixed();
      float localAccuracy = accuracy;
      if (mTracker != null) {
        Location loc = mTracker.getLastKnownLocation();
        if (loc != null && loc.hasAccuracy()) localAccuracy = loc.getAccuracy();
      }
      int localFixedSats = runGpsStatus.getSatellitesFixed();
      int localAvailableSats = runGpsStatus.getSatellitesAvailable();
      // Do not overwrite a valid home-screen fix while the execution listener
      // is still warming up. A startup reading with no fix (or a transient
      // low-quality reading) must not turn an already Excellent signal into
      // Ruim. Only publish execution data once it contains a real fix.
      if (localFixed && (localAccuracy > 0 || localFixedSats > 0)) {
        shared.update(
            runGpsStatus.isEnabled(),
            runGpsStatus.isStarted(),
            true,
            localAccuracy,
            localFixedSats,
            localAvailableSats);
        enabled = shared.isEnabled();
        started = shared.isStarted();
        fixed = shared.isFixed();
        accuracy = shared.getAccuracy();
        fixedSats = shared.getSatellitesFixed();
      }
    }

    int color = 0xFFF44336;
    String label = "Ruim";
    int activeBars = 1;
    if (enabled && started && fixed) {
      if (accuracy > 0 && accuracy <= 7 && fixedSats > 7) {
        color = 0xFF00E676; label = "Excelente"; activeBars = 3;
      } else if (accuracy > 0 && accuracy <= 15 && fixedSats > 4) {
        color = 0xFFFFB300; label = "Bom"; activeBars = 2;
      }
    }
    runGpsHeaderDot.setTextColor(color);
    runGpsHeaderLevel.setText(label);
    runGpsHeaderLevel.setTextColor(color);
    for (int i = 0; i < runGpsHeaderBars.getChildCount(); i++) {
      View bar = runGpsHeaderBars.getChildAt(i);
      android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
      bg.setColor(i < activeBars ? color : 0xFF59636D);
      bg.setCornerRadius(2f);
      bar.setBackground(bg);
    }
  }

  private Timer timer = null;

  private void startTimer() {
    timer = new Timer();
    timer.schedule(
        new TimerTask() {
          @Override
          public void run() {
            RunActivity.this.handler.post(RunActivity.this::onTick);
          }
        },
        0,
        500);
  }

  private void stopTimer() {
    if (timer != null) {
      timer.cancel();
      timer.purge();
      timer = null;
    }
  }

  private Location l = null;

  public void onTick() {
    if (workout != null) {
      workout.onTick();
      updateRunGpsHeader();
      updateView();

      if (mTracker != null) {
        Location l2 = mTracker.getLastKnownLocation();
        if (l2 != null && !l2.equals(l)) {
          l = l2;
        }
        if (mapWrapper != null && l2 != null) {
          mapWrapper.updateCurrentLocation(l2);
        }
        refreshLiveMap();
      }
    }
  }

  private void initLiveMap() {
    if (mapDb == null || mTracker == null) return;
    if (!(BuildConfig.OSMDROID_ENABLED || BuildConfig.MAPBOX_ENABLED)) return;
    View mapView = findViewById(R.id.run_mapview);
    if (mapView == null) return;
    if (mapWrapper == null) {
      mapWrapper = new MapWrapper(this, mapDb, mTracker.getActivityId(), formatter, mapView);
      mapWrapper.onCreate(null);
      lastMapRefresh = 0L;
    }
    refreshLiveMap();
  }

  private void refreshLiveMap() {
    if (mapWrapper == null) return;
    long now = android.os.SystemClock.elapsedRealtime();
    if (now - lastMapRefresh < 1800L) return;
    lastMapRefresh = now;
    mapWrapper.refresh();
  }

  private boolean isPaceCoachEventVoiceEnabled() {
    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
    SharedPreferences audioPrefs = WorkoutBuilder.getAudioCuePreferences(
        this, prefs, getString(R.string.pref_basic_audio));
    return audioPrefs.getBoolean(getString(R.string.cueinfo_event_voice_enabled), true);
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (workout == null) {
      // "should not happen"
      finish();
      return;
    }
    if (resultCode == AppCompatActivity.RESULT_OK) {
      /*
       * they saved
       */
      Double manualDistance = null;
      if (data != null && data.hasExtra("MANUAL_DISTANCE")) {
        manualDistance = data.getDoubleExtra("MANUAL_DISTANCE", 0);
      }
      // Guardar is the real finalization point. Speak the complete summary here,
      // while the Workout/Tracker still contain the final activity values. STOP
      // only opens the finish screen and therefore must not speak "Treino finalizado".
      // Build the final sentence BEFORE completing the Tracker. TrackerTTS is
      // intentionally independent from this final announcement because the
      // Tracker shuts its TTS component down during completeActivity().
      String finalVoiceText = null;
      if (isPaceCoachEventVoiceEnabled()) {
        org.runnerup.workout.feedback.PaceCoachActivitySummaryFeedback finalFeedback =
            new org.runnerup.workout.feedback.PaceCoachActivitySummaryFeedback();
        HashMap<String, Object> finalBind = new HashMap<>();
        finalBind.put(Workout.KEY_FORMATTER, new org.runnerup.util.Formatter(this));
        finalFeedback.onBind(workout, finalBind);
        finalVoiceText = finalFeedback.buildMessage(workout);
      }
      workout.onComplete(Scope.ACTIVITY, workout);
      if (mTracker != null) {
        mTracker.completeActivity(/* save= */ true, manualDistance);
      }
      mTracker = null;
      final String textToSpeak = finalVoiceText;
      if (textToSpeak != null && !textToSpeak.isEmpty()) {
        org.runnerup.workout.feedback.PaceCoachFinalVoice.speak(
            this, textToSpeak, this::finish);
      } else {
        finish();
      }
    } else if (resultCode == AppCompatActivity.RESULT_CANCELED) {
      /*
       * they discarded
       */
      workout.onComplete(Scope.ACTIVITY, workout);
      mTracker.completeActivity(/* save= */ false, /* manualDistance= */ null);
      mTracker = null;
      finish();
    } else if (resultCode == AppCompatActivity.RESULT_FIRST_USER) {
      // Returning from the save/discard screen must restore the exact execution
      // state that existed when STOP was pressed. STOP intentionally leaves the
      // Tracker PAUSED so that choosing "Voltar" does not terminate the activity.
      if (mTracker != null && mTracker.getState() == TrackerState.PAUSED) {
        stopTimer();
        if (workout != null) {
          workout.onPause(workout);
        }
        setPauseButtonEnabled(false);
        mTracker.displayNotificationState();
        updateView();
      } else if (mTracker != null && mTracker.getState() == TrackerState.STARTED) {
        startTimer();
        if (workout != null) {
          workout.onResume(workout);
        }
        setPauseButtonEnabled(true);
        updateView();
      }
    } else {
      if (BuildConfig.DEBUG) {
        throw new AssertionError();
      }
    }
  }

  private void newLap() {
    if (workout != null) {
      workout.onNewLapOrNextStep();
    }
  }

  private void setPauseButtonEnabled(boolean enabled) {
    if (pauseButton == null) return;
    pauseButton.setScaleType(android.widget.ImageView.ScaleType.CENTER);
    pauseButton.setPadding(0, 0, 0, 0);
    if (previewOnly) {
      ViewCompat.setBackground(
          pauseButton, AppCompatResources.getDrawable(this, R.drawable.bg_run_round_blue));
      pauseButton.setImageResource(R.drawable.ic_run_play_centered);
      pauseButton.setContentDescription("Iniciar treino");
      TextView label = findViewById(R.id.pause_label);
      if (label != null) label.setText("INICIAR");
      return;
    }
    if (enabled) {
      ViewCompat.setBackground(
          pauseButton, AppCompatResources.getDrawable(this, R.drawable.bg_run_round_blue));
      pauseButton.setImageResource(R.drawable.ic_run_pause_centered);
      pauseButton.setContentDescription("Pausar treino");
      TextView label = findViewById(R.id.pause_label);
      if (label != null) label.setText("PAUSAR");
    } else {
      ViewCompat.setBackground(
          pauseButton, AppCompatResources.getDrawable(this, R.drawable.bg_run_round_blue));
      pauseButton.setImageResource(R.drawable.ic_run_play_centered);
      pauseButton.setContentDescription("Retomar treino");
      TextView label = findViewById(R.id.pause_label);
      if (label != null) label.setText("INICIAR");
    }
  }

  private void setVoiceEnabled(boolean enabled) {
    voiceEnabled = enabled;
    if (workout != null && !previewOnly) {
      workout.setVoiceEnabled(enabled);
    }
    if (voiceButton == null) return;
    voiceButton.setImageResource(enabled ? R.drawable.ic_run_volume_32dp : R.drawable.ic_run_volume_off_32dp);
    voiceButton.setContentDescription(enabled ? "Voz ON" : "Voz OFF");
    if (voiceLabel != null) {
      voiceLabel.setText(enabled ? "VOZ ON" : "VOZ OFF");
      voiceLabel.setTextColor(enabled ? getColor(R.color.colorAccent) : getColor(R.color.colorTextSecondary));
    }
  }

  private void togglePause() {
    if (mTracker == null) return;

    TrackerState state = mTracker.getState();

    if (state == TrackerState.STARTED) {
      // Pause the real Tracker first.  The Tracker owns elapsed active time,
      // GPS sampling and the persisted activity state.
      mTracker.pause();

      if (mTracker.getState() != TrackerState.PAUSED) {
        Log.e(getClass().getName(),
            "Pause failed: Tracker state is " + mTracker.getState());
        return;
      }

      // Only after the Tracker is definitely paused synchronize the Workout
      // model and the execution UI.  Do not call any method that can resume
      // the Tracker before this point.
      if (workout != null) {
        workout.onPause(workout);
      }
      stopTimer();
      setPauseButtonEnabled(false);
      updateView();
      return;
    }

    if (state == TrackerState.PAUSED) {
      try {
        // The Workout owns step-specific resume behavior. Some step types call
        // Tracker.resume() themselves while others intentionally do not. Let
        // the workout perform that part first, then guarantee that a manual
        // pause is actually released for every workout type.
        if (workout != null) {
          workout.onResume(workout);
        }

        if (mTracker.getState() == TrackerState.PAUSED) {
          mTracker.resume();
        }

        if (mTracker.getState() != TrackerState.STARTED) {
          Log.e(getClass().getName(),
              "Resume failed: Tracker state is " + mTracker.getState());
          setPauseButtonEnabled(false);
          return;
        }

        startTimer();
        setPauseButtonEnabled(true);
        updateView();
      } catch (Throwable ex) {
        // Never let a workout component (TTS/sensor/trigger) crash the
        // execution activity during a manual resume. If the core Tracker has
        // already resumed, keep the UI in the running state.
        Log.e(getClass().getName(), "Failed to resume workout", ex);
        try {
          if (mTracker != null && mTracker.getState() == TrackerState.PAUSED) {
            mTracker.resume();
          }
        } catch (Throwable retryEx) {
          Log.e(getClass().getName(), "Retrying workout resume failed", retryEx);
        }
        if (mTracker != null && mTracker.getState() == TrackerState.STARTED) {
          startTimer();
          setPauseButtonEnabled(true);
          updateView();
        }
      }
    }
  }

  private void doStop() {
    if (previewOnly) {
      finish();
      return;
    }
    if (mTracker == null || workout == null) return;

    TrackerState state = mTracker.getState();
    if (state != TrackerState.STARTED && state != TrackerState.PAUSED) return;

    // STOP opens the finishing screen; it does NOT finalize the activity yet.
    // Keep the Tracker in PAUSED so that "Voltar" can safely return to the
    // execution screen without losing the activity or forcing a resume. The
    // activity is actually completed only when the user chooses Guardar or
    // Descartar in DetailActivity.
    if (state == TrackerState.STARTED) {
      mTracker.pause();
      if (mTracker.getState() != TrackerState.PAUSED) {
        Log.e(getClass().getName(),
            "Unable to pause tracker before opening finish screen");
        return;
      }
      workout.onPause(workout);
    }

    stopTimer();
    handler.removeCallbacks(previewStartRunnable);
    previewStartPending = false;
    mTracker.displayNotificationState();
    setPauseButtonEnabled(false);

    Intent intent = new Intent(RunActivity.this, DetailActivity.class);
    intent.putExtra("mode", "save");
    intent.putExtra("ID", mTracker.getActivityId());
    // requestCode=1 means we intentionally return to the paused execution
    // state if the user chooses "Voltar".
    RunActivity.this.startActivityForResult(intent, 1);
  }

  /**
   * Returns from the execution screen to the Pace Coach workout review screen
   * without saving or discarding the current activity. If the workout is
   * running, pause it first so the Tracker remains alive and resumable.
   * StartFragment will detect the paused Tracker and show RETOMAR TREINO.
   */
  private void returnToWorkoutReview() {
    if (previewOnly) {
      finish();
      return;
    }

    if (mTracker != null) {
      TrackerState state = mTracker.getState();
      if (state == TrackerState.STARTED) {
        mTracker.pause();
        if (mTracker.getState() != TrackerState.PAUSED) {
          Log.e(getClass().getName(),
              "Unable to pause tracker before returning to workout review");
          return;
        }
        if (workout != null) workout.onPause(workout);
        stopTimer();
        mTracker.displayNotificationState();
      }
    }

    // RunActivity is launched by StartFragment with startActivityForResult().
    // Return through that existing parent/child contract instead of launching
    // MainLayout again. Starting a second MainLayout while the original one is
    // already underneath RunActivity can recreate/bind the UI and Tracker at
    // the same time and is the source of the crash seen when VOLTAR is pressed.
    //
    // The Tracker remains PAUSED and therefore remains the single owner of the
    // in-progress activity. StartFragment receives this result and restores
    // the workout review screen, where RETOMAR TREINO can reopen this same
    // execution context.
    Intent result = new Intent();
    result.putExtra("RETURN_TO_COACH_PREVIEW", true);
    String previewKind = getIntent().getStringExtra("PREVIEW_KIND");
    if (previewKind == null) {
      previewKind = getIntent().getStringExtra("COACH_TAB");
    }
    if (previewKind != null) result.putExtra("PREVIEW_KIND", previewKind);
    String previewTarget = getIntent().getStringExtra("PREVIEW_TARGET");
    if (previewTarget != null) result.putExtra("PREVIEW_TARGET", previewTarget);
    setResult(Activity.RESULT_FIRST_USER, result);
    finish();
  }

  private final OnClickListener newLapButtonClick = v -> returnToWorkoutReview();
  private final OnClickListener pauseButtonClick = v -> {
    if (previewOnly) {
      startPreviewWorkout();
    } else {
      togglePause();
    }
  };
  private final OnClickListener stopButtonClick = v -> doStop();

  @Override
  public boolean onKeyDown(int keyCode, KeyEvent event) {
    final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
    final Resources res = this.getResources();
    final boolean volumeButtonControls =
        prefs.getBoolean(res.getString(R.string.pref_volume_button_controls), false);

    if (volumeButtonControls
        && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
      return true;
    }
    return super.onKeyDown(keyCode, event);
  }

  @Override
  public boolean onKeyUp(int keyCode, KeyEvent event) {
    final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
    final Resources res = this.getResources();
    final boolean volumeButtonControls =
        prefs.getBoolean(res.getString(R.string.pref_volume_button_controls), false);

    if (volumeButtonControls
        && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
      switch (keyCode) {
        case KeyEvent.KEYCODE_VOLUME_UP:
          newLap();
          break;
        case KeyEvent.KEYCODE_VOLUME_DOWN:
          togglePause();
      }
      return true;
    }
    return super.onKeyUp(keyCode, event);
  }

  private void showOnLockScreen(boolean enabled) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
      setShowWhenLocked(enabled);
    } else {
      Window window = getWindow();
      if (enabled) {
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
      } else {
        window.clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
      }
    }
  }

  private void updateView() {
    if (workout == null) return;
    boolean isPaused = workout != null && workout.isPaused();
    if (!previewOnly && mTracker != null && mTracker.getState() == TrackerState.STOPPED && !isPaused) {
      doStop();
    } else {
      if (workout == null) {
        // "should not happen"
        return;
      }

      setPauseButtonEnabled(!workout.isPaused());
      double ad = workout.getDistance(Scope.ACTIVITY);
      double at = workout.getTime(Scope.ACTIVITY);
      double ap = workout.getSpeed(Scope.ACTIVITY);
      activityTime.setText(formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, Math.round(at)));
      activityDistance.setText(
          formatter.formatDistance(Formatter.Format.TXT_SHORT, Math.round(ad)));
      activityPace.setText(formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_SHORT, ap));

      double ld = workout.getDistance(Scope.LAP);
      double lt = workout.getTime(Scope.LAP);
      double lp = workout.getSpeed(Scope.LAP);
      lapTime.setText(formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, Math.round(lt)));
      lapDistance.setText(formatter.formatDistance(Formatter.Format.TXT_LONG, Math.round(ld)));
      lapPace.setText(formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_SHORT, lp));

      if (tableRowInterval != null
          && this.currentStep != null
          && workout.getWorkoutType() != Constants.WORKOUT_TYPE.BASIC
          && this.currentStep.getIntensity() == Intensity.ACTIVE) {
        double id = workout.getDistance(Scope.STEP);
        double it = workout.getTime(Scope.STEP);
        double ip = workout.getSpeed(Scope.STEP);

        tableRowInterval.setVisibility(View.VISIBLE);
        intervalTime.setText(
            formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, Math.round(it)));
        intervalDistance.setText(
            formatter.formatDistance(Formatter.Format.TXT_LONG, Math.round(id)));
        intervalPace.setText(
            formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_SHORT, ip));
      } else {
        // Do not show Interval Step row if no reason
        tableRowInterval.setVisibility(View.GONE);
      }

      // Synchronize the authoritative current block BEFORE rendering any
      // Pace Coach cards. Previously this happened at the very end of updateView,
      // after the cards had already been rendered with the previous block. That
      // made BLOCO ATUAL/PRÓXIMO BLOCO lag behind the real workout transition.
      Step curr = workout.getCurrentStep();
      if (curr != currentStep) {
        currentStep = curr;
        if (workoutList != null && workoutList.getAdapter() != null) {
          ((BaseAdapter) workoutList.getAdapter()).notifyDataSetChanged();
        }
      }

      // RITMO ATUAL DO TREINO comes only from the latest valid point-to-point GPS segment.
      // RITMO MÉDIO remains the independent activity-average metric.
      double currentGpsSpeed = workout.getSpeed(Scope.CURRENT);
      double coachComparisonSpeed = currentGpsSpeed;

      // The execution interface and the voice coach must use exactly the same
      // Pace Coach current-pace source. Never substitute STEP or ACTIVITY pace.
      updateCoachRunPanel(coachComparisonSpeed);
      updateCoachRunExtraPanel();

      if (mTracker != null && mTracker.isComponentConnected(TrackerHRM.NAME)) {
        double ahr = workout.getHeartRate(Scope.ACTIVITY);
        double ihr = workout.getHeartRate(Scope.STEP);
        double lhr = workout.getHeartRate(Scope.LAP);
        lapHr.setText(formatter.formatHeartRate(Formatter.Format.TXT_SHORT, lhr));
        intervalHr.setText(formatter.formatHeartRate(Formatter.Format.TXT_SHORT, ihr));
        activityHr.setText(formatter.formatHeartRate(Formatter.Format.TXT_SHORT, ahr));
        activityHr.setVisibility(View.VISIBLE);
        lapHr.setVisibility(View.VISIBLE);
        intervalHr.setVisibility(View.VISIBLE);
        activityHeaderHr.setVisibility(View.VISIBLE);
        if (hrDebug != null) {
          hrDebug.setVisibility(View.VISIBLE);
          mTracker.setHrDebug(hrDebug);
        }
      } else {
        activityHr.setVisibility(View.GONE);
        lapHr.setVisibility(View.GONE);
        intervalHr.setVisibility(View.GONE);
        activityHeaderHr.setVisibility(View.GONE);
      }

    }
  }

  private void updateCoachRunExtraPanel() {
    if (workout == null) return;
    Step step = currentStep;
    if (step == null) {
      if (coachRunStepProgress != null) {
        coachRunStepProgress.setText("— / " + Math.max(1, workout.getPaceCoachTotalStepCount()));
      }
      if (coachRunNextStep != null) coachRunNextStep.setText("—");
      if (coachRunNextTarget != null) coachRunNextTarget.setText("—");
      if (coachRunRemainingTime != null) coachRunRemainingTime.setText("00:00");
      if (coachRunRemainingDistance != null) coachRunRemainingDistance.setText("0 m");
      if (coachRunFreeProgress != null) {
        if (workout.getWorkoutType() == Constants.WORKOUT_TYPE.BASIC) {
          coachRunFreeProgress.setVisibility(View.VISIBLE);
          coachRunFreeProgress.setProgress(100);
        } else {
          coachRunFreeProgress.setVisibility(View.GONE);
          coachRunFreeProgress.setProgress(0);
        }
      }
      return;
    }

    // The execution engine is the single source of truth for the current
    // position. Do not impose a fixed number of blocks and do not count
    // RepeatStep containers as visible execution blocks.
    int currentIndex = workout.getPaceCoachCurrentStepIndex();
    int total = workout.getPaceCoachTotalStepCount();
    if (coachRunStepProgress != null) {
      // In the pre-start preview the Workout executor has not been started yet,
      // so it has no currentStepNo. The first executable block is nevertheless
      // the block displayed by the preview. Once PLAY starts the executor, its
      // real index becomes authoritative.
      int shown = currentIndex >= 0 ? currentIndex + 1 : 1;
      coachRunStepProgress.setText(shown + " / " + Math.max(1, total));
    }

    double elapsed = workout.getTime(Scope.STEP);
    if (coachRunFreeProgress != null) {
      // This progress bar belongs to the shared Bloco Atual card, not only to
      // Treino Livre. Every executable block can expose progress: distance
      // blocks use distance and time blocks use elapsed time. Preview starts at
      // 0%; execution updates it from the same Scope.STEP source as the card.
      coachRunFreeProgress.setVisibility(View.VISIBLE);
      double plannedDistance = 0;
      double plannedTime = 0;
      if (step.isPaceCoachFreeRun()) {
        plannedDistance = step.getPaceCoachPlannedDistanceMeters();
        if (!(plannedDistance > 0)) plannedDistance = step.getDurationValue();
        plannedTime = step.getPaceCoachPlannedTimeSeconds();
      } else if (step.getDurationType() == Dimension.DISTANCE) {
        plannedDistance = step.getDurationValue();
      } else if (step.getDurationType() == Dimension.TIME) {
        plannedTime = step.getDurationValue();
      }

      int percent = 0;
      if (!previewOnly) {
        if (plannedDistance > 0) {
          double doneDistance = workout.getDistance(Scope.STEP);
          percent = (int) Math.round(
              Math.min(1.0, Math.max(0.0, doneDistance / plannedDistance)) * 100.0);
        } else if (plannedTime > 0) {
          percent = (int) Math.round(
              Math.min(1.0, Math.max(0.0, elapsed / plannedTime)) * 100.0);
        }
      }
      coachRunFreeProgress.setProgress(percent);
    }
    double remainingTime = 0;
    double remainingDistance = 0;
    if (step.isPaceCoachFreeRun()) {
      double plannedTime = step.getPaceCoachPlannedTimeSeconds();
      if (plannedTime > 0) {
        remainingTime = Math.max(0, plannedTime - elapsed);
      }
      double plannedDistance = step.getPaceCoachPlannedDistanceMeters();
      if (!(plannedDistance > 0)) plannedDistance = step.getDurationValue();
      remainingDistance = Math.max(0, plannedDistance - workout.getDistance(Scope.STEP));
    } else if (step.getDurationType() == Dimension.TIME) {
      remainingTime = Math.max(0, step.getDurationValue() - elapsed);
    } else if (step.getDurationType() == Dimension.DISTANCE) {
      remainingDistance = Math.max(0, step.getDurationValue() - workout.getDistance(Scope.STEP));
    }
    if (coachRunRemainingTime != null) {
      coachRunRemainingTime.setText(formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, Math.round(remainingTime)));
    }
    if (coachRunRemainingDistance != null) {
      coachRunRemainingDistance.setText(formatter.formatDistance(Formatter.Format.TXT_LONG, Math.round(remainingDistance)));
    }
    // The Bloco Atual card always shows the prescription of the block, not
    // the accumulated execution counters. The progress bar is responsible for
    // showing how much of that prescription has already been completed.
    // This keeps Treino Livre and Treino Estruturado on the same interface.
    double plannedDistanceForCard = 0;
    double plannedTimeForCard = 0;
    if (step.isPaceCoachFreeRun()) {
      plannedDistanceForCard = step.getPaceCoachPlannedDistanceMeters();
      plannedTimeForCard = step.getPaceCoachPlannedTimeSeconds();
    } else if (step.getDurationType() == Dimension.DISTANCE) {
      plannedDistanceForCard = step.getDurationValue();
    } else if (step.getDurationType() == Dimension.TIME) {
      plannedTimeForCard = step.getDurationValue();
    }

    if (coachRunIntervalDistanceVisible != null) {
      if (plannedDistanceForCard > 0) {
        coachRunIntervalDistanceVisible.setText(formatCoachKm(plannedDistanceForCard));
      } else {
        coachRunIntervalDistanceVisible.setText("—");
      }
    }
    if (coachRunIntervalTimeVisible != null) {
      if (plannedTimeForCard > 0) {
        coachRunIntervalTimeVisible.setText(
            formatter.formatElapsedTime(Formatter.Format.TXT_SHORT,
                Math.round(plannedTimeForCard)));
      } else {
        coachRunIntervalTimeVisible.setText("—");
      }
    }

    if (coachRunTargetSummary != null) {
      coachRunTargetSummary.setText(formatOverallTargetAverage());
    }

    if (coachRunActivityHrVisible != null && activityHr != null) {
      coachRunActivityHrVisible.setText(activityHr.getText());
    }

    if (coachRunNextStep != null && coachRunNextTarget != null) {
      Step next = null;
      if (previewOnly) {
        // Preview has not started the Workout executor yet, therefore the
        // executor cannot report a current/next step. Build the preview from
        // the exact same flattened execution sequence used at runtime.
        List<Step> previewSteps = workout.getPaceCoachExecutionSteps();
        if (previewSteps.size() > 1) {
          next = previewSteps.get(1);
        }
      } else {
        next = workout.getPaceCoachNextStep();
      }
      if (next != null) {
        coachRunNextStep.setText(getPaceCoachBlockDisplayName(next));
        coachRunNextTarget.setText(formatStepTarget(next));
      } else {
        coachRunNextStep.setText("—");
        coachRunNextTarget.setText("—");
      }
    }
  }

  /**
   * Calculates the general target shown in the bottom "ALVO MÉDIO" card.
   *
   * The value is an arithmetic mean of the target pace of all workout blocks.
   * For a target range, the block contributes the midpoint of that range.
   * This is intentionally independent from the current block: the bottom card
   * represents the whole workout, while the current-block card shows the exact
   * configured range.
   */
  private String formatOverallTargetAverage() {
    if (workout == null) return "—";

    List<Workout.StepListEntry> flat = workout.getStepList();
    double totalSecKm = 0.0;
    int count = 0;

    for (Workout.StepListEntry entry : flat) {
      Step step = entry.step();
      if (step == null || step.getTargetType() != Dimension.PACE
          || step.getTargetValue() == null) {
        continue;
      }

      double a = step.getTargetValue().minValue * 1000.0;
      double b = step.getTargetValue().maxValue * 1000.0;
      if (!(a > 0) || !(b > 0)
          || Double.isNaN(a) || Double.isNaN(b)
          || Double.isInfinite(a) || Double.isInfinite(b)) {
        continue;
      }

      // A range contributes its midpoint to the workout-wide average.
      totalSecKm += (a + b) / 2.0;
      count++;
    }

    if (count == 0) return "—";
    return formatPaceSecondsPerKm(totalSecKm / count).replace(" min/km", "");
  }

  private String formatCoachKm(double meters) {
    double km = Math.max(0.0, meters) / 1000.0;
    return String.format(java.util.Locale.getDefault(), "%.1f km", km).replace('.', ',');
  }

  private String formatStepTarget(Step step) {
    if (step == null || step.getTargetType() != Dimension.PACE || step.getTargetValue() == null) return "—";
    double a = step.getTargetValue().minValue * 1000.0;
    double b = step.getTargetValue().maxValue * 1000.0;
    double fast = Math.min(a, b);
    double slow = Math.max(a, b);
    String f = formatPaceSecondsPerKm(fast).replace(" min/km", "");
    String s = formatPaceSecondsPerKm(slow).replace(" min/km", "");
    return fast == slow ? f : f + " – " + s;
  }

  /**
   * Returns the only user-facing block names allowed by Pace Coach execution.
   * Structured workouts must describe blocks by their semantic type, never by
   * an internal/custom Step.name. This keeps the current/next cards and the
   * execution vocabulary aligned with the voice feedback.
   */
  private String getPaceCoachBlockDisplayName(Step step) {
    if (step == null) return "—";
    if (step.isPaceCoachFreeRun()) return "Treino Livre";

    switch (step.getIntensity()) {
      case WARMUP:
        return "Aquecimento";
      case COOLDOWN:
        return "Desaquecimento";
      case RECOVERY:
        return "Recuperação";
      case RESTING:
        return step.getDurationType() == Dimension.TIME ? "Descanso Off" : "Intervalo";
      case ACTIVE:
      default:
        return "Intervalo";
    }
  }

  private static String formatCoachRhythm(int rhythm) {
    if (rhythm == 0) return "Devagar";
    if (rhythm == 2) return "Rápido";
    return "Constante";
  }

  private void updateCoachRunPanel(double currentPaceValue) {
    if (coachRunPace == null) return;
    coachRunPace.setText(formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_SHORT, currentPaceValue));

    Step step = currentStep;
    if (step == null) {
      coachRunStep.setText("—");
      if (coachRunStepEffort != null) coachRunStepEffort.setText("");
      coachRunTarget.setText("—");
      coachRunState.setText("AGUARDAR");
      coachRunDifference.setText("");
      updateCoachRunIndicator("target");
      return;
    }

    // Structured workouts have a fixed vocabulary for executable blocks.
    // Never expose the internal/custom Step.name (e.g. the old "Ritmo COACH")
    // in the execution card. The block type/intensity is the source of truth.
    coachRunStep.setText(getPaceCoachBlockDisplayName(step));
    if (coachRunStepEffort != null) {
      if (step.isPaceCoachFreeRun()) {
        coachRunStepEffort.setText(formatCoachRhythm(step.getCoachRhythm()));
      } else {
        coachRunStepEffort.setText("");
      }
    }

    if (step.getTargetType() == Dimension.PACE && step.getTargetValue() != null) {
      // Workout pace targets are stored as seconds per meter. Runtime speed is meters/second.
      // Convert both to seconds/km before comparing, displaying and calculating the delta.
      double targetValueA = step.getTargetValue().minValue * 1000.0;
      double targetValueB = step.getTargetValue().maxValue * 1000.0;
      // Pace is expressed in seconds/km: the smaller value is faster.
      // Normalize the two configured limits so the comparison remains correct
      // regardless of how the workout stores the range endpoints.
      double fastLimitSecKm = Math.min(targetValueA, targetValueB);
      double slowLimitSecKm = Math.max(targetValueA, targetValueB);
      // Pace Coach displays the configured target range exactly as prescribed;
      // never replace the range with its arithmetic mean.
      coachRunTarget.setText(formatStepTarget(step));
      if (currentPaceValue <= 0 || Double.isNaN(currentPaceValue) || Double.isInfinite(currentPaceValue)) {
        coachRunState.setText("AGUARDAR");
        coachRunDifference.setTextColor(AppCompatResources.getColorStateList(this, R.color.colorAccent));
        coachRunDifference.setText("");
        updateCoachRunIndicator("target");
      } else {
        double currentPaceSecKm = 1000.0 / currentPaceValue;
        if (currentPaceSecKm < fastLimitSecKm) {
          coachRunState.setText("REDUZIR");
          coachRunDifference.setTextColor(AppCompatResources.getColorStateList(this, R.color.coachFast));
          coachRunDifference.setText(formatPaceDifference(fastLimitSecKm, currentPaceSecKm, "fast"));
          updateCoachRunIndicator("fast");
        } else if (currentPaceSecKm > slowLimitSecKm) {
          coachRunState.setText("ACELERAR");
          coachRunDifference.setTextColor(AppCompatResources.getColorStateList(this, R.color.coachSlow));
          coachRunDifference.setText(formatPaceDifference(slowLimitSecKm, currentPaceSecKm, "slow"));
          updateCoachRunIndicator("slow");
        } else {
          coachRunState.setText("MANTER");
          coachRunDifference.setText("No alvo");
          coachRunDifference.setTextColor(AppCompatResources.getColorStateList(this, R.color.colorAccent));
          updateCoachRunIndicator("target");
        }
      }
    } else {
      coachRunTarget.setText("Sem alvo");
      coachRunState.setText("LIVRE");
      coachRunDifference.setTextColor(AppCompatResources.getColorStateList(this, R.color.colorAccent));
      coachRunDifference.setText("");
      updateCoachRunIndicator("target");
    }
  }

  private void updateCoachRunIndicator(String active) {
    if (coachRunIndicatorFast == null) return;

    // Keep the three zones visible, but make the active zone immediately
    // identifiable. The active color remains unchanged; only its intensity
    // and visual prominence are increased.
    boolean fast = "fast".equals(active);
    boolean target = "target".equals(active);
    boolean slow = "slow".equals(active);

    coachRunIndicatorFast.setAlpha(fast ? 1.0f : 0.42f);
    coachRunIndicatorTarget.setAlpha(target ? 1.0f : 0.42f);
    coachRunIndicatorSlow.setAlpha(slow ? 1.0f : 0.42f);

    if (coachRunBarFast != null) {
      coachRunBarFast.setAlpha(fast ? 1.0f : 0.25f);
      coachRunBarFast.setScaleY(fast ? 1.18f : 1.0f);
      coachRunBarFast.setElevation(fast ? 6.0f : 0.0f);
    }
    if (coachRunBarTarget != null) {
      coachRunBarTarget.setAlpha(target ? 1.0f : 0.25f);
      coachRunBarTarget.setScaleY(target ? 1.18f : 1.0f);
      coachRunBarTarget.setElevation(target ? 6.0f : 0.0f);
    }
    if (coachRunBarSlow != null) {
      coachRunBarSlow.setAlpha(slow ? 1.0f : 0.25f);
      coachRunBarSlow.setScaleY(slow ? 1.18f : 1.0f);
      coachRunBarSlow.setElevation(slow ? 6.0f : 0.0f);
    }
  }

  private String formatPaceSecondsPerKm(double secondsPerKm) {
    if (Double.isNaN(secondsPerKm) || secondsPerKm <= 0) return "--:-- min/km";
    long total = Math.round(secondsPerKm);
    long minutes = total / 60;
    long seconds = total % 60;
    return String.format(java.util.Locale.getDefault(), "%d:%02d min/km", minutes, seconds);
  }

  private String formatPaceDifference(double targetSecKm, double currentSecKm, String direction) {
    long seconds = Math.round(Math.abs(currentSecKm - targetSecKm));
    if (seconds == 0) return "No alvo";
    if ("fast".equals(direction)) return seconds + " s mais rápido";
    if ("slow".equals(direction)) return seconds + " s mais lento";
    return seconds + " s do alvo";
  }

  private int getPosition(
      ArrayList<WorkoutRow> workoutRows, org.runnerup.workout.Step currentActivity) {
    for (int i = 0; i < workoutRows.size(); i++) {
      if (workoutRows.get(i).step == currentActivity) return i;
    }
    return 0;
  }

  private boolean mIsBound = false;

  private final ServiceConnection mConnection =
      new ServiceConnection() {
        public void onServiceConnected(ComponentName className, IBinder service) {
          // This is called when the connection with the service has been
          // established, giving us the service object we can use to
          // interact with the service. Because we have bound to a explicit
          // service that we know is running in our own process, we can
          // cast its IBinder to a concrete class and directly access it.
          if (mTracker == null) {
            mTracker = ((Tracker.LocalBinder) service).getService();
            // When PLAY is pressed from the pre-start preview, the same
            // RunActivity must become the real execution screen. Do not return
            // to StartFragment and do not let the preview be mistaken for a
            // completed/zero-length activity.
            if (previewStartPending) {
              handler.post(RunActivity.this::attemptStartPreviewWorkout);
            } else {
              // A reopened workout is already owned by Tracker. Do not run the
              // generic first-bind/startup path against a second UI lifecycle.
              // Bind the execution views only, preserve PAUSED/STARTED exactly,
              // and let the Play button perform the actual resume.
              if (reopeningExistingWorkout) {
                RunActivity.this.onExistingWorkoutTrackerBound();
              } else {
                RunActivity.this.onGpsTrackerBound();
              }
            }
          }
        }

        public void onServiceDisconnected(ComponentName className) {
          // This is called when the connection with the service has been
          // unexpectedly disconnected -- that is, its process crashed.
          // Because it is running in our same process, we should never
          // see this happen.
          mIsBound = false;
          mTracker = null;
        }
      };

  private void bindGpsTracker() {
    // Establish a connection with the service. We use an explicit
    // class name because we want a specific service implementation that
    // we know will be running in our own process (and thus won't be
    // supporting component replacement by other applications).
    mIsBound =
        getApplicationContext()
            .bindService(new Intent(this, Tracker.class), mConnection, Context.BIND_AUTO_CREATE);
  }

  private void unbindGpsTracker() {
    if (mIsBound) {
      // Detach our existing connection.
      getApplicationContext().unbindService(mConnection);
      mIsBound = false;
    }
  }

  class WorkoutAdapter extends BaseAdapter {

    final ArrayList<WorkoutRow> rows;

    WorkoutAdapter(ArrayList<WorkoutRow> workoutRows) {
      this.rows = workoutRows;
    }

    @Override
    public int getCount() {
      return rows.size();
    }

    @Override
    public Object getItem(int position) {
      return rows.get(position);
    }

    @Override
    public long getItemId(int position) {
      return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      WorkoutRow tmp = rows.get(position);
      if (tmp.step != null) {
        return getWorkoutRow(tmp.step, tmp.level, convertView, parent);
      } else {
        return getLapRow(tmp.lap, convertView, parent);
      }
    }

    private View getWorkoutRow(
        org.runnerup.workout.Step step, int level, View convertView, ViewGroup parent) {
      LayoutInflater inflater = LayoutInflater.from(RunActivity.this);
      View view = inflater.inflate(R.layout.workout_row, parent, false);
      TextView intensity = view.findViewById(R.id.workout_step_intensity);
      TextView durationType = view.findViewById(R.id.workout_step_duration_type);
      TextView durationValue = view.findViewById(R.id.workout_step_duration_value);
      TextView targetPace = view.findViewById(R.id.workout_step_pace);
      intensity.setPadding(level * 10, 0, 0, 0);
      intensity.setText(getResources().getText(step.getIntensity().getTextId()));
      if (step.getDurationType() != null) {
        durationType.setText(getResources().getText(step.getDurationType().getTextId()));
        durationValue.setText(
            formatter.format(
                Formatter.Format.TXT_LONG, step.getDurationType(), step.getDurationValue()));
      } else {
        durationType.setText("");
        durationValue.setText("");
      }
      if (currentStep == step) {
        // view.setBackgroundResource(android.R.color.background_light);
      } else {
        view.setBackgroundResource(android.R.color.black);
      }

      if (step.getTargetType() == null) {
        targetPace.setText("");
      } else {
        double minValue = step.getTargetValue().minValue;
        double maxValue = step.getTargetValue().maxValue;
        if (minValue == maxValue) {
          targetPace.setText(
              formatter.format(Formatter.Format.TXT_SHORT, step.getTargetType(), minValue));
        } else {
          targetPace.setText(
              String.format(
                  Locale.getDefault(),
                  "%s-%s",
                  formatter.format(Formatter.Format.TXT_SHORT, step.getTargetType(), minValue),
                  formatter.format(Formatter.Format.TXT_SHORT, step.getTargetType(), maxValue)));
        }
      }
      if (step.getIntensity() == Intensity.REPEAT) {
        if (step.getCurrentRepeat() >= step.getRepeatCount()) {
          durationValue.setText(org.runnerup.common.R.string.Finished);
        } else {
          durationValue.setText(
              String.format(
                  Locale.getDefault(),
                  "%d/%d",
                  (step.getCurrentRepeat() + 1),
                  step.getRepeatCount()));
        }
      }
      return view;
    }

    private View getLapRow(ContentValues tmp, View convertView, ViewGroup parent) {
      LayoutInflater inflater = LayoutInflater.from(RunActivity.this);
      return inflater.inflate(R.layout.laplist_row, parent, false);
    }
  }
}
