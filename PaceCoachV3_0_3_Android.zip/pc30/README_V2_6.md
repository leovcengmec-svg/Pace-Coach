# Pace Coach V2.6

## Objetivo
Tornar o treino estruturado realmente sequencial, com blocos de corrida e recuperação alternados.

## Mudanças
- Novo `WorkoutBuilder.addIntervalBlock(...)`.
- O exemplo 4 x 1 km agora é modelado como:
  aquecimento -> tiro 1 -> recuperação -> tiro 2 -> recuperação -> tiro 3 -> recuperação -> tiro 4 -> desaquecimento.
- O `WorkoutEngine` avança por cada bloco concreto e o `WorkoutVoice` pode anunciar cada transição.
- `RunCoachIntegration` encerra o executor quando o treino termina e emite `Treino concluído.`.
- Testes unitários para sequência e transições.

## Validação
O código foi inspecionado estaticamente e os testes foram adicionados. Este ambiente não possui Android SDK/Gradle configurado para gerar APK, portanto a compilação Android ainda precisa ser feita em ambiente Android/GitHub Actions.
