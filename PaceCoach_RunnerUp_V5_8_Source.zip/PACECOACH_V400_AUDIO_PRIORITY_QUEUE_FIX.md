# Pace Coach v400 — fila de áudio por prioridade

## Base
- Projeto-base: v398.
- Nome público: Pace Coach (preservado).
- Nome externo do ZIP: `PaceCoach_RunnerUp_V5_8_Source.zip` (preservado).

## Ordem de prioridade solicitada
1. Ritmo (`PRIO_RHYTHM`, valor 4): ritmo atual e orientações de ritmo.
2. Bloco (`PRIO_BLOCK`, valor 3): início/fim de bloco, métricas do bloco e contagens regressivas.
3. Situação geral (`PRIO_STATUS`, valor 2): situação periódica da atividade e avisos de pausa/retomada/finalização.
4. Dados gerais (`PRIO_GENERAL`, valor 1): anúncio geral por quilômetro e dados gerais da atividade.

## Comportamento da fila
- Um único utterance é enviado ao motor TTS por vez.
- Mensagens pendentes são ordenadas por prioridade e FIFO dentro da mesma prioridade.
- Uma nova mensagem só interrompe a fala atual quando tem prioridade estritamente maior.
- Ao interromper, o trecho atual é re-enfileirado; após o aviso prioritário, a fala é retomada e os trechos restantes continuam.
- As mensagens são divididas em frases/orações curtas (pontuação e vírgula) para limitar a repetição necessária ao retomar.
- O listener TTS é registrado em todos os modos, pois a fila depende dos callbacks de conclusão, erro e stop.
- Desativar a voz limpa as filas e cancela a fala ativa.

## Mapeamento
- Ritmo atual e CoachFeedback: prioridade 1 (maior).
- Dados do bloco / intervalos / countdowns: prioridade 2.
- Situação geral por tempo/distância e avisos de estado: prioridade 3.
- Dados gerais por KM e demais métricas gerais: prioridade 4 (menor).

## Limitação conhecida
Android TextToSpeech não oferece pausa/resume exatos em qualquer posição do áudio. A implementação para a fala ativa, reproduz o trecho curto interrompido desde o início depois do aviso prioritário e segue com o restante. Isso evita sobreposição; pode repetir uma oração curta, mas não descarta o restante da informação.

## Versão
- Revisão: v400.
- versionCode interno: 400 (APK esperado 23000400; Wear 23000401).
- versionName: 2.11.0.26.
- Artefato: `pacecoach-apk-v400-audio-priority-queue-fix`.

## Validação
- Testes unitários adicionados para a ordem das prioridades, regra de interrupção e classificação das quatro categorias.
- Compilação Android completa precisa ser confirmada no GitHub Actions.
