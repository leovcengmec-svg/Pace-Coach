# Pace Coach V2.0 — Execução de treino

A V2.0 inicia a passagem de "criar treino" para "executar treino".

Foi adicionado:
- WorkoutExecutor;
- snapshot da etapa ativa;
- comandos de voz/pace/finalização;
- botão de iniciar treino estruturado;
- indicação da etapa ativa na interface.

O objetivo desta versão é validar o conceito de execução antes de integrar
completamente a progressão ao GPS/RunService e ao TTS durante a corrida.

A integração de GPS em tempo real e transições automáticas pelo serviço será
a próxima etapa.
