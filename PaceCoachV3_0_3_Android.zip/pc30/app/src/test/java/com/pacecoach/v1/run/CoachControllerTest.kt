package com.pacecoach.v1.run

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CoachControllerTest {

    @Test
    fun firstStepProducesTransitionMessage() {
        val controller = CoachController()
        val step = ActiveStep(
            0, 1,
            WorkoutStep(
                kind = StepKind.RUN,
                targetPaceSeconds = 300,
                label = "1 km forte"
            )
        )

        val decision = controller.evaluate(
            step, 300, GpsQuality.GOOD, 5
        )

        assertEquals(CoachState.ON_TARGET, decision.state.state)
        assertTrue(decision.message?.contains("Próximo bloco") == true)
    }

    @Test
    fun gpsUncertainIsSpokenOnlyOnStateChange() {
        val controller = CoachController()
        val step = ActiveStep(
            0, 1,
            WorkoutStep(kind = StepKind.RUN, targetPaceSeconds = 300)
        )

        val first = controller.evaluate(step, null, GpsQuality.POOR, 5)
        val second = controller.evaluate(step, null, GpsQuality.POOR, 5)

        assertEquals(CoachState.GPS_UNCERTAIN, first.state.state)
        assertTrue(first.message != null)
        assertEquals(null, second.message)
    }
}
