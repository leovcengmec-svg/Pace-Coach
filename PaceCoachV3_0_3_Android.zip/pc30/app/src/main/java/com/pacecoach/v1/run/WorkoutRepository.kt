package com.pacecoach.v1.run

object WorkoutRepository {
    private val workouts = mutableListOf<StructuredWorkout>()

    fun save(workout: StructuredWorkout) {
        workouts.removeAll { it.name == workout.name }
        workouts.add(workout)
    }

    fun all(): List<StructuredWorkout> = workouts.toList()

    fun find(name: String): StructuredWorkout? = workouts.firstOrNull { it.name == name }

    fun delete(name: String) { workouts.removeAll { it.name == name } }
}
