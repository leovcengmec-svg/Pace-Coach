package com.pacecoach.v1.run

import kotlin.math.abs

/**
 * Decide quando um novo anúncio acrescenta informação.
 * Evita repetir a mesma mensagem quando o estado do corredor não mudou.
 */
class AnnouncementPolicy(
    private val changeThresholdSeconds: Int = 3,
    private val minimumSpeechGapMs: Long = 3000L
) {
    private var lastPace: Int? = null
    private var lastState: State? = null
    private var lastSpokenAt: Long = 0L

    enum class State { WITHIN, SLOWER, FASTER }

    fun shouldSpeak(
        paceSeconds: Int,
        targetSeconds: Int,
        marginSeconds: Int,
        nowMs: Long = System.currentTimeMillis()
    ): Boolean {
        if (nowMs - lastSpokenAt < minimumSpeechGapMs) return false

        val diff = paceSeconds - targetSeconds
        val state = when {
            abs(diff) <= marginSeconds -> State.WITHIN
            diff > 0 -> State.SLOWER
            else -> State.FASTER
        }

        val stateChanged = state != lastState
        val paceChanged = lastPace == null ||
                abs(paceSeconds - (lastPace ?: paceSeconds)) >= changeThresholdSeconds

        return stateChanged || paceChanged
    }

    fun markSpoken(paceSeconds: Int, targetSeconds: Int, marginSeconds: Int, nowMs: Long = System.currentTimeMillis()) {
        lastPace = paceSeconds
        val diff = paceSeconds - targetSeconds
        lastState = when {
            abs(diff) <= marginSeconds -> State.WITHIN
            diff > 0 -> State.SLOWER
            else -> State.FASTER
        }
        lastSpokenAt = nowMs
    }

    fun reset() {
        lastPace = null
        lastState = null
        lastSpokenAt = 0L
    }
}
