/*
 * Pace Coach backup support.
 *
 * Keeps the existing RunnerUp/RunnerUp-compatible database export untouched and adds a
 * complete application backup containing the activity database, custom workouts, app files,
 * shared preferences and a small manifest. The backup is intentionally self-contained so it
 * can be moved between installations without requiring a server.
 */
package org.runnerup.util;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import org.json.JSONObject;
import org.runnerup.db.DBHelper;
import org.runnerup.workout.WorkoutSerializer;

public final class PaceCoachBackupManager {
  public static final String MIME_TYPE = "application/zip";
  public static final String FILE_EXTENSION = ".pacecoachbackup";
  private static final String MANIFEST = "pacecoach-manifest.json";
  private static final String DATABASE_ENTRY = "database/runnerup.db";
  private static final String WORKOUTS_PREFIX = "workouts/";
  private static final String FILES_PREFIX = "files/";
  private static final String PREFS_PREFIX = "shared_prefs/";
  private static final int BUFFER_SIZE = 32 * 1024;

  private PaceCoachBackupManager() {}

  public static String suggestedFileName() {
    String stamp =
        new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date(System.currentTimeMillis()));
    return "PaceCoach_Backup_" + stamp + FILE_EXTENSION;
  }

  public static void exportBackup(Context context, Uri destination) throws Exception {
    if (destination == null) throw new IOException("Destino do backup não informado");

    Context app = context.getApplicationContext();
    File dbFile = new File(DBHelper.getDbPath(app));
    if (!dbFile.isFile()) throw new IOException("Banco de dados não encontrado");

    // Flush SQLite WAL before copying the database file.
    SQLiteDatabase db = DBHelper.getReadableDatabase(app);
    try (Cursor ignored = db.rawQuery("PRAGMA wal_checkpoint(FULL)", null)) {
      while (ignored.moveToNext()) {
        // Consume the result so SQLite can complete the checkpoint.
      }
    }

    try (OutputStream raw = app.getContentResolver().openOutputStream(destination);
        BufferedOutputStream buffered = new BufferedOutputStream(raw, BUFFER_SIZE);
        ZipOutputStream zip = new ZipOutputStream(buffered)) {
      JSONObject manifest = new JSONObject();
      manifest.put("format", "PaceCoachBackup");
      manifest.put("version", 1);
      manifest.put("createdAt", System.currentTimeMillis());
      manifest.put("package", app.getPackageName());
      manifest.put("database", "database/runnerup.db");
      manifest.put("includesWorkouts", true);
      manifest.put("includesFiles", true);
      manifest.put("includesPreferences", true);
      writeBytes(zip, MANIFEST, manifest.toString(2).getBytes(StandardCharsets.UTF_8));

      addFile(zip, dbFile, DATABASE_ENTRY);

      File workouts = app.getDir(WorkoutSerializer.WORKOUTS_DIR, 0);
      if (workouts.isDirectory()) addDirectory(zip, workouts, WORKOUTS_PREFIX);

      File files = app.getFilesDir();
      if (files.isDirectory()) addDirectory(zip, files, FILES_PREFIX);

      File prefs = new File(app.getApplicationInfo().dataDir, "shared_prefs");
      if (prefs.isDirectory()) addDirectory(zip, prefs, PREFS_PREFIX);
    }
  }

  public static void importBackup(Context context, Uri source) throws Exception {
    if (source == null) throw new IOException("Arquivo de backup não informado");

    Context app = context.getApplicationContext();
    File staging = new File(app.getCacheDir(), "pacecoach_restore_" + System.currentTimeMillis());
    if (!staging.mkdirs()) throw new IOException("Não foi possível criar a área temporária");

    try {
      File archive = new File(staging, "backup.zip");
      try (InputStream raw = app.getContentResolver().openInputStream(source);
          InputStream in = new BufferedInputStream(raw, BUFFER_SIZE);
          OutputStream out = new BufferedOutputStream(new FileOutputStream(archive), BUFFER_SIZE)) {
        if (raw == null) throw new IOException("Não foi possível abrir o backup");
        copy(in, out);
      }

      File stagedDb = new File(staging, DATABASE_ENTRY);
      extractRequiredAndData(archive, staging);
      validateDatabase(stagedDb);

      // Replace only after the complete archive has been copied and validated.
      File currentDb = new File(DBHelper.getDbPath(app));
      File parent = currentDb.getParentFile();
      if (parent != null && !parent.isDirectory() && !parent.mkdirs()) {
        throw new IOException("Não foi possível acessar o diretório do banco");
      }

      // A checkpointed backup does not need the previous WAL/SHM files. Keeping them could
      // make SQLite replay stale data after restore, so remove them before the next launch.
      File wal = new File(currentDb.getPath() + "-wal");
      File shm = new File(currentDb.getPath() + "-shm");
      if (wal.exists()) wal.delete();
      if (shm.exists()) shm.delete();
      copyFile(stagedDb, currentDb);

      File workoutsDestination = app.getDir(WorkoutSerializer.WORKOUTS_DIR, 0);
      File filesDestination = app.getFilesDir();
      File prefsDestination = new File(app.getApplicationInfo().dataDir, "shared_prefs");
      clearDirectoryContents(workoutsDestination);
      clearDirectoryContents(filesDestination);
      clearDirectoryContents(prefsDestination);
      restoreDirectory(new File(staging, WORKOUTS_PREFIX), workoutsDestination);
      restoreDirectory(new File(staging, FILES_PREFIX), filesDestination);
      restoreDirectory(new File(staging, PREFS_PREFIX), prefsDestination);
    } finally {
      deleteRecursively(staging);
    }
  }

  private static void extractRequiredAndData(File archive, File staging) throws IOException {
    try (ZipFile zip = new ZipFile(archive)) {
      ZipEntry manifestEntry = zip.getEntry(MANIFEST);
      ZipEntry dbEntry = zip.getEntry(DATABASE_ENTRY);
      if (manifestEntry == null || dbEntry == null) {
        throw new IOException("Este arquivo não é um backup completo do Pace Coach");
      }

      String manifest;
      try (InputStream in = zip.getInputStream(manifestEntry);
          ByteArrayOutputStream out = new ByteArrayOutputStream()) {
        copy(in, out);
        manifest = out.toString(StandardCharsets.UTF_8.name());
      }
      try {
        JSONObject obj = new JSONObject(manifest);
        if (!"PaceCoachBackup".equals(obj.optString("format"))) {
          throw new IOException("Formato de backup inválido");
        }
      } catch (Exception e) {
        if (e instanceof IOException) throw (IOException) e;
        throw new IOException("Manifesto de backup inválido", e);
      }

      java.util.Enumeration<? extends ZipEntry> entries = zip.entries();
      while (entries.hasMoreElements()) {
        ZipEntry entry = entries.nextElement();
        if (entry.isDirectory()) continue;
        String name = entry.getName();
        if (name.contains("..") || name.startsWith("/")) {
          throw new IOException("Backup contém caminho inválido");
        }
        if (!(name.equals(MANIFEST)
            || name.equals(DATABASE_ENTRY)
            || name.startsWith(WORKOUTS_PREFIX)
            || name.startsWith(FILES_PREFIX)
            || name.startsWith(PREFS_PREFIX))) {
          continue;
        }

        File target = new File(staging, name);
        File targetParent = target.getParentFile();
        if (targetParent != null && !targetParent.isDirectory() && !targetParent.mkdirs()) {
          throw new IOException("Não foi possível preparar a restauração");
        }
        try (InputStream in = zip.getInputStream(entry);
            OutputStream out = new BufferedOutputStream(new FileOutputStream(target), BUFFER_SIZE)) {
          copy(in, out);
        }
      }
    }
  }

  private static void validateDatabase(File dbFile) throws IOException {
    if (!dbFile.isFile() || dbFile.length() == 0) {
      throw new IOException("Backup sem banco de dados válido");
    }
    SQLiteDatabase db = null;
    try {
      db = SQLiteDatabase.openDatabase(dbFile.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
      try (Cursor c =
          db.rawQuery(
              "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='activity'", null)) {
        if (!c.moveToFirst() || c.getInt(0) != 1) {
          throw new IOException("Banco do backup não é compatível com o Pace Coach");
        }
      }
    } catch (IOException e) {
      throw e;
    } catch (Exception e) {
      throw new IOException("Não foi possível validar o banco do backup", e);
    } finally {
      if (db != null && db.isOpen()) db.close();
    }
  }

  private static void clearDirectoryContents(File directory) throws IOException {
    if (!directory.exists()) {
      if (!directory.mkdirs()) throw new IOException("Não foi possível criar " + directory);
      return;
    }
    File[] children = directory.listFiles();
    if (children == null) return;
    for (File child : children) deleteRecursively(child);
  }

  private static void restoreDirectory(File source, File destination) throws IOException {
    if (!source.isDirectory()) return;
    if (!destination.exists() && !destination.mkdirs()) {
      throw new IOException("Não foi possível criar " + destination);
    }
    File[] children = source.listFiles();
    if (children == null) return;
    for (File child : children) {
      File target = new File(destination, child.getName());
      if (child.isDirectory()) {
        restoreDirectory(child, target);
      } else {
        copyFile(child, target);
      }
    }
  }

  private static void addDirectory(ZipOutputStream zip, File directory, String prefix)
      throws IOException {
    File[] children = directory.listFiles();
    if (children == null) return;
    for (File child : children) {
      addFileOrDirectory(zip, child, prefix + child.getName());
    }
  }

  private static void addFileOrDirectory(ZipOutputStream zip, File file, String entryName)
      throws IOException {
    if (file.isDirectory()) {
      String dir = entryName.endsWith("/") ? entryName : entryName + "/";
      zip.putNextEntry(new ZipEntry(dir));
      zip.closeEntry();
      File[] children = file.listFiles();
      if (children != null) {
        for (File child : children) addFileOrDirectory(zip, child, dir + child.getName());
      }
    } else {
      addFile(zip, file, entryName);
    }
  }

  private static void addFile(ZipOutputStream zip, File file, String entryName) throws IOException {
    zip.putNextEntry(new ZipEntry(entryName));
    try (InputStream in = new BufferedInputStream(new FileInputStream(file), BUFFER_SIZE)) {
      copy(in, zip);
    }
    zip.closeEntry();
  }

  private static void writeBytes(ZipOutputStream zip, String entryName, byte[] data) throws IOException {
    zip.putNextEntry(new ZipEntry(entryName));
    zip.write(data);
    zip.closeEntry();
  }

  private static void copyFile(File from, File to) throws IOException {
    File parent = to.getParentFile();
    if (parent != null && !parent.isDirectory() && !parent.mkdirs()) {
      throw new IOException("Não foi possível criar " + parent);
    }
    try (InputStream in = new BufferedInputStream(new FileInputStream(from), BUFFER_SIZE);
        OutputStream out = new BufferedOutputStream(new FileOutputStream(to), BUFFER_SIZE)) {
      copy(in, out);
    }
  }

  private static void copy(InputStream in, OutputStream out) throws IOException {
    byte[] buffer = new byte[BUFFER_SIZE];
    int read;
    while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
  }

  private static void deleteRecursively(File file) {
    if (file == null || !file.exists()) return;
    if (file.isDirectory()) {
      File[] children = file.listFiles();
      if (children != null) for (File child : children) deleteRecursively(child);
    }
    file.delete();
  }
}
