/*
 * Copyright (C) 2012 - 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.util;

import static org.runnerup.util.Formatter.Format.TXT_SHORT;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Point;
import android.location.Location;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.osmdroid.api.IMapController;
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.BoundingBox;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.CustomZoomButtonsController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Polyline;
import org.runnerup.common.util.Constants;
import org.runnerup.db.entities.LocationEntity;

public class MapWrapper implements Constants {

  private final SQLiteDatabase mDB;
  private final long mID;
  private final Formatter formatter;
  private final MapView mapView;
  private final Context context;
  private final boolean detailMode;
  private volatile BoundingBox lastBounds;

  private final ExecutorService executor = Executors.newSingleThreadExecutor();
  private volatile Location currentLocation;
  private volatile List<Marker> activeLapMarkers = new ArrayList<>();
  private boolean hasCenteredOnCurrent = false;

  private static final java.lang.String OSMDROID_USER_AGENT = "org.runnerup.free";

  public MapWrapper(
      Context context,
      SQLiteDatabase mDB,
      long mID,
      Formatter formatter,
      java.lang.Object mapView) {
    this(context, mDB, mID, formatter, mapView, false);
  }

  public MapWrapper(
      Context context,
      SQLiteDatabase mDB,
      long mID,
      Formatter formatter,
      java.lang.Object mapView,
      boolean detailMode) {
    this.context = context;
    this.mDB = mDB;
    this.mID = mID;
    this.formatter = formatter;
    this.mapView = (MapView) mapView;
    this.detailMode = detailMode;
  }

  public static void start(Context context) {}

  public void onCreate(Bundle savedInstanceState) {
    mapView.setTileSource(TileSourceFactory.MAPNIK);
    mapView
        .getZoomController()
        .setVisibility(CustomZoomButtonsController.Visibility.NEVER);
    mapView.setMultiTouchControls(true);

    Configuration.getInstance().setUserAgentValue(OSMDROID_USER_AGENT);

    refresh();
  }

  // The results from the database query
  record Route(Polyline map, List<Marker> markers, List<Marker> lapMarkers, GeoPoint firstPoint, BoundingBox bounds) {}

  /** Update the live GPS position used by the running route overlay. */
  public void updateCurrentLocation(Location location) {
    if (location == null) return;
    currentLocation = new Location(location);
  }

  public void refresh() {
    executor.execute(
        () -> {
          final Route route = loadRouteData();

          // UI update
          mapView.post(
              () -> {
                IMapController mapController = mapView.getController();
                lastBounds = route.bounds;
                activeLapMarkers = route.lapMarkers;

                // For a completed workout, show the whole route instead of
                // centering only on the first point. For a live workout, keep
                // the runner centered while it is moving.
                Location live = currentLocation;
                if (live != null) {
                  mapController.setCenter(new GeoPoint(live.getLatitude(), live.getLongitude()));
                  if (!hasCenteredOnCurrent) {
                    mapController.setZoom(16.0);
                    hasCenteredOnCurrent = true;
                  }
                } else if (!hasCenteredOnCurrent && route.bounds != null) {
                  mapController.setCenter(route.bounds.getCenter());
                  mapView.zoomToBoundingBox(route.bounds, true, 80);
                  hasCenteredOnCurrent = true;
                } else if (!hasCenteredOnCurrent && route.firstPoint != null) {
                  mapController.setZoom(16.0);
                  mapController.setCenter(route.firstPoint);
                  hasCenteredOnCurrent = true;
                }

                // Replace the current live route with the newest valid GPS points.
                mapView.getOverlays().clear();
                for (Marker marker : route.markers) {
                  mapView.getOverlays().add(marker);
                }
                mapView.getOverlays().add(route.map);

                // Draw the current GPS position immediately, even when the latest
                // location has not been persisted to SQLite yet.
                if (live != null && isUsableLiveLocation(live)) {
                  Marker current = new Marker(mapView);
                  current.setPosition(new GeoPoint(live.getLatitude(), live.getLongitude()));
                  current.setIcon(createCurrentLocationIcon());
                  current.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER);
                  current.setInfoWindow(null);
                  mapView.getOverlays().add(current);
                }

                mapView.invalidate();
                mapView.post(() -> resolveLapLabelCollisions(route.lapMarkers));
              });
        });
  }

  /** The long-running database query and data processing logic. */
  private Route loadRouteData() {
    Polyline polyline = new Polyline(mapView, true);
    polyline.setInfoWindow(null);
    polyline.getOutlinePaint().setColor(Color.rgb(20, 166, 255));
    polyline.getOutlinePaint().setStrokeWidth(9.f);
    polyline.getOutlinePaint().setAntiAlias(true);

    java.util.List<Marker> markers = new ArrayList<>();
    java.util.List<Marker> lapMarkers = new ArrayList<>();
    java.util.List<GeoPoint> points = new LinkedList<>();

    LocationEntity.LocationList<LocationEntity> ll = new LocationEntity.LocationList<>(mDB, mID);
    int lastLap = -1;
    for (LocationEntity loc : ll) {
      GeoPoint point = new GeoPoint(loc.getLatitude(), loc.getLongitude());
      points.add(point);

      int lap = loc.getLap();
      if (lastLap != lap) {
        Marker marker = new Marker(mapView);
        marker.setPosition(point);
        java.lang.String info =
            "#"
                + loc.getLap()
                + " "
                + formatter.formatDistance(TXT_SHORT, loc.getDistance().longValue())
                + " "
                + formatter.formatElapsedTime(TXT_SHORT, Math.round(loc.getElapsed() / 1000.0));
        lastLap = lap;
        if (detailMode && loc.getDistance() != null && loc.getDistance().doubleValue() >= 1000.0) {
          String kmText = loc.getLap() + " km";
          String timeText = formatter.formatElapsedTime(TXT_SHORT, Math.round(loc.getElapsed() / 1000.0));
          marker.setIcon(createLapLabelIcon(kmText, timeText));
        } else {
          marker.setTextIcon(info);
        }
        marker.setInfoWindow(null);
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        markers.add(marker);
      }
    }
    ll.close();

    // The database writer can lag behind the live GPS callback by a short amount.
    // Add the latest validated position to the visible route so the line grows
    // continuously while the runner is moving instead of waiting for persistence.
    Location live = currentLocation;
    if (live != null && isUsableLiveLocation(live)) {
      GeoPoint livePoint = new GeoPoint(live.getLatitude(), live.getLongitude());
      if (points.isEmpty()) {
        points.add(livePoint);
      } else {
        GeoPoint last = points.get(points.size() - 1);
        float[] result = new float[1];
        Location.distanceBetween(
            last.getLatitude(), last.getLongitude(),
            livePoint.getLatitude(), livePoint.getLongitude(), result);
        // Avoid drawing tiny GPS jitter as extra route geometry.
        if (result[0] >= 2.0f) {
          points.add(livePoint);
        }
      }
    }

    // Add explicit start/end markers for imported GPX and recorded workouts.
    if (!points.isEmpty()) {
      Marker start = new Marker(mapView);
      start.setPosition(points.get(0));
      start.setTitle("Início");
      start.setIcon(detailMode ? createStartIcon() : createMapMarker(Color.rgb(40, 200, 120)));
      start.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
      start.setInfoWindow(null);
      markers.add(0, start);

      if (points.size() > 1) {
        Marker end = new Marker(mapView);
        end.setPosition(points.get(points.size() - 1));
        end.setTitle("Fim");
        end.setIcon(detailMode ? createFinishIcon() : createMapMarker(Color.rgb(255, 92, 92)));
        end.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        end.setInfoWindow(null);
        markers.add(end);
      }
    }

    // Imported GPX files can contain tens of thousands of GPS points.
    // Keeping every point in the map polyline makes osmdroid spend too much
    // time drawing on the UI thread when the detail screen is opened.
    // Preserve the complete route shape with bounded sampling instead.
    points = downsampleRoute(points, 2500);
    polyline.setPoints(points);

    GeoPoint firstPoint = points.isEmpty() ? null : points.get(0);
    BoundingBox bounds = points.isEmpty() ? null : BoundingBox.fromGeoPoints(points);
    return new Route(polyline, markers, lapMarkers, firstPoint, bounds);
  }


  /** Hide lap labels that would overlap each other on the current map viewport.
   *  The route remains fully visible; only redundant/overlapping labels are suppressed.
   */
  private void resolveLapLabelCollisions(List<Marker> lapMarkers) {
    if (lapMarkers == null || lapMarkers.size() < 2) return;

    Point previous = null;
    final int minVerticalGap = Math.round(58f * context.getResources().getDisplayMetrics().density);
    final int minHorizontalGap = Math.round(70f * context.getResources().getDisplayMetrics().density);

    for (Marker marker : lapMarkers) {
      marker.setEnabled(true);
      Point current = mapView.getProjection().toPixels(marker.getPosition(), null);
      if (previous != null) {
        int dx = Math.abs(current.x - previous.x);
        int dy = Math.abs(current.y - previous.y);
        if (dx < minHorizontalGap && dy < minVerticalGap) {
          marker.setEnabled(false);
          continue;
        }
      }
      previous = current;
    }
  }

  private List<GeoPoint> downsampleRoute(List<GeoPoint> source, int maxPoints) {
    if (source.size() <= maxPoints) return source;
    List<GeoPoint> sampled = new ArrayList<>(maxPoints);
    double step = (source.size() - 1.0) / (maxPoints - 1.0);
    int lastIndex = -1;
    for (int i = 0; i < maxPoints; i++) {
      int index = (int) Math.round(i * step);
      if (index == lastIndex) continue;
      sampled.add(source.get(index));
      lastIndex = index;
    }
    return sampled;
  }

  private boolean isUsableLiveLocation(Location location) {
    if (location == null || !location.hasAccuracy()) return false;
    return location.getAccuracy() <= 50.0f;
  }


  /** Fit the complete recorded route in the viewport. Used by the detail-screen map controls. */
  public void centerOnRoute() {
    mapView.post(() -> {
      if (lastBounds != null) {
        mapView.getController().setCenter(lastBounds.getCenter());
        mapView.zoomToBoundingBox(lastBounds, true, 80);
        mapView.invalidate();
        mapView.post(() -> {
          // Re-evaluate label visibility after the viewport/zoom changes.
          // The route itself is never hidden or modified.
          resolveLapLabelCollisions(getLapMarkersFromOverlays());
        });
      }
    });
  }

  public void zoomIn() {
    mapView.post(() -> {
      mapView.getController().zoomIn();
      mapView.invalidate();
      mapView.post(() -> resolveLapLabelCollisions(getLapMarkersFromOverlays()));
    });
  }

  public void zoomOut() {
    mapView.post(() -> {
      mapView.getController().zoomOut();
      mapView.invalidate();
      mapView.post(() -> resolveLapLabelCollisions(getLapMarkersFromOverlays()));
    });
  }


  private List<Marker> getLapMarkersFromOverlays() {
    return activeLapMarkers;
  }

  private BitmapDrawable createLapLabelIcon(String title, String subtitle) {
    float density = context.getResources().getDisplayMetrics().density;
    Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    titlePaint.setColor(Color.WHITE);
    titlePaint.setTextSize(14f * density);
    titlePaint.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD));
    Paint subPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    subPaint.setColor(Color.WHITE);
    subPaint.setTextSize(12f * density);
    float width = Math.max(titlePaint.measureText(title), subPaint.measureText(subtitle)) + 24f * density;
    float height = 48f * density;
    Bitmap bitmap = Bitmap.createBitmap((int) width, (int) height, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    bg.setColor(Color.rgb(15, 27, 37));
    bg.setStyle(Paint.Style.FILL);
    canvas.drawRoundRect(0, 0, width, height, 9f * density, 9f * density, bg);
    Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    stroke.setColor(Color.rgb(57, 169, 255));
    stroke.setStyle(Paint.Style.STROKE);
    stroke.setStrokeWidth(1.5f * density);
    canvas.drawRoundRect(0.75f * density, 0.75f * density, width - 0.75f * density, height - 0.75f * density, 9f * density, 9f * density, stroke);
    float x = 12f * density;
    canvas.drawText(title, x, 19f * density, titlePaint);
    canvas.drawText(subtitle, x, 38f * density, subPaint);
    return new BitmapDrawable(context.getResources(), bitmap);
  }

  private BitmapDrawable createStartIcon() {
    return createPinIcon(Color.rgb(40, 210, 120), true);
  }

  private BitmapDrawable createFinishIcon() {
    return createPinIcon(Color.rgb(255, 70, 70), false);
  }

  private BitmapDrawable createPinIcon(int color, boolean start) {
    float d = context.getResources().getDisplayMetrics().density;
    int size = (int) (42f * d);
    Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    p.setColor(color);
    canvas.drawCircle(size / 2f, size / 2f, 16f * d, p);
    p.setColor(Color.WHITE);
    p.setStyle(Paint.Style.STROKE);
    p.setStrokeWidth(2f * d);
    canvas.drawCircle(size / 2f, size / 2f, 16f * d, p);
    p.setStyle(Paint.Style.FILL);
    if (start) {
      Path tri = new Path();
      tri.moveTo(15f * d, 11f * d);
      tri.lineTo(15f * d, 31f * d);
      tri.lineTo(30f * d, 21f * d);
      tri.close();
      canvas.drawPath(tri, p);
    } else {
      p.setStrokeWidth(2f * d);
      p.setStyle(Paint.Style.STROKE);
      for (int row = 0; row < 2; row++) {
        for (int col = 0; col < 2; col++) {
          if ((row + col) % 2 == 0) {
            p.setStyle(Paint.Style.FILL);
            canvas.drawRect((15 + col * 6) * d, (15 + row * 6) * d, (21 + col * 6) * d, (21 + row * 6) * d, p);
          }
        }
      }
    }
    return new BitmapDrawable(context.getResources(), bitmap);
  }

  private GradientDrawable createMapMarker(int color) {
    GradientDrawable drawable = new GradientDrawable();
    drawable.setShape(GradientDrawable.OVAL);
    drawable.setColor(color);
    drawable.setStroke(3, Color.WHITE);
    drawable.setSize(30, 30);
    return drawable;
  }

  private GradientDrawable createCurrentLocationIcon() {
    GradientDrawable drawable = new GradientDrawable();
    drawable.setShape(GradientDrawable.OVAL);
    drawable.setColor(Color.rgb(20, 166, 255));
    drawable.setStroke(5, Color.WHITE);
    drawable.setSize(36, 36);
    return drawable;
  }

  public void onResume() {
    mapView.onResume();
  }

  public void onStart() {}

  public void onStop() {}

  public void onPause() {
    mapView.onPause();
  }

  public void onSaveInstanceState(Bundle outState) {}

  public void onLowMemory() {}

  public void onDestroy() {
    executor.shutdown();
  }
}
