package org.runnerup.workout;

/** Countdown trigger for Pace Coach Descanso Off. It uses the independent
 * wall-clock rest timer instead of the paused activity/step timer. */
public class DescansoOffCountdownTrigger extends Trigger {
  private final double[] thresholds;
  private int position;

  public DescansoOffCountdownTrigger(double durationSeconds) {
    java.util.ArrayList<Double> values = new java.util.ArrayList<>();
    double[] base = {60d, 30d, 10d, 5d, 4d, 3d, 2d, 1d};
    for (double v : base) if (durationSeconds >= v) values.add(v);
    if (values.isEmpty() || values.get(0) < durationSeconds) {
      values.add(0, durationSeconds);
    }
    thresholds = new double[values.size()];
    for (int i = 0; i < values.size(); i++) thresholds[i] = values.get(i);
    position = 0;
  }

  @Override public boolean onTick(Workout w) {
    Step step = w.getCurrentStep();
    if (step == null || !step.isPaceCoachOffRest()) return false;
    double remaining = step.getPaceCoachOffRestRemainingSeconds();
    while (position < thresholds.length && remaining <= thresholds[position] + 0.4d) {
      fire(w);
      position++;
    }
    return false;
  }

  @Override public void onRepeat(int current, int limit) {}

  @Override public void onStart(Scope what, Workout s) {
    if (what == Scope.STEP) {
      position = 0;
      for (Feedback f : triggerAction) f.onStart(s);
    }
  }

  @Override public void onPause(Workout s) {}
  @Override public void onStop(Workout s) {}
  @Override public void onResume(Workout s) {}
  @Override public void onComplete(Scope what, Workout s) {}
}
