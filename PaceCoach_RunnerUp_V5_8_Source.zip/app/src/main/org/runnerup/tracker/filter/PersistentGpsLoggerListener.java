/*
 * Copyright (C) 2012 jonas.oreland@gmail.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.tracker.filter;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.util.Log;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import org.runnerup.common.util.Constants;
import org.runnerup.tracker.LocationListenerBase;

/**
 * Persists GPS samples away from the UI and location callback threads.
 *
 * <p>A single-thread executor preserves the exact order in which accepted points arrive. Content
 * values are copied before they are queued, so lap/type changes made by the UI cannot rewrite an
 * already received location. Call {@link #flush(long)} before writing the final activity summary or
 * changing the database lifecycle.
 */
public class PersistentGpsLoggerListener extends LocationListenerBase implements Constants {
  private static final String TAG = "GpsDbWriter";
  private static final long DEFAULT_FLUSH_TIMEOUT_MS = 5000L;
  // 512 GPS samples represent several minutes at the normal polling rate. The queue is bounded
  // to prevent unbounded memory growth if SQLite is temporarily slower than the GPS provider.
  private static final int MAX_QUEUED_LOCATION_SAMPLES = 512;

  private final Object lock = new Object();
  private final ThreadPoolExecutor executor;
  private final boolean logGpxAccuracy;
  private volatile SQLiteDatabase database;
  private String table;
  private ContentValues key;
  private volatile boolean closed;

  public PersistentGpsLoggerListener(
      SQLiteDatabase db, String table, ContentValues key, boolean logGpxAccuracy) {
    this.database = db;
    this.table = table;
    this.logGpxAccuracy = logGpxAccuracy;

    AtomicInteger threadNumber = new AtomicInteger();
    ThreadFactory threadFactory =
        runnable -> {
          Thread thread =
              new Thread(runnable, "RunnerUp-GpsDbWriter-" + threadNumber.incrementAndGet());
          thread.setPriority(Thread.NORM_PRIORITY - 1);
          thread.setDaemon(true);
          return thread;
        };
    this.executor =
        new ThreadPoolExecutor(
            1,
            1,
            0L,
            TimeUnit.MILLISECONDS,
            new ArrayBlockingQueue<>(MAX_QUEUED_LOCATION_SAMPLES),
            threadFactory,
            // Normal GPS samples are produced on Tracker's dedicated Looper. If SQLite falls
            // behind, the producer applies back-pressure instead of allowing unbounded growth.
            // A rare lifecycle marker may be submitted by the caller/UI thread, but only when
            // the bounded queue is saturated.
            new ThreadPoolExecutor.CallerRunsPolicy() {
              @Override
              public void rejectedExecution(Runnable task, ThreadPoolExecutor pool) {
                if (pool.isShutdown()) {
                  throw new RejectedExecutionException("GPS database writer is shut down");
                }
                super.rejectedExecution(task, pool);
              }
            });
    setKey(key);
  }

  public SQLiteDatabase getDB() {
    return database;
  }

  public void setDB(SQLiteDatabase db) {
    database = db;
  }

  public String getTable() {
    synchronized (lock) {
      return table;
    }
  }

  public void setTable(String table) {
    synchronized (lock) {
      this.table = table;
    }
  }

  public ContentValues getKey() {
    synchronized (lock) {
      return key == null ? null : new ContentValues(key);
    }
  }

  public void setKey(ContentValues key) {
    synchronized (lock) {
      this.key = key == null ? null : new ContentValues(key);
    }
  }

  @Override
  public void onLocationChanged(
      Location location,
      Double elevation,
      Long elapsed,
      Double distance,
      Integer heartRate,
      Float cadence,
      Float temperature,
      Float pressure) {
    if (location == null || closed) {
      return;
    }

    final ContentValues values;
    final String destinationTable;
    synchronized (lock) {
      values = key == null ? new ContentValues() : new ContentValues(key);
      destinationTable = table;
    }

    values.put(DB.LOCATION.TIME, location.getTime());
    values.put(DB.LOCATION.LATITUDE, location.getLatitude());
    values.put(DB.LOCATION.LONGITUDE, location.getLongitude());
    if (elevation != null) {
      values.put(DB.LOCATION.ALTITUDE, elevation);
    }
    if (location.hasAccuracy()) {
      values.put(DB.LOCATION.ACCURANCY, location.getAccuracy());
    }

    if (logGpxAccuracy) {
      if (location.hasAltitude()) {
        values.put(DB.LOCATION.GPS_ALTITUDE, location.getAltitude());
      }
      if (location.hasSpeed()) {
        values.put(DB.LOCATION.SPEED, location.getSpeed());
      }
      if (location.hasBearing()) {
        values.put(DB.LOCATION.BEARING, location.getBearing());
      }
      if (location.getExtras() != null) {
        int satellites = location.getExtras().getInt("satellites", -1);
        if (satellites >= 0) {
          values.put(DB.LOCATION.SATELLITES, satellites);
        }
      }
      if (pressure != null) {
        values.put(DB.LOCATION.PRESSURE, pressure);
      }
    }
    if (elapsed != null) {
      values.put(DB.LOCATION.ELAPSED, elapsed);
    }
    if (distance != null) {
      values.put(DB.LOCATION.DISTANCE, distance);
    }
    if (heartRate != null) {
      values.put(DB.LOCATION.HR, heartRate);
    }
    if (cadence != null) {
      values.put(DB.LOCATION.CADENCE, cadence);
    }
    if (temperature != null) {
      values.put(DB.LOCATION.TEMPERATURE, temperature);
    }

    final SQLiteDatabase db = database;
    if (db == null || destinationTable == null || closed) {
      Log.w(TAG, "Dropping GPS sample because the database writer is not available");
      return;
    }

    try {
      executor.execute(
          () -> {
            try {
              long rowId = db.insert(destinationTable, null, values);
              if (rowId == -1L) {
                Log.e(TAG, "SQLite did not insert a GPS sample");
              }
            } catch (RuntimeException ex) {
              Log.e(TAG, "Unable to persist GPS sample", ex);
            }
          });
    } catch (RejectedExecutionException ex) {
      if (!closed) {
        Log.e(TAG, "GPS sample queue rejected a write", ex);
      }
    }
  }

  /** Waits until all samples queued before this call have been written. */
  public boolean flush(long timeoutMs) {
    if (closed || executor.isShutdown()) {
      return true;
    }

    final Future<?> barrier;
    try {
      barrier = executor.submit(() -> {});
    } catch (RejectedExecutionException ex) {
      return closed;
    }

    try {
      barrier.get(Math.max(1L, timeoutMs), TimeUnit.MILLISECONDS);
      return true;
    } catch (InterruptedException ex) {
      Thread.currentThread().interrupt();
      Log.e(TAG, "Interrupted while waiting for queued GPS samples", ex);
    } catch (ExecutionException | TimeoutException ex) {
      Log.e(TAG, "Timed out waiting for queued GPS samples", ex);
    }
    return false;
  }

  public boolean flush() {
    return flush(DEFAULT_FLUSH_TIMEOUT_MS);
  }

  /** Stops accepting new points and waits for previously queued writes to finish. */
  public boolean closeAndWait() {
    if (closed) {
      return executor.isTerminated();
    }
    // shutdown() drains all tasks already accepted by the executor. Setting closed first stops
    // new producers from adding work; a single bounded wait avoids the former two-timeout stall.
    closed = true;
    executor.shutdown();
    try {
      if (!executor.awaitTermination(DEFAULT_FLUSH_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
        Log.e(TAG, "GPS database writer did not stop within the shutdown timeout");
        return false;
      }
    } catch (InterruptedException ex) {
      Thread.currentThread().interrupt();
      Log.e(TAG, "Interrupted while stopping GPS database writer", ex);
      return false;
    }
    return executor.isTerminated();
  }
}
