# Pace Coach V2.1 — Coach em tempo real

A V2.1 cria a ponte entre:
- etapa ativa do treino;
- pace atual;
- pace-alvo da etapa;
- qualidade do GPS;
- estado do coach.

Estados:
- ON_TARGET
- SLOWER_THAN_TARGET
- FASTER_THAN_TARGET
- GPS_UNCERTAIN
- FINISHED

Também inclui um teste unitário determinístico para verificar a decisão do
estado do coach sem depender de GPS real.

Próxima etapa: ligar esta avaliação ao RunService para que as mudanças de
etapa e os estados relevantes sejam realmente anunciados pelo TTS durante a
corrida.
