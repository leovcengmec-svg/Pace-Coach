package org.runnerup.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Two-column duration picker used by Pace Coach free-run editor: hours + minutes. */
public class CoachDurationPicker extends LinearLayout {
  private final NumberPicker hours;
  private final NumberPicker minutes;

  public CoachDurationPicker(Context context, AttributeSet attrs) {
    super(context);
    setOrientation(HORIZONTAL);
    setGravity(Gravity.CENTER);
    setPadding(0, 0, 0, 0);
    setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));

    hours = createPicker(context, attrs, 23);
    minutes = createPicker(context, attrs, 59);
    addColumn(context, hours, "h");
    addColumn(context, minutes, "min");
  }

  private NumberPicker createPicker(Context context, AttributeSet attrs, int max) {
    NumberPicker picker = new NumberPicker(context, attrs);
    picker.setDigits(2);
    picker.setRange(0, max, false);
    picker.setOrientation(VERTICAL);
    picker.setGravity(Gravity.CENTER);
    picker.setPadding(0, 0, 0, 0);
    return picker;
  }

  private void addColumn(Context context, NumberPicker picker, String unit) {
    LinearLayout column = new LinearLayout(context);
    column.setOrientation(HORIZONTAL);
    column.setGravity(Gravity.CENTER);
    column.setPadding(0, 0, 0, 0);

    LinearLayout.LayoutParams pickerLp = new LinearLayout.LayoutParams(dp(context, 88), LayoutParams.WRAP_CONTENT);
    column.addView(picker, pickerLp);

    TextView label = new TextView(context);
    label.setText(unit);
    label.setTextSize(20);
    label.setTextColor(0xFFFFFFFF);
    label.setGravity(Gravity.CENTER_VERTICAL);
    LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(dp(context, 40), LayoutParams.WRAP_CONTENT);
    column.addView(label, labelLp);

    addView(column, new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
  }

  private static int dp(Context context, int value) {
    return (int) (value * context.getResources().getDisplayMetrics().density + 0.5f);
  }

  public long getSeconds() {
    return hoursValue() * 3600L + minutesValue() * 60L;
  }

  public void setSeconds(long seconds) {
    if (seconds < 0) seconds = 0;
    long h = seconds / 3600L;
    long m = (seconds % 3600L) / 60L;
    hours.setValue((int) Math.min(23, h));
    minutes.setValue((int) m);
  }

  public void setMinutesTotal(int totalMinutes) {
    if (totalMinutes < 0) totalMinutes = 0;
    setSeconds(totalMinutes * 60L);
  }

  private int hoursValue() { return hours.getValue(); }
  private int minutesValue() { return minutes.getValue(); }
}
