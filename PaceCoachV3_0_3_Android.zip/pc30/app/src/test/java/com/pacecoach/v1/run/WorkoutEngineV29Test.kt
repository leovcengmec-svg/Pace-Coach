package com.pacecoach.v1.run

import org.junit.Assert.*
import org.junit.Test

class WorkoutEngineV29Test {
    @Test fun timeStepsAdvanceWithoutPace() {
        val workout = StructuredWorkout("x", listOf(
            WorkoutStep(StepKind.WARMUP, durationSeconds = 60, label = "Aquecimento"),
            WorkoutStep(StepKind.COOLDOWN, durationSeconds = 60, label = "Desaquecimento")
        ))
        val e = WorkoutEngine(workout)
        e.start(0, 0f)
        assertEquals(0, e.current()!!.index)
        e.update(60_000, 0f)
        assertEquals(1, e.current()!!.index)
        e.update(120_000, 0f)
        assertTrue(e.isFinished())
    }

    @Test fun distanceStepAdvancesAtBoundary() {
        val workout = StructuredWorkout("x", listOf(
            WorkoutStep(StepKind.RUN, distanceMeters = 100f, label = "Tiro"),
            WorkoutStep(StepKind.RECOVERY, distanceMeters = 50f, label = "Recuperação")
        ))
        val e = WorkoutEngine(workout)
        e.start(0, 0f)
        e.update(10_000, 99f)
        assertEquals(0, e.current()!!.index)
        e.update(11_000, 100f)
        assertEquals(1, e.current()!!.index)
    }
}
