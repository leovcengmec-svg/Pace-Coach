package org.runnerup.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListView;

/**
 * ListView intended to be embedded inside a parent ScrollView.
 * It expands to the height of all its rows so the parent owns scrolling.
 */
public class NonScrollableListView extends ListView {
  public NonScrollableListView(Context context) {
    super(context);
  }

  public NonScrollableListView(Context context, AttributeSet attrs) {
    super(context, attrs);
  }

  public NonScrollableListView(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
  }

  @Override
  protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    int expandedHeightSpec =
        MeasureSpec.makeMeasureSpec(Integer.MAX_VALUE >> 2, MeasureSpec.AT_MOST);
    super.onMeasure(widthMeasureSpec, expandedHeightSpec);
  }
}
