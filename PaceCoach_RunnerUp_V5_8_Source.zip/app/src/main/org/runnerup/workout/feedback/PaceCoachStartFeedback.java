package org.runnerup.workout.feedback;

import android.content.Context;
import java.util.HashMap;
import org.runnerup.workout.Dimension;
import org.runnerup.workout.Feedback;
import org.runnerup.workout.Workout;

/** Spoken opening instruction for the Pace Coach free-run (Treino Constante). */
public class PaceCoachStartFeedback extends Feedback {
  private final Dimension targetDimension;
  private final double targetValue;
  private final double paceMinSecKm;
  private final double paceMaxSecKm;
  private RUTextToSpeech textToSpeech;

  public PaceCoachStartFeedback(Dimension targetDimension, double targetValue,
      double paceMinSecKm, double paceMaxSecKm) {
    this.targetDimension = targetDimension;
    this.targetValue = targetValue;
    this.paceMinSecKm = paceMinSecKm;
    this.paceMaxSecKm = paceMaxSecKm;
  }

  @Override
  public void onBind(Workout w, HashMap<String, Object> bindValues) {
    super.onBind(w, bindValues);
    if (bindValues.containsKey(Workout.KEY_TTS)) {
      textToSpeech = (RUTextToSpeech) bindValues.get(Workout.KEY_TTS);
    }
  }

  @Override
  public boolean equals(Feedback other) {
    if (!(other instanceof PaceCoachStartFeedback)) return false;
    PaceCoachStartFeedback that = (PaceCoachStartFeedback) other;
    return targetDimension == that.targetDimension
        && Double.compare(targetValue, that.targetValue) == 0
        && Double.compare(paceMinSecKm, that.paceMinSecKm) == 0
        && Double.compare(paceMaxSecKm, that.paceMaxSecKm) == 0;
  }

  @Override
  public void emit(Workout w, Context ctx) {
    if (textToSpeech == null) return;

    StringBuilder msg = new StringBuilder("Treino constante. ");
    if (targetDimension == Dimension.DISTANCE) {
      msg.append("Distância ").append(formatDistance(targetValue));
    } else {
      msg.append("Tempo ").append(formatTime(targetValue));
    }
    msg.append(". Ritmo Alvo ")
        .append(formatPace(paceMinSecKm))
        .append(" a ")
        .append(formatPace(paceMaxSecKm));

    textToSpeech.speak(msg.toString(), UtterancePrio.PRIO_COUNTDOWN, true, null);
  }

  private static String formatDistance(double meters) {
    double km = Math.max(0, meters) / 1000.0;
    if (Math.abs(km - Math.rint(km)) < 0.0001) {
      return String.format(java.util.Locale.getDefault(), "%.0f quilômetros", km);
    }
    return String.format(java.util.Locale.getDefault(), "%.1f quilômetros", km);
  }

  private static String formatTime(double seconds) {
    long total = Math.max(0, Math.round(seconds));
    long hours = total / 3600L;
    long minutes = (total % 3600L) / 60L;
    if (hours > 0) {
      if (minutes == 0) return hours == 1 ? "1 hora" : hours + " horas";
      return (hours == 1 ? "1 hora" : hours + " horas") + " e " + minutes + " minutos";
    }
    return minutes + " minutos";
  }

  private static String formatPace(double secondsPerKm) {
    long total = Math.max(0, Math.round(secondsPerKm));
    long minutes = total / 60L;
    long seconds = total % 60L;
    return minutes + " e " + seconds;
  }
}
