package org.runnerup.workout.feedback;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.runnerup.workout.Scope;

public class UtterancePriorityTest {
  @Test
  public void paceCoachAnnouncementOrderIsStrict() {
    assertTrue(UtterancePrio.PRIO_RHYTHM.value > UtterancePrio.PRIO_BLOCK.value);
    assertTrue(UtterancePrio.PRIO_BLOCK.value > UtterancePrio.PRIO_STATUS.value);
    assertTrue(UtterancePrio.PRIO_STATUS.value > UtterancePrio.PRIO_GENERAL.value);
  }

  @Test
  public void onlyHigherPriorityAnnouncementsInterruptCurrentSpeech() {
    assertTrue(UtterancePrio.shouldPreempt(4, 1));
    assertTrue(UtterancePrio.shouldPreempt(3, 2));
    assertFalse(UtterancePrio.shouldPreempt(2, 3));
    assertFalse(UtterancePrio.shouldPreempt(3, 3));
  }

  @Test
  public void summaryTypesUseTheRequestedPriorityOrder() {
    assertEquals(UtterancePrio.PRIO_RHYTHM,
        PaceCoachSummaryFeedback.priorityFor(Scope.CURRENT, "current"));
    assertEquals(UtterancePrio.PRIO_BLOCK,
        PaceCoachSummaryFeedback.priorityFor(Scope.STEP, "interval"));
    assertEquals(UtterancePrio.PRIO_STATUS,
        PaceCoachSummaryFeedback.priorityFor(Scope.ACTIVITY, "general"));
    assertEquals(UtterancePrio.PRIO_GENERAL,
        PaceCoachSummaryFeedback.priorityFor(Scope.ACTIVITY, "general_km"));
  }

  @Test
  public void legacyAliasesPreserveTheirMappedPriority() {
    assertEquals(UtterancePrio.PRIO_BLOCK.value, UtterancePrio.PRIO_COUNTDOWN.value);
    assertEquals(UtterancePrio.PRIO_STATUS.value, UtterancePrio.PRIO_COACH.value);
    assertEquals(UtterancePrio.PRIO_GENERAL.value, UtterancePrio.PRIO_CUE.value);
  }
}
