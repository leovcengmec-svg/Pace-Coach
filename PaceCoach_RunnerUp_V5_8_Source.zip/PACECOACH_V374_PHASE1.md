# Pace Coach / RunnerUp — revisão interna v374 · Fase 1

Base de origem: código-fonte oficial `versionCode 374` / `versionName 2.11.0.2`.

Esta revisão preserva a identidade técnica original (`org.runnerup`), os identificadores de instalação, o nome padrão do projeto e o número de versão da base. O arquivo ZIP de entrega mantém exatamente o nome `PaceCoach_RunnerUp_V5_8_Source.zip`.

## Escopo aplicado

### 1. Pipeline GPS único e serializado

- Criado um `HandlerThread` dedicado (`RunnerUp-LocationEvents`) no serviço `Tracker`.
- O `LocationManager` entrega atualizações ao mesmo Looper dedicado.
- A qualidade GNSS recebe as mesmas amostras brutas entregues ao `Tracker`; não abre uma segunda assinatura de localização.
- A tela inicial e a tela de execução consultam o estado do serviço; não criam listeners GPS concorrentes.
- Estados e callbacks de conexão são entregues à thread principal antes de chamar a camada de componentes/UI.
- Chamadas tardias de conexão são ignoradas quando a máquina de estados já saiu de `CONNECTING`.

### 2. Persistência de coordenadas fora do callback GPS

- `PersistentGpsLoggerListener` grava pontos em um executor de uma única thread, preservando a ordem FIFO.
- `ContentValues` e chave de atividade/volta são copiados ao enfileirar cada amostra.
- Fila limitada a 512 pontos; em saturação há back-pressure no produtor, em vez de crescimento ilimitado de memória ou perda silenciosa.
- Checkpoints (`flush`) antes de pausa, parada e conclusão da atividade.
- Encerramento do executor com drenagem de tarefas aceitas e espera limitada.

### 3. Isolamento de trabalho periférico

- Atualizações da notificação em frequência limitada e despachadas pela thread principal.
- Eventos de sincronização Live são enviados em executor serial separado, com `WorkoutInfo` imutável e fila limitada.
- Falhas de observadores e notificações são registradas sem interromper o processamento de localização.

### 4. Estado e qualidade GPS

- Registro de localização usa explicitamente o Looper dedicado.
- Recuperação reinscreve callbacks no mesmo Looper. Se a permissão for revogada ou o provedor desligado durante uma corrida, a assinatura antiga é liberada e o watchdog continua verificando quando pode tentar novamente.
- Falhas de registro GNSS são não fatais quando o fluxo de coordenadas permanece disponível.
- Critério de fix é recalculado a cada amostra para não conservar um fix antigo após degradação da precisão.
- O monitor de qualidade lê a mesma amostra aceita pelo Tracker.

### 5. GitHub Actions

- Workflow mantém o build de bundle e acrescenta APK Debug e Release.
- SDK configurado para `compileSdk 37` e Build Tools `36.0.0`, alinhados ao `build.gradle` da base.
- APKs são publicados como artefato `pacecoach-apk-v375-phase1` por 14 dias.

## Arquivos alterados

- `app/src/main/org/runnerup/tracker/Tracker.java`
- `app/src/main/org/runnerup/tracker/GpsStatus.java`
- `app/src/main/org/runnerup/tracker/component/TrackerGPS.java`
- `app/src/main/org/runnerup/tracker/filter/PersistentGpsLoggerListener.java`
- `app/src/main/org/runnerup/view/StartFragment.java`
- `app/src/main/org/runnerup/view/RunActivity.java`
- `.github/workflows/actions.yml`
- `.gitignore` (proteção para keystores locais)
- `PACECOACH_V374_PHASE1.md` (este documento)

## Assinatura e proteção de credenciais

O arquivo de origem continha uma keystore de desenvolvimento e um `release.properties` com credenciais. Esses dois arquivos foram excluídos da revisão distribuível para não expor material de assinatura. O `release.properties.sample` foi preservado. O workflow aceita a mesma keystore por Secrets do GitHub (`PACECOACH_KEYSTORE_BASE64`, `PACECOACH_KEYSTORE_PASSWORD`, `PACECOACH_KEY_ALIAS` e `PACECOACH_KEY_PASSWORD`). Sem esses Secrets, o GitHub ainda pode gerar APK Debug e um APK Release sem assinatura; para instalar por cima de uma versão existente com o mesmo `applicationId`, configure a chave de assinatura original.

## Validação pendente

A revisão foi submetida a inspeção estática e verificações de estrutura/consistência do pacote. A compilação Android e os testes instrumentados em POCO X7 Pro / Android 16 devem ser executados no GitHub Actions e no aparelho. Este ambiente não dispõe do Android SDK nem do `gradle-wrapper.jar` real (o arquivo presente no ZIP de origem é um ponteiro Git LFS), portanto não se declara um APK compilado localmente.
