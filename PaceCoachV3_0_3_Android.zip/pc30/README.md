# Pace Coach V1.2

MVP com comunicação em tempo real entre o serviço de GPS e a tela.

## O que foi corrigido
- A tela recebe atualizações do serviço de corrida.
- Pace atual aparece em tempo real.
- Distância e tempo aparecem em tempo real.
- Estado Iniciada/Encerrada é sincronizado.
- Avisos por distância ou tempo continuam disponíveis.
- Margem de pace continua configurável.
- Foreground Service continua responsável pelo GPS em segundo plano.

## Teste real
Use um celular Android físico, ao ar livre, com fones.
Teste inicialmente:
- alvo 5:00/km
- aviso a cada 100 m
- margem ±5 s

Não considerar a V1.2 clinicamente ou esportivamente validada até comparar com um dispositivo de referência em corrida real.
