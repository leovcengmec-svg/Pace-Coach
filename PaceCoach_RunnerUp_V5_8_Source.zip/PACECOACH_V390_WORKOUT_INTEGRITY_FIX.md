# Pace Coach v390 — treino estruturado, finalização e integridade do GPS

## Alterações

- A recomputação da atividade prefere `LOCATION.ELAPSED` (tempo ativo monotônico do Tracker) aos horários de relógio; usa horário apenas como fallback para GPX/legados sem ELAPSED. Rejeita saltos GPS incompatíveis com o tempo ativo. Toda a recomputação é transacional: se distância variar mais de 25% (e ao menos 100 m) ou tempo variar mais de 20% (e ao menos 120 s) do resumo já salvo, o banco desfaz as alterações e preserva a atividade original.
- As parciais por km/min são limitadas aos totais oficiais da atividade, impedindo que pontos GPS acima do resumo criem trechos fictícios na tela.
- A tabela `lap` passa a registrar explicitamente o início de cada Step estruturado (`pacecoach_block_start`), com migração do banco 33 para 34. Autolaps por km/min não criam novos blocos; o histórico legado é agrupado por metadados de prescrição iguais.
- A tela Blocos agrupa autolaps dentro do Step original. Para históricos anteriores à migração, usa agrupamento conservador por metadados de prescrição idênticos.
- A conclusão do último bloco não encerra a atividade. O loop de execução para de avançar o Step já concluído, congela os números apresentados para esse bloco, desabilita o comando de volta/volta manual, exibe aviso e mantém Tracker/cronômetro ativos até ação manual. Se o último bloco era um descanso OFF que pausava o Tracker, o serviço é retomado ao final desse descanso. Ao salvar, o tempo/distância pós-conclusão é guardado em um segmento técnico da atividade, fora dos blocos prescritos.
- Removido `showWhenLocked`/`FLAG_SHOW_WHEN_LOCKED` da tela de execução, deixando o bloqueio padrão do Android controlar a tela. A notificação contínua passa a informar quando o treino prescrito terminou, sem sobrepor o keyguard.
- O nome da atividade passa a ser Treino Livre, Treino Intervalado ou exatamente o nome do treino estruturado carregado.
- O comando de voltar/volta manual fica desabilitado depois da conclusão dos blocos, para que o corredor encerre a gravação explicitamente por PAUSE ou STOP.

## Versão

- App versionCode: 390 (Wear usa 391)
- versionName: 2.11.0.16
- Workflow artifact: `pacecoach-apk-v390-workout-integrity-fix`

## Validação pendente

A validação sintática, XML/YAML e integridade do ZIP é feita no ambiente de edição. A compilação Android completa e o teste de campo no POCO X7 Pro dependem do GitHub Actions e do dispositivo.
