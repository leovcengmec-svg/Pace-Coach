package com.pacecoach.v1.run

object WorkoutVoice {

    fun start(step: ActiveStep): String =
        stepDescription("Iniciando", step)

    fun next(step: ActiveStep): String =
        stepDescription("Próximo bloco", step)

    fun finish(): String =
        "Treino concluído."

    private fun stepDescription(prefix: String, active: ActiveStep): String {
        val step = active.step
        val target = step.targetPaceSeconds?.let { " a ${CoachMessageFormatter.formatPace(it)} por quilômetro" } ?: ""
        val repetition = if (step.repeats > 1) {
            " Repetição ${active.repetition} de ${step.repeats}."
        } else {
            ""
        }
        return "$prefix: ${step.label.ifBlank { kindName(step.kind) }}$target.$repetition"
    }

    private fun kindName(kind: StepKind): String = when (kind) {
        StepKind.WARMUP -> "aquecimento"
        StepKind.RUN -> "corrida"
        StepKind.RECOVERY -> "recuperação"
        StepKind.COOLDOWN -> "desaquecimento"
    }
}
