# Pace Coach — permissões para desenvolvimento

Durante o desenvolvimento, use `PERMITIR_PERMISSOES_DESENVOLVIMENTO.bat` depois de instalar o APK para conceder, via ADB, as permissões de execução necessárias ao teste.

O script procura automaticamente o pacote `org.runnerup.free` (incluindo a variante `.debug`) e tenta conceder:

- localização aproximada;
- localização precisa;
- localização em segundo plano;
- atividade física;
- notificações;
- Bluetooth Scan;
- Bluetooth Connect.

O Android pode restringir algumas permissões especiais dependendo da versão do sistema. O BAT não altera a política de segurança do aplicativo e não faz parte do fluxo de permissões da versão final.

Quando o projeto receber o comando **"aplicativo finalizado"**, este mecanismo de desenvolvimento deve ser removido e o aplicativo deve voltar ao fluxo normal de solicitação de permissões do Android.
