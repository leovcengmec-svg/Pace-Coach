/*
 * Copyright (C) 2026 Pace Coach contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */
package org.runnerup.workout.feedback;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.util.Locale;
import org.runnerup.util.Formatter;

/** Standalone final-workout TTS. It is intentionally independent of TrackerTTS,
 * because TrackerTTS is shut down when the saved activity is completed. */
public final class PaceCoachFinalVoice {
  private PaceCoachFinalVoice() {}

  public static void speak(Context context, String text, Runnable onFinished) {
    if (text == null || text.isEmpty()) {
      if (onFinished != null) onFinished.run();
      return;
    }
    final Context app = context.getApplicationContext();
    final TextToSpeech[] holder = new TextToSpeech[1];
    holder[0] = new TextToSpeech(app, status -> {
      TextToSpeech tts = holder[0];
      if (tts == null) {
        if (onFinished != null) onFinished.run();
        return;
      }
      if (status != TextToSpeech.SUCCESS) {
        tts.shutdown();
        if (onFinished != null) onFinished.run();
        return;
      }
      Locale locale = Formatter.getAudioLocale(app);
      if (locale != null) tts.setLanguage(locale);
      tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
        private void done() {
          tts.shutdown();
          if (onFinished != null) onFinished.run();
        }
        @Override public void onStart(String utteranceId) {}
        @Override public void onDone(String utteranceId) { done(); }
        @Override public void onError(String utteranceId) { done(); }
      });
      tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "pace_coach_final");
    });
  }
}
