# Pace Coach V1.6 — Pace/GPS robusto

Foco desta versão:
- filtrar ruído GPS pequeno;
- rejeitar saltos grandes;
- rejeitar velocidades instantâneas implausíveis;
- manter janela móvel de 20 s;
- impor limites de sanidade do pace;
- separar classificação de qualidade GPS para evolução do coach.

A intenção é reduzir oscilações falsas sem tornar o pace excessivamente lento para
responder a mudanças reais do corredor.

A validação definitiva depende de dados GPS reais no aparelho.
