/*
 * Copyright (C) 2012 - 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.view;

import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.content.ContextCompat;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.app.LoaderManager.LoaderCallbacks;
import androidx.loader.content.Loader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import org.runnerup.R;
import org.runnerup.common.util.Constants;
import org.runnerup.db.ActivityCleaner;
import org.runnerup.db.DBHelper;
import org.runnerup.db.entities.ActivityEntity;
import org.runnerup.importer.GPXImporter;
import org.runnerup.util.Formatter;
import org.runnerup.util.SimpleCursorLoader;
import org.runnerup.workout.Sport;

public class HistoryFragment extends Fragment
    implements Constants, OnItemClickListener, LoaderCallbacks<Cursor> {

  private SQLiteDatabase mDB = null;
  private Formatter formatter = null;

  CursorAdapter cursorAdapter = null;
  View fab = null;
  private String historyFilter = "all";
  private TextView historyPeriodTitle;
  private TextView historyPeriodStats;
  private static final int REQUEST_IMPORT_GPX = 1001;
  private static final int REQUEST_IMPORT_GPX_PACKAGE = 1002;
  private static final int REQUEST_IMPORT_GPX_RECALCULATE = 1003;
  private static final int REQUEST_IMPORT_GPX_PACKAGE_RECALCULATE = 1004;

  public HistoryFragment() {
    super(R.layout.history);
  }

  @Override
  public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);

    ListView listView = view.findViewById(R.id.history_list);
    fab = view.findViewById(R.id.history_add);
    historyPeriodTitle = view.findViewById(R.id.history_period_title);
    historyPeriodStats = view.findViewById(R.id.history_period_stats);
    setupHistoryFilters(view);

    Context context = requireContext();
    fab.setOnClickListener(
        v -> new AlertDialog.Builder(requireContext())
            .setTitle("Adicionar treino")
            .setItems(new String[] {"Adicionar treino manualmente", "Importar GPX", "Importar Pacote de GPX"}, (dialog, which) -> {
              if (which == 0) {
                Intent i = new Intent(context, ManualActivity.class);
                startActivityForResult(i, 0);
              } else {
                chooseGpxImportMode(which == 2);
              }
            })
            .show());

    mDB = DBHelper.getReadableDatabase(context);
    formatter = new Formatter(context);
    listView.setDividerHeight(2);
    listView.setOnItemClickListener(this);
    cursorAdapter = new HistoryListAdapter(context, null);
    listView.setAdapter(cursorAdapter);

    LoaderManager.getInstance(this).initLoader(0, null, this);
    AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);

    new ActivityCleaner().conditionalRecompute(mDB);
  }

  @Override
  public void onResume() {
    super.onResume();
    LoaderManager.getInstance(this).restartLoader(0, null, this);
  }

  @Override
  public void onDestroy() {
    super.onDestroy();
    DBHelper.closeDB(mDB);
  }

  @NonNull
  @Override
  public Loader<Cursor> onCreateLoader(int arg0, Bundle arg1) {
    String[] from =
        new String[] {
          "_id", DB.ACTIVITY.START_TIME, DB.ACTIVITY.DISTANCE, DB.ACTIVITY.TIME, DB.ACTIVITY.SPORT, DB.ACTIVITY.NAME
        };

    return new SimpleCursorLoader(
        requireContext(),
        mDB,
        DB.ACTIVITY.TABLE,
        from,
        historySelection(),
        historySelectionArgs(),
        DB.ACTIVITY.START_TIME + " desc, _id desc");
  }

  @Override
  public void onLoadFinished(@NonNull Loader<Cursor> arg0, Cursor arg1) {
    cursorAdapter.swapCursor(arg1);
    updateHistorySummary();
  }

  @Override
  public void onLoaderReset(@NonNull Loader<Cursor> loader) {
    if (cursorAdapter != null) {
      cursorAdapter.swapCursor(null);
    }
  }

  private void setupHistoryFilters(View root) {
    int[] ids = {R.id.history_filter_all, R.id.history_filter_week, R.id.history_filter_month, R.id.history_filter_year};
    String[] values = {"all", "week", "month", "year"};
    for (int i = 0; i < ids.length; i++) {
      final String value = values[i];
      View v = root.findViewById(ids[i]);
      if (v != null) v.setOnClickListener(x -> {
        historyFilter = value;
        updateHistoryFilterVisual(root);
        LoaderManager.getInstance(this).restartLoader(0, null, this);
      });
    }
    updateHistoryFilterVisual(root);
  }

  private void updateHistoryFilterVisual(View root) {
    int[] ids = {R.id.history_filter_all, R.id.history_filter_week, R.id.history_filter_month, R.id.history_filter_year};
    String[] values = {"all", "week", "month", "year"};
    for (int i = 0; i < ids.length; i++) {
      View v = root.findViewById(ids[i]);
      if (v instanceof TextView) {
        boolean selected = values[i].equals(historyFilter);
        v.setBackgroundResource(selected ? R.drawable.bg_coach_period_selected : android.R.color.transparent);
        ((TextView) v).setTextColor(ContextCompat.getColor(requireContext(), selected ? R.color.colorText : R.color.colorTextSecondary));
      }
    }
  }

  private long[] historyBounds() {
    Calendar start = Calendar.getInstance();
    Calendar end = Calendar.getInstance();
    if ("week".equals(historyFilter)) {
      start.set(Calendar.HOUR_OF_DAY,0); start.set(Calendar.MINUTE,0); start.set(Calendar.SECOND,0); start.set(Calendar.MILLISECOND,0);
      int day=start.get(Calendar.DAY_OF_WEEK);
      start.add(Calendar.DAY_OF_YEAR, (day == Calendar.SUNDAY) ? -6 : Calendar.MONDAY - day);
      end.setTimeInMillis(start.getTimeInMillis()); end.add(Calendar.DAY_OF_YEAR,7);
    } else if ("month".equals(historyFilter)) {
      start.set(Calendar.DAY_OF_MONTH,1); start.set(Calendar.HOUR_OF_DAY,0); start.set(Calendar.MINUTE,0); start.set(Calendar.SECOND,0); start.set(Calendar.MILLISECOND,0);
      end.setTimeInMillis(start.getTimeInMillis()); end.add(Calendar.MONTH,1);
    } else if ("year".equals(historyFilter)) {
      start.set(Calendar.DAY_OF_YEAR,1); start.set(Calendar.HOUR_OF_DAY,0); start.set(Calendar.MINUTE,0); start.set(Calendar.SECOND,0); start.set(Calendar.MILLISECOND,0);
      end.setTimeInMillis(start.getTimeInMillis()); end.add(Calendar.YEAR,1);
    } else {
      return new long[] {Long.MIN_VALUE, Long.MAX_VALUE};
    }
    return new long[] {start.getTimeInMillis()/1000L, end.getTimeInMillis()/1000L};
  }

  private String historySelection() {
    String base = "deleted == 0 AND " + DB.ACTIVITY.SPORT + " = ?";
    if ("all".equals(historyFilter)) return base;
    return base + " AND " + DB.ACTIVITY.START_TIME + " >= ? AND " + DB.ACTIVITY.START_TIME + " < ?";
  }

  private String[] historySelectionArgs() {
    if ("all".equals(historyFilter)) return new String[] {String.valueOf(DB.ACTIVITY.SPORT_RUNNING)};
    long[] b=historyBounds();
    return new String[] {String.valueOf(DB.ACTIVITY.SPORT_RUNNING), String.valueOf(b[0]), String.valueOf(b[1])};
  }

  private void updateHistorySummary() {
    if (mDB == null || historyPeriodTitle == null || historyPeriodStats == null) return;
    Calendar now = Calendar.getInstance();
    String title;
    if ("week".equals(historyFilter)) {
      long[] b=historyBounds();
      title = new java.text.SimpleDateFormat("dd/MM", Locale.getDefault()).format(new Date(b[0]*1000L)) + " – " + new java.text.SimpleDateFormat("dd/MM", Locale.getDefault()).format(new Date((b[1]-1)*1000L));
    } else if ("month".equals(historyFilter)) {
      title = formatter.formatMonth(now.getTime());
    } else if ("year".equals(historyFilter)) {
      title = String.valueOf(now.get(Calendar.YEAR));
    } else {
      title = formatter.formatMonth(now.getTime());
    }
    Cursor c=null; long count=0,time=0; double distance=0;
    try {
      String where=historySelection();
      c=mDB.rawQuery("SELECT COUNT(*), COALESCE(SUM("+DB.ACTIVITY.DISTANCE+"),0), COALESCE(SUM("+DB.ACTIVITY.TIME+"),0) FROM "+DB.ACTIVITY.TABLE+" WHERE "+where, historySelectionArgs());
      if(c.moveToFirst()){count=c.getLong(0); distance=c.getDouble(1); time=c.getLong(2);}
    } finally { if(c!=null)c.close(); }
    historyPeriodTitle.setText(title);
    historyPeriodStats.setText(String.format(Locale.getDefault(), "%d treinos • %.1f km • %s", count, distance/1000.0, formatter.formatElapsedTime(Formatter.Format.TXT, time)));
  }

  @Override
  public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
    Intent intent = new Intent(requireContext(), DetailActivity.class);
    intent.putExtra("ID", id);
    intent.putExtra("mode", "details");
    startActivityForResult(intent, 0);
  }

  private void chooseGpxImportMode(boolean multiple) {
    final String[] modes = {
      "Importar",
      "Importar e recalcular"
    };
    new AlertDialog.Builder(requireContext())
        .setTitle(multiple ? "Importar pacote de GPX" : "Importar GPX")
        .setItems(modes, (dialog, which) -> openGpxPicker(multiple, which == 1))
        .show();
  }

  private void openGpxPicker(boolean multiple, boolean recalculate) {
    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
    i.addCategory(Intent.CATEGORY_OPENABLE);
    i.setType("application/gpx+xml");
    i.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
        "application/gpx+xml", "application/octet-stream", "text/xml", "application/xml"});
    if (multiple) {
      i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
      startActivityForResult(i, recalculate
          ? REQUEST_IMPORT_GPX_PACKAGE_RECALCULATE : REQUEST_IMPORT_GPX_PACKAGE);
    } else {
      startActivityForResult(i, recalculate
          ? REQUEST_IMPORT_GPX_RECALCULATE : REQUEST_IMPORT_GPX);
    }
  }

  @Override
  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == android.app.Activity.RESULT_OK && data != null) {
      if ((requestCode == REQUEST_IMPORT_GPX || requestCode == REQUEST_IMPORT_GPX_RECALCULATE)
          && data.getData() != null) {
        importSingleGpx(data.getData(), requestCode == REQUEST_IMPORT_GPX_RECALCULATE);
      } else if (requestCode == REQUEST_IMPORT_GPX_PACKAGE
          || requestCode == REQUEST_IMPORT_GPX_PACKAGE_RECALCULATE) {
        ArrayList<Uri> uris = new ArrayList<>();
        if (data.getClipData() != null) {
          ClipData clip = data.getClipData();
          for (int i = 0; i < clip.getItemCount(); i++) {
            Uri uri = clip.getItemAt(i).getUri();
            if (uri != null) uris.add(uri);
          }
        } else if (data.getData() != null) {
          uris.add(data.getData());
        }
        if (!uris.isEmpty()) {
          importGpxPackage(uris, requestCode == REQUEST_IMPORT_GPX_PACKAGE_RECALCULATE);
        }
      }
    }
    LoaderManager.getInstance(this).restartLoader(0, null, this);
  }

  private void importSingleGpx(Uri uri, boolean recalculate) {
    try {
      GPXImporter.importGpx(requireContext(), uri, recalculate);
      String message = recalculate
          ? "GPX importado e recalculado"
          : "GPX importado";
      Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    } catch (Exception e) {
      android.util.Log.e("HistoryFragment", "GPX import failed", e);
      Toast.makeText(requireContext(), "Não foi possível importar o GPX", Toast.LENGTH_LONG).show();
    }
  }

  private void importGpxPackage(ArrayList<Uri> uris, boolean recalculate) {
    final Context context = requireContext();
    final ProgressDialog progress = new ProgressDialog(context);
    progress.setTitle(recalculate ? "Importar e recalcular pacote de GPX" : "Importar pacote de GPX");
    progress.setMessage("Preparando importação...");
    progress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
    progress.setMax(uris.size());
    progress.setProgress(0);
    progress.setCancelable(false);
    progress.show();

    new Thread(() -> {
      int imported = 0;
      int failed = 0;
      for (int i = 0; i < uris.size(); i++) {
        try {
          GPXImporter.importGpx(context, uris.get(i), recalculate);
          imported++;
        } catch (Exception e) {
          failed++;
          android.util.Log.e("HistoryFragment", "GPX package import failed: " + uris.get(i), e);
        }
        final int progressValue = i + 1;
        final int importedNow = imported;
        final int failedNow = failed;
        if (isAdded()) {
          requireActivity().runOnUiThread(() -> {
            if (progress.isShowing()) {
              progress.setProgress(progressValue);
              progress.setMessage("Importando " + progressValue + " de " + uris.size()
                  + "\nSucesso: " + importedNow + " • Falhas: " + failedNow);
            }
          });
        }
      }
      final int totalImported = imported;
      final int totalFailed = failed;
      if (isAdded()) {
        requireActivity().runOnUiThread(() -> {
          if (progress.isShowing()) progress.dismiss();
          LoaderManager.getInstance(this).restartLoader(0, null, this);
          String modeText = recalculate ? " importado(s) e recalculado(s)" : " importado(s)";
          Toast.makeText(context, "Pacote concluído: " + totalImported + modeText
              + (totalFailed > 0 ? " • " + totalFailed + " falha(s)" : ""),
              totalFailed > 0 ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT).show();
        });
      }
    }, "gpx-batch-import").start();
  }

  class HistoryListAdapter extends CursorAdapter {
    final LayoutInflater inflater;

    HistoryListAdapter(Context context, Cursor c) {
      super(context, c, true);
      inflater = LayoutInflater.from(context);
    }

    private boolean sameDayAsPrevious(int curYear, int curMonth, int curDay, Cursor cursor) {
      int curPosition = cursor.getPosition();
      if (curPosition == 0) return false;
      if (!cursor.moveToPrevious()) return false;
      long prevTimeInSecs = new ActivityEntity(cursor).getStartTime();
      cursor.moveToPosition(curPosition);
      Calendar prevCal = Calendar.getInstance();
      prevCal.setTime(new Date(prevTimeInSecs * 1000));
      return prevCal.get(Calendar.YEAR) == curYear
          && prevCal.get(Calendar.MONTH) == curMonth
          && prevCal.get(Calendar.DAY_OF_MONTH) == curDay;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
      ActivityEntity ae = new ActivityEntity(cursor);

      // month + day
      Date curDate = new Date(ae.getStartTime() * 1000);
      Calendar cal = Calendar.getInstance();
      cal.setTime(curDate);

      TextView sectionTitle = view.findViewById(R.id.history_section_title);
      int year = cal.get(Calendar.YEAR);
      int month = cal.get(Calendar.MONTH);
      if (sameDayAsPrevious(year, month, cal.get(Calendar.DAY_OF_MONTH), cursor)) {
        sectionTitle.setVisibility(View.GONE);
      } else {
        sectionTitle.setVisibility(View.VISIBLE);
        sectionTitle.setText(new java.text.SimpleDateFormat("dd 'DE' MMMM • EEEE", new Locale("pt", "BR")).format(curDate).toUpperCase(new Locale("pt", "BR")));
      }

      TextView dateText = view.findViewById(R.id.history_list_date);
      TextView timeText = view.findViewById(R.id.history_list_time);
      Calendar displayCal = Calendar.getInstance();
      displayCal.setTime(curDate);
      dateText.setText(String.format(Locale.getDefault(), "%02d/%02d/%04d", displayCal.get(Calendar.DAY_OF_MONTH), displayCal.get(Calendar.MONTH)+1, displayCal.get(Calendar.YEAR)));
      timeText.setText(String.format(Locale.getDefault(), "%02d:%02d", displayCal.get(Calendar.HOUR_OF_DAY), displayCal.get(Calendar.MINUTE)));
      TextView sportText = view.findViewById(R.id.history_list_sport);
      String activityName = ae.getName();
      if (activityName != null && !activityName.trim().isEmpty()) {
        sportText.setText(activityName.trim());
      } else {
        sportText.setText("Corrida");
      }

      // distance
      Double d = ae.getDistance();
      TextView distanceText = view.findViewById(R.id.history_list_distance);
      if (d != null) {
        distanceText.setText(formatter.formatDistance(Formatter.Format.TXT_SHORT, d.longValue()));
      } else {
        distanceText.setText("");
      }

      // sport + additional info
      Integer s = ae.getSport();
      ImageView emblem = view.findViewById(R.id.history_list_emblem);
      int sportColor = ContextCompat.getColor(context, Sport.colorOf(s));
      Drawable sportDrawable =
          AppCompatResources.getDrawable(context, Sport.drawableColored16Of(s));
      emblem.setImageDrawable(sportDrawable);
      distanceText.setTextColor(ContextCompat.getColor(context, R.color.colorAccent));

      // duration
      Long dur = ae.getTime();
      TextView durationText = view.findViewById(R.id.history_list_duration);
      if (dur != null) {
        durationText.setText(formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, dur));
      } else {
        durationText.setText("");
      }

      // pace
      TextView paceText = view.findViewById(R.id.history_list_pace);
      String paceTextContents = "";
      if (d != null && dur != null && dur != 0) {
        paceTextContents =
            formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_LONG, d / dur);
      }
      paceText.setText(paceTextContents);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
      return inflater.inflate(R.layout.history_row, parent, false);
    }
  }
}
