package org.runnerup.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ActivitySplitTimeTest {
  @Test
  public void convertsElapsedMillisecondsToSeconds() {
    assertEquals(0L, ActivitySplitTime.elapsedSecondsSince(1250L, 1250L));
    assertEquals(60L, ActivitySplitTime.elapsedSecondsSince(61250L, 1250L));
    assertEquals(121L, ActivitySplitTime.elapsedSecondsSince(122000L, 1000L));
  }

  @Test
  public void clampsOutOfOrderTimestampsToZero() {
    assertEquals(0L, ActivitySplitTime.elapsedSecondsSince(999L, 1000L));
  }
}
