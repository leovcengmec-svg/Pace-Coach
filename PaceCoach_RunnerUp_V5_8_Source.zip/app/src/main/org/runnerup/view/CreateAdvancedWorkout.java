package org.runnerup.view;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.view.WindowCompat;
import androidx.preference.PreferenceManager;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import org.runnerup.R;
import org.runnerup.tracker.GpsStatus;
import org.runnerup.util.ViewUtil;
import org.runnerup.widget.TitleSpinner;
import org.runnerup.workout.RepeatStep;
import org.runnerup.workout.Intensity;
import org.runnerup.workout.Step;
import org.runnerup.workout.Workout;
import org.runnerup.workout.WorkoutSerializer;

public class CreateAdvancedWorkout extends AppCompatActivity {

  private static final String CREATE_NEW_WORKOUT_OPTION = "Criar novo treino";
  private Workout advancedWorkout = null;
  private TitleSpinner advancedWorkoutSpinner = null;
  private StoredWorkoutListAdapter storedWorkoutListAdapter = null;
  private final WorkoutStepsAdapter advancedWorkoutStepsAdapter = new WorkoutStepsAdapter();
  private boolean dontAskAgain = false;
  private GpsStatus editorGpsStatus;
  private TextView editorGpsDot;
  private TextView editorGpsLevel;
  private ViewGroup editorGpsBars;
  private final Handler editorGpsHandler = new Handler(Looper.getMainLooper());
  private final Runnable editorGpsRefresh = new Runnable() {
    @Override
    public void run() {
      updateEditorGpsHeader();
      editorGpsHandler.postDelayed(this, 1000L);
    }
  };

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    EdgeToEdge.enable(this);
    Window window = getWindow();
    WindowCompat.getInsetsController(window, window.getDecorView())
        .setAppearanceLightStatusBars(false);
    super.onCreate(savedInstanceState);

    AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);

    setContentView(R.layout.create_advanced_workout);

    editorGpsDot = findViewById(R.id.advanced_gps_header_dot);
    editorGpsLevel = findViewById(R.id.advanced_gps_header_level);
    editorGpsBars = findViewById(R.id.advanced_gps_header_bars);
    findViewById(R.id.advanced_gps_header_status).setOnClickListener(v -> {
      try {
        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
      } catch (Exception ignored) {
      }
    });

    findViewById(R.id.advanced_editor_back_button).setOnClickListener(v -> {
      persistCurrentWorkoutName();
      finish();
    });

    Intent intent = getIntent();
    String advWorkoutName = intent.getStringExtra(ManageWorkoutsActivity.WORKOUT_NAME);
    boolean workoutEditMode =
        intent.getBooleanExtra(ManageWorkoutsActivity.WORKOUT_EDIT_MODE, false);

    try {
      createAdvancedWorkout(advWorkoutName, workoutEditMode);
    } catch (Exception e) {
      handleWorkoutFileException(e);
      return;
    }

    advancedWorkoutSpinner = findViewById(R.id.new_workout_spinner);
    storedWorkoutListAdapter = new StoredWorkoutListAdapter(this);
    storedWorkoutListAdapter.reload();
    advancedWorkoutSpinner.setAdapter(storedWorkoutListAdapter);
    // Pace Coach uses a two-level selector: first the workout category, then the
    // stored workouts inside that category. Keep the visual value in the spinner,
    // but handle the selector itself with the Pace Coach dialog so the category
    // back button can remain visible.
    advancedWorkoutSpinner.setViewOnClickListener(v -> showWorkoutCategorySelector());
    advancedWorkoutSpinner.setValue(advWorkoutName);

    dontAskAgain = false;

    ListView advancedStepList = findViewById(R.id.new_advnced_workout_steps);
    advancedStepList.setDividerHeight(0);
    advancedStepList.setAdapter(advancedWorkoutStepsAdapter);

    Button addStepButton = findViewById(R.id.add_step_button);
    addStepButton.setOnClickListener(addStepButtonClick);

    Button addRepeatButton = findViewById(R.id.add_repeat_button);
    addRepeatButton.setOnClickListener(addRepeatStepButtonClick);

    Button saveWorkoutButton = findViewById(R.id.workout_save_button);
    saveWorkoutButton.setOnClickListener(saveWorkoutButtonClick);

    Button discardWorkoutButton = findViewById(R.id.workout_discard_button);
    discardWorkoutButton.setOnClickListener(discardWorkoutButtonClick);

    Button renameWorkoutButton = findViewById(R.id.workout_rename_button);
    renameWorkoutButton.setVisibility(View.GONE);

    if (workoutEditMode) {
      // Avoid users inadvertently deleting existing workouts while editing:
      // (discard button should only be available when creating a workout)
      discardWorkoutButton.setVisibility(View.GONE);
      renameWorkoutButton.setVisibility(View.VISIBLE);
      renameWorkoutButton.setOnClickListener(renameWorkoutButtonClick);
    }

    // Persist the currently displayed workout name when leaving via the back button so that
    // StartFragment's advanced tab points at (and shows) this workout when we return.
    getOnBackPressedDispatcher()
        .addCallback(
            this,
            new OnBackPressedCallback(true) {
              @Override
              public void handleOnBackPressed() {
                persistCurrentWorkoutName();
                finish();
              }
            });

    ViewUtil.Insets(findViewById(R.id.create_advanced_workout_view), true);
  }

  @Override
  protected void onResume() {
    super.onResume();
    startEditorGps();
    editorGpsHandler.removeCallbacks(editorGpsRefresh);
    editorGpsHandler.post(editorGpsRefresh);
  }

  @Override
  protected void onPause() {
    editorGpsHandler.removeCallbacks(editorGpsRefresh);
    stopEditorGps();
    super.onPause();
  }

  private void startEditorGps() {
    if (editorGpsStatus == null) {
      editorGpsStatus = new GpsStatus(getApplicationContext());
    }
    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
        != PackageManager.PERMISSION_GRANTED) {
      updateEditorGpsHeader();
      return;
    }
    try {
      if (editorGpsStatus.isEnabled() && !editorGpsStatus.isLogging()) {
        editorGpsStatus.start(() -> runOnUiThread(this::updateEditorGpsHeader));
      }
    } catch (Exception ignored) {
    }
    updateEditorGpsHeader();
  }

  private void stopEditorGps() {
    if (editorGpsStatus != null && editorGpsStatus.isLogging()) {
      try {
        editorGpsStatus.stop(() -> {});
      } catch (Exception ignored) {
      }
    }
  }

  private void updateEditorGpsHeader() {
    if (editorGpsDot == null || editorGpsLevel == null || editorGpsBars == null) {
      return;
    }
    int color = 0xFFF44336;
    String label = "Ruim";
    int activeBars = 1;
    boolean enabled = editorGpsStatus != null && editorGpsStatus.isEnabled();
    boolean fixed = editorGpsStatus != null && editorGpsStatus.isFixed();
    int sats = editorGpsStatus == null ? 0 : editorGpsStatus.getSatellitesFixed();
    float accuracy = -1f;
    if (enabled && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
        == PackageManager.PERMISSION_GRANTED) {
      try {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Location last = lm == null ? null : lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (last != null) accuracy = last.getAccuracy();
      } catch (Exception ignored) {
      }
    }
    if (fixed && accuracy > 0 && accuracy <= 7f && sats > 7) {
      label = "Excelente";
      color = 0xFF00E676;
      activeBars = 3;
    } else if (fixed && accuracy > 0 && accuracy <= 15f && sats > 4) {
      label = "Bom";
      color = 0xFFFFB300;
      activeBars = 2;
    }
    editorGpsLevel.setText(label);
    editorGpsLevel.setTextColor(color);
    editorGpsDot.setTextColor(color);
    for (int i = 0; i < editorGpsBars.getChildCount(); i++) {
      View bar = editorGpsBars.getChildAt(i);
      android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
      bg.setColor(i < activeBars ? color : 0xFF59636D);
      bg.setCornerRadius(2f);
      bar.setBackground(bg);
    }
  }

  private void persistCurrentWorkoutName() {
    if (advancedWorkoutSpinner == null) {
      return;
    }
    try {
      String curName = advancedWorkoutSpinner.getValue().toString();
      SharedPreferences prefs =
          PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
      prefs.edit().putString(getString(R.string.pref_advanced_workout), curName).apply();
    } catch (Exception ignored) {
      // If the spinner value can't be read, fall back to the default back behaviour.
    }
  }

  private void loadSelectedWorkout(String name) {
    if (name == null || name.trim().isEmpty()) return;
    try {
      advancedWorkout = WorkoutSerializer.readFile(getApplicationContext(), name);
      boolean changed = normalizeLegacyStructuredDistances(advancedWorkout);
      changed |= normalizeRepeatSpecialSteps(advancedWorkout);
      if (changed) {
        WorkoutSerializer.writeFile(getApplicationContext(), name, advancedWorkout);
      }
      advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
      advancedWorkoutStepsAdapter.notifyDataSetChanged();
      PreferenceManager.getDefaultSharedPreferences(getApplicationContext())
          .edit()
          .putString(getString(R.string.pref_advanced_workout), name)
          .apply();
    } catch (Exception e) {
      handleWorkoutFileException(e);
    }
  }

  /** Repairs structured workouts saved by the old double-meter conversion bug. */
  private boolean normalizeLegacyStructuredDistances(Workout workout) {
    if (workout == null) return false;
    boolean changed = false;
    for (Workout.StepListEntry entry : workout.getStepList()) {
      Step step = entry.step();
      if (step.getDurationType() == org.runnerup.workout.Dimension.DISTANCE) {
        double meters = step.getDurationValue();
        if (meters >= 1000000.0 && Math.abs(meters % 1000.0) < 0.001) {
          step.setDurationValue(meters / 1000.0);
          changed = true;
        }
      }
    }
    return changed;
  }

  private static final String PREF_WORKOUT_CATEGORY_PREFIX = "pacecoach_workout_category_";
  private static final String CATEGORY_REGENERATIVO = "Regenerativo";
  private static final String CATEGORY_RODAGEM = "Rodagem";
  private static final String CATEGORY_INTERVALADO = "Intervalado";
  private static final String CATEGORY_FARTLEK = "Fartlek";
  private static final String CATEGORY_TEMPO = "Corrida de Tempo";
  private static final String CATEGORY_LONGAO = "Longão";

  private static final String[] WORKOUT_CATEGORIES = {
      CATEGORY_REGENERATIVO,
      CATEGORY_RODAGEM,
      CATEGORY_INTERVALADO,
      CATEGORY_FARTLEK,
      CATEGORY_TEMPO,
      CATEGORY_LONGAO
  };

  private String categoryForWorkout(String workoutName) {
    if (workoutName == null || workoutName.trim().isEmpty()) return CATEGORY_RODAGEM;
    SharedPreferences prefs =
        PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
    String stored = prefs.getString(PREF_WORKOUT_CATEGORY_PREFIX + workoutName, null);
    if (stored != null && !stored.trim().isEmpty()) return stored;

    // Existing RunnerUp workouts did not have a Pace Coach category. Infer the
    // category only when the workout structure provides an unambiguous signal;
    // repeated blocks are interval workouts, otherwise use Rodagem as the neutral
    // fallback. No existing workout file is changed by this fallback.
    try {
      Workout w = WorkoutSerializer.readFile(getApplicationContext(), workoutName);
      for (Step step : w.getSteps()) {
        if (step instanceof RepeatStep) return CATEGORY_INTERVALADO;
      }
    } catch (Exception ignored) {
    }
    return CATEGORY_RODAGEM;
  }

  private void saveWorkoutCategory(String workoutName, String category) {
    if (workoutName == null || workoutName.trim().isEmpty() || category == null) return;
    PreferenceManager.getDefaultSharedPreferences(getApplicationContext())
        .edit()
        .putString(PREF_WORKOUT_CATEGORY_PREFIX + workoutName, category)
        .apply();
  }

  private String[] getStoredWorkoutNames() {
    String[] files =
        getApplicationContext()
            .getDir(WorkoutSerializer.WORKOUTS_DIR, 0)
            .list((dir, filename) -> filename.endsWith(".json"));
    if (files == null) return new String[0];
    String[] stored = new String[files.length];
    for (int i = 0; i < files.length; i++) {
      String file = files[i];
      int dot = file.lastIndexOf('.');
      stored[i] = dot > 0 ? file.substring(0, dot) : file;
    }
    java.util.Arrays.sort(stored, String.CASE_INSENSITIVE_ORDER);
    return stored;
  }

  private void showWorkoutCategorySelector() {
    final android.widget.LinearLayout content = new android.widget.LinearLayout(this);
    content.setOrientation(android.widget.LinearLayout.VERTICAL);
    content.setPadding(dp(10), dp(6), dp(10), dp(6));

    final android.widget.ScrollView scroll = new android.widget.ScrollView(this);
    scroll.setFillViewport(true);
    scroll.addView(content);

    final AlertDialog dialog =
        new AlertDialog.Builder(this)
            .setTitle("Selecione seu treino")
            .setView(scroll)
            .create();

    showWorkoutCategories(content, dialog);
    dialog.show();
    if (dialog.getWindow() != null) {
      dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_coach_hero);
    }
  }

  private void showWorkoutCategories(android.widget.LinearLayout content, AlertDialog dialog) {
    content.removeAllViews();
    addSelectorRow(
        content,
        "+",
        "Criar novo treino",
        true,
        v -> {
          dialog.dismiss();
          showCreateNewWorkoutDialog();
        });

    for (String category : WORKOUT_CATEGORIES) {
      addCategorySelectorRow(
          content,
          category,
          v -> showWorkoutsForCategory(content, dialog, category));
    }
  }

  private void showWorkoutsForCategory(
      android.widget.LinearLayout content, AlertDialog dialog, String category) {
    content.removeAllViews();
    addSelectorRow(
        content,
        "‹",
        "Voltar às categorias",
        true,
        v -> showWorkoutCategories(content, dialog));

    String[] stored = getStoredWorkoutNames();
    int count = 0;
    for (String workoutName : stored) {
      if (!category.equals(categoryForWorkout(workoutName))) continue;
      count++;
      final String selectedName = workoutName;
      addSelectorRow(
          content,
          "",
          selectedName,
          false,
          v -> {
            loadSelectedWorkout(selectedName);
            advancedWorkoutSpinner.setValue(selectedName);
            dialog.dismiss();
          });
    }

    if (count == 0) {
      TextView empty = new TextView(this);
      empty.setText("Nenhum treino salvo nesta categoria.");
      empty.setTextColor(getResources().getColor(R.color.colorTextSecondary));
      empty.setTextSize(16);
      empty.setPadding(dp(20), dp(16), dp(20), dp(16));
      content.addView(empty);
    }
  }

  private void addSelectorRow(
      ViewGroup parent,
      String icon,
      String label,
      boolean accent,
      View.OnClickListener listener) {
    TextView row = new TextView(this);
    row.setText((icon == null || icon.isEmpty()) ? label : icon + "    " + label);
    row.setTextSize(18);
    row.setGravity(android.view.Gravity.CENTER_VERTICAL);
    row.setMinHeight(dp(56));
    row.setPadding(dp(16), 0, dp(16), 0);
    row.setTextColor(
        getResources().getColor(accent ? R.color.colorAccent : R.color.colorText));
    row.setBackgroundResource(accent ? R.drawable.bg_coach_setting : R.drawable.title_spinner);
    row.setOnClickListener(listener);
    android.widget.LinearLayout.LayoutParams lp =
        new android.widget.LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
    lp.setMargins(0, dp(3), 0, dp(3));
    parent.addView(row, lp);
  }

  private int categoryIconRes(String category) {
    if (CATEGORY_REGENERATIVO.equals(category)) return R.drawable.pc_category_regenerativo;
    if (CATEGORY_RODAGEM.equals(category)) return R.drawable.pc_category_rodagem;
    if (CATEGORY_INTERVALADO.equals(category)) return R.drawable.pc_category_intervalado;
    if (CATEGORY_FARTLEK.equals(category)) return R.drawable.pc_category_fartlek;
    if (CATEGORY_TEMPO.equals(category)) return R.drawable.pc_category_tempo;
    return R.drawable.pc_category_longao;
  }

  private void addCategorySelectorRow(
      ViewGroup parent, String label, View.OnClickListener listener) {
    android.widget.LinearLayout row = new android.widget.LinearLayout(this);
    row.setOrientation(android.widget.LinearLayout.HORIZONTAL);
    row.setGravity(android.view.Gravity.CENTER_VERTICAL);
    row.setPadding(dp(16), 0, dp(16), 0);
    row.setBackgroundResource(R.drawable.title_spinner);
    row.setOnClickListener(listener);

    ImageView icon = new ImageView(this);
    icon.setImageResource(categoryIconRes(label));
    icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
    android.widget.LinearLayout.LayoutParams iconLp =
        new android.widget.LinearLayout.LayoutParams(dp(40), dp(40));
    iconLp.setMargins(0, 0, dp(12), 0);
    row.addView(icon, iconLp);

    TextView text = new TextView(this);
    text.setText(label);
    text.setTextSize(18);
    text.setGravity(android.view.Gravity.CENTER_VERTICAL);
    text.setTextColor(getResources().getColor(R.color.colorText));
    row.addView(text, new android.widget.LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

    TextView arrow = new TextView(this);
    arrow.setText("▾");
    arrow.setTextSize(20);
    arrow.setGravity(android.view.Gravity.CENTER);
    arrow.setTextColor(getResources().getColor(R.color.colorText));
    row.addView(arrow, new android.widget.LinearLayout.LayoutParams(dp(30), ViewGroup.LayoutParams.MATCH_PARENT));

    android.widget.LinearLayout.LayoutParams lp =
        new android.widget.LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
    lp.setMargins(0, dp(3), 0, dp(3));
    parent.addView(row, lp);
  }

  private int dp(int value) {
    return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
  }

  private final class StoredWorkoutListAdapter extends BaseAdapter {
    private String[] workoutList = new String[0];

    StoredWorkoutListAdapter(Context context) {}

    @Override
    public int getCount() {
      return workoutList.length;
    }

    @Override
    public Object getItem(int position) {
      return workoutList[position];
    }

    @Override
    public long getItemId(int position) {
      return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      TextView text = convertView instanceof TextView
          ? (TextView) convertView
          : new TextView(CreateAdvancedWorkout.this);
      text.setText(workoutList[position]);
      return text;
    }

    void reload() {
      workoutList = getStoredWorkoutNames();
      notifyDataSetChanged();
    }
  }

  private void showCreateNewWorkoutDialog() {
    final android.widget.LinearLayout form = new android.widget.LinearLayout(this);
    form.setOrientation(android.widget.LinearLayout.VERTICAL);
    form.setPadding(dp(24), dp(4), dp(24), dp(4));

    TextView nameLabel = new TextView(this);
    nameLabel.setText("Definir nome");
    nameLabel.setTextColor(getResources().getColor(R.color.colorText));
    nameLabel.setTextSize(16);
    form.addView(nameLabel);

    final EditText input = new EditText(this);
    input.setInputType(InputType.TYPE_CLASS_TEXT);
    input.setSingleLine(true);
    input.setHint("Digite o nome do treino...");
    android.widget.LinearLayout.LayoutParams inputLp =
        new android.widget.LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    inputLp.setMargins(0, dp(4), 0, dp(14));
    form.addView(input, inputLp);

    TextView categoryLabel = new TextView(this);
    categoryLabel.setText("Categoria do treino");
    categoryLabel.setTextColor(getResources().getColor(R.color.colorText));
    categoryLabel.setTextSize(16);
    form.addView(categoryLabel);

    final TextView categorySelector = new TextView(this);
    categorySelector.setText("Selecione a categoria");
    categorySelector.setTextColor(getResources().getColor(R.color.colorTextSecondary));
    categorySelector.setTextSize(16);
    categorySelector.setGravity(android.view.Gravity.CENTER_VERTICAL);
    categorySelector.setMinHeight(dp(54));
    categorySelector.setPadding(dp(14), 0, dp(14), 0);
    categorySelector.setBackgroundResource(R.drawable.title_spinner);
    android.widget.LinearLayout.LayoutParams categoryLp =
        new android.widget.LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
    categoryLp.setMargins(0, dp(5), 0, 0);
    form.addView(categorySelector, categoryLp);

    final String[] selectedCategory = {null};
    categorySelector.setOnClickListener(v -> {
      // Use an explicit clickable row for each category.  The previous
      // AlertDialog/ListAdapter combination could display the radio buttons
      // but not reliably dispatch the selection on some Android versions.
      final android.widget.LinearLayout categoryContent =
          new android.widget.LinearLayout(this);
      categoryContent.setOrientation(android.widget.LinearLayout.VERTICAL);
      categoryContent.setPadding(dp(8), dp(4), dp(8), dp(4));

      final AlertDialog categoryDialog =
          new AlertDialog.Builder(this)
              .setTitle("Categoria do treino")
              .setView(categoryContent)
              .create();

      for (String category : WORKOUT_CATEGORIES) {
        final String selected = category;
        android.widget.LinearLayout row =
            new android.widget.LinearLayout(this);
        row.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(dp(56));
        row.setPadding(dp(8), 0, dp(8), 0);
        row.setBackgroundResource(R.drawable.title_spinner);
        row.setOnClickListener(view -> {
          selectedCategory[0] = selected;
          categorySelector.setText(selected);
          categorySelector.setTextColor(getResources().getColor(R.color.colorText));
          categoryDialog.dismiss();
        });

        ImageView icon = new ImageView(this);
        icon.setImageResource(categoryIconRes(selected));
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        row.addView(
            icon,
            new android.widget.LinearLayout.LayoutParams(dp(40), dp(52)));

        TextView label = new TextView(this);
        label.setText(selected);
        label.setTextSize(17);
        label.setTextColor(getResources().getColor(R.color.colorText));
        label.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.addView(
            label,
            new android.widget.LinearLayout.LayoutParams(0, dp(52), 1f));

        RadioButton radio = new RadioButton(this);
        radio.setChecked(selected.equals(selectedCategory[0]));
        radio.setClickable(false);
        row.addView(
            radio,
            new android.widget.LinearLayout.LayoutParams(dp(48), dp(52)));

        android.widget.LinearLayout.LayoutParams rowLp =
            new android.widget.LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        rowLp.setMargins(0, dp(2), 0, dp(2));
        categoryContent.addView(row, rowLp);
      }

      categoryDialog.show();
    });

    final AlertDialog dialog =
        new AlertDialog.Builder(this)
            .setTitle("Criar novo treino")
            .setView(form)
            .setNegativeButton("CANCELAR", (d, which) -> d.dismiss())
            .setPositiveButton("CRIAR TREINO", null)
            .create();

    dialog.setOnShowListener(
        d ->
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
              String name = input.getText().toString().trim();
              if (name.isEmpty()
                  || name.contains("/")
                  || name.contains("\\")
                  || name.contains("..")) {
                Toast.makeText(this, org.runnerup.common.R.string.Invalid_workout_name, Toast.LENGTH_SHORT).show();
                return;
              }
              if (selectedCategory[0] == null) {
                Toast.makeText(this, "Selecione uma categoria.", Toast.LENGTH_SHORT).show();
                return;
              }
              File file = WorkoutSerializer.getFile(getApplicationContext(), name);
              if (file.exists()) {
                Toast.makeText(this, org.runnerup.common.R.string.Workout_name_already_in_use, Toast.LENGTH_SHORT).show();
                return;
              }
              try {
                advancedWorkout = new Workout();
                WorkoutSerializer.writeFile(getApplicationContext(), name, advancedWorkout);
                saveWorkoutCategory(name, selectedCategory[0]);
                advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
                advancedWorkoutStepsAdapter.notifyDataSetChanged();
                storedWorkoutListAdapter.reload();
                advancedWorkoutSpinner.setValue(name);
                PreferenceManager.getDefaultSharedPreferences(getApplicationContext())
                    .edit()
                    .putString(getString(R.string.pref_advanced_workout), name)
                    .apply();
                dialog.dismiss();
              } catch (Exception e) {
                handleWorkoutFileException(e);
              }
            }));
    dialog.show();
    if (dialog.getWindow() != null) {
      dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_coach_hero);
    }
  }

  private int categoryIndex(String category) {
    for (int i = 0; i < WORKOUT_CATEGORIES.length; i++) {
      if (WORKOUT_CATEGORIES[i].equals(category)) return i;
    }
    return -1;
  }

  private void createAdvancedWorkout(String name, boolean workoutEditMode)
      throws JSONException, IOException {
    if (workoutEditMode) {
      advancedWorkout = WorkoutSerializer.readFile(getApplicationContext(), name);
      boolean changed = normalizeLegacyStructuredDistances(advancedWorkout);
      changed |= normalizeRepeatSpecialSteps(advancedWorkout);
      if (changed) {
        WorkoutSerializer.writeFile(getApplicationContext(), name, advancedWorkout);
      }
    } else {
      advancedWorkout = new Workout();
      WorkoutSerializer.writeFile(getApplicationContext(), name, advancedWorkout);
    }
    advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
    advancedWorkoutStepsAdapter.notifyDataSetChanged();
  }

  final class WorkoutStepsAdapter extends BaseAdapter {

    List<Workout.StepListEntry> steps = new ArrayList<>();

    @Override
    public int getCount() {
      return steps.size();
    }

    @Override
    public Object getItem(int position) {
      return steps.get(position);
    }

    @Override
    public long getItemId(int position) {
      return 0;
    }

    private class ViewHolderWorkoutStepsAdapter {
      private TextView number;
      private StepButton button;
      private Button add;
      private Button del;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      View view = convertView;
      ViewHolderWorkoutStepsAdapter viewHolder;

      if (view == null) {
        viewHolder = new ViewHolderWorkoutStepsAdapter();

        LayoutInflater inflater = getLayoutInflater();
        view = inflater.inflate(R.layout.advanced_workout_row, parent, false);

        viewHolder.number = view.findViewById(R.id.step_number);
        viewHolder.button = view.findViewById(R.id.workout_step_button);
        viewHolder.button.setOnChangedListener(onWorkoutChanged);

        viewHolder.add = view.findViewById(R.id.add_button);
        viewHolder.add.setOnClickListener(onAddButtonClick);

        viewHolder.del = view.findViewById(R.id.del_button);
        viewHolder.del.setOnClickListener(onDeleteButtonClick);

        view.setTag(viewHolder);
      } else {
        viewHolder = (ViewHolderWorkoutStepsAdapter) view.getTag();
      }

      Workout.StepListEntry entry = steps.get(position);
      viewHolder.number.setText(String.valueOf(position + 1));
      viewHolder.button.setStep(entry.step());
      float pxToDp = getResources().getDisplayMetrics().density;
      viewHolder.button.setPadding((int) (entry.level() * 8 * pxToDp + 0.5f), 0, 0, 0);

      return view;
    }
  }

  private final View.OnClickListener onAddButtonClick =
      view -> {
        // The + button is inside the trailing action container, so its direct parent
        // is NOT the row. Walk up to the actual row before looking up the StepButton.
        View row = (View) view.getParent();
        if (row != null) row = (View) row.getParent();
        final StepButton stepButton = row == null ? null : row.findViewById(R.id.workout_step_button);

        if (stepButton == null || stepButton.getStep() == null || advancedWorkout == null) {
          return;
        }

        Step currentStep = stepButton.getStep();
        if (currentStep instanceof RepeatStep rs) {
          rs.getSteps().add(new Step());
        } else {

          int index = advancedWorkout.getSteps().indexOf(currentStep);
          if (index >= 0) {
            advancedWorkout.getSteps().add(index + 1, new Step());
          } else {
            // The displayed list is flattened, so the selected step may belong
            // to a RepeatStep. Insert only in the RepeatStep that actually owns it.
            boolean inserted = false;
            for (Step se : advancedWorkout.getSteps()) {
              if (se instanceof RepeatStep rs) {
                int nestedIndex = rs.getSteps().indexOf(currentStep);
                if (nestedIndex >= 0) {
                  rs.getSteps().add(nestedIndex + 1, new Step());
                  inserted = true;
                  break;
                }
              }
            }
            if (!inserted) {
              return;
            }
          }
        }
        advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
        advancedWorkoutStepsAdapter.notifyDataSetChanged();
      };

  private final View.OnClickListener onDeleteButtonClick =
      new View.OnClickListener() {

        @Override
        public void onClick(View view) {
          // The × button is inside the trailing action container; its direct parent
          // is one level below the ListView row.
          View row = (View) view.getParent();
          if (row != null) row = (View) row.getParent();
          final StepButton stepButton = row == null ? null : row.findViewById(R.id.workout_step_button);

          if (stepButton == null || stepButton.getStep() == null || advancedWorkout == null) {
            return;
          }

          if (!dontAskAgain) {
            new AlertDialog.Builder(CreateAdvancedWorkout.this)
                .setMultiChoiceItems(
                    new String[] {"Don't ask again"},
                    new boolean[] {dontAskAgain},
                    (dialog, indexSelected, isChecked) -> dontAskAgain = isChecked)
                .setTitle(org.runnerup.common.R.string.Are_you_sure)
                .setPositiveButton(
                    org.runnerup.common.R.string.Yes,
                    (dialog, which) -> {
                      dialog.dismiss();
                      deleteStep(stepButton);
                    })
                .setNegativeButton(
                    org.runnerup.common.R.string.No, (dialog, which) -> dialog.dismiss())
                .show();
          } else {
            deleteStep(stepButton);
          }
        }

        private void deleteStep(StepButton button) {
          Step s = button.getStep();
          for (Step se : advancedWorkout.getSteps()) {
            if (se instanceof RepeatStep) {
              for (Step subStep : ((RepeatStep) se).getSteps()) {
                if (subStep.equals(s)) {
                  ((RepeatStep) se).getSteps().remove(s);
                  break;
                }
              }
            }
            if (se.equals(s)) {
              advancedWorkout.getSteps().remove(se);
              break;
            }
          }

          normalizeRepeatSpecialSteps(advancedWorkout);
          advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
          advancedWorkoutStepsAdapter.notifyDataSetChanged();
        }
      };

  private final Runnable onWorkoutChanged =
      () -> {
        String advWorkoutName = advancedWorkoutSpinner.getValue().toString();
        if (advancedWorkout != null) {
          Context ctx = getApplicationContext();
          try {
            normalizeRepeatSpecialSteps(advancedWorkout);
            advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
            advancedWorkoutStepsAdapter.notifyDataSetChanged();
            WorkoutSerializer.writeFile(ctx, advWorkoutName, advancedWorkout);
          } catch (Exception ex) {
            new AlertDialog.Builder(CreateAdvancedWorkout.this)
                .setTitle(org.runnerup.common.R.string.Failed_to_load_workout)
                .setMessage("" + ex)
                .setPositiveButton(
                    org.runnerup.common.R.string.OK, (dialog, which) -> dialog.dismiss())
                .show();
          }
        }
      };

  private final View.OnClickListener addStepButtonClick =
      v -> {
        // A repeat marker starts a block. Until another repeat marker is added,
        // new normal steps belong to the most recent repeat block. This gives the
        // editor the approved flat syntax: Repetir Nx -> all following steps
        // until the next Repetir are repeated Nx times.
        RepeatStep activeRepeat = getLastTopLevelRepeat();
        if (activeRepeat != null) {
          activeRepeat.getSteps().add(new Step());
        } else {
          advancedWorkout.addStep(new Step());
        }
        advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
        advancedWorkoutStepsAdapter.notifyDataSetChanged();
      };

  private RepeatStep getLastTopLevelRepeat() {
    if (advancedWorkout == null) return null;
    List<Step> topLevel = advancedWorkout.getSteps();
    if (topLevel.isEmpty()) return null;
    Step last = topLevel.get(topLevel.size() - 1);
    return last instanceof RepeatStep ? (RepeatStep) last : null;
  }

  private final View.OnClickListener addRepeatStepButtonClick =
      view -> {
        advancedWorkout.addStep(new RepeatStep());
        advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
        advancedWorkoutStepsAdapter.notifyDataSetChanged();
      };

  /**
   * Warmup and cooldown are special boundary steps and must never execute as
   * children of a repeat block. If the user creates one below a repeat, promote
   * it to the top level immediately after that repeat block.
   */
  private boolean normalizeRepeatSpecialSteps(Workout workout) {
    if (workout == null) return false;
    boolean changed = false;
    List<Step> topLevel = workout.getSteps();
    for (int i = 0; i < topLevel.size(); i++) {
      Step container = topLevel.get(i);
      if (!(container instanceof RepeatStep)) continue;

      RepeatStep repeat = (RepeatStep) container;
      ArrayList<Step> promote = new ArrayList<>();
      for (Step child : new ArrayList<>(repeat.getSteps())) {
        Intensity intensity = child.getIntensity();
        if (intensity == Intensity.WARMUP || intensity == Intensity.COOLDOWN) {
          repeat.getSteps().remove(child);
          promote.add(child);
          changed = true;
        }
      }
      if (!promote.isEmpty()) {
        topLevel.addAll(i + 1, promote);
        i += promote.size();
      }
    }
    return changed;
  }

  private final View.OnClickListener saveWorkoutButtonClick =
      v -> {
        try {
          String advWorkoutName = advancedWorkoutSpinner.getValue().toString();
          normalizeRepeatSpecialSteps(advancedWorkout);
          advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
          advancedWorkoutStepsAdapter.notifyDataSetChanged();
          WorkoutSerializer.writeFile(getApplicationContext(), advWorkoutName, advancedWorkout);
          // Keep StartFragment's structured preview linked to the workout that was
          // actually edited/saved. Returning to Treino Estruturado must render this
          // exact serialized workout, not a stale/default selection.
          PreferenceManager.getDefaultSharedPreferences(getApplicationContext())
              .edit()
              .putString(getString(R.string.pref_advanced_workout), advWorkoutName)
              .apply();
          Intent result = new Intent();
          result.putExtra(ManageWorkoutsActivity.WORKOUT_NAME, advWorkoutName);
          setResult(RESULT_OK, result);
          finish();
        } catch (Exception e) {
          handleWorkoutFileException(e);
        }
      };

  private void handleWorkoutFileException(Exception e) {
    new AlertDialog.Builder(CreateAdvancedWorkout.this)
        .setTitle(getString(org.runnerup.common.R.string.Failed_to_create_workout))
        .setMessage(e.toString())
        .setPositiveButton(org.runnerup.common.R.string.OK, (dialog, which) -> dialog.dismiss())
        .show();
  }

  private final View.OnClickListener discardWorkoutButtonClick =
      view ->
          new AlertDialog.Builder(CreateAdvancedWorkout.this)
              .setTitle(org.runnerup.common.R.string.Delete_workout)
              .setMessage(org.runnerup.common.R.string.Are_you_sure)
              .setPositiveButton(
                  org.runnerup.common.R.string.Yes,
                  (dialog, which) -> {
                    dialog.dismiss();
                    String name = advancedWorkoutSpinner.getValue().toString();
                    File f = WorkoutSerializer.getFile(getApplicationContext(), name);
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                    finish();
                  })
              .setNegativeButton(
                  org.runnerup.common.R.string.No, (dialog, which) -> dialog.dismiss())
              .show();

  private final View.OnClickListener renameWorkoutButtonClick =
      view -> {
        final EditText newWorkoutNameEditText = new EditText(CreateAdvancedWorkout.this);
        newWorkoutNameEditText.setHint(org.runnerup.common.R.string.Enter_new_workout_name);
        newWorkoutNameEditText.setInputType(InputType.TYPE_CLASS_TEXT);
        newWorkoutNameEditText.setSingleLine(true);
        newWorkoutNameEditText.setMaxLines(1);
        newWorkoutNameEditText.setText(advancedWorkoutSpinner.getValue().toString());

        new AlertDialog.Builder(CreateAdvancedWorkout.this)
            .setView(newWorkoutNameEditText)
            .setPositiveButton(
                org.runnerup.common.R.string.OK,
                (dialog, which) -> {
                  String newWorkoutName = newWorkoutNameEditText.getText().toString().trim();
                  String oldWorkoutName = advancedWorkoutSpinner.getValue().toString().trim();
                  if (newWorkoutName.isEmpty()
                      || newWorkoutName.contains("/")
                      || newWorkoutName.contains("\\")
                      || newWorkoutName.contains("..")) {
                    Toast.makeText(
                            CreateAdvancedWorkout.this,
                            org.runnerup.common.R.string.Invalid_workout_name,
                            Toast.LENGTH_SHORT)
                        .show();
                    return;
                  }
                  if (newWorkoutName.equals(oldWorkoutName)) {
                    Toast.makeText(
                            CreateAdvancedWorkout.this,
                            org.runnerup.common.R.string
                                .New_workout_name_is_the_same_as_the_old_one,
                            Toast.LENGTH_SHORT)
                        .show();
                    return;
                  }
                  File f = WorkoutSerializer.getFile(getApplicationContext(), newWorkoutName);
                  if (f.exists()) {
                    Toast.makeText(
                            CreateAdvancedWorkout.this,
                            org.runnerup.common.R.string.Workout_name_already_in_use,
                            Toast.LENGTH_SHORT)
                        .show();
                    return;
                  }
                  try {
                    WorkoutSerializer.writeFile(
                        getApplicationContext(), newWorkoutName, advancedWorkout);
                    File oldFile =
                        WorkoutSerializer.getFile(getApplicationContext(), oldWorkoutName);
                    if (!oldFile.delete())
                      throw new IOException("Failed to delete old workout file");
                    SharedPreferences prefs =
                        PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    String key = getString(R.string.pref_advanced_workout);
                    if (oldWorkoutName.contentEquals(prefs.getString(key, ""))) {
                      prefs.edit().putString(key, newWorkoutName).apply();
                    }
                    String category = categoryForWorkout(oldWorkoutName);
                    prefs.edit()
                        .remove(PREF_WORKOUT_CATEGORY_PREFIX + oldWorkoutName)
                        .putString(PREF_WORKOUT_CATEGORY_PREFIX + newWorkoutName, category)
                        .apply();
                    advancedWorkoutSpinner.setValue(newWorkoutName);
                    dialog.dismiss();
                    finish();
                  } catch (Exception e) {
                    handleWorkoutFileException(e);
                  }
                })
            .setNegativeButton(
                org.runnerup.common.R.string.Cancel, (dialog, which) -> dialog.dismiss())
            .show();
      };
}
