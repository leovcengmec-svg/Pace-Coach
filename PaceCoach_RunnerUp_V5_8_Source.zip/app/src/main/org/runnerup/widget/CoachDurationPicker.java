package org.runnerup.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Two-column duration picker used by Pace Coach free-run editor: hours + minutes. */
public class CoachDurationPicker extends LinearLayout {
  private final NumberPicker hours;
  private final NumberPicker minutes;

  public CoachDurationPicker(Context context, AttributeSet attrs) {
    super(context);
    setOrientation(HORIZONTAL);
    setGravity(Gravity.CENTER);
    setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));

    hours = createPicker(context, attrs, 23);
    minutes = createPicker(context, attrs, 59);
    addPickerWithUnit(context, hours, "h");
    addPickerWithUnit(context, minutes, "min");
  }

  private NumberPicker createPicker(Context context, AttributeSet attrs, int max) {
    NumberPicker picker = new NumberPicker(context, attrs);
    picker.setDigits(2);
    picker.setRange(0, max, false);
    picker.setOrientation(VERTICAL);
    return picker;
  }

  private void addPickerWithUnit(Context context, NumberPicker picker, String unit) {
    LinearLayout column = new LinearLayout(context);
    column.setOrientation(HORIZONTAL);
    column.setGravity(Gravity.CENTER_VERTICAL);
    column.setPadding(6, 0, 6, 0);
    column.addView(picker, new LinearLayout.LayoutParams(112, LayoutParams.WRAP_CONTENT));

    TextView label = new TextView(context);
    label.setText(unit);
    label.setTextSize(20);
    label.setTextColor(0xFFFFFFFF);
    label.setGravity(Gravity.CENTER_VERTICAL);
    column.addView(label, new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
    addView(column);
  }

  public long getSeconds() {
    return hoursValue() * 3600L + minutesValue() * 60L;
  }

  public void setSeconds(long seconds) {
    if (seconds < 0) seconds = 0;
    long h = seconds / 3600L;
    long m = (seconds % 3600L) / 60L;
    hours.setValue((int) Math.min(23, h));
    minutes.setValue((int) m);
  }

  public void setMinutesTotal(int totalMinutes) {
    if (totalMinutes < 0) totalMinutes = 0;
    setSeconds(totalMinutes * 60L);
  }

  private int hoursValue() {
    return hours.getValue();
  }

  private int minutesValue() {
    return minutes.getValue();
  }
}
