# Pace Coach V3.0.3

Correção de compilação no RunService: CoachEvent.Speak expõe a propriedade `text`, não `message`.

Mantém as correções anteriores de JVM 17 e integração GPS/coach.
