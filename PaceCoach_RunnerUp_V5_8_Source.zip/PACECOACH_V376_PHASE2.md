# Pace Coach / RunnerUp — revisão interna v376 · Fase 2

Base oficial do projeto: v374 (`versionName 2.11.0.2`).

Histórico de revisão:
- v374: base oficial recebida.
- v375: revisão Fase 1 (pipeline de rastreamento e persistência assíncrona).
- v376: esta revisão Fase 2 (integridade, backup, restauração e recuperação do banco).

Identidade técnica preservada: `org.runnerup`. O nome do ZIP de entrega permanece exatamente `PaceCoach_RunnerUp_V5_8_Source.zip`.

## Incremento de versão

- `versionCode` interno do projeto: `376` (a base Gradle adiciona o offset de `minSdk`; com `minSdk 23`, o APK Android reporta `23000376`).
- `versionName`: `2.11.0.2` (preservado, conforme a identidade de versão do RunnerUp).
- Wear mantém o incremento `+1` previsto pela estrutura original do projeto.

## Escopo aplicado

### 1. Snapshot SQLite consistente

- `DBHelper.getWritableDatabase()` agora solicita explicitamente uma conexão gravável.
- Adicionado `createConsistentBackupSnapshot()`.
- O snapshot verifica o modo de journal, conclui o checkpoint WAL quando necessário e muda temporariamente para journal DELETE antes de copiar o banco.
- A cópia do arquivo principal ocorre sob transação exclusiva de escrita, impedindo gravações concorrentes durante a captura.
- O modo WAL original é restaurado após a cópia quando aplicável.
- A saída é sincronizada em disco e rejeitada quando vazia.

### 2. Fechamento controlado das conexões

- Adicionado `DBHelper.closeForMaintenance()` para encerrar a instância singleton e suas conexões compartilhadas antes de substituir o arquivo.
- Adicionado `endMaintenance()` para reabrir o acesso somente após commit ou rollback.
- O acesso normal ao banco é bloqueado enquanto a manutenção está em andamento.
- O método normal `closeDB()` continua preservando a semântica histórica de banco compartilhado.

### 3. Backup formato v2 com integridade

- Manifesto versionado, compatível com backups v1 existentes.
- SHA-256 e tamanho individual para cada arquivo do payload.
- Verificação das somas e da quantidade de arquivos antes de aceitar uma restauração v2.
- Validação integral SQLite (`PRAGMA integrity_check`).
- Verificação de tabelas essenciais (`activity`, `location`, `lap`, `account`) e rejeição de esquemas mais novos que o app.
- Limites para tamanho comprimido, tamanho descompactado, tamanho individual, manifesto e quantidade de entradas.
- Rejeição de caminhos absolutos, `..`, barras invertidas, nomes duplicados e entradas fora das pastas esperadas.

### 4. Restauração em duas etapas com rollback

- O arquivo é primeiro copiado para uma área temporária.
- ZIP, manifesto, checksums e banco são validados antes de tocar nos dados atuais.
- O banco e os diretórios atuais são preservados como rollback.
- A conexão SQLite compartilhada é fechada antes de substituir o arquivo.
- O banco é instalado por arquivo temporário e rename, com preservação do anterior.
- Pastas de treinos, arquivos internos e preferências são substituídas somente após staging e snapshot.
- Em caso de falha após o início da substituição, o estado anterior é restaurado.
- Arquivos auxiliares SQLite antigos (`-wal`, `-shm`, `-journal`) são removidos antes da instalação.

### 5. Proteção de atividade em andamento

- Exportação/restauração completas e importação/exportação de banco isolado são bloqueadas enquanto uma corrida estiver gravando ou pausada.
- Antes de manutenção, o `Tracker` descarrega a fila de pontos, encerra o gravador e solta a referência local ao banco.
- Após commit ou rollback, o serviço pode reabrir sua conexão compartilhada.
- O importador legado usado por intents e os menus de banco isolado foram redirecionados para o fluxo validado; não copiam mais diretamente sobre o arquivo ativo.
- A limpeza de atividades excluídas agora é transacional e não fecha a conexão SQLite singleton compartilhada.
- Os acessores SQLite detectam e reabrem referências que tenham sido encerradas.
- A interface informa que é necessário fechar e reabrir o Pace Coach para recarregar preferências mantidas em memória.

## Arquivos alterados

- `build.gradle`
- `.github/workflows/actions.yml`
- `app/src/main/org/runnerup/db/DBHelper.java`
- `app/src/main/org/runnerup/tracker/Tracker.java`
- `app/src/main/org/runnerup/util/PaceCoachBackupManager.java`
- `app/src/main/org/runnerup/view/SettingsMaintenanceFragment.java`
- `app/src/main/org/runnerup/view/MainLayout.java` (o import legado continua roteado pelo wrapper seguro do `DBHelper`)
- `app/res/values/strings.xml`
- `app/test/java/org/runnerup/util/PaceCoachBackupArchiveTest.java`
- `PACECOACH_V374_PHASE1.md` (histórico de revisão e artefato corrigidos)
- `PACECOACH_V376_PHASE2.md`

## Limitações e validação pendente

- Esta revisão foi verificada estaticamente e por validações de estrutura/versão do pacote.
- A compilação Android, os testes unitários/lint e os testes no aparelho ainda precisam executar no GitHub Actions e no POCO X7 Pro.
- Backups v1 continuam aceitos, mas não possuem checksums retroativos; ainda passam pela validação SQLite completa.
- Backups completos não são permitidos durante corrida ativa/pausada para evitar capturar dados ainda em gravação.
- Depois da restauração, fechar e abrir o app é necessário para recarregar valores de `SharedPreferences` já mantidos em memória.
