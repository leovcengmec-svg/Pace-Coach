# Pace Coach V5.0

V5.0 fecha a primeira camada visual do fluxo de treino estruturado sobre o motor RunnerUp.

## Fluxo visual
Dashboard → Treino estruturado → Visualização do treino → Edição → Áudio → Iniciar → Tela de corrida.

## Preservado
- Motor RunnerUp para GPS, distância, tempo, pace, áudio e execução.
- Preview do treino antes de iniciar.
- Edição dos blocos existente.
- Configuração de áudio existente.
- Pace mínimo/máximo por bloco da V4.2/V4.3.
- Camadas de áudio Geral / Intervalo / Atual da V4.3.
- Compatibilidade de build do ambiente GitHub Actions já ajustado.

## V5.0 visual
- Sequência vertical em cartões de largura total.
- Cabeçalho orientado à visualização do treino.
- Resumo de etapas, distância e guia de pace.
- Ações Editar e Iniciar com hierarquia clara.
- Editor com linguagem de blocos/sequência.

V5.0 é uma evolução visual sobre V4.3; não substitui o motor de execução.
