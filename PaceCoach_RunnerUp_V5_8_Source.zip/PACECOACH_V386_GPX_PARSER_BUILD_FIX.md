# Pace Coach / RunnerUp — revisão interna v386

## Correção do erro de compilação da v384

A execução do GitHub Actions apontou em `GPXImporter.java:72`:

`incompatible types: InputStream cannot be converted to Reader`

A causa era a chamada `XmlPullParser.setInput(in)`, que não corresponde a uma sobrecarga disponível na API utilizada pelo projeto Android. O método de entrada binária requer dois parâmetros: `setInput(InputStream, String)`.

## Correção aplicada

- Alterada a chamada para `parser.setInput(in, null)`.
- O parser continua recebendo o fluxo binário original, podendo detectar a codificação pelo BOM ou pela declaração XML, sem criar um `Reader` UTF-8 à força.
- Mantidas as correções de importação adicionadas na v384: suporte a `<trkpt>` e `<rtept>`, leitura de texto/CDATA fragmentados, validação de coordenadas, transação do banco e mensagens de erro diagnósticas.
- Mantida a identificação original do aplicativo e do arquivo ZIP.

## Identificação

- Revisão interna: `v386`.
- `versionCode`: `386` (código Android esperado: `23000386`, com minSdk 23).
- `versionName`: `2.11.0.12`.
- Artefato GitHub Actions: `pacecoach-apk-v386-gpx-import-fix`.

## Verificações locais

- Confirmada a chamada à sobrecarga `setInput(InputStream, String)` no importador.
- Código Java analisado sintaticamente, sem erros de sintaxe.
- XMLs e workflow validados.
- ZIP testado integralmente.

## Validação pendente

A compilação Android completa precisa ser confirmada pelo GitHub Actions. Depois de compilar, o importador ainda precisa ser testado no aparelho com o arquivo GPX que apresentou falha; esse arquivo não foi anexado até esta revisão.
