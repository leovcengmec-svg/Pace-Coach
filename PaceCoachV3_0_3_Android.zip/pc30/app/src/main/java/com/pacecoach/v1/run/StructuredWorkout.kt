package com.pacecoach.v1.run

enum class StepKind {
    WARMUP,
    RUN,
    RECOVERY,
    COOLDOWN
}

data class WorkoutStep(
    val kind: StepKind,
    val durationSeconds: Long? = null,
    val distanceMeters: Float? = null,
    val targetPaceSeconds: Int? = null,
    val repeats: Int = 1,
    val label: String = ""
)

data class StructuredWorkout(
    val name: String,
    val steps: List<WorkoutStep>
)
