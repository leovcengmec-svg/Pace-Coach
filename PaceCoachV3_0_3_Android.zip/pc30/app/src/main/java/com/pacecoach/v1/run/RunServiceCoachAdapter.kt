package com.pacecoach.v1.run

class RunServiceCoachAdapter(
    private val integration: RunCoachIntegration = RunCoachIntegration()
) {
    fun begin(workout: StructuredWorkout, nowMs: Long, distanceM: Float): String? {
        integration.startWorkout(workout, nowMs, distanceM)
        return integration.currentStep()?.let { WorkoutVoice.start(it) }
    }

    fun onLiveUpdate(
        nowMs: Long,
        distanceM: Float,
        paceSeconds: Int?,
        gpsAccuracyMeters: Float,
        targetMarginSeconds: Int
    ): CoachEvent {
        val before = integration.currentStep()
        val decision = integration.update(nowMs, distanceM, paceSeconds, gpsAccuracyMeters, targetMarginSeconds)
        if (decision.state.state == CoachState.FINISHED) {
            return CoachEvent.Finished(decision.message ?: WorkoutVoice.finish())
        }
        val after = integration.currentStep()
        if (before != null && after != null && (before.index != after.index || before.repetition != after.repetition)) {
            return CoachEvent.Speak(WorkoutVoice.next(after))
        }
        if (decision.state.state == CoachState.GPS_UNCERTAIN && decision.message == null) {
            return CoachEvent.GpsUncertain
        }
        return decision.message?.let { CoachEvent.Speak(it) } ?: CoachEvent.None
    }

    fun currentStep(): ActiveStep? = integration.currentStep()
    fun isRunning(): Boolean = integration.isRunning()
    fun stop() { integration.clear() }
}
