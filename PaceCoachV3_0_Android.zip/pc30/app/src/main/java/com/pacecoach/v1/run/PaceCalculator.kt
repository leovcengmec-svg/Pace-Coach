package com.pacecoach.v1.run

import android.location.Location
import kotlin.math.abs

/**
 * Pace calculator with GPS quality checks and a rolling time window.
 * Designed to reject obvious GPS jumps while keeping the pace responsive.
 */
class PaceCalculator(
    private val windowSeconds: Long = 20L
) {
    data class Sample(val timestampMs: Long, val cumulativeDistanceM: Float)

    private val samples = ArrayDeque<Sample>()
    private var totalDistanceM = 0f
    private var lastLocation: Location? = null

    fun reset() {
        samples.clear()
        totalDistanceM = 0f
        lastLocation = null
    }

    fun addLocation(location: Location): Int? {
        val accuracy = location.accuracy
        if (accuracy.isNaN() || accuracy > 30f) return currentPaceSeconds()

        val previous = lastLocation
        if (previous != null) {
            val dtMs = (location.time - previous.time).coerceAtLeast(1L)
            val d = previous.distanceTo(location)

            // Ignore tiny GPS noise.
            if (d < 2f) {
                lastLocation = location
                return currentPaceSeconds()
            }

            // Reject implausible movement for a running watch interval.
            val speedMps = d / (dtMs / 1000f)
            if (d > 60f || speedMps > 12f) {
                return currentPaceSeconds()
            }

            totalDistanceM += d
        }

        lastLocation = location

        val now = location.time
        samples.addLast(Sample(now, totalDistanceM))

        val cutoff = now - windowSeconds * 1000L
        while (samples.size > 2 && samples.first().timestampMs < cutoff) {
            samples.removeFirst()
        }

        return currentPaceSeconds()
    }

    fun distanceMeters(): Float = totalDistanceM

    private fun currentPaceSeconds(): Int? {
        if (samples.size < 2) return null

        val first = samples.first()
        val last = samples.last()
        val distance = last.cumulativeDistanceM - first.cumulativeDistanceM
        val elapsedS = (last.timestampMs - first.timestampMs) / 1000f

        if (distance < 10f || elapsedS < 3f) return null

        val pace = elapsedS / distance * 1000f

        // Running pace sanity bounds: 2:30/km to 15:00/km.
        if (pace < 150f || pace > 900f) return null

        return pace.toInt()
    }
}
