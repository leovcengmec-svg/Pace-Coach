package org.runnerup.view;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import org.runnerup.R;
import org.runnerup.db.DBHelper;
import org.runnerup.util.PaceCoachBackupManager;

public class SettingsMaintenanceFragment extends PreferenceFragmentCompat {

  private static final String TAG = "SettingsMaintenance";
  private final ExecutorService backupExecutor = Executors.newSingleThreadExecutor();
  private final Handler mainHandler = new Handler(Looper.getMainLooper());

  /**
   * ActivityResultLauncher for handling the result of the {@link Intent#ACTION_CREATE_DOCUMENT}
   * intent used for exporting the database.
   *
   * <p>When the user selects a destination file, this launcher receives the {@link Uri} and
   * initiates the database export process via {@link DBHelper#exportDatabase(Context, Uri)}. If the
   * export is cancelled or no Uri is returned, a toast message is shown and a warning is logged.
   */
  private final ActivityResultLauncher<Intent> exportBackupLauncher =
      registerForActivityResult(
          new ActivityResultContracts.StartActivityForResult(),
          result -> {
            Uri toUri = getUriFromResult(result);
            if (toUri == null) {
              showToast(org.runnerup.R.string.pacecoach_backup_cancelled);
              return;
            }
            runBackupTask(
                () -> PaceCoachBackupManager.exportBackup(requireContext(), toUri),
                org.runnerup.R.string.pacecoach_backup_success,
                org.runnerup.R.string.pacecoach_backup_error);
          });

  private final ActivityResultLauncher<Intent> importBackupLauncher =
      registerForActivityResult(
          new ActivityResultContracts.StartActivityForResult(),
          result -> {
            Uri fromUri = getUriFromResult(result);
            if (fromUri == null) {
              showToast(org.runnerup.R.string.pacecoach_restore_cancelled);
              return;
            }
            new androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle(org.runnerup.R.string.pacecoach_restore_title)
                .setMessage(org.runnerup.R.string.pacecoach_restore_message)
                .setPositiveButton(
                    android.R.string.yes,
                    (dialog, which) ->
                        runBackupTask(
                            () -> PaceCoachBackupManager.importBackup(requireContext(), fromUri),
                            org.runnerup.R.string.pacecoach_restore_success,
                            org.runnerup.R.string.pacecoach_restore_error))
                .setNegativeButton(android.R.string.no, null)
                .show();
          });

  private final ActivityResultLauncher<Intent> exportDbLauncher =
      registerForActivityResult(
          new ActivityResultContracts.StartActivityForResult(),
          result -> {
            Uri toUri = getUriFromResult(result);
            if (toUri != null) {
              android.content.Context appContext = requireContext().getApplicationContext();
              runBackupTask(
                  () -> PaceCoachBackupManager.exportDatabaseOnly(appContext, toUri),
                  R.string.pacecoach_database_export_success,
                  R.string.pacecoach_database_export_error);
            } else {
              showToast(org.runnerup.common.R.string.export_cancelled);
              Log.w(TAG, "Database export cancelled or URI not found.");
            }
          });

  /** Imports a raw SQLite database using the validated, rollback-capable maintenance path. */
  private final ActivityResultLauncher<Intent> importDbLauncher =
      registerForActivityResult(
          new ActivityResultContracts.StartActivityForResult(),
          result -> {
            Uri fromUri = getUriFromResult(result);
            if (fromUri == null) {
              showToast(org.runnerup.common.R.string.import_cancelled);
              Log.w(TAG, "Database import cancelled or URI not found.");
              return;
            }
            android.content.Context appContext = requireContext().getApplicationContext();
            new androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle(R.string.pacecoach_database_import_title)
                .setMessage(R.string.pacecoach_database_import_message)
                .setPositiveButton(
                    android.R.string.yes,
                    (dialog, which) ->
                        runBackupTask(
                            () ->
                                PaceCoachBackupManager.importDatabaseOnly(
                                    appContext, fromUri),
                            R.string.pacecoach_database_import_success,
                            R.string.pacecoach_database_import_error))
                .setNegativeButton(android.R.string.no, null)
                .show();
          });

  private final Preference.OnPreferenceClickListener onBackupClick =
      preference -> {
        Intent intent =
            new Intent(Intent.ACTION_CREATE_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType(PaceCoachBackupManager.MIME_TYPE)
                .putExtra(Intent.EXTRA_TITLE, PaceCoachBackupManager.suggestedFileName());
        exportBackupLauncher.launch(intent);
        return true;
      };

  private final Preference.OnPreferenceClickListener onRestoreBackupClick =
      preference -> {
        Intent intent =
            new Intent(Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType(PaceCoachBackupManager.MIME_TYPE)
                .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
        importBackupLauncher.launch(intent);
        return true;
      };

  private final Preference.OnPreferenceClickListener onExportClick =
      preference -> {
        Intent intent =
            new Intent(Intent.ACTION_CREATE_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                // Use "application/octet-stream" to be consistent with the mime type used in
                // the http intent-filter for MainLayout (in AndroidManifest).
                .setType("application/octet-stream")
                .putExtra(
                    Intent.EXTRA_TITLE,
                    "runnerup.db.export"); // Suggest a name (note: user may change it)
        exportDbLauncher.launch(intent);
        return true;
      };
  private final Preference.OnPreferenceClickListener onImportClick =
      preference -> {
        Intent intent =
            new Intent(Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/octet-stream")
                .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
        importDbLauncher.launch(intent);
        return true;
      };
  private final Preference.OnPreferenceClickListener onPruneClick =
      preference -> {
        final ProgressDialog dialog = new ProgressDialog(requireContext());
        dialog.setTitle(org.runnerup.common.R.string.Pruning_deleted_activities_from_database);
        dialog.show();
        DBHelper.purgeDeletedActivities(requireContext(), dialog, dialog::dismiss);
        return false;
      };

  @Override
  public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
    setPreferencesFromResource(R.xml.settings_maintenance, rootKey);
    Resources res = getResources();
    {
      Preference btn = findPreference(res.getString(R.string.pref_backup_full));
      if (btn != null) {
        btn.setOnPreferenceClickListener(onBackupClick);
      }
    }
    {
      Preference btn = findPreference(res.getString(R.string.pref_restore_backup));
      if (btn != null) {
        btn.setOnPreferenceClickListener(onRestoreBackupClick);
      }
    }
    {
      Preference btn = findPreference(res.getString(R.string.pref_exportdb));
      if (btn != null) {
        btn.setOnPreferenceClickListener(onExportClick);
      }
    }
    {
      Preference btn = findPreference(res.getString(R.string.pref_importdb));
      if (btn != null) {
        btn.setOnPreferenceClickListener(onImportClick);
      }
    }
    {
      Preference btn = findPreference(res.getString(R.string.pref_prunedb));
      if (btn != null) {
        btn.setOnPreferenceClickListener(onPruneClick);
      }
    }
  }

  /**
   * Helper method to check the result of an ActivityResult and extract the Uri.
   *
   * @param result The ActivityResult from the launcher.
   * @return The Uri if the result was OK and data is present, otherwise null.
   */
  @Nullable
  private Uri getUriFromResult(ActivityResult result) {
    if (result.getResultCode() == Activity.RESULT_OK) {
      Intent data = result.getData();
      if (data != null && data.getData() != null) {
        return data.getData();
      }
    }
    return null;
  }
  private void runBackupTask(BackupTask task, int successRes, int errorRes) {
    backupExecutor.execute(
        () -> {
          Exception failure = null;
          try {
            task.run();
          } catch (Exception ex) {
            failure = ex;
            Log.e(TAG, "Backup operation failed", ex);
          }
          Exception result = failure;
          mainHandler.post(
              () -> {
                if (!isAdded()) return;
                if (result == null) {
                  showToast(successRes);
                } else {
                  Toast.makeText(
                          requireContext(),
                          getString(errorRes) + "\n" + result.getMessage(),
                          Toast.LENGTH_LONG)
                      .show();
                }
              });
        });
  }

  private void showToast(int resId) {
    if (!isAdded()) return;
    Toast.makeText(requireContext(), resId, Toast.LENGTH_SHORT).show();
  }

  private interface BackupTask {
    void run() throws Exception;
  }

  @Override
  public void onDestroy() {
    // Let an in-flight restore finish or roll back before the host destroys the fragment.
    backupExecutor.shutdown();
    mainHandler.removeCallbacksAndMessages(null);
    super.onDestroy();
  }

}
