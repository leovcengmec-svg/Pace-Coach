# Pace Coach v396 — Correção do mapa, parciais e resumo

## Base

Revisão v394. Preserva a identidade do Pace Coach e as correções de integridade das atividades.

## 1. Mapa e percurso

- `LocationEntity.LocationList` agora entrega o primeiro registro e avança o cursor somente depois de ler o ponto atual; antes o primeiro ponto era descartado.
- Tanto o mapa quanto as parciais usam a mesma sequência normalizada de `LocationEntity`, evitando divergência entre a rota desenhada e o painel de quilômetros.
- A distância acumulada prioriza `LOCATION.DISTANCE` salvo pelo Tracker e deriva a distância geográfica quando os dados antigos/importados não contêm esse valor.
- O tempo acumulado prioriza `LOCATION.ELAPSED` (tempo ativo) e deriva o tempo pelos registros quando a coluna não existe.
- O seletor e painel do mapa usam os splits GPS por quilômetro, não as linhas da tabela LAP que, em treinos estruturados, representam blocos.
- A série é normalizada a partir do primeiro ponto e limitada pelos totais oficiais da atividade; não altera coordenadas nem regrava o histórico existente.

## 2. Distância da parcial final

- A última linha incompleta na aba Voltas agora mostra o número e a distância real, por exemplo `7 · 0,57 km`, mantendo a identificação `Parcial`.
- O ritmo da parcial continua normalizado pela distância efetivamente percorrida.

## 3. Detalhamento de cada bloco

- Cada bloco conserva as linhas LAP automáticas que o compõem.
- Tocar em um bloco abre uma janela com as parciais internas por quilômetro (e o último trecho incompleto), reconstruídas usando a mesma sequência normalizada de `LocationEntity`.
- Cada parcial mostra tempo, distância, ritmo, ritmo-alvo e resultado (dentro/mais rápido/mais lento). Quando o GPS não tem dados suficientes, a janela informa que o detalhamento não está disponível, sem inventar parciais.
- Os dados são lidos do histórico existente; não é criada uma nova atividade nem são alteradas as voltas.

## 4. Resumo da home

- Removido o seletor `Dia` e as ramificações de cálculo associadas ao período diário.
- Permanecem `Semana`, `Mês` e `Ano`, com `Semana` como seleção inicial.

## Versão

- Revisão interna: v396.
- `versionCode` base: 396 (código Android esperado: 23000396, com minSdk 23).
- Wear reserva o código seguinte: 23000397.
- `versionName`: 2.11.0.22.
- Artefato GitHub Actions: `pacecoach-apk-v396-route-splits-summary-fix`.

## Validação pendente

- A compilação Android completa e o teste no POCO X7 Pro dependem do GitHub Actions/aparelho.
- Verificar no aparelho: mapa com tempos dos km, km parcial mostrando a distância, toque no bloco Intervalo mostrando as parciais e seletor somente Semana/Mês/Ano.
- A compilação Android completa não foi executada neste ambiente; a confirmação é feita pelo GitHub Actions.
