/*
 * Copyright (C) 2014 jonas.oreland@gmail.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package org.runnerup.tracker.component;

import static android.location.LocationManager.GPS_PROVIDER;
import static android.location.LocationManager.NETWORK_PROVIDER;
import static android.location.LocationManager.PASSIVE_PROVIDER;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import androidx.core.content.ContextCompat;
import androidx.preference.PreferenceManager;
import org.runnerup.R;
import org.runnerup.common.tracker.TrackerState;
import org.runnerup.tracker.GpsStatus;
import org.runnerup.tracker.Tracker;
import org.runnerup.util.TickListener;

/** GPS tracker component. Location callbacks are serialized on Tracker's dedicated Looper. */
public class TrackerGPS extends DefaultTrackerComponent implements TickListener {
  private static final String NAME = "GPS";
  private static final long WATCHDOG_INTERVAL_MS = 10000L;
  private static final long STALE_LOCATION_TIMEOUT_MS = 25000L;
  private static final long INITIAL_FIX_TIMEOUT_MS = 45000L;
  private static final long RECOVERY_COOLDOWN_MS = 30000L;

  private final Tracker tracker;
  private final Handler watchdogHandler = new Handler(Looper.getMainLooper());
  private final Handler mainHandler = new Handler(Looper.getMainLooper());
  private final Runnable watchdogRunnable = this::checkGpsWatchdog;
  private final GpsLessLocationProvider gpsLessLocationProvider = new GpsLessLocationProvider();

  private volatile boolean withoutGps;
  private volatile LocationManager locationManager;
  private volatile GpsStatus gpsStatus;
  private volatile Callback connectCallback;
  private volatile long connectStartedElapsedRealtimeMs;
  private volatile long lastRecoveryElapsedRealtimeMs;
  private int onEndCounter;
  private int frequencyMs = 500;
  private int frequencyMeters;
  private Location lastLocation;
  private volatile boolean shuttingDown;

  public TrackerGPS(Tracker tracker) {
    this.tracker = tracker;
  }

  @Override
  public String getName() {
    return NAME;
  }

  @Override
  public ResultCode onInit(Callback callback, Context context) {
    try {
      LocationManager manager =
          (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
      if (manager == null) {
        return ResultCode.RESULT_NOT_SUPPORTED;
      }
      locationManager = manager;
      if (withoutGps) {
        return ResultCode.RESULT_OK;
      }
      if (manager.getProvider(GPS_PROVIDER) == null) {
        return ResultCode.RESULT_NOT_SUPPORTED;
      }
      return ResultCode.RESULT_OK;
    } catch (RuntimeException ex) {
      Log.e(NAME, "Unable to initialize LocationManager", ex);
      return ResultCode.RESULT_ERROR;
    }
  }

  public void setWithoutGps(boolean enabled) {
    if (withoutGps == enabled) {
      return;
    }
    withoutGps = enabled;
    if (!enabled) {
      gpsLessLocationProvider.stop();
      return;
    }

    TrackerState state = tracker.getState();
    if (state == TrackerState.INIT
        || state == TrackerState.CLEANUP
        || state == TrackerState.ERROR
        || state == TrackerState.INITIALIZING
        || state == TrackerState.INITIALIZED) {
      return;
    }

    stopGpsUpdates();
    onTick();
    gpsLessLocationProvider.start(onEndCounter);
  }

  private int parseAndFixInteger(
      SharedPreferences preferences, int resourceId, String defaultValue, Context context) {
    String value = preferences.getString(context.getString(resourceId), defaultValue);
    if (TextUtils.isEmpty(value)) {
      preferences.edit().putString(context.getString(resourceId), defaultValue).apply();
      value = defaultValue;
    }
    try {
      return Integer.parseInt(value);
    } catch (NumberFormatException ex) {
      Log.w(NAME, "Invalid GPS preference; using " + defaultValue, ex);
      preferences.edit().putString(context.getString(resourceId), defaultValue).apply();
      return Integer.parseInt(defaultValue);
    }
  }

  private Location getLastKnownLocation(LocationManager manager, Context context) {
    String[] providers = {GPS_PROVIDER, NETWORK_PROVIDER, PASSIVE_PROVIDER};
    Location newest = null;
    for (String provider : providers) {
      try {
        Location candidate = manager.getLastKnownLocation(provider);
        if (candidate != null && (newest == null || candidate.getTime() > newest.getTime())) {
          newest = new Location(candidate);
        }
      } catch (SecurityException | IllegalArgumentException ex) {
        Log.d(NAME, "Last-known location unavailable for " + provider, ex);
      } catch (RuntimeException ex) {
        Log.w(NAME, "Unable to read last-known location from " + provider, ex);
      }
    }

    if (newest == null) {
      newest = new Location("RunnerUp");
    } else {
      newest.removeSpeed();
      newest.removeAltitude();
      newest.removeAccuracy();
      newest.removeBearing();
    }
    newest.setTime(System.currentTimeMillis());
    return newest;
  }

  @Override
  public ResultCode onConnecting(Callback callback, Context context) {
    connectCallback = null;
    stopGpsUpdates();
    shuttingDown = false;
    connectStartedElapsedRealtimeMs = SystemClock.elapsedRealtime();

    LocationManager manager = locationManager;
    if (manager == null) {
      manager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
      locationManager = manager;
    }
    if (manager == null) {
      Log.e(NAME, "Cannot connect: LocationManager is unavailable");
      return ResultCode.RESULT_ERROR_FATAL;
    }

    if (withoutGps) {
      SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
      frequencyMs =
          Math.max(
              250,
              parseAndFixInteger(preferences, R.string.pref_pollInterval, "500", context));
      lastLocation = getLastKnownLocation(manager, context);
      gpsLessLocationProvider.start(onEndCounter);
      return ResultCode.RESULT_OK;
    }

    if (ContextCompat.checkSelfPermission(tracker, Manifest.permission.ACCESS_FINE_LOCATION)
        != PackageManager.PERMISSION_GRANTED) {
      Log.e(NAME, "Cannot connect: ACCESS_FINE_LOCATION is not granted");
      return ResultCode.RESULT_ERROR_FATAL;
    }

    try {
      if (!manager.isProviderEnabled(GPS_PROVIDER)) {
        Log.w(NAME, "Cannot connect: GPS provider is disabled");
        return ResultCode.RESULT_ERROR_FATAL;
      }

      SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
      frequencyMs = Math.max(250, parseAndFixInteger(preferences, R.string.pref_pollInterval, "500", context));
      frequencyMeters = Math.max(0, parseAndFixInteger(preferences, R.string.pref_pollDistance, "0", context));
      lastLocation = getLastKnownLocation(manager, context);

      Handler callbackHandler = tracker.getLocationHandler();
      if (callbackHandler == null) {
        Log.e(NAME, "Cannot connect: Tracker location Handler is unavailable");
        return ResultCode.RESULT_ERROR_FATAL;
      }

      GpsStatus status = new GpsStatus(context);
      if (!status.start(this, false, callbackHandler)) {
        Log.e(NAME, "Cannot connect: GPS status monitor could not be started");
        return ResultCode.RESULT_ERROR_FATAL;
      }

      try {
        manager.requestLocationUpdates(
            GPS_PROVIDER, frequencyMs, frequencyMeters, tracker, callbackHandler.getLooper());
      } catch (RuntimeException ex) {
        status.stop(this);
        Log.e(NAME, "Cannot connect: GPS location subscription failed", ex);
        return ResultCode.RESULT_ERROR_FATAL;
      }

      gpsStatus = status;
      connectCallback = callback;
      scheduleGpsWatchdog();
      tracker.notifyGpsStatusChanged();
      Log.i(NAME, "GPS subscribed on dedicated Tracker Looper; waiting for a reliable fix");
      return ResultCode.RESULT_PENDING;
    } catch (SecurityException ex) {
      stopGpsUpdates();
      Log.e(NAME, "Cannot connect: location permission was revoked", ex);
      return ResultCode.RESULT_ERROR_FATAL;
    } catch (RuntimeException ex) {
      stopGpsUpdates();
      Log.e(NAME, "Unable to start GPS tracking", ex);
      return ResultCode.RESULT_ERROR_FATAL;
    }
  }

  public GpsStatus getGpsStatus() {
    return gpsStatus;
  }

  public boolean isGpsProviderEnabled() {
    LocationManager manager = locationManager;
    if (manager == null) return false;
    try {
      return manager.isProviderEnabled(GPS_PROVIDER);
    } catch (RuntimeException ex) {
      Log.w(NAME, "Unable to inspect GPS provider", ex);
      return false;
    }
  }

  @Override
  public boolean isConnected() {
    if (withoutGps) {
      return true;
    }
    GpsStatus status = gpsStatus;
    LocationManager manager = locationManager;
    if (status == null || !status.isFixed() || manager == null) {
      return false;
    }
    if (ContextCompat.checkSelfPermission(tracker, Manifest.permission.ACCESS_FINE_LOCATION)
        != PackageManager.PERMISSION_GRANTED) {
      return false;
    }
    try {
      long lastUpdate = status.getLastLocationUpdateElapsedRealtimeMs();
      return manager.isProviderEnabled(GPS_PROVIDER)
          && lastUpdate > 0L
          && SystemClock.elapsedRealtime() - lastUpdate < STALE_LOCATION_TIMEOUT_MS;
    } catch (RuntimeException ex) {
      Log.w(NAME, "Unable to verify GPS connection state", ex);
      return false;
    }
  }

  private void scheduleGpsWatchdog() {
    watchdogHandler.removeCallbacks(watchdogRunnable);
    watchdogHandler.postDelayed(watchdogRunnable, WATCHDOG_INTERVAL_MS);
  }

  private void stopGpsWatchdog() {
    watchdogHandler.removeCallbacks(watchdogRunnable);
  }

  private void checkGpsWatchdog() {
    if (shuttingDown || withoutGps) {
      return;
    }
    TrackerState state = tracker.getState();
    if (state != TrackerState.CONNECTING
        && state != TrackerState.CONNECTED
        && state != TrackerState.STARTED
        && state != TrackerState.PAUSED) {
      return;
    }

    if (ContextCompat.checkSelfPermission(tracker, Manifest.permission.ACCESS_FINE_LOCATION)
        != PackageManager.PERMISSION_GRANTED) {
      failPendingConnection("Precise location permission was revoked");
      if (state == TrackerState.STARTED || state == TrackerState.PAUSED) {
        scheduleGpsWatchdog();
      }
      return;
    }

    LocationManager manager = locationManager;
    if (manager == null) {
      failPendingConnection("LocationManager became unavailable");
      if (state == TrackerState.STARTED || state == TrackerState.PAUSED) {
        scheduleGpsWatchdog();
      }
      return;
    }
    try {
      if (!manager.isProviderEnabled(GPS_PROVIDER)) {
        failPendingConnection("GPS provider was disabled");
        if (tracker.getState() == TrackerState.STARTED || tracker.getState() == TrackerState.PAUSED) {
          scheduleGpsWatchdog();
        }
        return;
      }
    } catch (RuntimeException ex) {
      Log.w(NAME, "GPS watchdog could not inspect provider state", ex);
      scheduleGpsWatchdog();
      return;
    }

    long now = SystemClock.elapsedRealtime();
    GpsStatus status = gpsStatus;
    long lastUpdate = status == null ? 0L : status.getLastLocationUpdateElapsedRealtimeMs();
    boolean initialFixPending = connectCallback != null;
    boolean stale;
    if (lastUpdate == 0L && initialFixPending) {
      stale = now - connectStartedElapsedRealtimeMs >= INITIAL_FIX_TIMEOUT_MS;
    } else {
      stale = status == null || !status.isStarted() || lastUpdate == 0L
          || now - lastUpdate >= STALE_LOCATION_TIMEOUT_MS;
    }

    if (stale && now - lastRecoveryElapsedRealtimeMs >= RECOVERY_COOLDOWN_MS) {
      lastRecoveryElapsedRealtimeMs = now;
      recoverGpsUpdates();
    }
    scheduleGpsWatchdog();
  }

  private void failPendingConnection(String reason) {
    Callback callback = connectCallback;
    connectCallback = null;
    // Also release a stale subscription after a workout has already connected. In that case
    // there is no initial-connect callback to fail, but the watchdog must be able to re-register
    // the provider when the user enables GPS or restores permission.
    stopGpsUpdates();
    tracker.notifyGpsStatusChanged();
    if (callback == null) {
      Log.w(NAME, reason);
      return;
    }
    Log.e(NAME, reason);
    dispatchComponentCallback(callback, ResultCode.RESULT_ERROR_FATAL);
  }

  private void dispatchComponentCallback(Callback callback, ResultCode result) {
    Runnable delivery = () -> callback.run(this, result);
    if (Looper.myLooper() == Looper.getMainLooper()) {
      delivery.run();
    } else if (!mainHandler.post(delivery)) {
      Log.e(NAME, "Unable to dispatch Tracker component callback to the main thread");
    }
  }

  private void recoverGpsUpdates() {
    LocationManager manager = locationManager;
    Handler callbackHandler = tracker.getLocationHandler();
    if (manager == null || callbackHandler == null) {
      failPendingConnection("GPS recovery could not access LocationManager or callback Handler");
      return;
    }

    Log.w(NAME, "GPS updates are stale; re-registering the location subscription");
    stopGpsUpdates();
    GpsStatus replacementStatus = new GpsStatus(tracker);
    try {
      if (!replacementStatus.start(this, false, callbackHandler)) {
        failPendingConnection("GPS recovery could not start its quality monitor");
        return;
      }
      manager.requestLocationUpdates(
          GPS_PROVIDER, frequencyMs, frequencyMeters, tracker, callbackHandler.getLooper());
      gpsStatus = replacementStatus;
      Log.i(NAME, "GPS location subscription recovered");
    } catch (RuntimeException ex) {
      replacementStatus.stop(this);
      stopGpsUpdates();
      Log.e(NAME, "GPS recovery failed", ex);
      failPendingConnection("GPS recovery failed: " + ex.getClass().getSimpleName());
    }
  }

  private void stopGpsUpdates() {
    stopGpsWatchdog();
    LocationManager manager = locationManager;
    if (manager != null) {
      try {
        manager.removeUpdates(tracker);
      } catch (RuntimeException ex) {
        Log.d(NAME, "GPS location updates were already removed", ex);
      }
    }
    GpsStatus status = gpsStatus;
    gpsStatus = null;
    if (status != null) {
      status.stop(this);
    }
  }

  /** Unconditionally releases location resources when the Android service is destroyed. */
  public void shutdown() {
    shuttingDown = true;
    connectCallback = null;
    stopGpsUpdates();
    gpsLessLocationProvider.stop();
  }

  @Override
  public ResultCode onEnd(Callback callback, Context context) {
    onEndCounter++;
    shutdown();
    withoutGps = false;
    return ResultCode.RESULT_OK;
  }

  private final class GpsLessLocationProvider implements Runnable {
    private int sessionCounter;
    private Handler handler;

    void start(int endCounter) {
      sessionCounter = endCounter;
      handler = tracker.getLocationHandler();
      if (handler != null) {
        handler.removeCallbacks(this);
        handler.post(this);
      }
    }

    void stop() {
      if (handler != null) {
        handler.removeCallbacks(this);
      }
    }

    @Override
    public void run() {
      if (handler == null || sessionCounter < TrackerGPS.this.onEndCounter) {
        return;
      }
      TrackerState state = tracker.getState();
      if (state == TrackerState.INIT
          || state == TrackerState.CLEANUP
          || state == TrackerState.ERROR) {
        return;
      }

      Location seed = lastLocation;
      Location location = seed == null ? new Location("RunnerUp") : new Location(seed);
      location.setTime(System.currentTimeMillis());
      tracker.onLocationChanged(location);
      handler.postDelayed(this, Math.max(250, frequencyMs));
    }
  }

  /** Called by Tracker for each sample from its one LocationManager subscription. */
  public void onLocationUpdate(Location location) {
    GpsStatus status = gpsStatus;
    if (status != null && location != null) {
      status.onLocationChanged(location);
    }
  }

  @Override
  public void onTick() {
    tracker.notifyGpsStatusChanged();
    if (withoutGps) {
      completePendingConnection();
      return;
    }

    GpsStatus status = gpsStatus;
    if (status != null && status.isFixed()) {
      completePendingConnection();
    }
  }

  private void completePendingConnection() {
    Callback callback = connectCallback;
    if (callback == null) {
      return;
    }
    connectCallback = null;
    connectStartedElapsedRealtimeMs = 0L;
    Log.i(NAME, "Reliable GPS fix received; Tracker connection completed");
    scheduleGpsWatchdog();
    dispatchComponentCallback(callback, ResultCode.RESULT_OK);
  }
}
