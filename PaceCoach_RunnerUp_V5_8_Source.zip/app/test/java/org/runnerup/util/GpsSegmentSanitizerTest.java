package org.runnerup.util;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class GpsSegmentSanitizerTest {
  @Test
  public void acceptsNormalRunningSegments() {
    assertTrue(GpsSegmentSanitizer.isPlausible(18.0d, 3000L, 5.0d));
    assertTrue(GpsSegmentSanitizer.isPlausible(0.5d, 1000L, 3.0d));
  }

  @Test
  public void rejectsGpsJumpsAndInvalidDurations() {
    assertFalse(GpsSegmentSanitizer.isPlausible(950.0d, 2000L, 4.0d));
    assertFalse(GpsSegmentSanitizer.isPlausible(5.0d, 0L, 4.0d));
    assertFalse(GpsSegmentSanitizer.isPlausible(Double.NaN, 1000L, 4.0d));
  }
}
