package com.pacecoach.v1.run

import org.junit.Assert.assertEquals
import org.junit.Test

class CoachRuntimeTest {

    @Test
    fun targetStatesAreCorrect() {
        val step = ActiveStep(
            index = 0,
            repetition = 1,
            step = WorkoutStep(
                kind = StepKind.RUN,
                targetPaceSeconds = 300,
                label = "5:00/km"
            )
        )

        val runtime = CoachRuntime()

        assertEquals(
            CoachState.ON_TARGET,
            runtime.evaluate(step, 302, GpsQuality.GOOD, 5).state
        )

        assertEquals(
            CoachState.SLOWER_THAN_TARGET,
            runtime.evaluate(step, 312, GpsQuality.GOOD, 5).state
        )

        assertEquals(
            CoachState.FASTER_THAN_TARGET,
            runtime.evaluate(step, 288, GpsQuality.GOOD, 5).state
        )

        assertEquals(
            CoachState.GPS_UNCERTAIN,
            runtime.evaluate(step, null, GpsQuality.POOR, 5).state
        )
    }
}
