package com.pacecoach.v1.run

enum class GpsQuality {
    GOOD,
    ACCEPTABLE,
    POOR;

    companion object {
        fun fromAccuracy(accuracyMeters: Float): GpsQuality = when {
            accuracyMeters <= 10f -> GOOD
            accuracyMeters <= 30f -> ACCEPTABLE
            else -> POOR
        }
    }
}
