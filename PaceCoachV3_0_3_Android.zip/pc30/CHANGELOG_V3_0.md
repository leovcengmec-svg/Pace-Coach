# V3.0

- Wired `startWorkout` UI action to structured workout execution.
- Bumped app version to 3.0.
- Added GitHub Actions Android debug build workflow.
- Standardized CI on JDK 17 + Gradle 8.9.
- Preserved V2.9 GPS, pace, coach and workout behavior.


## V3.0.1
- Corrigida compatibilidade JVM: Java e Kotlin configurados para JVM 17.
