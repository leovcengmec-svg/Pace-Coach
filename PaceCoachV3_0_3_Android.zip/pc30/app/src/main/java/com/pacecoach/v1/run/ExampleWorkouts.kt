package com.pacecoach.v1.run

object ExampleWorkouts {

    fun interval4x1k(): StructuredWorkout =
        WorkoutBuilder("4 x 1 km")
            .addTimeStep(
                kind = StepKind.WARMUP,
                durationSeconds = 600,
                label = "Aquecimento"
            )
            .addIntervalBlock(
                runDistanceMeters = 1000f,
                runTargetPaceSeconds = 290,
                runLabel = "1 km forte",
                recoveryDurationSeconds = 120,
                recoveryLabel = "Recuperação",
                repeats = 4
            )
            .addTimeStep(
                kind = StepKind.COOLDOWN,
                durationSeconds = 600,
                label = "Desaquecimento"
            )
            .build()
}
