package org.runnerup.view;

import android.content.ContentValues;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.TextView;
import android.view.ViewGroup;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import org.runnerup.R;
import org.runnerup.common.util.Constants;
import org.runnerup.content.ShareImageProvider;
import org.runnerup.db.DBHelper;
import org.runnerup.workout.Intensity;

/** Pace Coach visual activity sharing. Generates deterministic PNG cards from stored activity data. */
public class ShareActivity extends AppCompatActivity implements Constants {
  private static final int CARD_W = 1080;
  private static final int CARD_H = 1350;
  private static final int TEMPLATE_SUMMARY = 0;
  private static final int TEMPLATE_MAP = 1;
  private static final int TEMPLATE_STATS = 2;
  private static final int TEMPLATE_PACE = 3;
  private static final int TEMPLATE_BLOCKS = 4;
  private static final int TEMPLATE_MINIMAL = 5;
  private static final int TEMPLATE_SPLITS = 6;
  private static final int TEMPLATE_METRICS = 7;
  private static final int TEMPLATE_HERO = 8;
  private static final int TEMPLATE_OVERLAY = 9;
  private static final int TEMPLATE_ELEVATION = 10;
  private static final int FORMAT_PORTRAIT = 0;
  private static final int FORMAT_STORY = 1;
  private static final int FORMAT_SQUARE = 2;

  private long activityId;
  private ActivityData data;
  private ImageView preview;
  private int template = TEMPLATE_SUMMARY;
  private Bitmap rendered;
  private int format = FORMAT_PORTRAIT;
  private boolean transparentBackground = true;
  private ArrayList<ContentValues> blocks = new ArrayList<>();
  private final String[] templateNames = {"Resumo", "Mapa", "Estatísticas", "Ritmo", "Blocos", "Minimalista", "Parciais", "Métricas", "Distância", "Foto", "Elevação"};
  private final ArrayList<Button> formatButtons = new ArrayList<>();

  @Override protected void onCreate(Bundle state) {
    super.onCreate(state);
    setContentView(R.layout.share_activity);
    activityId = getIntent().getLongExtra("activity_id", -1L);
    if (activityId < 0) { finish(); return; }
    data = loadActivity(activityId);
    if (data == null) { Toast.makeText(this, "Atividade não encontrada", Toast.LENGTH_SHORT).show(); finish(); return; }
    preview = findViewById(R.id.share_preview);
    setupTemplateSwipe();
    buildFormatButtons();
    findViewById(R.id.share_image_button).setOnClickListener(v -> shareImage());
    findViewById(R.id.share_copy_button).setOnClickListener(v -> copyImage());
    android.widget.CheckBox transparent = findViewById(R.id.share_transparent_background);
    transparent.setChecked(true);
    transparent.setOnCheckedChangeListener((button, checked) -> { transparentBackground = checked; render(); });
    render();
  }

  /** Switches templates with horizontal swipes on the preview instead of a wall of buttons. */
  private void setupTemplateSwipe() {
    TextView indicator = findViewById(R.id.share_template_indicator);
    TextView hint = findViewById(R.id.share_template_hint);
    GestureDetector detector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
      @Override public boolean onDown(MotionEvent event) { return true; }
      @Override public boolean onFling(MotionEvent first, MotionEvent last, float velocityX, float velocityY) {
        if (first == null || last == null) return false;
        float dx = last.getX() - first.getX();
        float dy = last.getY() - first.getY();
        if (Math.abs(dx) < dp(48) || Math.abs(dx) < Math.abs(dy) * 1.2f) return false;
        changeTemplate(dx < 0 ? 1 : -1);
        return true;
      }
    });
    preview.setClickable(true);
    preview.setOnTouchListener((view, event) -> detector.onTouchEvent(event));
    indicator.setOnClickListener(v -> changeTemplate(1));
    hint.setOnClickListener(v -> changeTemplate(1));
    updateTemplateIndicator();
  }

  private void changeTemplate(int direction) {
    template = (template + direction + templateNames.length) % templateNames.length;
    updateTemplateIndicator();
    render();
  }

  private void updateTemplateIndicator() {
    TextView indicator = findViewById(R.id.share_template_indicator);
    if (indicator != null) {
      indicator.setText(templateNames[template].toUpperCase(Locale.ROOT) + "  ·  " + (template + 1) + "/" + templateNames.length);
    }
  }

  private void buildFormatButtons() {
    LinearLayout row = findViewById(R.id.share_formats);
    row.removeAllViews(); formatButtons.clear();
    String[] labels = {"4:5", "9:16", "1:1"};
    for (int i = 0; i < labels.length; i++) {
      final int choice = i;
      Button b = new Button(this);
      b.setText(labels[i]); b.setAllCaps(false); b.setTextSize(12); b.setTypeface(Typeface.DEFAULT_BOLD);
      b.setMinHeight(0); b.setMinimumHeight(0); b.setPadding(0, 0, 0, 0);
      LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), 1f);
      lp.setMargins(dp(2), 0, dp(2), 0); row.addView(b, lp); formatButtons.add(b);
      b.setOnClickListener(v -> { format = choice; updateSelectorStyles(); render(); });
    }
    updateSelectorStyles();
  }

  private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

  private void updateSelectorStyles() {
    updateTemplateIndicator();
    for (int i = 0; i < formatButtons.size(); i++) styleSelector(formatButtons.get(i), i == format);
  }

  private void styleSelector(Button button, boolean selected) {
    GradientDrawable bg = new GradientDrawable();
    bg.setColor(selected ? Color.rgb(22,119,210) : Color.rgb(18,38,52));
    bg.setCornerRadius(dp(8));
    if (selected) bg.setStroke(dp(2), Color.rgb(83,177,255));
    else bg.setStroke(dp(1), Color.rgb(39,62,78));
    button.setBackground(bg);
    button.setTextColor(selected ? Color.WHITE : Color.rgb(184,202,215));
    if (android.os.Build.VERSION.SDK_INT >= 21) button.setElevation(selected ? dp(2) : 0);
  }

  private void render() {
    int w = CARD_W;
    int h = format == FORMAT_STORY ? 1920 : (format == FORMAT_SQUARE ? 1080 : CARD_H);
    if (template == TEMPLATE_BLOCKS || template == TEMPLATE_SPLITS) h = Math.max(h, 500 + blocks.size() * 80);
    rendered = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
    Canvas c = new Canvas(rendered);
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
    if (transparentBackground) c.drawColor(Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR);
    else c.drawColor(Color.rgb(4, 15, 23));
    // Fit the same design system to each social format instead of cropping metrics.
    if (format == FORMAT_STORY) {
      // Enlarge the approved 4:5 composition into the 9:16 canvas. This avoids
      // the narrow card floating in a large empty story while preserving margins.
      c.translate(0f, (h - CARD_H * 1.2f) / 2f);
      c.scale(1.2f, 1.2f);
    } else if (format == FORMAT_SQUARE) {
      // Scale to a square-safe composition without cropping the side metrics.
      c.translate(135f, 0f);
      c.scale(0.8f, 0.8f);
    }
    if (template != TEMPLATE_HERO && template != TEMPLATE_SUMMARY && template != TEMPLATE_MINIMAL) drawHeader(c, p);
    if (template == TEMPLATE_MAP) drawMap(c, p);
    if (template == TEMPLATE_STATS) drawStats(c, p);
    if (template == TEMPLATE_PACE) drawPace(c, p);
    if (template == TEMPLATE_BLOCKS) drawBlocks(c, p);
    if (template == TEMPLATE_MINIMAL) drawMinimal(c, p);
    if (template == TEMPLATE_SUMMARY) drawSummary(c, p);
    if (template == TEMPLATE_SPLITS) drawSplits(c, p);
    if (template == TEMPLATE_METRICS) drawMetricTiles(c, p);
    if (template == TEMPLATE_HERO) drawHero(c, p);
    if (template == TEMPLATE_OVERLAY) drawOverlay(c, p);
    if (template == TEMPLATE_ELEVATION) drawElevation(c, p);
    preview.setImageBitmap(rendered);
    updateTemplateIndicator();
  }

  /** Shared brand/date rail used by data-first templates. Activity titles belong to each card layout. */
  private void drawHeader(Canvas c, Paint p) {
    // Runner mark, drawn as vector strokes so the exported card remains crisp at every size.
    p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(7);
    p.setColor(Color.WHITE); c.drawCircle(77, 67, 12, p);
    p.setStrokeWidth(9);
    c.drawLine(76, 83, 61, 105, p);
    c.drawLine(76, 84, 99, 91, p);
    c.drawLine(66, 101, 49, 119, p);
    c.drawLine(67, 101, 88, 117, p);
    p.setStyle(Paint.Style.FILL);
    p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(42); p.setColor(Color.WHITE);
    c.drawText("Pace Coach", 112, 86, p);

    p.setTypeface(Typeface.DEFAULT); p.setTextSize(22); p.setColor(Color.rgb(205, 218, 228));
    String date = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(new Date(data.startTime * 1000L));
    String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(data.startTime * 1000L));
    c.drawText(date.toUpperCase(Locale.getDefault()), 1010 - p.measureText(date.toUpperCase(Locale.getDefault())), 64, p);
    c.drawText(time, 1010 - p.measureText(time), 94, p);
    p.setColor(Color.rgb(24, 88, 120)); c.drawRoundRect(62, 145, 1018, 151, 3, 3, p);
  }

  private void drawBlocks(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(46); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("Treino Estruturado",70,235,p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(22); p.setColor(Color.rgb(160,180,194));
    c.drawText(blocks.size()+" blocos  ·  "+formatDistance(data.distance)+"  ·  "+formatTime(data.time),70,275,p);

    int y=325; int target=0,inside=0,slower=0,faster=0;
    p.setColor(Color.rgb(126,151,166)); p.setTextSize(18); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("BLOCO",90,y,p); c.drawText("DURAÇÃO",420,y,p); c.drawText("DISTÂNCIA",565,y,p);
    c.drawText("RITMO",735,y,p); c.drawText("RESULTADO",875,y,p);
    p.setColor(Color.rgb(34,65,82)); c.drawRect(65,y+18,1015,y+21,p);
    int rowHeight=Math.max(48,Math.min(86,(rendered.getHeight()-y-155)/Math.max(1,blocks.size())));
    for(int i=0;i<blocks.size();i++) {
      ContentValues b=blocks.get(i); int rowTop=y+28+i*rowHeight; int intensity=getInt(b,DB.LAP.INTENSITY,1);
      double d=getDouble(b,DB.LAP.DISTANCE); long t=getLong(b,DB.LAP.TIME);
      double actual=t>0&&d>0?t*1000.0/d:0; double min=getTarget(b,DB.LAP.PLANNED_PACE_MIN,DB.LAP.PLANNED_PACE);
      double max=getTarget(b,DB.LAP.PLANNED_PACE_MAX,DB.LAP.PLANNED_PACE); boolean has=min>0&&max>0;
      int resultColor=Color.rgb(135,155,168); String result="—";
      if(has&&actual>0) {target++; if(actual>=min&&actual<=max){inside++;resultColor=Color.rgb(40,220,120);result="No alvo";} else if(actual>max){slower++;resultColor=Color.rgb(255,190,40);result="Mais lento";} else {faster++;resultColor=Color.rgb(255,75,90);result="Mais rápido";}}
      p.setColor(Color.rgb(12,31,44)); c.drawRoundRect(new RectF(65,rowTop,1015,rowTop+rowHeight-4),9,9,p);
      p.setColor(blockColor(intensity)); c.drawRoundRect(new RectF(65,rowTop,75,rowTop+rowHeight-4),4,4,p);
      float textY=rowTop+rowHeight*0.60f; p.setColor(Color.WHITE); p.setTextSize(rowHeight<60?19:23); p.setTypeface(Typeface.DEFAULT_BOLD);
      String blockName=(i+1)+". "+blockTitle(intensity); if(blockName.length()>19)blockName=blockName.substring(0,18)+"…";
      c.drawText(blockName,90,textY,p);
      p.setTypeface(Typeface.DEFAULT); p.setTextSize(rowHeight<60?18:21); p.setColor(Color.rgb(218,230,238));
      c.drawText(formatTime(t),420,textY,p); c.drawText(formatDistance(d),565,textY,p); c.drawText(actual>0?formatPace(actual).replace("/km","") : "—",735,textY,p);
      p.setColor(resultColor); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(rowHeight<60?16:18); c.drawText(result,875,textY,p);
      if(has&&rowHeight>=70) {p.setColor(Color.rgb(145,168,183));p.setTypeface(Typeface.DEFAULT);p.setTextSize(15);c.drawText("Alvo "+formatRange(min,max),90,rowTop+rowHeight-10,p);}
    }
    int footerY=rendered.getHeight()-100;
    p.setColor(Color.rgb(255,190,40)); p.setTextSize(26); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("DESEMPENHO DO TREINO",70,footerY-26,p);
    int pct=target>0?Math.round(inside*100f/target):0;
    p.setColor(Color.rgb(32,60,73)); c.drawRoundRect(70,footerY,850,footerY+22,11,11,p);
    p.setColor(Color.rgb(40,210,100)); c.drawRoundRect(70,footerY,70+780*pct/100f,footerY+22,11,11,p);
    p.setColor(Color.rgb(40,220,120)); p.setTextSize(42); c.drawText(target>0?pct+"%":"—",880,footerY+27,p);
    p.setColor(Color.rgb(170,190,202)); p.setTypeface(Typeface.DEFAULT); p.setTextSize(18);
    c.drawText(inside+" no alvo  ·  "+slower+" mais lentos  ·  "+faster+" mais rápidos",70,footerY+58,p);
  }

  private void drawMinimal(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(34); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("PACE COACH",70,220,p);
    p.setColor(Color.rgb(80,170,255)); p.setTextSize(110); c.drawText(formatDistance(data.distance),70,430,p);
    p.setColor(Color.WHITE); p.setTextSize(58); c.drawText(formatPace(data.distance,data.time),70,535,p);
    p.setColor(Color.LTGRAY); p.setTextSize(30); c.drawText(formatTime(data.time),70,595,p);
    p.setColor(Color.rgb(80,170,255)); c.drawRoundRect(70,690,1010,700,5,5,p);
    p.setColor(Color.LTGRAY); p.setTextSize(26); c.drawText(data.name,70,780,p);
  }

  private void drawSplits(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(46); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("Parciais", 70, 270, p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(25); p.setColor(Color.LTGRAY);
    c.drawText("Segmentos registrados nesta atividade", 70, 315, p);
    if (blocks.isEmpty()) { c.drawText("Sem parciais registradas", 70, 410, p); return; }
    int top=380, bottom=rendered.getHeight()-120;
    int rh=Math.max(36,Math.min(88,(bottom-top)/blocks.size()));
    for(int i=0;i<blocks.size();i++) {
      ContentValues b=blocks.get(i); int y=top+i*rh;
      double d=getDouble(b,DB.LAP.DISTANCE); long t=getLong(b,DB.LAP.TIME);
      double pace=d>0&&t>0?t*1000.0/d:0;
      p.setColor(Color.rgb(25,43,55)); c.drawRoundRect(new RectF(65,y,1015,y+rh-5),12,12,p);
      p.setColor(Color.WHITE); p.setTextSize(rh<55?20:27); p.setTypeface(Typeface.DEFAULT_BOLD);
      c.drawText(String.valueOf(i+1),85,y+rh*0.62f,p);
      p.setTypeface(Typeface.DEFAULT); c.drawText(formatDistance(d),155,y+rh*0.62f,p);
      c.drawText(formatTime(t),470,y+rh*0.62f,p);
      c.drawText(pace>0?formatPace(pace):"—",740,y+rh*0.62f,p);
    }
  }

  private void drawMetricTiles(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(46); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(data.name,70,270,p);
    tile(c,p,"DISTÂNCIA",formatDistance(data.distance),70,350,490,570,Color.rgb(35,155,240));
    tile(c,p,"TEMPO TOTAL",formatTime(data.time),535,350,1010,570,Color.rgb(0,190,220));
    tile(c,p,"RITMO MÉDIO",formatPace(data.distance,data.time),70,610,490,830,Color.rgb(30,210,130));
    tile(c,p,"ELEVAÇÃO",data.elevation>0?formatNumber(data.elevation)+" m":"—",535,610,1010,830,Color.rgb(100,190,230));
    tile(c,p,"FC MÉDIA",data.avgHr>0?data.avgHr+" bpm":"—",70,870,490,1090,Color.rgb(245,90,105));
    tile(c,p,"CADÊNCIA",data.avgCadence>0?formatNumber(data.avgCadence)+" ppm":"—",535,870,1010,1090,Color.rgb(170,120,255));
  }

  private void tile(Canvas c,Paint p,String label,String value,float l,float t,float r,float b,int accent) {
    p.setColor(Color.argb(220,13,27,38)); c.drawRoundRect(new RectF(l,t,r,b),28,28,p);
    p.setColor(accent); c.drawRoundRect(l,t,l+9,b,5,5,p);
    p.setColor(Color.LTGRAY); p.setTextSize(23); p.setTypeface(Typeface.DEFAULT); c.drawText(label,l+28,t+52,p);
    p.setColor(Color.WHITE); p.setTextSize(48); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(value,l+28,t+125,p);
  }

  private void drawHero(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(38); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("Pace Coach",70,130,p);
    p.setTextSize(54); c.drawText(data.name,70,245,p);
    p.setColor(Color.rgb(255,145,30)); c.drawRoundRect(70,285,1010,300,7,7,p);
    p.setColor(Color.WHITE); p.setTextSize(160); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(formatDistance(data.distance).replace(" km", ""),70,600,p);
    p.setTextSize(52); c.drawText(data.distance>=1000?"KM":"METROS",80,665,p);
    stat(c,p,"TEMPO",formatTime(data.time),70,870);
    stat(c,p,"RITMO MÉDIO",formatPace(data.distance,data.time),560,870);
    stat(c,p,"ELEVAÇÃO",data.elevation>0?formatNumber(data.elevation)+" m":"—",70,1110);
    p.setColor(Color.LTGRAY); p.setTextSize(22); c.drawText(new SimpleDateFormat("dd MMM yyyy · HH:mm",Locale.getDefault()).format(new Date(data.startTime*1000L)),560,1175,p);
  }

  private void drawElevation(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(46); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("Perfil de elevação",70,270,p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(26); p.setColor(Color.LTGRAY);
    c.drawText(data.elevation>0?"Ganho acumulado: "+formatNumber(data.elevation)+" m":"Dados de altitude indisponíveis",70,325,p);
    float x=75,y=410,w=930,h=590;
    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.rgb(35,75,90));
    for(int i=0;i<5;i++) c.drawLine(x,y+i*h/4f,x+w,y+i*h/4f,p);
    double min=Double.MAX_VALUE,max=-Double.MAX_VALUE; int count=0;
    for(double[] pt:data.route) if(pt.length>2&&!Double.isNaN(pt[2])) {min=Math.min(min,pt[2]);max=Math.max(max,pt[2]);count++;}
    if(count>=2&&max>min) {
      Path path=new Path(); boolean first=true; int valid=0;
      for(int i=0;i<data.route.size();i++){double[] pt=data.route.get(i);if(pt.length<=2||Double.isNaN(pt[2]))continue;float xx=x+(w*valid/(float)Math.max(1,count-1));float yy=y+h-(float)((pt[2]-min)/(max-min))*h;if(first){path.moveTo(xx,yy);first=false;}else path.lineTo(xx,yy);valid++;}
      p.setColor(Color.rgb(40,220,135));p.setStrokeWidth(8);c.drawPath(path,p);
      p.setStyle(Paint.Style.FILL);p.setColor(Color.LTGRAY);p.setTextSize(23);c.drawText(formatNumber(min)+" m",75,1035,p);c.drawText(formatNumber(max)+" m",75,385,p);
    } else {
      p.setStyle(Paint.Style.FILL);p.setColor(Color.LTGRAY);p.setTextSize(28);c.drawText("Esta atividade não possui pontos de altitude suficientes.",70,570,p);
    }
    stat(c,p,"DISTÂNCIA",formatDistance(data.distance),70,1130);
    stat(c,p,"TEMPO",formatTime(data.time),560,1130);
  }

  private void drawOverlay(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(48); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(data.name,70,260,p);
    p.setColor(Color.rgb(80,170,255)); p.setStrokeWidth(8); c.drawRoundRect(70,290,1010,300,5,5,p);
    stat(c,p,"DISTÂNCIA",formatDistance(data.distance),70,430);
    stat(c,p,"TEMPO",formatTime(data.time),560,430);
    stat(c,p,"RITMO MÉDIO",formatPace(data.distance,data.time),70,690);
    stat(c,p,"ELEVAÇÃO",data.elevation>0?formatNumber(data.elevation)+" m":"—",560,690);
    p.setColor(Color.WHITE); p.setTextSize(26); p.setTypeface(Typeface.DEFAULT); c.drawText("Pace Coach",70,1120,p);
  }

  private int blockColor(int intensity) {
    Intensity type = Intensity.valueOf(intensity);
    if (type == Intensity.WARMUP) return Color.rgb(255,138,0);
    if (type == Intensity.RECOVERY) return Color.rgb(176,108,255);
    if (type == Intensity.RESTING) return Color.rgb(0,199,217);
    if (type == Intensity.COOLDOWN) return Color.rgb(92,107,192);
    return Color.rgb(45,155,240);
  }

  private String blockTitle(int intensity) {
    Intensity type = Intensity.valueOf(intensity);
    if (type == Intensity.WARMUP) return "Aquecimento";
    if (type == Intensity.RECOVERY) return "Recuperação";
    if (type == Intensity.RESTING) return "Descanso Off";
    if (type == Intensity.COOLDOWN) return "Desaquecimento";
    return "Intervalo";
  }

  private double getTarget(ContentValues b, String preferred, String legacy) {
    double v = b.containsKey(preferred) ? b.getAsDouble(preferred) * 1000.0 : 0;
    if (v > 0) return v;
    return b.containsKey(legacy) ? b.getAsDouble(legacy) * 1000.0 : 0;
  }

  private double getDouble(ContentValues b, String key) { return b.containsKey(key) ? b.getAsDouble(key) : 0; }
  private long getLong(ContentValues b, String key) { return b.containsKey(key) ? b.getAsLong(key) : 0; }
  private int getInt(ContentValues b, String key, int fallback) { return b.containsKey(key) ? b.getAsInteger(key) : fallback; }
  private String formatPace(double sec) { if (sec<=0) return "—"; long s=Math.round(sec); return String.format(Locale.getDefault(),"%d:%02d/km",s/60,s%60); }
  private String formatRange(double min,double max) { return Math.abs(min-max)<0.5 ? formatPace(min) : formatPace(min).replace("/km","")+" – "+formatPace(max).replace("/km",""); }

  private void drawSummary(Canvas c, Paint p) {
    // Approved vertical summary model: transparent canvas, brand, title, gradient rail,
    // and three stacked metric rows. No opaque panel that would hide a photo underneath.
    p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(7); p.setColor(Color.WHITE);
    c.drawCircle(83,72,12,p); p.setStrokeWidth(9);
    c.drawLine(82,88,66,111,p); c.drawLine(82,89,105,97,p); c.drawLine(70,108,53,127,p); c.drawLine(71,108,91,126,p);
    p.setStyle(Paint.Style.FILL); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(39); p.setColor(Color.WHITE);
    c.drawText("Pace Coach",115,88,p);

    String title=safe(data.name,"Corrida");
    p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(52); p.setColor(Color.WHITE);
    while(title.length()>4&&p.measureText(title)>900) title=title.substring(0,title.length()-1);
    c.drawText(title,70,185,p);
    p.setShader(new LinearGradient(70,215,1010,215,new int[]{Color.rgb(255,205,30),Color.rgb(255,132,30),Color.rgb(245,65,75)},null,Shader.TileMode.CLAMP));
    c.drawRoundRect(70,205,1010,219,7,7,p); p.setShader(null);

    String[] labels={"DISTÂNCIA","TEMPO","RITMO MÉDIO"};
    String[] values={formatDistance(data.distance),formatTime(data.time),formatPace(data.distance,data.time)};
    int[] colors={Color.rgb(255,112,28),Color.rgb(0,172,245),Color.rgb(30,220,125)};
    int[] baselines={345,555,765};
    for(int i=0;i<3;i++) {
      int cy=baselines[i]-37; p.setColor(Color.argb(48,255,255,255)); c.drawRoundRect(new RectF(62,cy-45,145,cy+42),19,19,p);
      p.setColor(colors[i]); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(8);
      if(i==0) { c.drawCircle(103,cy-5,20,p); c.drawLine(90,cy+10,113,cy-15,p); }
      else if(i==1) { c.drawCircle(103,cy-5,23,p); c.drawLine(103,cy-5,103,cy-20,p); c.drawLine(103,cy-5,117,cy+2,p); }
      else { c.drawArc(new RectF(80,cy-28,126,cy+18),180,180,false,p); c.drawLine(103,cy-5,116,cy-18,p); }
      p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setTypeface(Typeface.DEFAULT); p.setTextSize(26); c.drawText(labels[i],165,baselines[i]-48,p);
      p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(values[i].length()>9?61:74); c.drawText(values[i],165,baselines[i]+28,p);
    }
    p.setColor(Color.rgb(165,184,198)); p.setTypeface(Typeface.DEFAULT); p.setTextSize(22);
    String date=new SimpleDateFormat("dd MMM yyyy · HH:mm",Locale.getDefault()).format(new Date(data.startTime*1000L));
    c.drawText(date,70,925,p);
    p.setColor(Color.rgb(255,255,255)); p.setTextSize(21); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("Pace Coach",70,1000,p);
  }

  private void drawStats(Canvas c, Paint p) {
    p.setColor(Color.WHITE); p.setTextSize(44); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("Estatísticas", 70, 230, p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(22); p.setColor(Color.rgb(153,174,188));
    c.drawText(data.name == null ? "Atividade registrada" : data.name, 70, 270, p);

    // Compact three-column metrics row, matching the approved analytical card.
    metricColumn(c,p,"DISTÂNCIA",formatDistance(data.distance),70,320,Color.rgb(45,165,245));
    metricColumn(c,p,"TEMPO TOTAL",formatTime(data.time),390,320,Color.rgb(0,190,220));
    metricColumn(c,p,"RITMO MÉDIO",formatPace(data.distance,data.time),710,320,Color.rgb(40,215,135));
    p.setColor(Color.rgb(28,57,72)); p.setStrokeWidth(2); p.setStyle(Paint.Style.STROKE);
    c.drawLine(365,300,365,430,p); c.drawLine(685,300,685,430,p); p.setStyle(Paint.Style.FILL);

    p.setColor(Color.WHITE); p.setTextSize(26); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("GRÁFICO DE RITMO",70,490,p);
    drawChartFrame(c,p,70,515,940,285);
    drawSimplePaceGraph(c,p,70,515,940,285);
    p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(80,170,255)); p.setTextSize(21);
    c.drawText("Ritmo médio  " + formatPace(data.distance,data.time),735,545,p);
    p.setColor(Color.WHITE); p.setTextSize(26); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("GRÁFICO DE ELEVAÇÃO",70,875,p);
    drawChartFrame(c,p,70,900,940,250);
    drawElevationGraph(c,p,70,900,940,250);
    p.setColor(Color.rgb(155,178,193)); p.setTypeface(Typeface.DEFAULT); p.setTextSize(20);
    c.drawText("0 km",70,1180,p); c.drawText(formatDistance(data.distance),900,1180,p);
    p.setColor(Color.rgb(80,170,255)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(23);
    c.drawText("ELEVAÇÃO ACUMULADA  " + (data.elevation>0?formatNumber(data.elevation)+" m":"—"),70,1240,p);
  }

  private void metricColumn(Canvas c, Paint p, String label, String value, float x, float y, int accent) {
    p.setColor(accent); c.drawCircle(x+8,y+1,7,p);
    p.setColor(Color.rgb(170,190,203)); p.setTextSize(19); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText(label,x+25,y+7,p);
    p.setColor(Color.WHITE); p.setTextSize(value.length()>9?29:36); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText(value,x,y+58,p);
  }

  private void drawChartFrame(Canvas c, Paint p, float x, float y, float w, float h) {
    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.rgb(34,68,86));
    for(int i=0;i<5;i++) c.drawLine(x,y+i*h/4f,x+w,y+i*h/4f,p);
    for(int i=0;i<6;i++) c.drawLine(x+i*w/5f,y,x+i*w/5f,y+h,p);
    p.setStyle(Paint.Style.FILL);
  }

  private void drawElevationGraph(Canvas c, Paint p, float x, float y, float w, float h) {
    ArrayList<double[]> points = new ArrayList<>();
    double min=Double.MAX_VALUE,max=-Double.MAX_VALUE;
    for(double[] pt:data.route) if(pt.length>2&&!Double.isNaN(pt[2])) {points.add(pt);min=Math.min(min,pt[2]);max=Math.max(max,pt[2]);}
    if(points.size()<2 || max-min<0.5) {
      p.setColor(Color.rgb(130,155,169)); p.setTextSize(22); p.setTypeface(Typeface.DEFAULT);
      c.drawText("Sem dados de altitude suficientes",x+20,y+h/2f,p); return;
    }
    Path area=new Path(), line=new Path();
    for(int i=0;i<points.size();i++) {
      double[] pt=points.get(i); float xx=x+w*i/(float)(points.size()-1);
      float yy=y+h-(float)((pt[2]-min)/(max-min))*h;
      if(i==0){line.moveTo(xx,yy);area.moveTo(xx,y+h);area.lineTo(xx,yy);} else {line.lineTo(xx,yy);area.lineTo(xx,yy);}
    }
    area.lineTo(x+w,y+h); area.close();
    p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(65,40,220,135)); c.drawPath(area,p);
    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(7); p.setColor(Color.rgb(40,220,135)); c.drawPath(line,p);
    p.setStyle(Paint.Style.FILL);
    p.setColor(Color.rgb(165,190,202)); p.setTextSize(18);
    c.drawText(formatNumber(max)+" m",x+8,y+24,p); c.drawText(formatNumber(min)+" m",x+8,y+h-8,p);
  }

  private void drawPace(Canvas c, Paint p) {
    // Approved pace-first composition: one large pace value, detailed graph, compact footer.
    p.setColor(Color.WHITE); p.setTextSize(44); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("Ritmo da corrida",70,235,p);
    p.setTypeface(Typeface.DEFAULT); p.setTextSize(23); p.setColor(Color.rgb(165,185,199));
    c.drawText("RITMO MÉDIO",70,315,p);
    p.setColor(Color.WHITE); p.setTextSize(94); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText(formatPace(data.distance,data.time),70,415,p);
    p.setColor(Color.rgb(80,170,255)); p.setTextSize(22); p.setTypeface(Typeface.DEFAULT);
    c.drawText("min/km",75,455,p);
    drawChartFrame(c,p,70,500,940,430);
    drawSimplePaceGraph(c,p,70,500,940,430);
    p.setColor(Color.rgb(155,178,193)); p.setTextSize(20);
    p.setColor(Color.rgb(22,42,56)); c.drawRoundRect(new RectF(60,1000,1020,1190),24,24,p);
    metricColumn(c,p,"DISTÂNCIA",formatDistance(data.distance),90,1060,Color.rgb(45,165,245));
    metricColumn(c,p,"TEMPO",formatTime(data.time),405,1060,Color.rgb(0,190,220));
    metricColumn(c,p,"RITMO ALVO","—",720,1060,Color.rgb(40,215,135));
    p.setColor(Color.rgb(80,170,255)); p.setTextSize(20); p.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("PACE COACH  ·  ANÁLISE DE RITMO",70,1250,p);
  }

  private void drawMap(Canvas c, Paint p) {
    // Transparent route card matching the approved reference: no invented street grid.
    // Keep geographic proportions and place the route above a compact 3-metric footer.
    p.setStyle(Paint.Style.FILL);
    p.setColor(Color.WHITE); p.setTextSize(43); p.setTypeface(Typeface.DEFAULT_BOLD);
    String title = safe(data.name, "Corrida");
    while (title.length() > 4 && p.measureText(title) > 900) title = title.substring(0, title.length()-1);
    c.drawText(title, 70, 205, p);

    RectF routeArea = new RectF(75, 245, 1005, 925);
    if (data.route.size() >= 2) {
      double minLat=Double.MAX_VALUE,maxLat=-Double.MAX_VALUE,minLon=Double.MAX_VALUE,maxLon=-Double.MAX_VALUE;
      for (double[] pt:data.route) { minLat=Math.min(minLat,pt[0]); maxLat=Math.max(maxLat,pt[0]); minLon=Math.min(minLon,pt[1]); maxLon=Math.max(maxLon,pt[1]); }
      double latSpan=Math.max(0.00001,maxLat-minLat), lonSpan=Math.max(0.00001,maxLon-minLon);
      // Correct for longitude's latitude-dependent scale; fit without stretching the route.
      double meanLat=(minLat+maxLat)/2d;
      double geoW=lonSpan*Math.max(0.15,Math.cos(Math.toRadians(meanLat)));
      double geoH=latSpan;
      double scale=Math.min((routeArea.width()-70)/geoW,(routeArea.height()-70)/geoH);
      float drawnW=(float)(geoW*scale), drawnH=(float)(geoH*scale);
      float left=routeArea.centerX()-drawnW/2f, top=routeArea.centerY()-drawnH/2f;
      ArrayList<float[]> points=new ArrayList<>();
      for(double[] pt:data.route) {
        float xx=left+(float)((pt[1]-minLon)*Math.max(0.15,Math.cos(Math.toRadians(meanLat)))*scale);
        float yy=top+drawnH-(float)((pt[0]-minLat)*scale);
        points.add(new float[]{xx,yy});
      }
      p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
      p.setStrokeWidth(25); p.setColor(Color.argb(105,0,0,0));
      Path shadow=new Path(); shadow.moveTo(points.get(0)[0],points.get(0)[1]);
      for(int i=1;i<points.size();i++) shadow.lineTo(points.get(i)[0],points.get(i)[1]); c.drawPath(shadow,p);
      double avg=data.distance>0&&data.time>0?data.time*1000d/data.distance:420d;
      for(int i=1;i<points.size();i++) {
        float[] a=points.get(i-1),b=points.get(i); double[] prev=data.route.get(i-1),cur=data.route.get(i);
        double meters=distanceMeters(prev[0],prev[1],cur[0],cur[1]);
        double seconds=(cur[3]-prev[3])/1000d; double pace=meters>0&&seconds>0?seconds*1000d/meters:avg;
        int color=pace<avg-15?Color.rgb(35,220,105):(pace>avg+20?Color.rgb(255,80,65):Color.rgb(255,205,35));
        p.setColor(color); p.setStrokeWidth(15); c.drawLine(a[0],a[1],b[0],b[1],p);
      }
      p.setStyle(Paint.Style.FILL); float[] first=points.get(0),last=points.get(points.size()-1);
      p.setColor(Color.WHITE); c.drawCircle(first[0],first[1],21,p); p.setColor(Color.rgb(255,140,20)); c.drawCircle(first[0],first[1],14,p);
      p.setColor(Color.WHITE); c.drawCircle(last[0],last[1],21,p); p.setColor(Color.rgb(20,35,45)); c.drawCircle(last[0],last[1],14,p);
    } else {
      p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(190,205,215)); p.setTextSize(27); p.setTypeface(Typeface.DEFAULT);
      c.drawText("Percurso GPS indisponível", 235, 570, p);
    }

    // Rounded translucent footer strip, as in the approved map card.
    p.setColor(Color.argb(238,13,24,32)); c.drawRoundRect(new RectF(65,970,1015,1170),30,30,p);
    float[] centers={220,540,860};
    String[] values={formatDistance(data.distance),formatTime(data.time),formatPace(data.distance,data.time)};
    String[] labels={"km","tempo","/km"};
    int[] accents={Color.rgb(255,112,28),Color.rgb(0,190,225),Color.rgb(40,220,130)};
    for(int i=0;i<3;i++) {
      float cx=centers[i]; p.setColor(accents[i]); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(7);
      if(i==0) { c.drawCircle(cx-65,1035,20,p); c.drawLine(cx-75,1044,cx-57,1025,p); }
      else if(i==1) { c.drawCircle(cx-65,1035,20,p); c.drawLine(cx-65,1035,cx-65,1022,p); c.drawLine(cx-65,1035,cx-54,1041,p); }
      else { c.drawArc(new RectF(cx-87,1015,cx-43,1059),180,180,false,p); c.drawLine(cx-65,1037,cx-52,1024,p); }
      p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(values[i].length()>8?28:35);
      c.drawText(values[i],cx-30,1038,p);
      p.setTypeface(Typeface.DEFAULT); p.setTextSize(20); p.setColor(Color.rgb(195,208,218)); c.drawText(labels[i],cx-28,1070,p);
    }
    p.setColor(Color.rgb(205,220,230)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(22);
    c.drawText("Pace Coach",70,1230,p);
  }

  private void drawSimplePaceGraph(Canvas c, Paint p, float x, float y, float w, float h) {
    // Pace scale is fixed to 4:00–9:00 min/km; labels and plotted values share this scale.
    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.rgb(39,67,83));
    for(int i=0;i<5;i++) { float yy=y+i*h/4f; c.drawLine(x,yy,x+w,yy,p); }
    for(int i=0;i<6;i++) { float xx=x+i*w/5f; c.drawLine(xx,y,xx,y+h,p); }
    p.setStyle(Paint.Style.FILL); p.setTypeface(Typeface.DEFAULT); p.setTextSize(18); p.setColor(Color.rgb(156,178,192));
    String[] paceTicks={"4:00","5:15","6:30","7:45","9:00"};
    for(int i=0;i<paceTicks.length;i++) c.drawText(paceTicks[i],x+5,y+i*h/4f+20,p);
    for(int i=0;i<=5;i++) {
      String km=String.format(Locale.getDefault(),"%.0f",(data.distance/1000d)*i/5d);
      c.drawText(km,x+i*w/5f-p.measureText(km)/2f,y+h+26,p);
    }
    double avgPace=data.distance>0&&data.time>0?data.time*1000d/data.distance:420d;
    float avgY=y+(float)((Math.max(240,Math.min(540,avgPace))-240)/300d*h);
    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(Color.rgb(45,174,230));
    for(float xx=x;xx<x+w;xx+=20) c.drawLine(xx,avgY,Math.min(xx+10,x+w),avgY,p);
    if(data.route.size()>=2) {
      ArrayList<double[]> samples=new ArrayList<>(); double total=0; double[] prev=data.route.get(0);
      for(int i=1;i<data.route.size();i++) {
        double[] cur=data.route.get(i); double meters=distanceMeters(prev[0],prev[1],cur[0],cur[1]);
        double seconds=(cur[3]-prev[3])/1000d;
        if(meters>=2&&seconds>0&&seconds<120) { total+=meters; samples.add(new double[]{total,seconds*1000d/meters}); }
        prev=cur;
      }
      if(!samples.isEmpty()&&total>0) {
        p.setColor(Color.rgb(60,190,255)); p.setStrokeWidth(8); Path path=new Path(); boolean first=true;
        for(double[] sample:samples) {
          float xx=x+(float)(sample[0]/Math.max(total,data.distance)*w);
          double pace=Math.max(240,Math.min(540,sample[1])); float yy=y+(float)((pace-240)/300d*h);
          if(first){path.moveTo(xx,yy);first=false;}else path.lineTo(xx,yy);
        }
        c.drawPath(path,p);
      }
    }
    p.setStyle(Paint.Style.FILL);
  }

  private double distanceMeters(double lat1,double lon1,double lat2,double lon2) {
    double dLat=Math.toRadians(lat2-lat1),dLon=Math.toRadians(lon2-lon1);
    double a=Math.sin(dLat/2)*Math.sin(dLat/2)+Math.cos(Math.toRadians(lat1))*Math.cos(Math.toRadians(lat2))*Math.sin(dLon/2)*Math.sin(dLon/2);
    return 6371000d*2*Math.atan2(Math.sqrt(a),Math.sqrt(Math.max(0,1-a)));
  }

  private void stat(Canvas c, Paint p, String label, String value, float x, float y) {
    p.setColor(Color.rgb(150,160,165)); p.setTextSize(24); p.setTypeface(Typeface.DEFAULT); c.drawText(label.toUpperCase(Locale.getDefault()),x,y,p);
    p.setColor(Color.WHITE); p.setTextSize(56); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(value,x,y+65,p);
  }

  private ActivityData loadActivity(long id) {
    SQLiteDatabase db=DBHelper.getReadableDatabase(this);
    ActivityData d=new ActivityData();
    Cursor c=db.query(DB.ACTIVITY.TABLE,new String[]{DB.ACTIVITY.NAME,DB.ACTIVITY.START_TIME,DB.ACTIVITY.DISTANCE,DB.ACTIVITY.TIME,DB.ACTIVITY.AVG_HR,DB.ACTIVITY.AVG_CADENCE},"_id=?",new String[]{String.valueOf(id)},null,null,null);
    if(!c.moveToFirst()){c.close();return null;}
    d.name=safe(c.getString(0),"Corrida"); d.startTime=c.getLong(1); d.distance=c.isNull(2)?0:c.getDouble(2); d.time=c.isNull(3)?0:c.getLong(3); d.avgHr=c.isNull(4)?0:c.getInt(4); d.avgCadence=c.isNull(5)?0:c.getDouble(5); c.close();
    Cursor l=db.query(DB.LOCATION.TABLE,new String[]{DB.LOCATION.LATITUDE,DB.LOCATION.LONGITUDE,DB.LOCATION.TYPE,DB.LOCATION.ALTITUDE,DB.LOCATION.TIME},DB.LOCATION.ACTIVITY+"=? AND ("+DB.LOCATION.TYPE+"=? OR "+DB.LOCATION.TYPE+"=?)",new String[]{String.valueOf(id),String.valueOf(DB.LOCATION.TYPE_GPS),String.valueOf(DB.LOCATION.TYPE_START)},null,null,DB.LOCATION.TIME+" ASC");
    double previousAltitude=Double.NaN;
    while(l.moveToNext()) { double altitude=l.isNull(3)?Double.NaN:l.getDouble(3); d.route.add(new double[]{l.getDouble(0),l.getDouble(1),altitude,l.getLong(4)}); if(!Double.isNaN(altitude)){if(!Double.isNaN(previousAltitude)&&altitude>previousAltitude&&altitude-previousAltitude<20)d.elevation+=altitude-previousAltitude;previousAltitude=altitude;} } l.close();
    Cursor bcur=db.query(DB.LAP.TABLE,new String[]{DB.LAP.INTENSITY,DB.LAP.TIME,DB.LAP.DISTANCE,DB.LAP.PLANNED_PACE,DB.LAP.PLANNED_PACE_MIN,DB.LAP.PLANNED_PACE_MAX},DB.LAP.ACTIVITY+"=?",new String[]{String.valueOf(id)},null,null,"_id ASC");
    while(bcur.moveToNext()) { ContentValues b=new ContentValues(); b.put(DB.LAP.INTENSITY,bcur.getInt(0)); b.put(DB.LAP.TIME,bcur.getLong(1)); b.put(DB.LAP.DISTANCE,bcur.getDouble(2)); if(!bcur.isNull(3)) b.put(DB.LAP.PLANNED_PACE,bcur.getDouble(3)); if(!bcur.isNull(4)) b.put(DB.LAP.PLANNED_PACE_MIN,bcur.getDouble(4)); if(!bcur.isNull(5)) b.put(DB.LAP.PLANNED_PACE_MAX,bcur.getDouble(5)); blocks.add(b); } bcur.close();
    return d;
  }

  private void shareImage() {
    try {
      File dir=new File(getCacheDir(),"share_cards"); if(!dir.exists()&&!dir.mkdirs()) throw new Exception("cache");
      String name="pacecoach_"+activityId+"_"+template+".png"; File file=new File(dir,name);
      try(FileOutputStream out=new FileOutputStream(file)){rendered.compress(Bitmap.CompressFormat.PNG,100,out);}
      Uri uri=Uri.parse("content://"+ShareImageProvider.AUTHORITY+"/"+name);
      Intent send=new Intent(Intent.ACTION_SEND); send.setType("image/png"); send.putExtra(Intent.EXTRA_STREAM,uri); send.setClipData(ClipData.newUri(getContentResolver(), data.name, uri)); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
      startActivity(Intent.createChooser(send,"Compartilhar atividade"));
    } catch(Exception e){Toast.makeText(this,"Não foi possível gerar a imagem",Toast.LENGTH_SHORT).show();}
  }

  private void copyImage() {
    try {
      File dir=new File(getCacheDir(),"share_cards"); if(!dir.exists()&&!dir.mkdirs()) throw new Exception("cache");
      String name="pacecoach_"+activityId+"_"+template+"_clipboard.png"; File file=new File(dir,name);
      try(FileOutputStream out=new FileOutputStream(file)){rendered.compress(Bitmap.CompressFormat.PNG,100,out);}
      Uri uri=Uri.parse("content://"+ShareImageProvider.AUTHORITY+"/"+name);
      ClipData clip=ClipData.newUri(getContentResolver(),data.name,uri);
      ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
      if(clipboard==null) throw new Exception("clipboard");
      clipboard.setPrimaryClip(clip);
      Toast.makeText(this,"Imagem copiada. Cole em um app compatível com imagens.",Toast.LENGTH_LONG).show();
    } catch(Exception e){Toast.makeText(this,"Não foi possível copiar a imagem",Toast.LENGTH_SHORT).show();}
  }

  private static String safe(String s,String fallback){return s==null||s.trim().isEmpty()?fallback:s.trim();}
  private static String formatDistance(double meters){return meters>=1000?String.format(Locale.getDefault(),"%.2f km",meters/1000d):String.format(Locale.getDefault(),"%.0f m",meters);}
  private static String formatTime(long seconds){long sec=Math.max(0,seconds);if(sec>=3600)return String.format(Locale.getDefault(),"%02d:%02d:%02d",sec/3600,(sec%3600)/60,sec%60);return String.format(Locale.getDefault(),"%02d:%02d",sec/60,sec%60);}
  private static String formatPace(double meters,long ms){if(meters<=0||ms<=0)return "—";double secPerKm=(ms)/(meters/1000d);int s=(int)Math.round(secPerKm);return String.format(Locale.getDefault(),"%d:%02d/km",s/60,s%60);}
  private static String formatNumber(double v){return String.format(Locale.getDefault(),"%.0f",v);}

  private static class ActivityData {String name;long startTime,time;double distance,avgCadence,elevation;int avgHr;ArrayList<double[]> route=new ArrayList<>();}
}
