/*
 * Copyright (C) 2026 Pace Coach contributors
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 */

package org.runnerup.workout.feedback;

import android.content.Context;
import java.util.HashMap;
import org.runnerup.workout.Dimension;
import org.runnerup.workout.Feedback;
import org.runnerup.workout.Scope;
import org.runnerup.workout.Workout;

/**
 * Pace Coach audio summary for the three independent announcement levels:
 * GENERAL (whole workout), INTERVAL (current step), and CURRENT (pace only).
 */
public class PaceCoachSummaryFeedback extends Feedback {
  private final Scope scope;
  private final String kind;
  private final boolean includeTime;
  private final boolean includeDistance;
  private final boolean includePace;
  private final boolean includeSpeed;
  private final boolean includeHr;
  private RUTextToSpeech textToSpeech;
  private org.runnerup.util.Formatter formatter;

  public PaceCoachSummaryFeedback(Scope scope, String kind) {
    this(scope, kind, true, true, true, false, false);
  }

  public PaceCoachSummaryFeedback(Scope scope, String kind, boolean includeTime,
      boolean includeDistance, boolean includePace, boolean includeSpeed, boolean includeHr) {
    this.scope = scope;
    this.kind = kind;
    this.includeTime = includeTime;
    this.includeDistance = includeDistance;
    this.includePace = includePace;
    this.includeSpeed = includeSpeed;
    this.includeHr = includeHr;
  }

  @Override
  public void onBind(Workout s, HashMap<String, Object> bindValues) {
    super.onBind(s, bindValues);
    if (bindValues.containsKey(Workout.KEY_TTS)) {
      textToSpeech = (RUTextToSpeech) bindValues.get(Workout.KEY_TTS);
    }
    if (bindValues.containsKey(Workout.KEY_FORMATTER)) {
      formatter = (org.runnerup.util.Formatter) bindValues.get(Workout.KEY_FORMATTER);
    }
  }

  @Override
  public boolean equals(Feedback other) {
    if (!(other instanceof PaceCoachSummaryFeedback that)) return false;
    return scope == that.scope && kind.equals(that.kind) && includeTime == that.includeTime && includeDistance == that.includeDistance && includePace == that.includePace && includeSpeed == that.includeSpeed && includeHr == that.includeHr;
  }

  @Override
  public void emit(Workout w, Context ctx) {
    if (textToSpeech == null || formatter == null) return;

    if (scope == Scope.CURRENT || "current".equals(kind)) {
      // Keep the spoken CURRENT pace identical to the Pace Coach value shown
      // on screen: active interval pace for interval workouts, otherwise
      // activity-average pace. Using raw GPS CURRENT here could announce a
      // different value from the screen (for example 16:40 vs 18:39).
      // CURRENT audio follows the same live/smoothed GPS pace used by the
      // on-screen PACE ATUAL field. This avoids speaking the activity average
      // while the display is showing the current running pace.
      double paceSpeed = w.getSpeed(Scope.CURRENT);
      if (w.getWorkoutType() != org.runnerup.common.util.Constants.WORKOUT_TYPE.BASIC
          && w.getCurrentStep() != null
          && w.getCurrentStep().getIntensity() == org.runnerup.workout.Intensity.ACTIVE) {
        double stepSpeed = w.getSpeed(Scope.STEP);
        if (stepSpeed > 0 && !Double.isNaN(stepSpeed) && !Double.isInfinite(stepSpeed)) {
          paceSpeed = stepSpeed;
        }
      }
      // CURRENT means live current pace only. Do not fall back to activity-average
      // pace while the live GPS window is not ready; speaking an invented pace
      // at the configured cadence leads to messages such as "ritmo indisponível, acelere".
      if (!(paceSpeed > 0) || Double.isNaN(paceSpeed) || Double.isInfinite(paceSpeed)) return;
      double pace = 1.0 / paceSpeed;
      if (!(pace > 0) || Double.isNaN(pace) || Double.isInfinite(pace)) return;
      StringBuilder msg = new StringBuilder("Ritmo: ").append(formatPace(pace));
      org.runnerup.workout.Step currentStep = w.getCurrentStep();
      if (currentStep != null && currentStep.getTargetType() == Dimension.PACE
          && currentStep.getTargetValue() != null) {
        org.runnerup.workout.Range target = currentStep.getTargetValue();
        // Smaller seconds/km means faster. If current pace is below the
        // fast limit, the runner is too fast and must slow down. If it is
        // above the slow limit, the runner is too slow and must accelerate.
        if (pace < target.minValue) {
          msg.append(", desacelere");
        } else if (pace > target.maxValue) {
          msg.append(", acelere");
        } else {
          msg.append(", no alvo");
        }
      }
      textToSpeech.speak(msg.toString(), UtterancePrio.PRIO_COACH, /* flush= */ true, null);
      return;
    }

    StringBuilder msg = new StringBuilder();
    appendSelected(msg, includeTime, scope == Scope.ACTIVITY ? "Tempo total: " : "Tempo: ",
        formatter.format(org.runnerup.util.Formatter.Format.CUE_LONG, Dimension.TIME, w.get(scope, Dimension.TIME)));
    appendSelected(msg, includeDistance, scope == Scope.ACTIVITY ? "Distância total: " : "Distância: ",
        formatter.format(org.runnerup.util.Formatter.Format.CUE_LONG, Dimension.DISTANCE, w.get(scope, Dimension.DISTANCE)));
    appendSelected(msg, includePace, scope == Scope.ACTIVITY ? "Ritmo médio: " : "Ritmo médio do intervalo: ",
        formatPace(w.get(scope, Dimension.PACE)));
    if (includeSpeed) appendSelected(msg, true, "Velocidade média: ",
        formatter.format(org.runnerup.util.Formatter.Format.CUE_LONG, Dimension.SPEED, w.get(scope, Dimension.SPEED)));
    if (includeHr) appendSelected(msg, true, "Frequência cardíaca média: ",
        formatter.format(org.runnerup.util.Formatter.Format.CUE_LONG, Dimension.HR, w.get(scope, Dimension.HR)));
    if (msg.length() > 0) {
      textToSpeech.speak(msg.toString(), UtterancePrio.PRIO_CUE, /* flush= */ false, null);
    }
  }

  /**
   * Format a RunnerUp pace value. Workout#getPace returns seconds per meter,
   * not meters per second. Convert that value directly to seconds per kilometer.
   *
   * Very low GPS speeds can produce meaningless multi-hour paces; those values
   * are intentionally not announced.
   */
  private static void appendSelected(StringBuilder msg, boolean enabled, String label, String value) {
    if (!enabled) return;
    if (msg.length() > 0) msg.append(". ");
    msg.append(label).append(value);
  }

  private String formatPace(double secondsPerMeter) {
    if (Double.isNaN(secondsPerMeter) || Double.isInfinite(secondsPerMeter)
        || secondsPerMeter <= 0) {
      return "indisponível";
    }

    int totalSeconds = (int) Math.round(secondsPerMeter * 1000.0);
    // Do not turn GPS drift / near-zero speed into absurd spoken paces.
    if (totalSeconds > 30 * 60) return "indisponível";

    int minutes = totalSeconds / 60;
    int seconds = totalSeconds % 60;
    return minutes + " e " + seconds;
  }
}
