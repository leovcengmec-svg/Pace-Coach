package org.runnerup.util;

/** Safety limits for route-based recomputation of an already saved activity. */
public final class ActivityRecomputeGuard {
  private static final double DISTANCE_RELATIVE_TOLERANCE = 0.25d;
  private static final double DISTANCE_ABSOLUTE_TOLERANCE_METERS = 100d;
  private static final double TIME_RELATIVE_TOLERANCE = 0.20d;
  private static final long TIME_ABSOLUTE_TOLERANCE_SECONDS = 120L;

  private ActivityRecomputeGuard() {}

  /**
   * Returns false when recomputation would change an existing official summary
   * by an amount large enough to suggest a damaged or incomplete GPS route.
   * Missing original values do not block first-time aggregation.
   */
  public static boolean isSafe(
      double savedDistanceMeters,
      long savedTimeSeconds,
      double computedDistanceMeters,
      long computedTimeSeconds) {
    boolean distanceOutlier = savedDistanceMeters > DISTANCE_ABSOLUTE_TOLERANCE_METERS
        && Math.abs(computedDistanceMeters - savedDistanceMeters)
            > Math.max(DISTANCE_ABSOLUTE_TOLERANCE_METERS,
                savedDistanceMeters * DISTANCE_RELATIVE_TOLERANCE);
    boolean timeOutlier = savedTimeSeconds > 0L
        && Math.abs(computedTimeSeconds - savedTimeSeconds)
            > Math.max(TIME_ABSOLUTE_TOLERANCE_SECONDS,
                Math.round(savedTimeSeconds * TIME_RELATIVE_TOLERANCE));
    return !distanceOutlier && !timeOutlier;
  }
}
