/*
 * Copyright (C) 2012 - 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.view;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.GradientDrawable;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.preference.PreferenceManager;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.text.SimpleDateFormat;
import java.util.Objects;
import org.runnerup.BuildConfig;
import org.runnerup.R;
import org.runnerup.common.tracker.TrackerState;
import org.runnerup.common.util.Constants;
import org.runnerup.common.util.Constants.DB;
import org.runnerup.common.util.ValueModel;
import org.runnerup.db.DBHelper;
import org.runnerup.hr.HRProvider;
import org.runnerup.hr.MockHRProvider;
import org.runnerup.notification.GpsBoundState;
import org.runnerup.notification.GpsSearchingState;
import org.runnerup.notification.NotificationManagerDisplayStrategy;
import org.runnerup.notification.NotificationStateManager;
import org.runnerup.tracker.GpsInformation;
import org.runnerup.tracker.Tracker;
import org.runnerup.tracker.component.TrackerCadence;
import org.runnerup.tracker.component.TrackerHRM;
import org.runnerup.tracker.component.TrackerWear;
import org.runnerup.util.Formatter;
import org.runnerup.util.SafeParse;
import org.runnerup.util.TickListener;
import org.runnerup.widget.SpinnerInterface.OnCloseDialogListener;
import org.runnerup.widget.SpinnerInterface.OnSetValueListener;
import org.runnerup.widget.TitleSpinner;
import org.runnerup.widget.WidgetUtil;
import org.runnerup.workout.Dimension;
import org.runnerup.workout.Workout;
import org.runnerup.workout.Workout.StepListEntry;
import org.runnerup.workout.WorkoutBuilder;
import org.runnerup.workout.WorkoutSerializer;

public class StartFragment extends Fragment implements TickListener, GpsInformation {

  private enum GpsLevel {
    NOT_FIXED,
    POOR,
    ACCEPTABLE,
    GOOD
  }

  private static final String TAB_BASIC = "basic";
  private static final String TAB_INTERVAL = "interval";
  static final String TAB_ADVANCED = "advanced";

  private boolean statusDetailsShown = false;

  // StartFragment normally stop GPS in onDestroy (or onStop)
  // but if the fragment stop as it has started a RunActivity
  // it should not!
  // TODO Figure out a way to do this prettier
  private boolean runActivityPending = false;
  // Pace Coach preview: when the user taps INICIAR TREINO, start GPS if needed and
  // launch RunActivity automatically as soon as the tracker reaches CONNECTED.
  private boolean coachStartPending = false;
  private Tracker mTracker = null;
  private org.runnerup.tracker.GpsStatus mGpsStatus = null;

  private TabHost tabHost = null;
  private View startButton = null;

  private ImageView expandIcon = null;
  private TextView noDevicesConnected = null;

  private Button gpsEnable = null;
  private ImageView gpsIndicator = null;
  private TextView gpsMessage = null;
  private LinearLayout gpsDetailRow = null;
  private ImageView gpsDetailIndicator = null;
  private TextView gpsDetailMessage = null;
  private TextView gpsHeaderDot = null;
  private TextView gpsHeaderLevel = null;
  private LinearLayout gpsHeaderBars = null;

  private View hrIndicator = null;
  private TextView hrMessage = null;

  private View wearOsIndicator = null;
  private TextView wearOsMessage = null;
  private TrackerWear.WearNotifier mWearNotifier = null;

  boolean sportWithoutGps = false;
  boolean batteryLevelMessageShown = false;

  TitleSpinner simpleTargetType = null;
  TitleSpinner simpleTargetPaceMin = null;
  TitleSpinner simpleTargetPaceValue = null;
  TitleSpinner simpleTargetTime = null;
  TitleSpinner simpleTargetDistance = null;
  TitleSpinner simpleTargetHrz = null;
  TitleSpinner simpleTargetRhythm = null;
  AudioSchemeListAdapter simpleAudioListAdapter = null;
  HRZonesListAdapter hrZonesAdapter = null;

  TitleSpinner intervalRepetitions = null;
  TitleSpinner intervalType = null;
  TitleSpinner intervalTime = null;
  TitleSpinner intervalDistance = null;
  TitleSpinner intervalPaceMin = null;
  TitleSpinner intervalPaceMax = null;
  TitleSpinner intervalRhythm = null;
  TitleSpinner intervalRestType = null;
  TitleSpinner intervalRestTime = null;
  TitleSpinner intervalRestDistance = null;
  TitleSpinner intervalRestPaceMin = null;
  TitleSpinner intervalRestPaceMax = null;
  TitleSpinner intervalRestRhythm = null;
  TitleSpinner intervalWarmupType = null;
  TitleSpinner intervalWarmupTime = null;
  TitleSpinner intervalWarmupDistance = null;
  TitleSpinner intervalWarmupPaceMin = null;
  TitleSpinner intervalWarmupPaceMax = null;
  TitleSpinner intervalWarmupRhythm = null;
  TitleSpinner intervalCooldownType = null;
  TitleSpinner intervalCooldownTime = null;
  TitleSpinner intervalCooldownDistance = null;
  TitleSpinner intervalCooldownPaceMin = null;
  TitleSpinner intervalCooldownPaceMax = null;
  TitleSpinner intervalCooldownRhythm = null;
  AudioSchemeListAdapter intervalAudioListAdapter = null;

  TitleSpinner advancedWorkoutSpinner = null;
  WorkoutListAdapter advancedWorkoutListAdapter = null;
  Workout advancedWorkout = null;
  View coachDashboard = null;
  View coachWorkspace = null;
  TextView coachWorkspaceTitle = null;
  TextView coachWorkspaceSubtitle = null;
  private TextView coachPeriodWorkouts = null;
  private TextView coachPeriodDistance = null;
  private TextView coachPeriodTime = null;
  private TextView coachPeriodPace = null;
  private TextView coachChartPeriod = null;
  private TextView coachChartTotal = null;
  private LinearLayout coachChart = null;
  private LinearLayout coachAchievements = null;
  private LinearLayout coachRecentList = null;
  private String coachSelectedPeriod = "day";
  ListView advancedStepList = null;
  final WorkoutStepsAdapter advancedWorkoutStepsAdapter = new WorkoutStepsAdapter();

  SQLiteDatabase mDB = null;

  Formatter formatter = null;
  private NotificationStateManager notificationStateManager;
  private GpsSearchingState gpsSearchingState;
  private GpsBoundState gpsBoundState;
  // Id to identify a permission request.
  // Note that the result is not used, the user is dropped back to initial view when a request is
  // done.
  private static final int REQUEST_LOCATION = 3000;
  private static final int START_ACTIVITY = 112;

  private final SharedPreferences.OnSharedPreferenceChangeListener prefChangeListener =
      (sharedPrefs, key) -> {
        assert key != null;
        if (key.equals(getString(R.string.pref_advanced_workout))) {
          String newName = sharedPrefs.getString(key, "");
          if (!newName.isEmpty()) {
            loadAdvanced(newName);
            if (advancedWorkoutSpinner != null) {
              advancedWorkoutSpinner.setValue(newName);
            }
            if (advancedWorkoutListAdapter != null) {
              advancedWorkoutListAdapter.reload();
            }
          }
        }
      };

  public StartFragment() {
    super(R.layout.start);
  }

  @Override
  public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);

    AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);

    Context context = requireContext();
    mDB = DBHelper.getWritableDatabase(context);
    formatter = new Formatter(context);

    bindGpsTracker();
    mGpsStatus = new org.runnerup.tracker.GpsStatus(context);
    NotificationManager notificationManager =
        ContextCompat.getSystemService(context, NotificationManager.class);
    notificationStateManager =
        new NotificationStateManager(new NotificationManagerDisplayStrategy(notificationManager));
    gpsSearchingState = new GpsSearchingState(context, this);
    gpsBoundState = new GpsBoundState(context);

    // Pace Coach is a running-only app: keep the activity sport fixed to Running.
    PreferenceManager.getDefaultSharedPreferences(context)
        .edit()
        .putInt(getString(R.string.pref_sport), DB.ACTIVITY.SPORT_RUNNING)
        .apply();

    startButton = view.findViewById(R.id.start_button);
    startButton.setOnClickListener(startButtonClick);

    expandIcon = view.findViewById(R.id.expand_icon);
    noDevicesConnected = view.findViewById(R.id.device_status);

    gpsIndicator = view.findViewById(R.id.gps_indicator);
    gpsMessage = view.findViewById(R.id.gps_message);
    gpsDetailRow = view.findViewById(R.id.gps_detail_row);
    gpsDetailIndicator = view.findViewById(R.id.gps_detail_indicator);
    gpsDetailMessage = view.findViewById(R.id.gps_detail_message);
    gpsHeaderDot = view.findViewById(R.id.gps_header_dot);
    gpsHeaderLevel = view.findViewById(R.id.gps_header_level);
    gpsHeaderBars = view.findViewById(R.id.gps_header_bars);
    View gpsHeaderStatus = view.findViewById(R.id.gps_header_status);
    if (gpsHeaderStatus != null) {
      gpsHeaderStatus.setOnClickListener(v -> requestGpsPermissionsFromDashboard());
    }

    gpsEnable = view.findViewById(R.id.gps_enable_button);
    gpsEnable.setOnClickListener(gpsEnableClick);

    hrMessage = view.findViewById(R.id.hr_message);
    hrIndicator = view.findViewById(R.id.hr_indicator);

    wearOsIndicator = view.findViewById(R.id.wearos_indicator);
    wearOsMessage = view.findViewById(R.id.wearos_message);

    // Pace Coach home/workspaces do not display the legacy GPS status bar.
    View legacyStatusLayout = view.findViewById(R.id.status_layout);
    if (legacyStatusLayout != null) {
      legacyStatusLayout.setVisibility(View.GONE);
      legacyStatusLayout.setOnClickListener(null);
    }

    // TODO: Replace TabHost with ViewPager2 and TabLayout
    tabHost = view.findViewById(R.id.tabhost_start);
    tabHost.setup();
    TabSpec tabSpec = tabHost.newTabSpec(TAB_BASIC);
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(context, getString(org.runnerup.common.R.string.Basic)));
    tabSpec.setContent(R.id.start_basic_tab);
    tabHost.addTab(tabSpec);

    tabSpec = tabHost.newTabSpec(TAB_INTERVAL);
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(
            context, getString(org.runnerup.common.R.string.Interval)));
    tabSpec.setContent(R.id.start_interval_tab);
    tabHost.addTab(tabSpec);

    tabSpec = tabHost.newTabSpec(TAB_ADVANCED);
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(
            context, getString(org.runnerup.common.R.string.Advanced)));
    tabSpec.setContent(R.id.start_advanced_tab);
    tabHost.addTab(tabSpec);

    tabHost.setOnTabChangedListener(onTabChangeListener);

    // Pace Coach home: keep the dashboard clean and open each mode in its own workspace.
    coachDashboard = view.findViewById(R.id.coach_dashboard);
    coachWorkspace = view.findViewById(R.id.coach_workspace);
    coachWorkspaceTitle = view.findViewById(R.id.coach_workspace_title);
    coachWorkspaceSubtitle = view.findViewById(R.id.coach_workspace_subtitle);
    coachPeriodWorkouts = view.findViewById(R.id.coach_period_workouts);
    coachPeriodDistance = view.findViewById(R.id.coach_period_distance);
    coachPeriodTime = view.findViewById(R.id.coach_period_time);
    coachPeriodPace = view.findViewById(R.id.coach_period_pace);
    coachChartPeriod = view.findViewById(R.id.coach_chart_period);
    coachChartTotal = view.findViewById(R.id.coach_chart_total);
    coachChart = view.findViewById(R.id.coach_chart);
    coachAchievements = view.findViewById(R.id.coach_achievements);
    coachRecentList = view.findViewById(R.id.coach_recent_list);
    setupCoachPeriodSelector(view);
    view.findViewById(R.id.coach_card_free).setOnClickListener(v -> openCoachWorkspace(TAB_BASIC, "Treino Livre"));
    view.findViewById(R.id.coach_card_interval).setOnClickListener(v -> openCoachWorkspace(TAB_INTERVAL, "Treino Intervalado"));
    view.findViewById(R.id.coach_card_workout).setOnClickListener(v -> openCoachWorkspace(TAB_ADVANCED, "Treino Estruturado"));
    View historyCard = view.findViewById(R.id.coach_history_card);
    View.OnClickListener openHistory = v -> {
      if (getActivity() instanceof MainLayout) {
        ((MainLayout) getActivity()).navigateToPage(1);
      }
    };
    if (historyCard != null) historyCard.setOnClickListener(openHistory);
    View achievementsMore = view.findViewById(R.id.coach_achievements_more);
    if (achievementsMore != null) achievementsMore.setOnClickListener(openHistory);
    View recentMore = view.findViewById(R.id.coach_recent_more);
    if (recentMore != null) recentMore.setOnClickListener(openHistory);
    view.findViewById(R.id.coach_back_button).setOnClickListener(v -> closeCoachWorkspace());

    // Pace Coach structured-workout preview actions. The preview uses the existing RunnerUp
    // workout/tracker engine; these buttons only provide the modern entry points.
    view.findViewById(R.id.advanced_preview_start).setOnClickListener(v -> startCoachWorkout());
    view.findViewById(R.id.advanced_preview_edit).setOnClickListener(v -> openCurrentAdvancedWorkoutForEdit());
    view.findViewById(R.id.basic_preview_edit).setOnClickListener(v -> openBasicEditor());
    view.findViewById(R.id.basic_editor_save).setOnClickListener(v -> saveBasicEditor());
    view.findViewById(R.id.interval_preview_edit).setOnClickListener(v -> openIntervalEditor());
    view.findViewById(R.id.interval_editor_save).setOnClickListener(v -> saveIntervalEditor());

    // tabHost.getTabWidget().setBackgroundColor(Color.DKGRAY);

    LayoutInflater inflater = getLayoutInflater();
    simpleAudioListAdapter = new AudioSchemeListAdapter(mDB, inflater, false);
    simpleAudioListAdapter.reload();
    simpleTargetType = view.findViewById(R.id.tab_basic_target_type);
    simpleTargetPaceMin = view.findViewById(R.id.tab_basic_target_pace_min);
    simpleTargetPaceValue = view.findViewById(R.id.tab_basic_target_pace_max);
    simpleTargetTime = view.findViewById(R.id.tab_basic_target_time);
    simpleTargetDistance = view.findViewById(R.id.tab_basic_target_distance);
    hrZonesAdapter = new HRZonesListAdapter(context, inflater);
    simpleTargetHrz = view.findViewById(R.id.tab_basic_target_hrz);
    simpleTargetHrz.setAdapter(hrZonesAdapter);
    simpleTargetRhythm = view.findViewById(R.id.basic_target_rhythm);
    simpleTargetType.setOnCloseDialogListener(simpleTargetTypeClick);
    // Pace Coach free run supports only time + pace or distance + pace.
    int savedFreeTarget = simpleTargetType.getValueInt();
    if (savedFreeTarget != DB.DIMENSION.TIME && savedFreeTarget != DB.DIMENSION.DISTANCE) {
      simpleTargetType.setValue(DB.DIMENSION.TIME);
    }
    view.findViewById(R.id.basic_preview_start).setOnClickListener(v -> startCoachWorkout());
    view.findViewById(R.id.interval_preview_start).setOnClickListener(v -> startCoachWorkout());

    intervalRepetitions = view.findViewById(R.id.interval_repetitions);
    intervalType = view.findViewById(R.id.interval_type);
    intervalTime = view.findViewById(R.id.start_interval_time);
    intervalTime.setOnSetValueListener(onSetTimeValidator);
    intervalDistance = view.findViewById(R.id.interval_distance);
    intervalPaceMin = view.findViewById(R.id.interval_pace_min);
    intervalPaceMax = view.findViewById(R.id.interval_pace_max);
    intervalRhythm = view.findViewById(R.id.interval_rhythm);
    intervalType.setOnSetValueListener(intervalTypeSetValue);
    intervalRestType = view.findViewById(R.id.interval_rest_type);
    intervalRestTime = view.findViewById(R.id.interval_rest_time);
    intervalRestTime.setOnSetValueListener(onSetTimeValidator);
    intervalRestDistance = view.findViewById(R.id.interval_rest_distance);
    intervalRestPaceMin = view.findViewById(R.id.interval_rest_pace_min);
    intervalRestPaceMax = view.findViewById(R.id.interval_rest_pace_max);
    intervalRestRhythm = view.findViewById(R.id.interval_rest_rhythm);
    intervalRestType.setOnSetValueListener(intervalRestTypeSetValue);

    intervalWarmupType = view.findViewById(R.id.interval_warmup_type);
    intervalWarmupTime = view.findViewById(R.id.interval_warmup_time);
    intervalWarmupDistance = view.findViewById(R.id.interval_warmup_distance);
    intervalWarmupPaceMin = view.findViewById(R.id.interval_warmup_pace_min);
    intervalWarmupPaceMax = view.findViewById(R.id.interval_warmup_pace_max);
    intervalWarmupRhythm = view.findViewById(R.id.interval_warmup_rhythm);
    intervalWarmupType.setOnSetValueListener(intervalWarmupTypeSetValue);
    intervalWarmupTypeSetValue.preSetValue(intervalWarmupType.getValueInt());

    intervalCooldownType = view.findViewById(R.id.interval_cooldown_type);
    intervalCooldownTime = view.findViewById(R.id.interval_cooldown_time);
    intervalCooldownDistance = view.findViewById(R.id.interval_cooldown_distance);
    intervalCooldownPaceMin = view.findViewById(R.id.interval_cooldown_pace_min);
    intervalCooldownPaceMax = view.findViewById(R.id.interval_cooldown_pace_max);
    intervalCooldownRhythm = view.findViewById(R.id.interval_cooldown_rhythm);
    intervalCooldownType.setOnSetValueListener(intervalCooldownTypeSetValue);
    intervalCooldownTypeSetValue.preSetValue(intervalCooldownType.getValueInt());
    intervalTypeSetValue.preSetValue(intervalType.getValueInt());
    intervalRestTypeSetValue.preSetValue(intervalRestType.getValueInt());
    intervalAudioListAdapter = new AudioSchemeListAdapter(mDB, inflater, false);
    intervalAudioListAdapter.reload();

    advancedWorkoutSpinner = view.findViewById(R.id.advanced_workout_spinner);
    advancedWorkoutListAdapter = new WorkoutListAdapter(inflater);
    advancedWorkoutListAdapter.reload();
    advancedWorkoutSpinner.setAdapter(advancedWorkoutListAdapter);
    advancedWorkoutSpinner.setOnSetValueListener(
        new OnConfigureWorkoutsListener(advancedWorkoutListAdapter));
    advancedStepList = view.findViewById(R.id.advanced_step_list);
    advancedStepList.setDividerHeight(0);
    advancedStepList.setAdapter(advancedWorkoutStepsAdapter);

    Intent i = requireActivity().getIntent();
    if (i != null) {
      if (i.hasExtra("mode")) {
        if (Objects.equals(i.getStringExtra("mode"), TAB_ADVANCED)) {
          tabHost.setCurrentTab(2);
          i.removeExtra("mode");
        }
      }
    }

    updateTargetView();

    mWearNotifier = new TrackerWear.WearNotifier(requireActivity().getApplicationContext());
    mWearNotifier.onViewCreated();

  }

  private void setGpsNotRequired(boolean val) {
    if (sportWithoutGps == val) {
      return;
    }

    sportWithoutGps = val;
    if (sportWithoutGps) {
      // Turning GPS off
      if (mTracker != null) {
        mTracker.setWithoutGps(true);
      }
    } else {
      // Toggling GPS on
      Log.e(getClass().getName(), "mTracker.reset()");
      if (mTracker != null) {
        mTracker.setWithoutGps(false);
        mTracker.reset();
        if (mGpsStatus.isStarted()) {
          mTracker.setup();
          startGps();
        }
      }
    }
  }

  private class OnConfigureAudioListener implements OnSetValueListener {
    final AudioSchemeListAdapter adapter;

    OnConfigureAudioListener(AudioSchemeListAdapter adapter) {
      this.adapter = adapter;
    }

    @Override
    public String preSetValue(String newValue) throws IllegalArgumentException {
      if (newValue != null
          && newValue.contentEquals((String) adapter.getItem(adapter.getCount() - 1))) {
        Intent i = new Intent(requireContext(), AudioCueSettingsActivity.class);
        startActivity(i);
        throw new IllegalArgumentException();
      }
      return newValue;
    }

    @Override
    public int preSetValue(int newValueId) throws IllegalArgumentException {
      return newValueId;
    }
  }

  private class OnConfigureWorkoutsListener implements OnSetValueListener {
    final WorkoutListAdapter adapter;

    OnConfigureWorkoutsListener(WorkoutListAdapter adapter) {
      this.adapter = adapter;
    }

    @Override
    public String preSetValue(String newValue) throws IllegalArgumentException {
      if (newValue != null
          && newValue.contentEquals((String) adapter.getItem(adapter.getCount() - 1))) {
        Intent i = new Intent(requireContext(), ManageWorkoutsActivity.class);
        startActivity(i);
        throw new IllegalArgumentException();
      }
      loadAdvanced(newValue);
      return newValue;
    }

    @Override
    public int preSetValue(int newValueId) throws IllegalArgumentException {
      loadAdvanced(null);
      return newValueId;
    }
  }

  @Override
  public void onStart() {
    super.onStart();
    registerStartEventListener();
  }

  @Override
  public void onResume() {
    super.onResume();
    simpleAudioListAdapter.reload();
    intervalAudioListAdapter.reload();
    advancedWorkoutListAdapter.reload();

    // Ensure spinner reflects current preference after returning from CreateAdvancedWorkout
    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(requireContext());
    String currentWorkoutName = prefs.getString(getString(R.string.pref_advanced_workout), "");
    if (advancedWorkoutSpinner != null) {
      if (!currentWorkoutName.isEmpty()) {
        advancedWorkoutSpinner.setValue(currentWorkoutName);
        // Explicitly reload the saved workout so the preview always mirrors the
        // blocks currently shown by Editor de Treino, even if the spinner value
        // itself did not change and therefore its listener was not fired.
        loadAdvanced(currentWorkoutName);
      } else if (advancedWorkoutListAdapter != null && advancedWorkoutListAdapter.getCount() > 1) {
        // Keep the structured-workout preview populated even when no preference
        // was persisted (for example after a clean install). Select the first
        // real workout; the last adapter item is the management command.
        String firstWorkout = advancedWorkoutListAdapter.getItem(0).toString();
        advancedWorkoutSpinner.setValue(firstWorkout);
        prefs.edit().putString(getString(R.string.pref_advanced_workout), firstWorkout).apply();
      }
    }
    hrZonesAdapter.reload();
    simpleTargetHrz.setAdapter(hrZonesAdapter);
    if (!hrZonesAdapter.hrZones.isConfigured()) {
      simpleTargetType.addDisabledValue(DB.DIMENSION.HRZ);
    } else {
      simpleTargetType.clearDisabled();
    }

    if (Objects.requireNonNull(tabHost.getCurrentTabTag()).contentEquals(TAB_ADVANCED)) {
      loadAdvanced(null);
    }

    if (!mIsBound || mTracker == null) {
      bindGpsTracker();
    } else {
      onGpsTrackerBound();
    }
    updateCoachDashboardStats();
    updateCoachSummary();
    this.updateView();
    PreferenceManager.getDefaultSharedPreferences(requireContext())
        .registerOnSharedPreferenceChangeListener(prefChangeListener);
    mWearNotifier.onResume();
  }

  @Override
  public void onPause() {
    super.onPause();
    PreferenceManager.getDefaultSharedPreferences(requireContext())
        .unregisterOnSharedPreferenceChangeListener(prefChangeListener);

    // Keep the GPS warm across transient pauses (permissions/dialogs) so the home screen
    // can show signal readiness without waiting for a new GPS lock. It is stopped when the
    // fragment is destroyed or when a workout takes ownership of the tracker.
    mWearNotifier.onPause();
  }

  @Override
  public void onStop() {
    super.onStop();
    unregisterStartEventListener();
    if (!runActivityPending) {
      stopGps();
    }
  }

  @Override
  public void onDestroy() {
    stopGps();
    unbindGpsTracker();
    mGpsStatus = null;

    DBHelper.closeDB(mDB);
    super.onDestroy();
    mWearNotifier.onDestroy();
  }

  private final BroadcastReceiver startEventBroadcastReceiver =
      new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
          requireActivity()
              .runOnUiThread(
                  () -> {
                    if (mTracker == null || startButton.getVisibility() != View.VISIBLE) {
                      return;
                    }

                    if (mTracker.getState() == TrackerState.INIT /* this will start gps */
                        || mTracker.getState() == TrackerState.INITIALIZED /* ...start a workout*/
                        || mTracker.getState() == TrackerState.CONNECTED) {
                      startButton.performClick();
                    }
                  });
        }
      };

  private void registerStartEventListener() {
    IntentFilter intentFilter = new IntentFilter();
    // START_WORKOUT is used by Wear when GPS is captured
    // START_ACTIVITY should also start GPS if not done
    intentFilter.addAction(Constants.Intents.START_ACTIVITY);
    intentFilter.addAction(Constants.Intents.START_WORKOUT);
    ContextCompat.registerReceiver(
        requireActivity(),
        startEventBroadcastReceiver,
        intentFilter,
        ContextCompat.RECEIVER_NOT_EXPORTED);
  }

  private void unregisterStartEventListener() {
    try {
      requireActivity().unregisterReceiver(startEventBroadcastReceiver);
    } catch (Exception ignored) {
    }
  }

  private void onGpsTrackerBound() {
    // check and request permissions at startup
    boolean missingEssentialPermission = checkPermissions(false);
    mTracker.setWithoutGps(sportWithoutGps);
    if (!missingEssentialPermission) {
      // Pace Coach keeps GPS warm while the home screen is open, before a workout starts.
      startGps();
    } else {
      Log.d(getClass().getName(), "onGpsTrackerBound state: " + mTracker.getState());
      switch (mTracker.getState()) {
        case INIT:
        case CLEANUP:
          mTracker.setup();
          break;
        case INITIALIZING:
        case INITIALIZED:
          break;
        case CONNECTING:
        case CONNECTED:
        case STARTED:
        case PAUSED:
          break;
        case ERROR:
          break;
      }
    }
    updateView();
  }

  public boolean getAutoStartGps() {
    // Pace Coach intentionally keeps GPS warm while its home screen is active.
    return true;
  }

  private void startGps() {
    Log.d(getClass().getName(), "StartFragment.startGps()");
    if (!sportWithoutGps) {
      if (!mGpsStatus.isEnabled()) {
        startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
      }
      // GPS preparation on the visible home screen must stay silent.
      // The ongoing notification is created only when the workout actually starts.
    }

    if (mGpsStatus != null && !mGpsStatus.isStarted()) {
      mGpsStatus.start(this);
    }

    if (mTracker != null) {
      mTracker.setWithoutGps(sportWithoutGps);
      mTracker.connect();
    }
  }

  public void stopGps() {
    Log.d(getClass().getName(), "StartFragment.stopGps() skipStop: " + this.runActivityPending);
    if (runActivityPending) {
      return;
    }

    if (mGpsStatus != null) {
      mGpsStatus.stop(this);
    }

    if (mTracker != null) {
      mTracker.reset();
    }

    notificationStateManager.cancelNotification();
  }

  public boolean isGpsLogging() {
    if (mGpsStatus == null) {
      // If mGpsStatus is null, GPS logging is not possible.
      return false;
    }
    return mGpsStatus.isLogging();
  }

  private void notificationBatteryLevel(int batteryLevel) {
    if ((batteryLevel < 0) || (batteryLevel > 100)) {
      return;
    }

    Context context = requireContext();
    final String pref_key = getString(R.string.pref_battery_level_low_notification_discard);
    final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);

    int batteryLevelHighThreshold =
        SafeParse.parseInt(
            prefs.getString(getString(R.string.pref_battery_level_high_threshold), "75"), 75);
    if ((batteryLevel > batteryLevelHighThreshold) && (prefs.contains(pref_key))) {
      prefs.edit().remove(pref_key).apply();
      return;
    }

    int batteryLevelLowThreshold =
        SafeParse.parseInt(
            prefs.getString(getString(R.string.pref_battery_level_low_threshold), "15"), 15);
    if (batteryLevel > batteryLevelLowThreshold) {
      return;
    }

    if (prefs.getBoolean(pref_key, false)) {
      return;
    }

    final CheckBox dontShowAgain = new CheckBox(context);
    dontShowAgain.setText(getResources().getText(org.runnerup.common.R.string.Do_not_show_again));

    new AlertDialog.Builder(context)
        .setView(dontShowAgain)
        .setCancelable(false)
        .setTitle(org.runnerup.common.R.string.Warning)
        .setMessage(
            getResources().getText(org.runnerup.common.R.string.Low_HRM_battery_level)
                + "\n"
                + getResources().getText(org.runnerup.common.R.string.Battery_level)
                + ": "
                + batteryLevel
                + "%")
        .setPositiveButton(
            org.runnerup.common.R.string.OK,
            (dialog, which) -> {
              if (dontShowAgain.isChecked()) {
                prefs.edit().putBoolean(pref_key, true).apply();
              }
            })
        .show();
  }

  private final OnTabChangeListener onTabChangeListener =
      tabId -> {
        if (tabId.contentEquals(TAB_ADVANCED)) {
          loadAdvanced(null);
        }
        updateView();
      };

  private void openIntervalEditor() {
    if (coachWorkspaceTitle != null) coachWorkspaceTitle.setText("Treino Intervalado");
    if (coachWorkspaceSubtitle != null) {
      coachWorkspaceSubtitle.setText("Revise o treino antes de salvar.");
      coachWorkspaceSubtitle.setVisibility(View.VISIBLE);
    }
    if (tabHost != null) tabHost.setCurrentTabByTag(TAB_INTERVAL);
    View root = getView();
    if (root != null) {
      View preview = root.findViewById(R.id.interval_preview_content);
      View editor = root.findViewById(R.id.interval_editor_content);
      if (preview != null) preview.setVisibility(View.GONE);
      if (editor != null) editor.setVisibility(View.VISIBLE);
    }
  }

  private void saveIntervalEditor() {
    updateIntervalPreview();
    View root = getView();
    if (root != null) {
      View editor = root.findViewById(R.id.interval_editor_content);
      View preview = root.findViewById(R.id.interval_preview_content);
      if (editor != null) editor.setVisibility(View.GONE);
      if (preview != null) preview.setVisibility(View.VISIBLE);
    }
    if (coachWorkspaceTitle != null) coachWorkspaceTitle.setText("Treino Intervalado");
    if (coachWorkspaceSubtitle != null) {
      coachWorkspaceSubtitle.setText("Revise seu treino antes de iniciar.");
      coachWorkspaceSubtitle.setVisibility(View.VISIBLE);
    }
  }

  private void openBasicEditor() {
    if (coachWorkspaceTitle != null) coachWorkspaceTitle.setText("Treino Livre");
    if (coachWorkspaceSubtitle != null) {
      coachWorkspaceSubtitle.setText("Revise o treino antes de salvar.");
      coachWorkspaceSubtitle.setVisibility(View.VISIBLE);
    }
    if (tabHost != null) tabHost.setCurrentTabByTag(TAB_BASIC);
    View root = getView();
    if (root != null) {
      View preview = root.findViewById(R.id.basic_free_preview_content);
      View editor = root.findViewById(R.id.basic_editor_content);
      if (preview != null) preview.setVisibility(View.GONE);
      if (editor != null) editor.setVisibility(View.VISIBLE);
      updateTargetView();
    }
  }

  private void saveBasicEditor() {
    updateBasicPreview();
    View root = getView();
    if (root != null) {
      View preview = root.findViewById(R.id.basic_free_preview_content);
      View editor = root.findViewById(R.id.basic_editor_content);
      if (editor != null) editor.setVisibility(View.GONE);
      if (preview != null) preview.setVisibility(View.VISIBLE);
    }
    if (coachWorkspaceTitle != null) coachWorkspaceTitle.setText("Treino Livre");
    if (coachWorkspaceSubtitle != null) {
      coachWorkspaceSubtitle.setText("Revise seu treino antes de iniciar.");
      coachWorkspaceSubtitle.setVisibility(View.VISIBLE);
    }
  }

  private void updateCoachDashboardStats() {
    // Kept for compatibility with the existing Pace Coach dashboard references.
    updateCoachSummary();
  }

  private void setupCoachPeriodSelector(View root) {
    View selector = root.findViewById(R.id.coach_period_selector);
    if (selector != null) selector.setVisibility(View.VISIBLE);
    int[] ids = {R.id.coach_period_day, R.id.coach_period_week, R.id.coach_period_month, R.id.coach_period_year};
    String[] values = {"day", "week", "month", "year"};
    for (int i = 0; i < ids.length; i++) {
      final String value = values[i];
      View v = root.findViewById(ids[i]);
      if (v != null) {
        v.setVisibility(View.VISIBLE);
        v.setOnClickListener(view -> {
          coachSelectedPeriod = value;
          updateCoachSummary();
        });
      }
    }
    updateCoachPeriodSelectorVisual();
  }

  private void updateCoachPeriodSelectorVisual() {
    View root = getView();
    if (root == null) return;
    int[] ids = {R.id.coach_period_day, R.id.coach_period_week, R.id.coach_period_month, R.id.coach_period_year};
    String[] values = {"day", "week", "month", "year"};
    for (int i = 0; i < ids.length; i++) {
      View v = root.findViewById(ids[i]);
      if (v instanceof TextView) {
        boolean selected = values[i].equals(coachSelectedPeriod);
        v.setBackgroundResource(selected ? R.drawable.bg_coach_period_selected : android.R.color.transparent);
        ((TextView) v).setTextColor(getResources().getColor(
            selected ? R.color.colorText : R.color.colorTextSecondary));
      }
    }
  }

  private long[] getCoachPeriodBounds(String period) {
    Calendar start = Calendar.getInstance();
    Calendar end = Calendar.getInstance();
    if ("day".equals(period)) {
      start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0);
      end.setTimeInMillis(start.getTimeInMillis()); end.add(Calendar.DAY_OF_YEAR, 1);
    } else if ("week".equals(period)) {
      start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0);
      int day = start.get(Calendar.DAY_OF_WEEK);
      int delta = (day == Calendar.SUNDAY) ? -6 : Calendar.MONDAY - day;
      start.add(Calendar.DAY_OF_YEAR, delta);
      end.setTimeInMillis(start.getTimeInMillis()); end.add(Calendar.DAY_OF_YEAR, 7);
    } else if ("year".equals(period)) {
      start.set(Calendar.DAY_OF_YEAR, 1); start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0);
      end.setTimeInMillis(start.getTimeInMillis()); end.add(Calendar.YEAR, 1);
    } else {
      start.set(Calendar.DAY_OF_MONTH, 1); start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0);
      end.setTimeInMillis(start.getTimeInMillis()); end.add(Calendar.MONTH, 1);
    }
    return new long[] {start.getTimeInMillis() / 1000L, end.getTimeInMillis() / 1000L};
  }

  private String coachPeriodLabel() {
    if ("day".equals(coachSelectedPeriod)) return "Dia";
    if ("week".equals(coachSelectedPeriod)) return "Semana";
    if ("year".equals(coachSelectedPeriod)) return "Ano";
    return "Mês";
  }

  private String formatCoachPace(long seconds, double meters) {
    if (seconds <= 0 || meters <= 0) return "--:--";
    double secPerKm = seconds / (meters / 1000.0);
    long total = Math.round(secPerKm);
    long min = total / 60L;
    long sec = total % 60L;
    return String.format(Locale.getDefault(), "%d:%02d", min, sec);
  }

  private void updateCoachSummary() {
    View root = getView();
    if (root != null) {
      View selector = root.findViewById(R.id.coach_period_selector);
      if (selector != null) selector.setVisibility(View.VISIBLE);
    }
    if (mDB == null || coachPeriodWorkouts == null) return;
    long[] bounds = getCoachPeriodBounds(coachSelectedPeriod);
    Cursor cursor = null;
    long count = 0, totalTime = 0;
    double totalDistance = 0;
    try {
      cursor = mDB.rawQuery("SELECT " + DB.ACTIVITY.START_TIME + ", " + DB.ACTIVITY.DISTANCE + ", " + DB.ACTIVITY.TIME + " FROM " + DB.ACTIVITY.TABLE
              + " WHERE " + DB.ACTIVITY.DELETED + " = 0 AND " + DB.ACTIVITY.SPORT + " = ? AND " + DB.ACTIVITY.START_TIME + " >= ? AND " + DB.ACTIVITY.START_TIME + " < ?",
          new String[] {String.valueOf(DB.ACTIVITY.SPORT_RUNNING), String.valueOf(bounds[0]), String.valueOf(bounds[1])});
      while (cursor.moveToNext()) {
        count++;
        totalDistance += cursor.getDouble(1);
        totalTime += cursor.getLong(2);
      }
    } finally { if (cursor != null) cursor.close(); }

    coachPeriodWorkouts.setText(String.valueOf(count));
    coachPeriodDistance.setText(String.format(Locale.getDefault(), "%.1f", totalDistance / 1000.0));
    coachPeriodTime.setText(formatter.formatElapsedTime(Formatter.Format.TXT, totalTime));
    coachPeriodPace.setText(formatCoachPace(totalTime, totalDistance));
    coachChartPeriod.setText(coachPeriodLabel());

    double previousDistance = getCoachPeriodDistance(shiftCoachPeriodStart(bounds[0], -1), bounds[0]);
    coachChartTotal.setText(String.format(Locale.getDefault(),
        "Atual  %.1f km   •   Anterior  %.1f km", totalDistance / 1000.0, previousDistance / 1000.0));

    updateCoachPeriodSelectorVisual();
    updateCoachChart(bounds[0], bounds[1]);
    updateCoachAchievements();
    updateCoachRecentActivities();
  }

  private double getCoachPeriodDistance(long startSeconds, long endSeconds) {
    Cursor c = null;
    double distance = 0;
    try {
      c = mDB.rawQuery("SELECT COALESCE(SUM(" + DB.ACTIVITY.DISTANCE + "),0) FROM " + DB.ACTIVITY.TABLE
              + " WHERE " + DB.ACTIVITY.DELETED + " = 0 AND " + DB.ACTIVITY.SPORT + " = ? AND " + DB.ACTIVITY.START_TIME + " >= ? AND " + DB.ACTIVITY.START_TIME + " < ?",
          new String[] {String.valueOf(DB.ACTIVITY.SPORT_RUNNING), String.valueOf(startSeconds), String.valueOf(endSeconds)});
      if (c.moveToFirst()) distance = c.getDouble(0);
    } finally { if (c != null) c.close(); }
    return distance;
  }

  private long[] getCoachPreviousPeriodBounds(long currentStartSeconds) {
    Calendar start = Calendar.getInstance();
    start.setTimeInMillis(currentStartSeconds * 1000L);
    Calendar end = (Calendar) start.clone();
    if ("day".equals(coachSelectedPeriod)) {
      start.add(Calendar.DAY_OF_YEAR, -1);
    } else if ("week".equals(coachSelectedPeriod)) {
      start.add(Calendar.WEEK_OF_YEAR, -1);
    } else if ("month".equals(coachSelectedPeriod)) {
      start.add(Calendar.MONTH, -1);
    } else {
      start.add(Calendar.YEAR, -1);
    }
    end.setTimeInMillis(currentStartSeconds * 1000L);
    return new long[] {start.getTimeInMillis() / 1000L, end.getTimeInMillis() / 1000L};
  }

  private long shiftCoachPeriodStart(long currentStartSeconds, int amount) {
    Calendar c = Calendar.getInstance();
    c.setTimeInMillis(currentStartSeconds * 1000L);
    if ("day".equals(coachSelectedPeriod)) c.add(Calendar.DAY_OF_YEAR, amount);
    else if ("week".equals(coachSelectedPeriod)) c.add(Calendar.WEEK_OF_YEAR, amount);
    else if ("month".equals(coachSelectedPeriod)) c.add(Calendar.MONTH, amount);
    else c.add(Calendar.YEAR, amount);
    return c.getTimeInMillis() / 1000L;
  }

  private long[] getCoachPeriodAtOffset(long currentStartSeconds, int offset) {
    Calendar start = Calendar.getInstance();
    start.setTimeInMillis(currentStartSeconds * 1000L);
    if ("day".equals(coachSelectedPeriod)) start.add(Calendar.DAY_OF_YEAR, offset);
    else if ("week".equals(coachSelectedPeriod)) start.add(Calendar.WEEK_OF_YEAR, offset);
    else if ("month".equals(coachSelectedPeriod)) start.add(Calendar.MONTH, offset);
    else start.add(Calendar.YEAR, offset);
    Calendar end = (Calendar) start.clone();
    if ("day".equals(coachSelectedPeriod)) end.add(Calendar.DAY_OF_YEAR, 1);
    else if ("week".equals(coachSelectedPeriod)) end.add(Calendar.WEEK_OF_YEAR, 1);
    else if ("month".equals(coachSelectedPeriod)) end.add(Calendar.MONTH, 1);
    else end.add(Calendar.YEAR, 1);
    return new long[] {start.getTimeInMillis() / 1000L, end.getTimeInMillis() / 1000L};
  }

  private String coachHistoryBucketLabel(int offset) {
    // Labels are tied to the real calendar period represented by each point.
    // Day: exact date (dd/MM).
    // Week: real Monday-Sunday date range (dd-dd/MM, including month when needed).
    // Month: real month/year.
    // Year: real year.
    Calendar base = Calendar.getInstance();
    long[] currentBounds = getCoachPeriodBounds(coachSelectedPeriod);
    base.setTimeInMillis(currentBounds[0] * 1000L);

    if ("day".equals(coachSelectedPeriod)) {
      base.add(Calendar.DAY_OF_YEAR, offset);
      return String.format(Locale.getDefault(), "%02d/%02d",
          base.get(Calendar.DAY_OF_MONTH), base.get(Calendar.MONTH) + 1);
    }

    if ("week".equals(coachSelectedPeriod)) {
      Calendar weekStart = (Calendar) base.clone();
      weekStart.add(Calendar.WEEK_OF_YEAR, offset);
      Calendar weekEnd = (Calendar) weekStart.clone();
      weekEnd.add(Calendar.DAY_OF_YEAR, 6);

      if (weekStart.get(Calendar.MONTH) == weekEnd.get(Calendar.MONTH)) {
        return String.format(Locale.getDefault(), "%02d–%02d/%02d",
            weekStart.get(Calendar.DAY_OF_MONTH),
            weekEnd.get(Calendar.DAY_OF_MONTH),
            weekEnd.get(Calendar.MONTH) + 1);
      }
      return String.format(Locale.getDefault(), "%02d/%02d–%02d/%02d",
          weekStart.get(Calendar.DAY_OF_MONTH), weekStart.get(Calendar.MONTH) + 1,
          weekEnd.get(Calendar.DAY_OF_MONTH), weekEnd.get(Calendar.MONTH) + 1);
    }

    if ("month".equals(coachSelectedPeriod)) {
      base.add(Calendar.MONTH, offset);
      final String[] months = {"Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
          "Jul", "Ago", "Set", "Out", "Nov", "Dez"};
      return months[base.get(Calendar.MONTH)] + "/" + base.get(Calendar.YEAR);
    }

    base.add(Calendar.YEAR, offset);
    return String.valueOf(base.get(Calendar.YEAR));
  }

  private void updateCoachChart(long currentStartSeconds, long currentEndSeconds) {
    if (coachChart == null || mDB == null) return;
    coachChart.removeAllViews();

    // The graph is always anchored to TODAY'S current period.
    // It shows the current period at the right and previous periods to the left:
    // Day = today + previous days; Week = current week + previous weeks;
    // Month = current month + previous months; Year = current year + previous years.
    final int n = "day".equals(coachSelectedPeriod) ? 7
        : ("year".equals(coachSelectedPeriod) ? 5 : 6);
    final double[] values = new double[n];

    for (int i = 0; i < n; i++) {
      int offset = i - (n - 1);
      long[] period = getCoachPeriodAtOffset(currentStartSeconds, offset);
      values[i] = getCoachPeriodDistance(period[0], period[1]) / 1000.0;
    }

    CoachLineChart chart = new CoachLineChart(requireContext());
    chart.setData(values, n);
    coachChart.addView(chart, new LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
  }

  private class CoachLineChart extends View {
    private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pointPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private double[] values = new double[0];
    private int count = 0;

    CoachLineChart(Context context) {
      super(context);
      gridPaint.setColor(0x334F6475);
      gridPaint.setStrokeWidth(dp(1));
      linePaint.setColor(getResources().getColor(R.color.colorAccent));
      linePaint.setStyle(Paint.Style.STROKE);
      linePaint.setStrokeWidth(dp(3));
      linePaint.setStrokeCap(Paint.Cap.ROUND);
      linePaint.setStrokeJoin(Paint.Join.ROUND);
      pointPaint.setColor(getResources().getColor(R.color.colorAccent));
      pointPaint.setStyle(Paint.Style.FILL);
      labelPaint.setColor(getResources().getColor(R.color.colorTextSecondary));
      labelPaint.setTextSize(dp(8));
      labelPaint.setTextAlign(Paint.Align.CENTER);
    }

    void setData(double[] data, int n) {
      values = data == null ? new double[0] : data.clone();
      count = Math.max(0, Math.min(n, values.length));
      invalidate();
    }

    private float dp(float value) {
      return value * getResources().getDisplayMetrics().density;
    }

    @Override protected void onDraw(Canvas canvas) {
      super.onDraw(canvas);
      if (count == 0) return;
      float left = dp(16);
      float right = getWidth() - dp(12);
      float top = dp(12);
      float bottom = getHeight() - dp(28);
      float chartW = Math.max(1, right - left);
      float chartH = Math.max(1, bottom - top);
      double max = 1.0;
      for (int i = 0; i < count; i++) max = Math.max(max, values[i]);
      for (int g = 0; g < 4; g++) {
        float y = top + chartH * g / 3f;
        canvas.drawLine(left, y, right, y, gridPaint);
      }
      Path path = new Path();
      for (int i = 0; i < count; i++) {
        float x = count == 1 ? left + chartW / 2f : left + chartW * i / (count - 1f);
        float y = bottom - (float)((values[i] / max) * chartH);
        if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
      }
      canvas.drawPath(path, linePaint);
      for (int i = 0; i < count; i++) {
        float x = count == 1 ? left + chartW / 2f : left + chartW * i / (count - 1f);
        float y = bottom - (float)((values[i] / max) * chartH);
        canvas.drawCircle(x, y, dp(i == count - 1 ? 5 : 3.5f), pointPaint);
        canvas.drawText(coachHistoryBucketLabel(i - count + 1), x, getHeight() - dp(7), labelPaint);
      }
    }
  }

  private void updateCoachAchievements() {
    if (coachAchievements == null || mDB == null) return;
    coachAchievements.removeAllViews();

    Cursor c = null;
    long count = 0;
    double distance = 0;
    long time = 0;
    try {
      c = mDB.rawQuery(
          "SELECT COUNT(*), COALESCE(SUM(" + DB.ACTIVITY.DISTANCE + "),0), "
              + "COALESCE(SUM(" + DB.ACTIVITY.TIME + "),0) FROM " + DB.ACTIVITY.TABLE
              + " WHERE " + DB.ACTIVITY.DELETED + " = 0 AND "
              + DB.ACTIVITY.SPORT + " = ?",
          new String[] {String.valueOf(DB.ACTIVITY.SPORT_RUNNING)});
      if (c.moveToFirst()) {
        count = c.getLong(0);
        distance = c.getDouble(1);
        time = c.getLong(2);
      }
    } finally {
      if (c != null) c.close();
    }

    // A conquista only appears after its criterion has actually been reached.
    // Criteria: 1, 5 and 10 workouts; 50 and 100 km; 10 hours.
    String[][] items = {
        {"👟", "1º treino", count >= 1 ? "1º treino" : ""},
        {"🏃", "5 treinos", count >= 5 ? "5 treinos" : ""},
        {"🔥", "10 treinos", count >= 10 ? "10 treinos" : ""},
        {"📍", "50 km", distance >= 50000 ? "50 km" : ""},
        {"📍", "100 km", distance >= 100000 ? "100 km" : ""},
        {"⏱", "10 horas", time >= 36000 ? "10 horas" : ""}
    };

    int achieved = 0;
    for (String[] item : items) {
      if (item[2].isEmpty()) continue;
      achieved++;
      LinearLayout card = new LinearLayout(requireContext());
      card.setOrientation(LinearLayout.VERTICAL);
      card.setGravity(android.view.Gravity.CENTER);
      card.setPadding(dpInt(6), dpInt(4), dpInt(6), dpInt(4));
      card.setBackgroundResource(R.drawable.bg_coach_card);

      TextView icon = new TextView(requireContext());
      icon.setText(item[0]);
      icon.setTextSize(21);
      icon.setGravity(android.view.Gravity.CENTER);
      card.addView(icon, new LinearLayout.LayoutParams(
          ViewGroup.LayoutParams.MATCH_PARENT, dpInt(40)));

      TextView label = new TextView(requireContext());
      label.setText(item[2]);
      label.setTextColor(getResources().getColor(R.color.colorTextSecondary));
      label.setTextSize(9);
      label.setGravity(android.view.Gravity.CENTER);
      label.setSingleLine(true);
      card.addView(label, new LinearLayout.LayoutParams(
          ViewGroup.LayoutParams.MATCH_PARENT, dpInt(24)));

      LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dpInt(92), dpInt(82));
      lp.setMargins(0, 0, dpInt(8), 0);
      coachAchievements.addView(card, lp);
    }

    if (achieved == 0) {
      TextView empty = new TextView(requireContext());
      empty.setText("Complete seu primeiro treino para desbloquear conquistas.");
      empty.setTextColor(getResources().getColor(R.color.colorTextSecondary));
      empty.setTextSize(10);
      empty.setGravity(android.view.Gravity.CENTER_VERTICAL);
      coachAchievements.addView(empty, new LinearLayout.LayoutParams(
          ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }
  }

  private int dpInt(float value) {
    return Math.round(value * getResources().getDisplayMetrics().density);
  }

  private void updateCoachRecentActivities() {
    if (coachRecentList == null || mDB == null) return;
    coachRecentList.removeAllViews();
    Cursor c = null;
    try {
      c = mDB.rawQuery("SELECT _id, " + DB.ACTIVITY.NAME + ", " + DB.ACTIVITY.START_TIME + ", " + DB.ACTIVITY.DISTANCE + ", " + DB.ACTIVITY.TIME + " FROM " + DB.ACTIVITY.TABLE + " WHERE " + DB.ACTIVITY.DELETED + " = 0 AND " + DB.ACTIVITY.SPORT + " = ? ORDER BY " + DB.ACTIVITY.START_TIME + " DESC, _id DESC LIMIT 3", new String[] {String.valueOf(DB.ACTIVITY.SPORT_RUNNING)});
      SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy • HH:mm", Locale.getDefault());
      while (c.moveToNext()) {
        final long activityId = c.getLong(0);
        String name = c.getString(1);
        if (name == null || name.trim().isEmpty()) name = "Corrida";
        double dist = c.getDouble(3);
        long t = c.getLong(4);

        LinearLayout card = new LinearLayout(requireContext());
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dpInt(14), dpInt(10), dpInt(12), dpInt(10));
        card.setBackgroundResource(R.drawable.bg_coach_card);
        card.setClickable(true);
        card.setFocusable(true);
        card.setOnClickListener(v -> {
          Intent intent = new Intent(requireContext(), DetailActivity.class);
          intent.putExtra("ID", activityId);
          intent.putExtra("mode", "details");
          startActivityForResult(intent, 0);
        });

        LinearLayout top = new LinearLayout(requireContext());
        top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);

        ImageView icon = new ImageView(requireContext());
        icon.setImageResource(R.drawable.ic_coach_runner);
        icon.setColorFilter(ContextCompat.getColor(requireContext(), R.color.sportRunning), android.graphics.PorterDuff.Mode.SRC_IN);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        top.addView(icon, new LinearLayout.LayoutParams(dpInt(32), dpInt(32)));

        LinearLayout titleBox = new LinearLayout(requireContext());
        titleBox.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleLp.setMargins(dpInt(8), 0, 0, 0);
        top.addView(titleBox, titleLp);

        TextView title = new TextView(requireContext());
        title.setText(name);
        title.setTextColor(getResources().getColor(R.color.colorText));
        title.setTextSize(13);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setSingleLine(true);
        titleBox.addView(title);

        TextView date = new TextView(requireContext());
        date.setText(df.format(new Date(c.getLong(2) * 1000L)));
        date.setTextColor(getResources().getColor(R.color.colorTextSecondary));
        date.setTextSize(9);
        titleBox.addView(date);

        TextView arrow = new TextView(requireContext());
        arrow.setText("›");
        arrow.setTextColor(getResources().getColor(R.color.colorAccent));
        arrow.setTextSize(28);
        arrow.setGravity(android.view.Gravity.CENTER);
        top.addView(arrow, new LinearLayout.LayoutParams(dpInt(24), dpInt(32)));
        card.addView(top);

        LinearLayout stats = new LinearLayout(requireContext());
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setPadding(dpInt(40), dpInt(4), 0, 0);
        TextView meta = new TextView(requireContext());
        meta.setText(String.format(Locale.getDefault(), "%.1f km   •   %s   •   %s/km", dist / 1000.0, formatter.formatElapsedTime(Formatter.Format.TXT, t), formatCoachPace(t, dist)));
        meta.setTextColor(getResources().getColor(R.color.colorText));
        meta.setTextSize(10);
        meta.setSingleLine(true);
        stats.addView(meta, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        card.addView(stats);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dpInt(8));
        coachRecentList.addView(card, lp);
      }
    } finally { if (c != null) c.close(); }
  }

  private void openCoachWorkspace(String tab, String title) {
    if (coachDashboard != null) coachDashboard.setVisibility(View.GONE);
    if (coachWorkspace != null) coachWorkspace.setVisibility(View.VISIBLE);
    if (coachWorkspaceTitle != null) coachWorkspaceTitle.setText(title);
    if (coachWorkspaceSubtitle != null) {
      coachWorkspaceSubtitle.setText("Revise seu treino antes de iniciar.");
      coachWorkspaceSubtitle.setVisibility(View.VISIBLE);
    }
    if (tabHost != null) tabHost.setCurrentTabByTag(tab);
    View root = getView();
    if (root != null && tab.contentEquals(TAB_BASIC)) {
      View preview = root.findViewById(R.id.basic_free_preview_content);
      View editor = root.findViewById(R.id.basic_editor_content);
      if (preview != null) preview.setVisibility(View.VISIBLE);
      if (editor != null) editor.setVisibility(View.GONE);
      updateBasicPreview();
    } else if (root != null && tab.contentEquals(TAB_INTERVAL)) {
      View preview = root.findViewById(R.id.interval_preview_content);
      View editor = root.findViewById(R.id.interval_editor_content);
      if (preview != null) preview.setVisibility(View.VISIBLE);
      if (editor != null) editor.setVisibility(View.GONE);
      updateIntervalPreview();
    }
  }

  private void closeCoachWorkspace() {
    if (coachWorkspace != null) coachWorkspace.setVisibility(View.GONE);
    if (coachDashboard != null) coachDashboard.setVisibility(View.VISIBLE);
  }

  private Workout prepareWorkout() {
    Context ctx = requireActivity().getApplicationContext();
    SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
    SharedPreferences audioPref;
    Workout w;

    if (Objects.requireNonNull(tabHost.getCurrentTabTag()).contentEquals(TAB_BASIC)) {
      audioPref =
          WorkoutBuilder.getAudioCuePreferences(ctx, pref, getString(R.string.pref_basic_audio));
      Dimension target = Dimension.valueOf(simpleTargetType.getValueInt());
      w = WorkoutBuilder.createDefaultWorkout(getResources(), pref, target);
    } else if (tabHost.getCurrentTabTag().contentEquals(TAB_INTERVAL)) {
      audioPref =
          WorkoutBuilder.getAudioCuePreferences(ctx, pref, getString(R.string.pref_interval_audio));
      w = WorkoutBuilder.createDefaultIntervalWorkout(getResources(), pref);
    } else if (tabHost.getCurrentTabTag().contentEquals(TAB_ADVANCED)) {
      audioPref =
          WorkoutBuilder.getAudioCuePreferences(ctx, pref, getString(R.string.pref_advanced_audio));
      w = advancedWorkout;
    } else {
      w = null;
      audioPref = null;
    }
    if (w != null) {
      WorkoutBuilder.prepareWorkout(getResources(), pref, w);
      WorkoutBuilder.addAudioCuesToWorkout(getResources(), w, audioPref, pref);
    }
    return w;
  }

  /**
   * Starts a Pace Coach workout from the modern preview screen. Unlike the legacy
   * start button, the preview action must not require the user to first wait for
   * the GPS/Tracker button to become visible. Permissions are configured from the
   * GPS dashboard; once they are granted, the workout starts immediately or waits
   * for the tracker to reach CONNECTED.
   */
  private void startCoachWorkout() {
    if (runActivityPending) {
      return;
    }

    // Permissions are configured from the GPS dashboard. Starting a workout must
    // never open the permission dialog; if the required location permission is
    // still missing, the user can tap the GPS dashboard first.
    if (checkPermissions(false)) {
      return;
    }

    if (mTracker == null || mGpsStatus == null) {
      updateView();
      return;
    }

    if (mTracker.getState() == TrackerState.CONNECTED) {
      coachStartPending = false;
      startWorkout();
      return;
    }

    coachStartPending = true;
    startGps();
    updateView();
  }

  private void startWorkout() {
    mGpsStatus.stop(StartFragment.this);

    // unregister receivers
    unregisterStartEventListener();

    // This will start the advancedWorkoutSpinner!
    mTracker.setWorkout(prepareWorkout());
    mTracker.start();

    runActivityPending = true;
    Intent intent = new Intent(requireContext(), RunActivity.class);
    // TODO: Use the Activity Result API
    StartFragment.this.startActivityForResult(intent, START_ACTIVITY);
    notificationStateManager.cancelNotification(); // will be added by RunActivity
  }

  private final OnClickListener startButtonClick =
      v -> {
        if (mTracker.getState() == TrackerState.CONNECTED) {
          startWorkout();
          return;
        }
        updateView();
      };

  /**
   * The GPS dashboard is the single permission/setup entry point.
   *
   * Once the user grants the permissions here, starting a workout no longer needs
   * to show the permission flow again. If everything is already granted, a tap
   * simply makes sure GPS is running.
   */
  private void requestGpsPermissionsFromDashboard() {
    if (checkPermissions(true)) {
      return;
    }

    if (mTracker != null && mTracker.getState() != TrackerState.CONNECTED) {
      startGps();
    }
    updateView();
  }

  private final OnClickListener gpsEnableClick =
      v -> requestGpsPermissionsFromDashboard();

  @Override
  public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    if (requestCode == REQUEST_LOCATION) {
      boolean granted = grantResults.length > 0;
      for (int result : grantResults) {
        if (result != PackageManager.PERMISSION_GRANTED) {
          granted = false;
          break;
        }
      }
      if (granted) {
        startGps();
      }
      updateView();
    }
  }

  private List<String> getPermissions() {
    List<String> requiredPerms = new ArrayList<>();
    requiredPerms.add(Manifest.permission.ACCESS_FINE_LOCATION);
    requiredPerms.add(Manifest.permission.ACCESS_COARSE_LOCATION);

    Context ctx = requireContext();
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      requiredPerms.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION);

      final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
      boolean enabled =
          prefs.getBoolean(
              this.getString(org.runnerup.R.string.pref_use_cadence_step_sensor), true);
      if (enabled && TrackerCadence.isAvailable(ctx)) {
        requiredPerms.add(Manifest.permission.ACTIVITY_RECOGNITION);
      }
    }

    PackageManager packageManager = requireContext().getPackageManager();
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S /* Android12, sdk31*/
        && (packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)
            || packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH))) {
      final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
      final String btDeviceName = prefs.getString(getString(R.string.pref_bt_name), null);
      if (btDeviceName != null && !btDeviceName.isEmpty()) {
        requiredPerms.add(Manifest.permission.BLUETOOTH_CONNECT);
        requiredPerms.add(Manifest.permission.BLUETOOTH_SCAN);
      }
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      requiredPerms.add(Manifest.permission.POST_NOTIFICATIONS);
    }

    return requiredPerms;
  }

  /**
   * Check that required permissions are allowed
   *
   * @param popup
   * @return
   */
  private boolean checkPermissions(boolean popup) {
    boolean missingEssentialPermission = false;
    boolean missingAnyPermission = false;
    List<String> requiredPerms = getPermissions();
    List<String> requestPerms = new ArrayList<>();
    Context ctx = requireContext();

    for (final String perm : requiredPerms) {
      if (ContextCompat.checkSelfPermission(ctx, perm) != PackageManager.PERMISSION_GRANTED) {
        missingAnyPermission = true;
        // Filter non essential permissions for result
        boolean nonEssential =
            (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                    && perm.equals(Manifest.permission.ACTIVITY_RECOGNITION)
                || Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    && (perm.equals(Manifest.permission.BLUETOOTH_CONNECT)
                        || perm.equals(Manifest.permission.BLUETOOTH_SCAN))
                || Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                    && perm.equals(Manifest.permission.POST_NOTIFICATIONS));
        missingEssentialPermission = missingEssentialPermission || !nonEssential;
        if (ActivityCompat.shouldShowRequestPermissionRationale(requireActivity(), perm)) {
          // A denied permission, show motivation in a popup
          String s = "Permission " + perm + " is explicitly denied";
          Log.i(getClass().getName(), s);
        } else {
          requestPerms.add(perm);
        }
      }
    }

    if (missingAnyPermission) {
      final String[] permissions = new String[requestPerms.size()];
      requestPerms.toArray(permissions);

      if (popup && (missingEssentialPermission || !requestPerms.isEmpty())) {
        // Essential or requestable permissions missing
        String baseMessage =
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                ? getString(org.runnerup.common.R.string.GPS_permission_text_Android12)
                : Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                    ? getString(org.runnerup.common.R.string.GPS_permission_text)
                    : getString(org.runnerup.common.R.string.GPS_permission_text_pre_Android10);

        AlertDialog.Builder builder =
            new AlertDialog.Builder(ctx)
                .setTitle(org.runnerup.common.R.string.GPS_permission_required)
                .setNegativeButton(
                    org.runnerup.common.R.string.Cancel, (dialog, which) -> dialog.dismiss());
        if (!requestPerms.isEmpty()) {
          // Let Android request the permissions
          builder
              .setPositiveButton(
                  org.runnerup.common.R.string.OK,
                  (dialog, id) -> {
                    Activity activity = getActivity();
                    if (activity != null) {
                      ActivityCompat.requestPermissions(activity, permissions, REQUEST_LOCATION);
                    }
                  })
              .setMessage(
                  baseMessage
                      + "\n"
                      + getString(org.runnerup.common.R.string.Request_permission_text));
        } else {
          // Open settings for the app (no direct shortcut to permissions)
          Intent intent =
              new Intent()
                  .setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                  .setData(Uri.fromParts("package", ctx.getPackageName(), null));
          builder
              .setPositiveButton(
                  org.runnerup.common.R.string.OK, (dialog, id) -> startActivity(intent))
              .setMessage(
                  baseMessage
                      + "\n\n"
                      + getString(org.runnerup.common.R.string.Request_permission_text));
        }
        builder.show();
      }
    }

    // https://developer.android.com/training/monitoring-device-state/doze-standby#support_for_other_use_cases
    // Permission REQUEST_IGNORE_BATTERY_OPTIMIZATIONS requires special approval in Play
    final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
    final Resources res = this.getResources();
    final boolean suppressOptimizeBatteryPopup =
        prefs.getBoolean(res.getString(R.string.pref_suppress_battery_optimization_popup), false);
    PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
    if (popup
        && !suppressOptimizeBatteryPopup
        && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
        && !pm.isIgnoringBatteryOptimizations(ctx.getPackageName())) {
      Intent intent;
      int msgId;
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        // Around Android 9 the Battery usage setting is available in the app setting too, which is
        // easier to
        // change than in the system settings
        intent =
            new Intent()
                .setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                .setData(Uri.fromParts("package", ctx.getPackageName(), null));
        msgId = org.runnerup.common.R.string.Battery_optimization_check_text_Android9;
      } else {
        intent = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
        msgId = org.runnerup.common.R.string.Battery_optimization_check_text;
      }

      new AlertDialog.Builder(ctx)
          .setTitle(org.runnerup.common.R.string.Battery_optimization_check)
          .setMessage(msgId)
          .setPositiveButton(
              org.runnerup.common.R.string.OK, (dialog, which) -> this.startActivity(intent))
          .setNeutralButton(
              org.runnerup.common.R.string.Do_not_show_again,
              (dialog, which) ->
                  prefs
                      .edit()
                      .putBoolean(
                          res.getString(R.string.pref_suppress_battery_optimization_popup), true)
                      .apply())
          .setNegativeButton(
              org.runnerup.common.R.string.Cancel, (dialog, which) -> dialog.dismiss())
          .show();
    }

    return missingEssentialPermission;
  }

  private void toggleStatusDetails() {
    statusDetailsShown = !statusDetailsShown;
    float bottomMargin;

    if (statusDetailsShown) {
      expandIcon.setImageResource(R.drawable.ic_expand_down_white_24dp);
      bottomMargin = getResources().getDimension(R.dimen.fab_margin_68row);
    } else {
      expandIcon.setImageResource(R.drawable.ic_expand_up_white_24dp);
      bottomMargin = getResources().getDimension(R.dimen.fab_margin_44row);
    }

    ViewGroup.MarginLayoutParams params =
        (ViewGroup.MarginLayoutParams) startButton.getLayoutParams();
    params.setMargins(params.leftMargin, params.topMargin, params.rightMargin, (int) bottomMargin);
    startButton.setLayoutParams(params);

    updateView();
  }

  private GpsLevel getGpsLevel(double gpsAccuracyMeters, int sats) {
    if (!mGpsStatus.isFixed()) {
      return GpsLevel.NOT_FIXED;
    }
    if (gpsAccuracyMeters <= 7 && sats > 7) {
      return GpsLevel.GOOD;
    } else if (gpsAccuracyMeters <= 15 && sats > 4) {
      return GpsLevel.ACCEPTABLE;
    } else {
      return GpsLevel.POOR;
    }
  }

  public void updateView() {
    updateStartGpsButtonView();
    updateStartButtonView();
    updateGPSView();
    boolean hrPresent = updateHRView();
    boolean wearPresent = updateWearOSView();

    if (!hrPresent && !wearPresent && statusDetailsShown) {
      noDevicesConnected.setVisibility(View.VISIBLE);
    } else {
      noDevicesConnected.setVisibility(View.GONE);
    }
  }

  private void updateStartButtonView() {
    // Pace Coach workspaces use their own full-width INICIAR TREINO button.
    // Never show the legacy floating Play button over those layouts.
    if (coachWorkspace != null && coachWorkspace.getVisibility() == View.VISIBLE) {
      startButton.setVisibility(View.GONE);
      return;
    }
    do {
      if (!mGpsStatus.isStarted()) {
        break;
      }

      if (!sportWithoutGps) {
        if (!mGpsStatus.isLogging()) {
          break;
        }

        if (!mGpsStatus.isFixed()) {
          break;
        }
      }

      if (mTracker == null || !mIsBound) {
        break;
      }

      if (mTracker.getState() != TrackerState.CONNECTED) {
        break;
      }

      if (Objects.requireNonNull(tabHost.getCurrentTabTag()).contentEquals(TAB_ADVANCED)
          && advancedWorkout == null) {
        break;
      }

      startButton.setVisibility(View.VISIBLE);
      return;
    } while (false);

    startButton.setVisibility(View.GONE);
  }

  private void updateStartGpsButtonView() {
    do {
      if (mGpsStatus.isStarted()) {
        break;
      }

      //
      if (sportWithoutGps) {
        gpsEnable.setText(org.runnerup.common.R.string.Start_tracker);
      } else if (mGpsStatus.isEnabled()) {
        gpsEnable.setText(org.runnerup.common.R.string.Start_GPS);
      } else {
        gpsEnable.setText(org.runnerup.common.R.string.Enable_GPS);
      }
      gpsEnable.setVisibility(View.VISIBLE);
      return;
    } while (false);

    gpsEnable.setVisibility(View.GONE);
  }

  private void updateGPSView() {
    if (gpsHeaderDot == null || gpsHeaderLevel == null || gpsHeaderBars == null) {
      return;
    }

    if (!mGpsStatus.isEnabled() || !mGpsStatus.isStarted() || sportWithoutGps) {
      setGpsHeaderState("Ruim", 0xFFF44336);
      return;
    }

    int satFixedCount = mGpsStatus.getSatellitesFixed();
    float accuracy = getGpsAccuracy();
    GpsLevel gpsLevel = getGpsLevel(accuracy, satFixedCount);

    switch (gpsLevel) {
      case GOOD:
        setGpsHeaderState("Excelente", 0xFF00E676);
        break;
      case ACCEPTABLE:
        setGpsHeaderState("Bom", 0xFFFFB300);
        break;
      case POOR:
      case NOT_FIXED:
      default:
        setGpsHeaderState(gpsLevel == GpsLevel.NOT_FIXED ? "Ruim" : "Ruim", 0xFFF44336);
        break;
    }

    // Keep the legacy status objects updated for accessibility/diagnostics, but the home UI
    // uses the compact GPS dashboard in the toolbar.
    int satAvailCount = mGpsStatus.getSatellitesAvailable();
    String gpsAccuracy = getGpsAccuracyString(accuracy);
    String gpsDetail =
        gpsAccuracy.isEmpty()
            ? String.format(
                getString(org.runnerup.common.R.string.GPS_status_no_accuracy),
                satFixedCount, satAvailCount)
            : String.format(
                getString(org.runnerup.common.R.string.GPS_status_accuracy),
                satFixedCount, satAvailCount, gpsAccuracy);
    gpsDetailMessage.setText(gpsDetail);

    switch (gpsLevel) {
      case NOT_FIXED:
        gpsIndicator.setImageResource(R.drawable.ic_gps_0);
        gpsDetailIndicator.setImageResource(R.drawable.ic_gps_0);
        gpsMessage.setText(org.runnerup.common.R.string.Waiting_for_GPS);
        break;
      case POOR:
        gpsIndicator.setImageResource(R.drawable.ic_gps_1);
        gpsDetailIndicator.setImageResource(R.drawable.ic_gps_1);
        gpsMessage.setText(org.runnerup.common.R.string.GPS_level_poor);
        break;
      case ACCEPTABLE:
        gpsIndicator.setImageResource(R.drawable.ic_gps_2);
        gpsDetailIndicator.setImageResource(R.drawable.ic_gps_2);
        gpsMessage.setText(org.runnerup.common.R.string.GPS_level_acceptable);
        break;
      case GOOD:
        gpsIndicator.setImageResource(R.drawable.ic_gps_3);
        gpsDetailIndicator.setImageResource(R.drawable.ic_gps_3);
        gpsMessage.setText(org.runnerup.common.R.string.GPS_level_good);
        break;
    }

    // Do not publish GPS-search/ready notifications while the home screen is open.
    // GPS status is shown in the Pace Coach dashboard. RunActivity owns the ongoing
    // notification once a workout has actually started.
  }

  private void setGpsHeaderState(String label, int color) {
    gpsHeaderLevel.setText(label);
    gpsHeaderLevel.setTextColor(color);
    gpsHeaderDot.setTextColor(color);
    if (gpsHeaderBars != null) {
      for (int i = 0; i < gpsHeaderBars.getChildCount(); i++) {
        View bar = gpsHeaderBars.getChildAt(i);
        GradientDrawable background = new GradientDrawable();
        background.setColor(color);
        background.setCornerRadius(2f);
        bar.setBackground(background);
      }
    }
  }

  private boolean updateHRView() {
    if (mTracker == null || !mTracker.isComponentConfigured(TrackerHRM.NAME)) {
      hrIndicator.setVisibility(View.GONE);
      hrMessage.setVisibility(View.GONE);
      return false;
    }
    Integer hrVal = null;
    if (mTracker.isComponentConnected(TrackerHRM.NAME)) {
      hrVal = mTracker.getCurrentHRValue();
    }
    if (hrVal != null) {
      if (!batteryLevelMessageShown) {
        batteryLevelMessageShown = true;
        notificationBatteryLevel(mTracker.getCurrentBatteryLevel());
      }
    }

    hrMessage.setText(getHRDetailString());
    hrIndicator.setVisibility(View.VISIBLE);
    if (statusDetailsShown) {
      hrMessage.setVisibility(View.VISIBLE);
    } else {
      hrMessage.setVisibility(View.GONE);
    }

    return true;
  }

  private boolean updateWearOSView() {
    if (mTracker == null || !mTracker.isComponentConfigured(TrackerWear.NAME)) {
      wearOsIndicator.setVisibility(View.GONE);
      wearOsMessage.setVisibility(View.GONE);
      return false;
    }

    wearOsIndicator.setVisibility(View.VISIBLE);

    if (!mTracker.isComponentConnected(TrackerWear.NAME)) {
      wearOsMessage.setVisibility(View.VISIBLE);
      wearOsMessage.setText("?");
    } else if (statusDetailsShown) {
      // wearOsMessage.setText(""); //todo show device name
      wearOsMessage.setVisibility(View.GONE);
    } else {
      wearOsMessage.setVisibility(View.GONE);
    }

    return true;
  }

  @Override
  public float getGpsAccuracy() {
    if (mTracker != null) {
      Location l = mTracker.getLastKnownLocation();

      if (l != null) {
        return l.getAccuracy();
      }
    }
    return -1;
  }

  public String getGpsAccuracyString(float accuracy) {
    String res = "";
    if (accuracy > 0) {
      String accString = formatter.formatElevation(Formatter.Format.TXT_LONG, accuracy);
      if (mTracker.getCurrentElevation() != null) {
        res =
            String.format(
                Locale.getDefault(),
                getString(org.runnerup.common.R.string.GPS_accuracy_elevation),
                accString,
                formatter.formatElevation(
                    Formatter.Format.TXT_LONG, mTracker.getCurrentElevation()));
      } else {
        res =
            String.format(
                Locale.getDefault(),
                getString(org.runnerup.common.R.string.GPS_accuracy_no_elevation),
                accString);
      }
    }
    if (BuildConfig.DEBUG && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      // Extra info in debug builds
      if (mTracker != null) {
        Location l = mTracker.getLastKnownLocation();

        if (l != null) {
          res +=
              String.format(
                  Locale.getDefault(),
                  " [%1$s, %2$s/%3$s, %4$.1f/%5$.1f deg]",
                  formatter.formatElevation(
                      Formatter.Format.TXT_LONG, l.getVerticalAccuracyMeters()),
                  formatter.formatSpeed(Formatter.Format.TXT_SHORT, l.getSpeed()),
                  formatter.formatSpeed(
                      Formatter.Format.TXT_LONG, l.getSpeedAccuracyMetersPerSecond()),
                  l.getBearing(),
                  l.getBearingAccuracyDegrees());
        }
      }
    }
    return res;
  }

  private String getHRDetailString() {
    StringBuilder str = new StringBuilder();

    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(requireContext());
    final String btDeviceName = prefs.getString(getString(R.string.pref_bt_name), null);

    if (btDeviceName != null) {
      str.append(btDeviceName);
    } else if (MockHRProvider.NAME.contentEquals(
        prefs.getString(getString(R.string.pref_bt_provider), ""))) {
      str.append("mock: ").append(prefs.getString(getString(R.string.pref_bt_address), "???"));
    }

    if (mTracker.isComponentConnected(TrackerHRM.NAME)) {
      Integer hrVal = mTracker.getCurrentHRValue();
      if (hrVal != null) {
        str.append(" ").append(hrVal);
        Integer batteryLevel = mTracker.getCurrentBatteryLevel();

        if (batteryLevel != HRProvider.BATTERY_LEVEL_UNAVAILABLE) {
          str.append(" ").append(batteryLevel).append("%");
        }
      }
    }
    return str.toString();
  }

  private boolean mIsBound = false;
  private final ServiceConnection mConnection =
      new ServiceConnection() {
        public void onServiceConnected(ComponentName className, IBinder service) {
          // This is called when the connection with the service has been
          // established, giving us the service object we can use to
          // interact with the service. Because we have bound to a explicit
          // service that we know is running in our own process, we can
          // cast its IBinder to a concrete class and directly access it.
          mTracker = ((Tracker.LocalBinder) service).getService();
          // Tell the user about this for our demo.
          StartFragment.this.onGpsTrackerBound();
          if (mTracker != null) {
            mTracker.registerTrackerStateListener(trackerStateListener);
          }
        }

        public void onServiceDisconnected(ComponentName className) {
          // This is called when the connection with the service has been
          // unexpectedly disconnected -- that is, its process crashed.
          // Because it is running in our same process, we should never
          // see this happen.
          if (mTracker != null) {
            mTracker.unregisterTrackerStateListener(trackerStateListener);
          }
          mTracker = null;
        }
      };

  private void bindGpsTracker() {
    // Establish a connection with the service. We use an explicit
    // class name because we want a specific service implementation that
    // we know will be running in our own process (and thus won't be
    // supporting component replacement by other applications).
    mIsBound =
        requireActivity()
            .getApplicationContext()
            .bindService(
                new Intent(requireContext(), Tracker.class), mConnection, Context.BIND_AUTO_CREATE);
  }

  private void unbindGpsTracker() {
    if (mIsBound) {
      // Detach our existing connection.
      requireActivity().getApplicationContext().unbindService(mConnection);
      mIsBound = false;
    }
    if (mTracker != null) {
      mTracker.unregisterTrackerStateListener(trackerStateListener);
    }
    mTracker = null;
  }

  // TODO: Use Activity Result API
  @Override
  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    registerStartEventListener();

    if (data != null) {
      if (data.getStringExtra("url") != null)
        Log.d(
            getClass().getName(), "data.getStringExtra(\"url\") => " + data.getStringExtra("url"));
      if (data.getStringExtra("ex") != null)
        Log.d(getClass().getName(), "data.getStringExtra(\"ex\") => " + data.getStringExtra("ex"));
      if (data.getStringExtra("obj") != null)
        Log.d(
            getClass().getName(), "data.getStringExtra(\"obj\") => " + data.getStringExtra("obj"));
    }
    if (requestCode == START_ACTIVITY) {
      runActivityPending = false;
      if (!mIsBound || mTracker == null) {
        bindGpsTracker();
      } else {
        onGpsTrackerBound();
      }
    } else {
      advancedWorkoutListAdapter.reload();
    }
    updateView();
  }

  @Override
  public void onTick() {
    updateView();
    updateBasicPreview();
    updateIntervalPreview();
  }

  private final OnCloseDialogListener simpleTargetTypeClick =
      (spinner, ok) -> {
        if (ok) {
          updateTargetView();
          updateBasicPreview();
        }
      };

  private void updateTargetView() {
    Dimension dim = Dimension.valueOf(simpleTargetType.getValueInt());

    simpleTargetTime.setEnabled(false);
    simpleTargetDistance.setEnabled(false);
    simpleTargetPaceMin.setEnabled(false);
    simpleTargetPaceValue.setEnabled(false);

    simpleTargetTime.setVisibility(View.GONE);
    simpleTargetDistance.setVisibility(View.GONE);
    viewVisibility(R.id.basic_target_time_helper, View.GONE);
    viewVisibility(R.id.basic_target_time_example, View.GONE);
    viewVisibility(R.id.basic_target_distance_helper, View.GONE);
    viewVisibility(R.id.basic_target_distance_example, View.GONE);
    viewVisibility(R.id.basic_target_divider, View.VISIBLE);
    simpleTargetPaceMin.setVisibility(View.VISIBLE);
    simpleTargetPaceValue.setVisibility(View.VISIBLE);
    viewVisibility(R.id.basic_pace_title, View.VISIBLE);
    viewVisibility(R.id.basic_pace_fields, View.VISIBLE);

    if (dim == Dimension.TIME) {
      simpleTargetTime.setEnabled(true);
      simpleTargetTime.setVisibility(View.VISIBLE);
      viewVisibility(R.id.basic_target_time_helper, View.VISIBLE);
      viewVisibility(R.id.basic_target_time_example, View.VISIBLE);
    } else if (dim == Dimension.DISTANCE) {
      simpleTargetDistance.setEnabled(true);
      simpleTargetDistance.setVisibility(View.VISIBLE);
      viewVisibility(R.id.basic_target_distance_helper, View.VISIBLE);
      viewVisibility(R.id.basic_target_distance_example, View.VISIBLE);
    } else {
      // Old preferences may contain unsupported free-run target values.
      simpleTargetType.setValue(DB.DIMENSION.TIME);
      simpleTargetTime.setEnabled(true);
      simpleTargetTime.setVisibility(View.VISIBLE);
    }
    simpleTargetPaceMin.setEnabled(true);
    simpleTargetPaceValue.setEnabled(true);
}

  private void updateBasicPreview() {
    View root = getView();
    if (root == null) return;

    TextView distanceView = root.findViewById(R.id.basic_summary_distance);
    TextView timeView = root.findViewById(R.id.basic_summary_time);
    LinearLayout freeStep = root.findViewById(R.id.basic_free_step);
    if (distanceView == null || timeView == null || freeStep == null) return;

    Dimension dim = Dimension.valueOf(simpleTargetType.getValueInt());
    if (dim != Dimension.TIME && dim != Dimension.DISTANCE) dim = Dimension.TIME;

    double paceFast = SafeParse.parseSeconds(
        simpleTargetPaceMin.getValue() == null ? "00:05:10" : simpleTargetPaceMin.getValue().toString(),
        5 * 60 + 10);
    double paceSlow = SafeParse.parseSeconds(
        simpleTargetPaceValue.getValue() == null ? "00:06:40" : simpleTargetPaceValue.getValue().toString(),
        6 * 60 + 40);
    if (paceFast <= 0) paceFast = 5 * 60 + 10;
    if (paceSlow <= 0) paceSlow = 6 * 60 + 40;
    if (paceSlow < paceFast) {
      double tmp = paceFast; paceFast = paceSlow; paceSlow = tmp;
    }
    double paceAverage = (paceFast + paceSlow) / 2.0;
    double distanceKm;
    double seconds;
    if (dim == Dimension.TIME) {
      seconds = SafeParse.parseSeconds(
          simpleTargetTime.getValue() == null ? "00:30:00" : simpleTargetTime.getValue().toString(),
          30 * 60);
      if (seconds < 0) seconds = 0;
      distanceKm = seconds / paceAverage;
    } else {
      double meters = SafeParse.parseDouble(
          simpleTargetDistance.getValue() == null ? "5000" : simpleTargetDistance.getValue().toString(),
          5000);
      if (meters < 0) meters = 0;
      distanceKm = meters / 1000.0;
      seconds = distanceKm * paceAverage;
    }

    String distanceText = formatDistanceKm(distanceKm);
    String timeText = formatDurationShort(seconds);
    distanceView.setText(distanceText);
    timeView.setText(timeText);
    // The approved layout must always show the complete value.  Keep the
    // normal visual size for short values, but reduce the font only when
    // the actual available width is insufficient (e.g. "42,0 km").
    distanceView.setEllipsize(null);
    timeView.setEllipsize(null);

    // Treino Livre uses exactly the same block template as Treino Intervalado.
    // Only the content changes: one continuous block named "Treino Constante".
    freeStep.removeAllViews();
    addIntervalPreviewStep(freeStep, 1, "▶", R.color.sportRunning,
        "Treino Constante - " + selectedRhythm(simpleTargetRhythm, "Constante"),
        distanceText + " • Ritmo " + formatPaceShort(paceFast) + "–" + formatPaceShort(paceSlow));

    distanceView.post(() -> fitPreviewValue(distanceView, 24f, 16f));
    timeView.post(() -> fitPreviewValue(timeView, 20f, 16f));
  }

  private void fitPreviewValue(TextView view, float maxSp, float minSp) {
    if (view == null || view.getWidth() <= 0) return;

    final int available = Math.max(1, view.getWidth()
        - view.getPaddingLeft() - view.getPaddingRight());
    float size = maxSp;
    view.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, size);

    // Measure with the real font currently used by the TextView.
    while (size > minSp && view.getPaint().measureText(view.getText().toString()) > available) {
      size -= 0.5f;
      view.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, size);
    }

    // Never allow the value to be replaced by an ellipsis.
    view.setEllipsize(null);
    view.setMaxLines(1);
  }

  private String formatPaceShort(double secondsPerKm) {
    long total = Math.max(0, Math.round(secondsPerKm));
    long minutes = total / 60;
    long seconds = total % 60;
    return String.format(Locale.getDefault(), "%d:%02d", minutes, seconds);
  }

  private String formatDistanceKm(double km) {
    return String.format(Locale.getDefault(), "%.1f km", Math.max(0, km));
  }

  private String formatDurationShort(double seconds) {
    long total = Math.max(0, Math.round(seconds));

    // Pace Coach duration display rule:
    // zero -> 00:00; under one hour -> MM:SS min;
    // one hour or more -> HhMM.
    // Examples: 00:30 -> 00:30 min, 00:59 -> 00:59 min,
    // 01:00 -> 1h00, 01:30 -> 1h30.
    if (total == 0) return "00:00";
    if (total < 3600) {
      long minutes = total / 60;
      long secs = total % 60;
      return String.format(Locale.getDefault(), "%02d:%02d min", minutes, secs);
    }

    long hours = total / 3600;
    long minutes = (total % 3600) / 60;
    return String.format(Locale.getDefault(), "%dh%02d", hours, minutes);
  }

  private void updateIntervalPreview() {
    View root = getView();
    if (root == null || intervalType == null || intervalRestType == null || intervalWarmupType == null || intervalCooldownType == null) return;
    LinearLayout container = root.findViewById(R.id.interval_preview_container);
    if (container == null) return;
    container.removeAllViews();

    int repetitions = 5;
    if (intervalRepetitions != null) {
      repetitions = Math.max(1, SafeParse.parseInt(String.valueOf(intervalRepetitions.getValue()), 5));
    }

    int n = 1;
    addIntervalPreviewStep(container, n++, "↗", R.color.stepWarmup,
        "Aquecimento - " + selectedRhythm(intervalWarmupRhythm, "Constante"),
        intervalValue(intervalWarmupType, intervalWarmupTime, intervalWarmupDistance)
            + " • Ritmo " + normalizePace(intervalWarmupPaceMin.getValue()) + "–" + normalizePace(intervalWarmupPaceMax.getValue()));
    addIntervalPreviewStep(container, n++, "×", R.color.colorAccent, "Repetições",
        repetitions + "x • Intervalo + Recuperação");
    addIntervalPreviewStep(container, n++, "▶", R.color.sportRunning,
        "Intervalo - " + selectedRhythm(intervalRhythm, "Rápido"),
        intervalValue(intervalType, intervalTime, intervalDistance) + " • Ritmo "
            + normalizePace(intervalPaceMin.getValue()) + "–" + normalizePace(intervalPaceMax.getValue()));
    addIntervalPreviewStep(container, n++, "■", R.color.stepRecovery,
        "Recuperação - " + selectedRhythm(intervalRestRhythm, "Devagar"),
        intervalValue(intervalRestType, intervalRestTime, intervalRestDistance) + " • Ritmo "
            + normalizePace(intervalRestPaceMin.getValue()) + "–" + normalizePace(intervalRestPaceMax.getValue()));
    addIntervalPreviewStep(container, n, "↘", R.color.stepRecovery,
        "Desaquecimento - " + selectedRhythm(intervalCooldownRhythm, "Constante"),
        intervalValue(intervalCooldownType, intervalCooldownTime, intervalCooldownDistance)
            + " • Ritmo " + normalizePace(intervalCooldownPaceMin.getValue()) + "–" + normalizePace(intervalCooldownPaceMax.getValue()));

    updateIntervalSummary(repetitions);
  }

  private String selectedRhythm(TitleSpinner spinner, String fallback) {
    if (spinner == null) return fallback;

    // TitleSpinner may expose the persisted numeric value (0/1/2) rather
    // than the displayed label. Always convert it to the user-facing name.
    try {
      int value = spinner.getValueInt();
      switch (value) {
        case 0: return "Devagar";
        case 1: return "Constante";
        case 2: return "Rápido";
        default: break;
      }
    } catch (Exception ignored) {
      // Fall through to the textual value for older spinner implementations.
    }

    if (spinner.getValue() == null) return fallback;
    String value = spinner.getValue().toString().trim();
    if ("0".equals(value)) return "Devagar";
    if ("1".equals(value)) return "Constante";
    if ("2".equals(value)) return "Rápido";
    return value.isEmpty() ? fallback : value;
  }

  private void updateIntervalSummary(int repetitions) {
    View root = getView();
    if (root == null) return;
    TextView distanceView = root.findViewById(R.id.interval_summary_distance);
    TextView timeView = root.findViewById(R.id.interval_summary_time);
    if (distanceView == null || timeView == null) return;

    double warmPace = averagePace(intervalWarmupPaceMin, intervalWarmupPaceMax, 6 * 60 + 30);
    double intervalPace = averagePace(intervalPaceMin, intervalPaceMax, 4 * 60 + 45);
    double restPace = averagePace(intervalRestPaceMin, intervalRestPaceMax, 6 * 60 + 20);
    double cooldownPace = averagePace(intervalCooldownPaceMin, intervalCooldownPaceMax, 6 * 60 + 30);

    double[] warm = intervalSegment(intervalWarmupType, intervalWarmupTime, intervalWarmupDistance, warmPace);
    double[] effort = intervalSegment(intervalType, intervalTime, intervalDistance, intervalPace);
    double[] recovery = intervalSegment(intervalRestType, intervalRestTime, intervalRestDistance, restPace);
    double[] cooldown = intervalSegment(intervalCooldownType, intervalCooldownTime, intervalCooldownDistance, cooldownPace);

    double totalSeconds = warm[0] + repetitions * (effort[0] + recovery[0]) + cooldown[0];
    double totalDistanceKm = warm[1] + repetitions * (effort[1] + recovery[1]) + cooldown[1];

    distanceView.setText(formatDistanceKm(totalDistanceKm));
    timeView.setText(formatDurationShort(totalSeconds));
    distanceView.post(() -> fitPreviewValue(distanceView, 24f, 16f));
    timeView.post(() -> fitPreviewValue(timeView, 20f, 16f));
  }

  private double averagePace(TitleSpinner min, TitleSpinner max, double fallback) {
    double fast = SafeParse.parseSeconds(min == null || min.getValue() == null ? "" : min.getValue().toString(), Math.round(fallback));
    double slow = SafeParse.parseSeconds(max == null || max.getValue() == null ? "" : max.getValue().toString(), Math.round(fallback));
    if (fast <= 0) fast = fallback;
    if (slow <= 0) slow = fallback;
    if (slow < fast) { double t = fast; fast = slow; slow = t; }
    return (fast + slow) / 2.0;
  }

  /** Returns {seconds, distanceKm}. */
  private double[] intervalSegment(TitleSpinner type, TitleSpinner time, TitleSpinner distance, double paceSecondsPerKm) {
    if (type == null) return new double[] {0, 0};
    if (type.getValueInt() == 0) {
      double seconds = SafeParse.parseSeconds(time == null || time.getValue() == null ? "" : time.getValue().toString(), 0);
      return new double[] {seconds, seconds / Math.max(1, paceSecondsPerKm)};
    }
    double km = SafeParse.parseDouble(distance == null || distance.getValue() == null ? "0" : distance.getValue().toString(), 0) / 1000.0;
    return new double[] {km * paceSecondsPerKm, km};
  }

  private String intervalValue(TitleSpinner type, TitleSpinner time, TitleSpinner distance) {
    if (type == null) return "Livre";
    if (type.getValueInt() == 0) {
      double seconds = SafeParse.parseSeconds(
          time == null || time.getValue() == null ? "00:30:00" : time.getValue().toString(),
          30 * 60);
      return formatDurationShort(seconds);
    }

    double meters = SafeParse.parseDouble(
        distance == null || distance.getValue() == null ? "2000" : distance.getValue().toString(),
        2000);
    return formatDistanceKm(meters / 1000.0);
  }

  private void addIntervalPreviewStep(LinearLayout container, int number, String symbol, int colorRes, String title, String detail) {
    LinearLayout card = new LinearLayout(requireContext());
    card.setOrientation(LinearLayout.HORIZONTAL);
    card.setGravity(android.view.Gravity.CENTER_VERTICAL);
    card.setPadding(dp(12), dp(10), dp(12), dp(10));
    card.setBackgroundResource(R.drawable.bg_coach_step);
    LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    cp.bottomMargin = dp(8);
    card.setLayoutParams(cp);

    TextView badge = new TextView(requireContext());
    badge.setText(String.valueOf(number));
    badge.setGravity(android.view.Gravity.CENTER);
    badge.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorText));
    badge.setTextSize(12);
    badge.setTypeface(null, android.graphics.Typeface.BOLD);
    badge.setBackgroundResource(R.drawable.bg_coach_step_number);
    card.addView(badge, new LinearLayout.LayoutParams(dp(34), dp(34)));

    TextView ico = new TextView(requireContext());
    ico.setText(symbol);
    ico.setTextColor(ContextCompat.getColor(requireContext(), colorRes));
    ico.setTextSize(20);
    ico.setGravity(android.view.Gravity.CENTER);
    LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(34), dp(34));
    ip.setMargins(dp(8), 0, dp(6), 0);
    card.addView(ico, ip);

    LinearLayout body = new LinearLayout(requireContext());
    body.setOrientation(LinearLayout.VERTICAL);
    body.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
    TextView t = new TextView(requireContext());
    t.setText(title);
    t.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorText));
    t.setTextSize(15);
    t.setTypeface(null, android.graphics.Typeface.BOLD);
    body.addView(t);
    TextView d = new TextView(requireContext());
    d.setText(detail);
    d.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorTextSecondary));
    d.setTextSize(12);
    body.addView(d);
    card.addView(body);
    container.addView(card);
  }

  private String normalizePace(CharSequence value) {
    if (value == null) return "00:00";
    String s = value.toString().trim();

    // Pace Coach stores pace internally as seconds/km in several interval
    // controls. The preview must always present it exactly like Treino Livre:
    // minutes:seconds per km, never raw seconds.
    if (s.matches("\\d+(?:[.,]\\d+)?")) {
      double seconds = SafeParse.parseDouble(s.replace(',', '.'), 0);
      return formatPaceShort(seconds);
    }

    if (s.matches("\\d{2}:\\d{2}:\\d{2}")) return s.substring(3);
    if (s.matches("\\d{1}:\\d{2}")) return "0" + s;
    if (s.matches("\\d{2}:\\d{2}")) return s;
    return s;
  }

  private void viewVisibility(int id, int visibility) {
    View v = getView();
    if (v != null) {
      View target = v.findViewById(id);
      if (target != null) target.setVisibility(visibility);
    }
  }

  private void updateIntervalMeasureHelp(
      int typeValue,
      View timeView,
      View distanceView,
      int timeHelperId,
      int timeExampleId,
      int distanceHelperId,
      int distanceExampleId) {
    View root = getView();
    if (root == null) return;

    boolean time = typeValue == 0;
    View timeHelper = root.findViewById(timeHelperId);
    View timeExample = root.findViewById(timeExampleId);
    View distanceHelper = root.findViewById(distanceHelperId);
    View distanceExample = root.findViewById(distanceExampleId);

    if (timeHelper != null) timeHelper.setVisibility(time ? View.VISIBLE : View.GONE);
    if (timeExample != null) timeExample.setVisibility(time ? View.VISIBLE : View.GONE);
    if (distanceHelper != null) distanceHelper.setVisibility(time ? View.GONE : View.VISIBLE);
    if (distanceExample != null) distanceExample.setVisibility(time ? View.GONE : View.VISIBLE);
  }

  private final OnSetValueListener intervalTypeSetValue =
      new OnSetValueListener() {

        @Override
        public String preSetValue(String newValue) throws IllegalArgumentException {
          return newValue;
        }

        @Override
        public int preSetValue(int newValue) throws IllegalArgumentException {
          boolean time = (newValue == 0);
          intervalTime.setVisibility(time ? View.VISIBLE : View.GONE);
          intervalDistance.setVisibility(time ? View.GONE : View.VISIBLE);
          updateIntervalMeasureHelp(
              newValue,
              intervalTime,
              intervalDistance,
              R.id.interval_time_helper,
              R.id.interval_time_example,
              R.id.interval_distance_helper,
              R.id.interval_distance_example);
          return newValue;
        }
      };

  private final OnSetValueListener intervalRestTypeSetValue =
      new OnSetValueListener() {

        @Override
        public String preSetValue(String newValue) throws IllegalArgumentException {
          return newValue;
        }

        @Override
        public int preSetValue(int newValue) throws IllegalArgumentException {
          boolean time = (newValue == 0);
          intervalRestTime.setVisibility(time ? View.VISIBLE : View.GONE);
          intervalRestDistance.setVisibility(time ? View.GONE : View.VISIBLE);
          intervalRestPaceMin.setVisibility(View.VISIBLE);
          intervalRestPaceMax.setVisibility(View.VISIBLE);
          updateIntervalMeasureHelp(
              newValue,
              intervalRestTime,
              intervalRestDistance,
              R.id.interval_rest_time_helper,
              R.id.interval_rest_time_example,
              R.id.interval_rest_distance_helper,
              R.id.interval_rest_distance_example);
          return newValue;
        }
      };

  private final OnSetValueListener intervalWarmupTypeSetValue =
      new OnSetValueListener() {
        @Override
        public String preSetValue(String newValue) throws IllegalArgumentException {
          return newValue;
        }

        @Override
        public int preSetValue(int newValue) throws IllegalArgumentException {
          boolean time = newValue == 0;
          intervalWarmupTime.setVisibility(time ? View.VISIBLE : View.GONE);
          intervalWarmupDistance.setVisibility(time ? View.GONE : View.VISIBLE);
          updateIntervalMeasureHelp(
              newValue,
              intervalWarmupTime,
              intervalWarmupDistance,
              R.id.interval_warmup_time_helper,
              R.id.interval_warmup_time_example,
              R.id.interval_warmup_distance_helper,
              R.id.interval_warmup_distance_example);
          return newValue;
        }
      };

  private final OnSetValueListener intervalCooldownTypeSetValue =
      new OnSetValueListener() {
        @Override
        public String preSetValue(String newValue) throws IllegalArgumentException {
          return newValue;
        }

        @Override
        public int preSetValue(int newValue) throws IllegalArgumentException {
          boolean time = newValue == 0;
          intervalCooldownTime.setVisibility(time ? View.VISIBLE : View.GONE);
          intervalCooldownDistance.setVisibility(time ? View.GONE : View.VISIBLE);
          updateIntervalMeasureHelp(
              newValue,
              intervalCooldownTime,
              intervalCooldownDistance,
              R.id.interval_cooldown_time_helper,
              R.id.interval_cooldown_time_example,
              R.id.interval_cooldown_distance_helper,
              R.id.interval_cooldown_distance_example);
          return newValue;
        }
      };

  private void openCurrentAdvancedWorkoutForEdit() {
    if (advancedWorkoutSpinner == null) return;

    Object value = advancedWorkoutSpinner.getValue();
    String name = value == null ? "" : value.toString().trim();

    // The preview can be rendered before the serialized workout is loaded.
    // Resolve the selected workout here as well so EDITAR never becomes a no-op.
    if (name.isEmpty() || "Escolha um treino".equalsIgnoreCase(name)) {
      SharedPreferences pref =
          PreferenceManager.getDefaultSharedPreferences(requireActivity().getApplicationContext());
      name = pref.getString(getResources().getString(R.string.pref_advanced_workout), "");
    }

    if (name.isEmpty() || "Escolha um treino".equalsIgnoreCase(name)) {
      if (advancedWorkoutListAdapter != null && advancedWorkoutListAdapter.getCount() > 0) {
        Object first = advancedWorkoutListAdapter.getItem(0);
        if (first != null) name = first.toString().trim();
      }
    }

    if (name.isEmpty() || "Escolha um treino".equalsIgnoreCase(name)) return;

    // Keep the selected workout synchronized before opening the editor.
    loadAdvanced(name);
    PreferenceManager.getDefaultSharedPreferences(requireActivity().getApplicationContext())
        .edit()
        .putString(getResources().getString(R.string.pref_advanced_workout), name)
        .apply();
    advancedWorkoutSpinner.setValue(name);

    Intent intent = new Intent(requireContext(), CreateAdvancedWorkout.class);
    intent.putExtra(ManageWorkoutsActivity.WORKOUT_NAME, name);
    intent.putExtra(ManageWorkoutsActivity.WORKOUT_EDIT_MODE, true);
    startActivity(intent);
  }

  private void renderAdvancedPreview() {
    if (getView() == null) return;
    LinearLayout container = getView().findViewById(R.id.advanced_preview_container);
    if (container == null) return;

    TextView total = getView().findViewById(R.id.advanced_summary_distance);
    TextView time = getView().findViewById(R.id.advanced_summary_time);

    if (advancedWorkout == null || advancedWorkout.getStepList().isEmpty()) {
      if (total != null) total.setText("0,0 km");
      if (time != null) time.setText("00:00 min");
      container.removeAllViews();
      TextView empty = new TextView(requireContext());
      empty.setText("Crie ou selecione um treino para visualizar os blocos aqui.");
      empty.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorTextSecondary));
      empty.setTextSize(13);
      empty.setPadding(dp(4), dp(8), dp(4), dp(8));
      container.addView(empty);
      return;
    }

    List<StepListEntry> entries = advancedWorkout.getStepList();
    // Totals must be calculated from the real hierarchy, not the flattened preview list.
    // A RepeatStep is a container: every child inside it contributes repeatCount times.
    if (total != null) total.setText(buildAdvancedDistanceSummary(advancedWorkout));
    if (time != null) time.setText(buildAdvancedTimeSummary(advancedWorkout));

    container.removeAllViews();
    int shown = 0;
    for (StepListEntry entry : entries) {
      String title = previewIntensity(entry.step());
      String detail = formatStepDuration(entry.step());
      String paceText = formatStepTarget(entry.step());
      if (!paceText.isEmpty()) detail += "  •  " + paceText;

      String symbol = "•";
      int colorRes = R.color.colorAccent;
      switch (entry.step().getIntensity()) {
        case WARMUP:
          symbol = "↗"; colorRes = R.color.stepWarmup; break;
        case ACTIVE:
          symbol = "▶"; colorRes = R.color.sportRunning; break;
        case RECOVERY:
          symbol = "■"; colorRes = R.color.stepRecovery; break;
        case COOLDOWN:
          symbol = "↘"; colorRes = R.color.stepCooldown; break;
        case REPEAT:
          symbol = "×"; colorRes = R.color.colorAccent; break;
        case RESTING:
          symbol = "■"; colorRes = R.color.stepResting; break;
        default:
          break;
      }
      addIntervalPreviewStep(container, shown + 1, symbol, colorRes, title, detail);
      shown++;
    }
  }

  private String previewIntensity(org.runnerup.workout.Step step) {
    if (step == null) return "Etapa";
    String name = step.getName();
    if (name != null && !name.trim().isEmpty()) return name.trim();
    switch (step.getIntensity()) {
      case WARMUP: return "Aquecimento";
      case ACTIVE: return "Esforço";
      case RECOVERY: return "Recuperação";
      case COOLDOWN: return "Desaquecimento";
      case REPEAT: return "Repetições";
      case RESTING: return "Descanso";
      default: return "Etapa";
    }
  }

  private String formatStepDuration(org.runnerup.workout.Step step) {
    if (step == null) return "Livre";
    if (step instanceof org.runnerup.workout.RepeatStep) {
      return "Repetir " + ((org.runnerup.workout.RepeatStep) step).getRepeatCount() + "x";
    }
    if (step.getDurationType() == null) return "Livre";
    Dimension type = step.getDurationType();
    double value = step.getDurationValue();
    if (type == Dimension.TIME) return formatDurationShort(value);
    if (type == Dimension.DISTANCE) return formatDistanceKm(value / 1000.0);
    return "Livre";
  }

  private String formatStepTarget(org.runnerup.workout.Step step) {
    if (step == null || step.getTargetType() != Dimension.PACE || step.getTargetValue() == null) return "";
    double min = step.getTargetValue().minValue;
    double max = step.getTargetValue().maxValue;
    if (min <= 0 || max <= 0) return "";
    // Structured workout pace targets are stored in seconds per meter.
    // The Pace Coach UI displays seconds per kilometer.
    return "Ritmo " + formatPaceShort(min * 1000.0) + "-" + formatPaceShort(max * 1000.0);
  }

  /**
   * Repairs workouts created by the old structured-distance bug, where the
   * already-meter-based picker value was multiplied by 1000 a second time.
   * A value of 1,000,000 m therefore represents the intended 1,000 m (1.0 km).
   * Only the clearly corrupted >=1,000 km values are migrated; normal road
   * distances remain untouched.
   */
  private boolean normalizeLegacyStructuredDistances(Workout workout) {
    if (workout == null) return false;
    boolean changed = false;
    for (StepListEntry entry : workout.getStepList()) {
      org.runnerup.workout.Step step = entry.step();
      if (step.getDurationType() == Dimension.DISTANCE) {
        double meters = step.getDurationValue();
        if (meters >= 1000000.0 && Math.abs(meters % 1000.0) < 0.001) {
          step.setDurationValue(meters / 1000.0);
          changed = true;
        }
      }
    }
    return changed;
  }

  /**
   * Calculates the effective duration of a structured workout hierarchy.
   * RepeatStep is a container, so its children are multiplied by repeatCount.
   * Pace values are stored as seconds per meter.
   */
  private double estimateStepTimeSeconds(org.runnerup.workout.Step step) {
    if (step == null) return 0.0;
    if (step instanceof org.runnerup.workout.RepeatStep) {
      org.runnerup.workout.RepeatStep repeat =
          (org.runnerup.workout.RepeatStep) step;
      double blockSeconds = 0.0;
      for (org.runnerup.workout.Step child : repeat.getSteps()) {
        blockSeconds += estimateStepTimeSeconds(child);
      }
      return blockSeconds * Math.max(0, repeat.getRepeatCount());
    }

    Dimension type = step.getDurationType();
    double value = step.getDurationValue();
    if (type == Dimension.TIME) {
      return Math.max(0.0, value);
    }
    if (type == Dimension.DISTANCE
        && step.getTargetType() == Dimension.PACE
        && step.getTargetValue() != null) {
      double paceAverage =
          (step.getTargetValue().minValue + step.getTargetValue().maxValue) / 2.0;
      if (paceAverage > 0) return Math.max(0.0, value * paceAverage);
    }
    return 0.0;
  }

  /**
   * Calculates the effective distance of a structured workout hierarchy.
   * RepeatStep is a container, so its children are multiplied by repeatCount.
   * Pace values are stored as seconds per meter.
   */
  private double estimateStepDistanceMeters(org.runnerup.workout.Step step) {
    if (step == null) return 0.0;
    if (step instanceof org.runnerup.workout.RepeatStep) {
      org.runnerup.workout.RepeatStep repeat =
          (org.runnerup.workout.RepeatStep) step;
      double blockMeters = 0.0;
      for (org.runnerup.workout.Step child : repeat.getSteps()) {
        blockMeters += estimateStepDistanceMeters(child);
      }
      return blockMeters * Math.max(0, repeat.getRepeatCount());
    }

    Dimension type = step.getDurationType();
    double value = step.getDurationValue();
    if (type == Dimension.DISTANCE) {
      return Math.max(0.0, value);
    }
    if (type == Dimension.TIME
        && step.getTargetType() == Dimension.PACE
        && step.getTargetValue() != null) {
      double paceAverage =
          (step.getTargetValue().minValue + step.getTargetValue().maxValue) / 2.0;
      if (paceAverage > 0) return Math.max(0.0, value / paceAverage);
    }
    return 0.0;
  }

  private String buildAdvancedTimeSummary(org.runnerup.workout.Workout workout) {
    double seconds = 0.0;
    if (workout != null) {
      for (org.runnerup.workout.Step step : workout.getSteps()) {
        seconds += estimateStepTimeSeconds(step);
      }
    }
    return formatDurationShort(seconds);
  }

  private String buildAdvancedDistanceSummary(org.runnerup.workout.Workout workout) {
    double meters = 0.0;
    if (workout != null) {
      for (org.runnerup.workout.Step step : workout.getSteps()) {
        meters += estimateStepDistanceMeters(step);
      }
    }
    if (meters <= 0) return "Distância configurada por tempo ou livre";
    return formatter.format(Formatter.Format.TXT_SHORT, Dimension.DISTANCE, meters);
  }

  private int dp(int value) {
    return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
  }

  private void loadAdvanced(String name) {
    Context ctx = requireActivity().getApplicationContext();
    if (name == null) {
      SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
      name = pref.getString(getResources().getString(R.string.pref_advanced_workout), "");
    }
    advancedWorkout = null;
    if ("".contentEquals(name)) {
      renderAdvancedPreview();
      return;
    }
    try {
      advancedWorkout = WorkoutSerializer.readFile(ctx, name);
      if (normalizeLegacyStructuredDistances(advancedWorkout)) {
        WorkoutSerializer.writeFile(ctx, name, advancedWorkout);
      }
      advancedWorkoutStepsAdapter.steps = advancedWorkout.getStepList();
      advancedWorkoutStepsAdapter.notifyDataSetChanged();
      renderAdvancedPreview();
    } catch (Exception ex) {
      ex.printStackTrace();
      new AlertDialog.Builder(requireActivity())
          .setTitle(getString(org.runnerup.common.R.string.Failed_to_load_workout))
          .setMessage(ex.toString())
          .setPositiveButton(org.runnerup.common.R.string.OK, (dialog, which) -> dialog.dismiss())
          .show();
    }
  }

  @Override
  public int getSatellitesAvailable() {
    return mGpsStatus.getSatellitesAvailable();
  }

  @Override
  public int getSatellitesFixed() {
    return mGpsStatus.getSatellitesFixed();
  }

  final class WorkoutStepsAdapter extends BaseAdapter {

    List<StepListEntry> steps = new ArrayList<>();

    @Override
    public int getCount() {
      return steps.size();
    }

    @Override
    public Object getItem(int position) {
      return steps.get(position);
    }

    @Override
    public long getItemId(int position) {
      return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      StepListEntry entry = steps.get(position);
      StepButton button =
          (convertView instanceof StepButton)
              ? (StepButton) convertView
              : new StepButton(requireContext(), null);
      button.setStep(entry.step());

      float pxToDp = getResources().getDisplayMetrics().density;
      button.setPadding((int) (entry.level() * 8 * pxToDp + 0.5f), 0, 0, 0);
      button.setOnChangedListener(onWorkoutChanged);
      return button;
    }
  }

  private final Runnable onWorkoutChanged =
      () -> {
        String name = advancedWorkoutSpinner.getValue().toString();
        if (advancedWorkout != null) {
          Context ctx = requireActivity().getApplicationContext();
          try {
            WorkoutSerializer.writeFile(ctx, name, advancedWorkout);
          } catch (Exception ex) {
            new AlertDialog.Builder(requireContext())
                .setTitle(org.runnerup.common.R.string.Failed_to_load_workout)
                .setMessage(ex.toString())
                .setPositiveButton(
                    org.runnerup.common.R.string.OK, (dialog, which) -> dialog.dismiss())
                .show();
          }
        }
      };

  private final OnSetValueListener onSetTimeValidator =
      new OnSetValueListener() {

        @Override
        public String preSetValue(String newValue) throws IllegalArgumentException {

          if (WorkoutBuilder.validateSeconds(newValue)) return newValue;

          throw new IllegalArgumentException("Unable to parse time value: " + newValue);
        }

        @Override
        public int preSetValue(int newValue) throws IllegalArgumentException {
          return newValue;
        }
      };

  private final ValueModel.ChangeListener<TrackerState> trackerStateListener =
      new ValueModel.ChangeListener<>() {
        @Override
        public void onValueChanged(
            ValueModel<TrackerState> instance, TrackerState oldValue, TrackerState newValue) {
          onTick();

          if (coachStartPending
              && newValue == TrackerState.CONNECTED
              && !runActivityPending) {
            coachStartPending = false;
            startWorkout();
          }
        }
      };
}
