package com.pacecoach.v1.run

import kotlin.math.abs

object CoachMessageFormatter {

    fun formatPace(secondsPerKm: Int): String {
        val min = secondsPerKm / 60
        val sec = secondsPerKm % 60
        return String.format("%d:%02d", min, sec)
    }

    fun targetMessage(
        paceSeconds: Int,
        targetSeconds: Int,
        marginSeconds: Int
    ): String {
        val pace = formatPace(paceSeconds)
        val diff = paceSeconds - targetSeconds

        return when {
            abs(diff) <= marginSeconds ->
                "Ritmo $pace. Dentro do alvo."

            diff > 0 ->
                "Ritmo $pace. ${diff} segundos mais lento."

            else ->
                "Ritmo $pace. ${-diff} segundos mais rápido."
        }
    }
}
