# Pace Coach V1.7 — Coach de voz natural

Objetivo:
transformar os dados de pace em mensagens curtas, consistentes e úteis.

Exemplos:
- "Ritmo 5:02. Dentro do alvo."
- "Ritmo 5:12. 12 segundos mais lento."
- "Ritmo 4:48. 12 segundos mais rápido."

Também foi criada uma máquina de estados básica do coach para preparar:
- aquecimento;
- alvo;
- ritmo acima/abaixo;
- GPS incerto;
- finalização.

O TTS mantém fala curta, 1.15x e controle de Audio Focus.
A validação real de delay continua dependendo do APK e do aparelho/fone.
