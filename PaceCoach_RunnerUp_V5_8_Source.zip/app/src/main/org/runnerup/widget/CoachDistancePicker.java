package org.runnerup.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

/**
 * Single-column distance picker used by the Pace Coach free-run editor.
 * The approved layout presents one value (e.g. 10,0) with + above and - below,
 * followed by the km unit. The internal value is tenths of a kilometre.
 */
public class CoachDistancePicker extends LinearLayout {
  private final NumberPicker distance;

  public CoachDistancePicker(Context context, AttributeSet attrs) {
    super(context);
    setOrientation(HORIZONTAL);
    setGravity(Gravity.CENTER);
    setPadding(0, 0, 0, 0);
    setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));

    distance = new NumberPicker(context, attrs);
    distance.setRange(0, 9999, false);
    distance.setOrientation(VERTICAL);
    distance.setDigits(1);
    distance.setFormatter(value -> {
      String text = String.format(Locale.getDefault(), "%.1f", value / 10.0);
      return text.replace('.', ',');
    });

    LinearLayout.LayoutParams pickerLp =
        new LinearLayout.LayoutParams(dp(context, 170), LayoutParams.WRAP_CONTENT);
    addView(distance, pickerLp);

    TextView unit = new TextView(context);
    unit.setText("km");
    unit.setTextSize(20);
    unit.setTextColor(0xFFFFFFFF);
    unit.setGravity(Gravity.CENTER_VERTICAL);
    LinearLayout.LayoutParams unitLp =
        new LinearLayout.LayoutParams(dp(context, 48), LayoutParams.WRAP_CONTENT);
    unitLp.leftMargin = dp(context, 2);
    addView(unit, unitLp);
  }

  private static int dp(Context context, int value) {
    return (int) (value * context.getResources().getDisplayMetrics().density + 0.5f);
  }

  public long getDistance() {
    return Math.round(distance.getValue() * 100.0);
  }

  public void setDistance(long meters) {
    if (meters < 0) meters = 0;
    int tenths = (int) Math.round(meters / 100.0);
    distance.setValue(Math.max(0, Math.min(9999, tenths)));
  }

  @Override
  public void setEnabled(boolean enabled) {
    super.setEnabled(enabled);
    distance.setEnabled(enabled);
  }
}
