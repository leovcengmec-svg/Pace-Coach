/*
 * Copyright (C) 2012 - 2013 jonas.oreland@gmail.com
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.runnerup.view;

import static org.runnerup.content.ActivityProvider.GPX_MIME;
import static org.runnerup.content.ActivityProvider.TCX_MIME;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import org.runnerup.BuildConfig;
import org.runnerup.R;
import org.runnerup.common.util.Constants;
import org.runnerup.content.ActivityProvider;
import org.runnerup.db.ActivityCleaner;
import org.runnerup.db.DBHelper;
import org.runnerup.db.PathSimplifier;
import org.runnerup.export.SyncManager;
import org.runnerup.export.Synchronizer;
import org.runnerup.export.Synchronizer.Feature;
import org.runnerup.util.Bitfield;
import org.runnerup.util.FileNameHelper;
import org.runnerup.util.Formatter;
import org.runnerup.util.GraphWrapper;
import org.runnerup.util.MapWrapper;
import org.runnerup.util.SafeParse;
import org.runnerup.widget.SpinnerInterface.OnSetValueListener;
import org.runnerup.widget.TitleSpinner;
import org.runnerup.widget.WidgetUtil;
import org.runnerup.workout.Intensity;
import org.runnerup.workout.Sport;

public class DetailActivity extends AppCompatActivity implements Constants {

  private long mID = 0;
  private SQLiteDatabase mDB = null;
  private final HashSet<String> pendingSynchronizers = new HashSet<>();
  private final HashSet<String> alreadySynched = new HashSet<>();
  private final Map<String, String> synchedExternalId = new HashMap<>();

  private boolean lapHrPresent = false;
  private boolean lapElevationPresent = false;
  private boolean lapTimeMode = false;
  private TextView lapModeKm = null;
  private TextView lapModeTime = null;
  private TextView lapPrimaryHeader = null;
  private double[] lapElevation = null;
  private int[] lapHrAverage = null;
  private ContentValues[] laps = null;
  private final ArrayList<ContentValues> reports = new ArrayList<>();
  private final ArrayList<BaseAdapter> adapters = new ArrayList<>(2);

  private int mode; // 0 == save 1 == details
  private static final int MODE_SAVE = 0;
  private static final int MODE_DETAILS = 1;
  private boolean edit = false;
  private boolean uploading = false;

  private Button saveButton = null;
  private Button uploadButton = null;
  private Button resumeButton = null;
  private TextView activityTime = null;
  private TextView activityPace = null;
  private View activityPaceSeparator = null;
  private TextView activityDistance = null;

  private TitleSpinner sport = null;
  private TitleSpinner manualDistance = null;
  private EditText notes = null;
  private View rootView;
  private View mapTab;
  private View graphTab;
  private View blocksTab;
  private TextView detailDistanceValue;
  private TextView detailTimeValue;
  private TextView detailPaceValue;
  private TextView detailSpeedValue;
  private TextView detailCaloriesValue;
  private TextView detailInfoValue;
  private TextView detailSportValue;
  private TextView detailDateValue;
  private TextView detailDistanceRowValue;
  private TextView detailTimeRowValue;
  private TextView detailPaceRowValue;
  private TextView detailSpeedRowValue;
  private TextView detailElevationValue;
  private TextView detailElevationRowValue;
  private TextView detailCaloriesRowValue;
  private TextView workoutTypeValue;
  private TextView activityNameValue;
  private LinearLayout editControls;
  private LinearLayout blockListContainer;
  private View blockListHeader;
  private LinearLayout blockTableContainer;
  private TextView blockSummary;
  private TextView blockPerformanceValue;
  private TextView blockPerformanceDetail;
  private TextView mapLapTitle;
  private TextView mapLapDetails;
  private TextView mapLapTime;
  private TextView mapLapPace;
  private TextView mapLapElevation;
  private TextView mapTopKm;
  private TextView mapTopTime;
  private TextView mapTopPace;
  private View mapInfoPanel;
  private View mapTopInfoPanel;
  private View mapToggleInfoButton;
  private boolean mapInfoVisible = true;
  private View mapLapPrev;
  private View mapLapNext;
  private int mapLapIndex = 0;

  private MapWrapper mapWrapper = null;
  private GraphWrapper graphWrapper = null;

  private SyncManager syncManager = null;
  private Formatter formatter = null;

  private long mStartTime = 0; // activity start time in unix timestamp
  private ContentValues headerData = new ContentValues();
  private static final int EDIT_ACCOUNT_REQUEST = 2;

  /** Called when the activity is first created. */
  @Override
  public void onCreate(Bundle savedInstanceState) {
    EdgeToEdge.enable(this);
    Window window = getWindow();
    WindowCompat.getInsetsController(window, window.getDecorView())
        .setAppearanceLightStatusBars(false);
    super.onCreate(savedInstanceState);
    if (BuildConfig.OSMDROID_ENABLED || BuildConfig.MAPBOX_ENABLED) {
      // MapBox or Osmdroid, set mapWrapper.
      MapWrapper.start(this);
    }
    setContentView(R.layout.detail);
    rootView = findViewById(R.id.detail_view);

    Intent intent = getIntent();
    mID = intent.getLongExtra("ID", -1);
    String intentMode = intent.getStringExtra("mode");

    mDB = DBHelper.getReadableDatabase(this);
    syncManager = new SyncManager(this);
    formatter = new Formatter(this);

    if (intentMode.contentEquals("save")) {
      this.mode = MODE_SAVE;
    } else if (intentMode.contentEquals("details")) {
      this.mode = MODE_DETAILS;
    } else {
      if (BuildConfig.DEBUG) {
        throw new AssertionError();
      }
    }

    saveButton = findViewById(R.id.save_button);
    Button discardButton = findViewById(R.id.discard_button);
    resumeButton = findViewById(R.id.resume_button);
    uploadButton = findViewById(R.id.upload_button);
    Toolbar toolbar = findViewById(R.id.actionbar);
    setSupportActionBar(toolbar);
    if (getSupportActionBar() != null) {
      getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    WidgetUtil.addLegacyOverflowButton(window);

    detailDistanceValue = findViewById(R.id.detail_distance_value);
    detailTimeValue = findViewById(R.id.detail_time_value);
    detailPaceValue = findViewById(R.id.detail_pace_value);
    detailSpeedValue = findViewById(R.id.detail_speed_value);
    detailCaloriesValue = findViewById(R.id.detail_calories_value);
    detailInfoValue = findViewById(R.id.detail_info_value);
    detailSportValue = findViewById(R.id.detail_sport_value);
    detailDateValue = findViewById(R.id.detail_date_value);
    detailDistanceRowValue = findViewById(R.id.detail_distance_row_value);
    detailTimeRowValue = findViewById(R.id.detail_time_row_value);
    detailPaceRowValue = findViewById(R.id.detail_pace_row_value);
    detailSpeedRowValue = findViewById(R.id.detail_speed_row_value);
    detailElevationValue = findViewById(R.id.detail_elevation_value);
    detailElevationRowValue = findViewById(R.id.detail_elevation_row_value);
    detailCaloriesRowValue = findViewById(R.id.detail_calories_row_value);
    // The activity title/type also belonged to the removed large header.
    workoutTypeValue = findViewById(R.id.activity_workout_type);
    activityNameValue = findViewById(R.id.activity_name);
    editControls = findViewById(R.id.edit_controls);
    blockListContainer = findViewById(R.id.block_list_container);
    blockListHeader = findViewById(R.id.block_list_header);
    blockTableContainer = findViewById(R.id.block_table_container);
    blockSummary = findViewById(R.id.block_summary);
    blockPerformanceValue = findViewById(R.id.block_performance_value);
    blockPerformanceDetail = findViewById(R.id.block_performance_detail);
    mapLapTitle = findViewById(R.id.map_lap_title);
    mapLapDetails = null;
    mapLapTime = findViewById(R.id.map_lap_time);
    mapLapPace = findViewById(R.id.map_lap_pace);
    mapLapElevation = findViewById(R.id.map_lap_elevation);
    mapLapPrev = findViewById(R.id.map_lap_prev);
    mapLapNext = findViewById(R.id.map_lap_next);
    mapTopKm = findViewById(R.id.map_top_km);
    mapTopTime = findViewById(R.id.map_top_time);
    mapTopPace = findViewById(R.id.map_top_pace);
    mapInfoPanel = findViewById(R.id.map_info_panel);
    mapTopInfoPanel = findViewById(R.id.map_top_info_panel);
    mapToggleInfoButton = findViewById(R.id.map_toggle_info_button);
    if (mapToggleInfoButton != null) mapToggleInfoButton.setOnClickListener(v -> toggleMapInfo());
    if (mapLapPrev != null) mapLapPrev.setOnClickListener(v -> selectMapLap(mapLapIndex - 1));
    if (mapLapNext != null) mapLapNext.setOnClickListener(v -> selectMapLap(mapLapIndex + 1));
    sport = findViewById(R.id.summary_sport);
    sport.setOnSetValueListener(
        new OnSetValueListener() {
          @Override
          public String preSetValue(String newValue) throws IllegalArgumentException {
            return newValue;
          }

          @Override
          public int preSetValue(int newValue) throws IllegalArgumentException {
            updateViewForSport(newValue);
            ViewCompat.requestApplyInsets(rootView);
            headerData.put(DB.ACTIVITY.SPORT, newValue);
            return newValue;
          }
        });

    sport.setArrayEntries(Sport.getStringArray(getResources()));

    manualDistance = findViewById(R.id.summary_manual_distance);
    manualDistance.setOnSetValueListener(
        new OnSetValueListener() {
          @Override
          public String preSetValue(String newValue) throws IllegalArgumentException {
            double dist = SafeParse.parseDouble(newValue, 0); // convert to meters
            headerData.put(DB.ACTIVITY.DISTANCE, dist);
            updateHeader(headerData, /* fromManualDistance= */ true);
            return newValue;
          }

          @Override
          public int preSetValue(int newValue) throws IllegalArgumentException {
            return newValue;
          }
        });
    notes = findViewById(R.id.notes_text);

    saveButton.setOnClickListener(saveButtonClick);
    uploadButton.setOnClickListener(uploadButtonClick);

    uploadButton.setVisibility(View.GONE);

    TabHost th = findViewById(R.id.tabhost);
    th.setup();
    TabSpec tabSpec = th.newTabSpec("notes");
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(this, "Resumo"));
    tabSpec.setContent(R.id.tab_main);
    th.addTab(tabSpec);

    tabSpec = th.newTabSpec("laps");
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(this, getString(org.runnerup.common.R.string.Laps)));
    tabSpec.setContent(R.id.tab_lap);
    th.addTab(tabSpec);

    tabSpec = th.newTabSpec("blocks");
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(this, "Blocos"));
    tabSpec.setContent(R.id.tab_blocks);
    th.addTab(tabSpec);
    blocksTab = th.getTabWidget().getChildTabViewAt(th.getTabWidget().getChildCount() - 1);

    if (BuildConfig.OSMDROID_ENABLED || BuildConfig.MAPBOX_ENABLED) {
      tabSpec = th.newTabSpec("map");
      tabSpec.setIndicator(
          WidgetUtil.createHoloTabIndicator(this, getString(org.runnerup.common.R.string.Map)));
      tabSpec.setContent(R.id.tab_map);
      th.addTab(tabSpec);
      mapTab = th.getTabWidget().getChildTabViewAt(2);
    }

    tabSpec = th.newTabSpec("graph");
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(this, getString(org.runnerup.common.R.string.Graph)));
    tabSpec.setContent(R.id.tab_graph);
    th.addTab(tabSpec);
    // Get graph tab (cannot hardcode index due to optional map tab).
    int graphTabIndex = th.getTabWidget().getChildCount() - 1;
    graphTab = th.getTabWidget().getChildTabViewAt(graphTabIndex);

    tabSpec = th.newTabSpec("share");
    tabSpec.setIndicator(
        WidgetUtil.createHoloTabIndicator(this, getString(org.runnerup.common.R.string.Upload)));
    tabSpec.setContent(R.id.tab_upload);
    th.addTab(tabSpec);

    // Map and graph are intentionally initialized lazily. GPX imports can contain
    // thousands of GPS points; initializing both renderers while the Summary tab
    // is opening can make the Android main thread unresponsive (ANR).
    th.setOnTabChangedListener(
        tabId -> {
          if ("map".equals(tabId)) {
            ensureMapWrapper(savedInstanceState);
            if (mapWrapper != null) mapWrapper.focusLap(mapLapIndex);
          } else if ("graph".equals(tabId)) {
            ensureGraphWrapper();
          }
        });

    View mapCenterButton = findViewById(R.id.map_center_button);
    View mapZoomInButton = findViewById(R.id.map_zoom_in_button);
    View mapZoomOutButton = findViewById(R.id.map_zoom_out_button);
    if (mapCenterButton != null) {
      mapCenterButton.setOnClickListener(v -> {
        ensureMapWrapper(savedInstanceState);
        if (mapWrapper != null) mapWrapper.centerOnRoute();
      });
    }
    if (mapZoomInButton != null) {
      mapZoomInButton.setOnClickListener(v -> {
        ensureMapWrapper(savedInstanceState);
        if (mapWrapper != null) mapWrapper.zoomIn();
      });
    }
    if (mapZoomOutButton != null) {
      mapZoomOutButton.setOnClickListener(v -> {
        ensureMapWrapper(savedInstanceState);
        if (mapWrapper != null) mapWrapper.zoomOut();
      });
    }

    fillHeaderData();
    requery();
    selectMapLap(0);

    lapModeKm = findViewById(R.id.lap_mode_km);
    lapModeTime = findViewById(R.id.lap_mode_time);
    lapPrimaryHeader = findViewById(R.id.lap_list_primary_header);
    if (lapModeKm != null) {
      lapModeKm.setOnClickListener(v -> setLapDisplayMode(false));
    }
    if (lapModeTime != null) {
      lapModeTime.setOnClickListener(v -> setLapDisplayMode(true));
    }
    setLapDisplayMode(false);

    {
      ListView lv = findViewById(R.id.laplist);
      LapListAdapter adapter = new LapListAdapter();
      adapters.add(adapter);
      lv.setAdapter(adapter);
    }
    {
      ListView lv = findViewById(R.id.report_list);
      ReportListAdapter adapter = new ReportListAdapter();
      adapters.add(adapter);
      lv.setAdapter(adapter);
    }

    getOnBackPressedDispatcher()
        .addCallback(
            this,
            new OnBackPressedCallback(true) {
              @Override
              public void handleOnBackPressed() {
                if (uploading) {
                  // Ignore while uploading
                  return;
                }
                if (mode == MODE_SAVE) {
                  resumeButtonClick.onClick(resumeButton);
                } else {
                  finish();
                }
              }
            });

    ViewCompat.setOnApplyWindowInsetsListener(
        rootView,
        new OnApplyWindowInsetsListener() {
          @NonNull
          @Override
          public WindowInsetsCompat onApplyWindowInsets(
              @NonNull View v, @NonNull WindowInsetsCompat windowInsets) {
            Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            int bottomPadding =
                saveButton.getVisibility() == View.VISIBLE
                        || uploadButton.getVisibility() == View.VISIBLE
                    ? insets.bottom
                    : 0;
            v.setPadding(insets.left, 0, insets.right, bottomPadding);

            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) v.getLayoutParams();
            mlp.topMargin = insets.top;

            View graphScroll = findViewById(R.id.tab_graph);
            if (graphScroll != null) {
              graphScroll.setPadding(
                  graphScroll.getPaddingLeft(),
                  graphScroll.getPaddingTop(),
                  graphScroll.getPaddingRight(),
                  Math.max(0, insets.bottom - bottomPadding));
            }
            return WindowInsetsCompat.CONSUMED;
          }
        });

    if (this.mode == MODE_SAVE) {
      resumeButton.setOnClickListener(resumeButtonClick);
      discardButton.setOnClickListener(discardButtonClick);
      setEdit(true);
    } else if (this.mode == MODE_DETAILS) {
      resumeButton.setVisibility(View.GONE);
      discardButton.setVisibility(View.GONE);
      setEdit(false);
    }
  }

  private void ensureMapWrapper(Bundle savedInstanceState) {
    if (mapWrapper != null || !(BuildConfig.OSMDROID_ENABLED || BuildConfig.MAPBOX_ENABLED)) {
      return;
    }
    Object mapView = findViewById(R.id.mapview);
    if (mapView == null) return;
    mapWrapper = new MapWrapper(this, mDB, mID, formatter, mapView, true);
    mapWrapper.onCreate(savedInstanceState);
  }

  private void ensureGraphWrapper() {
    if (graphWrapper != null) return;
    LinearLayout graphTabLayout = findViewById(R.id.graphview);
    LinearLayout hrzonesBarLayout = findViewById(R.id.hrzonesBarLayout);
    if (graphTabLayout == null || hrzonesBarLayout == null) return;
    boolean useDistanceAsX = !Sport.isWithoutGps(sport.getValueInt());
    graphWrapper =
        new GraphWrapper(
            this, graphTabLayout, hrzonesBarLayout, formatter, mDB, mID, useDistanceAsX);
  }

  private void setEdit(boolean value) {
    edit = value;
    if (value) {
      saveButton.setVisibility(View.VISIBLE);
    } else {
      saveButton.setVisibility(View.GONE);
    }
    WidgetUtil.setEditable(notes, value);
    sport.setEnabled(value);
    if (editControls != null) {
      editControls.setVisibility(value ? View.VISIBLE : View.GONE);
    }
    updateViewForSport(sport.getValueInt());
    ViewCompat.requestApplyInsets(rootView);
  }

  private void updateDetailSummary(double distance, long time) {
    if (detailDistanceValue == null) return;
    detailDistanceValue.setText(formatter.formatDistance(Formatter.Format.TXT_SHORT, (long) distance));
    detailTimeValue.setText(formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, time));
    if (time > 0 && distance > 0) {
      String pace = formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_LONG, distance / time);
      detailPaceValue.setText(pace);
      double kmh = (distance / 1000.0) / (time / 3600.0);
      detailSpeedValue.setText(String.format(Locale.getDefault(), "%.1f km/h\nVelocidade média", kmh));
    } else {
      detailPaceValue.setText("--:--/km");
      detailSpeedValue.setText("—\nVelocidade média");
    }
    detailCaloriesValue.setText("—");
    String dateTime = mStartTime > 0 ? formatter.formatDateTime(mStartTime) : "—";
    String distanceText = formatter.formatDistance(Formatter.Format.TXT_SHORT, (long) distance);
    String timeText = formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, time);
    String paceText = time > 0 && distance > 0
        ? formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_LONG, distance / time)
        : "--:--/km";
    String speedText = time > 0 && distance > 0
        ? String.format(Locale.getDefault(), "%.1f km/h", (distance / 1000.0) / (time / 3600.0))
        : "—";

    if (detailSportValue != null) detailSportValue.setText("Corrida");
    if (detailDateValue != null) detailDateValue.setText(dateTime);
    if (detailDistanceRowValue != null) detailDistanceRowValue.setText(distanceText);
    if (detailTimeRowValue != null) detailTimeRowValue.setText(timeText);
    if (detailPaceRowValue != null) detailPaceRowValue.setText(paceText);
    if (detailSpeedRowValue != null) detailSpeedRowValue.setText(speedText);
    if (detailElevationValue != null) detailElevationValue.setText("—");
    if (detailElevationRowValue != null) detailElevationRowValue.setText("—");
    if (detailCaloriesRowValue != null) detailCaloriesRowValue.setText("—");
    if (detailInfoValue != null) {
      detailInfoValue.setText(
          "Esporte\tCorrida\n" +
          "Data/hora\t" + dateTime + "\n" +
          "Distância\t" + distanceText + "\n" +
          "Duração\t" + timeText + "\n" +
          "Ritmo médio\t" + paceText);
    }
  }

  private void populateBlockDetails() {
    if (blockListContainer == null || laps == null) return;
    blockListContainer.removeAllViews();
    if (blockTableContainer != null) blockTableContainer.removeAllViews();

    LayoutInflater inflater = LayoutInflater.from(this);
    int number = 1;
    int targetCount = 0;
    int achievedCount = 0;
    int slowerCount = 0;
    int fasterCount = 0;

    for (ContentValues lap : laps) {
      double d = lap.containsKey(DB.LAP.DISTANCE) ? lap.getAsDouble(DB.LAP.DISTANCE) : 0;
      long t = lap.containsKey(DB.LAP.TIME) ? lap.getAsLong(DB.LAP.TIME) : 0;
      double actualPaceSecKm = t > 0 && d > 0 ? (t * 1000.0) / d : 0;
      double targetPaceSecKm = lap.containsKey(DB.LAP.PLANNED_PACE)
          ? lap.getAsDouble(DB.LAP.PLANNED_PACE) * 1000.0 : 0;
      boolean hasTarget = targetPaceSecKm > 0;
      // Keep the same classification used by the performance summary:
      // within target = up to 1 second/km from the stored target;
      // slower = larger pace value; faster = smaller pace value.
      boolean achieved = hasTarget && actualPaceSecKm > 0
          && Math.abs(actualPaceSecKm - targetPaceSecKm) < 1.0;
      boolean slower = hasTarget && actualPaceSecKm > targetPaceSecKm + 1.0;
      boolean faster = hasTarget && actualPaceSecKm < targetPaceSecKm - 1.0;
      if (hasTarget) {
        targetCount++;
        if (achieved) {
          achievedCount++;
        } else if (slower) {
          slowerCount++;
        } else if (faster) {
          fasterCount++;
        }
      }

      View row = inflater.inflate(R.layout.laplist_row_coach, blockListContainer, false);
      TextView n = row.findViewById(R.id.block_number);
      android.widget.ImageView icon = row.findViewById(R.id.block_icon);
      View statusBar = row.findViewById(R.id.block_status_bar);
      TextView title = row.findViewById(R.id.block_title);
      TextView type = row.findViewById(R.id.block_type);
      TextView distance = row.findViewById(R.id.block_distance);
      TextView time = row.findViewById(R.id.block_time);
      TextView pace = row.findViewById(R.id.block_pace);
      TextView targetPace = row.findViewById(R.id.block_target_pace);
      TextView targetStatus = row.findViewById(R.id.block_target_status);
      TextView result = row.findViewById(R.id.block_hr);

      int intensityValue = lap.containsKey(DB.LAP.INTENSITY) ? lap.getAsInteger(DB.LAP.INTENSITY) : Intensity.ACTIVE.ordinal();
      Intensity intensity = Intensity.values()[Math.max(0, Math.min(intensityValue, Intensity.values().length - 1))];
      n.setText(String.valueOf(number));
      boolean partial = number == laps.length && d > 0 && d < 950.0;
      title.setText(partial ? "Parcial" : getBlockTitle(intensity, number));

      if (icon != null) {
        int iconRes;
        switch (intensity) {
          case WARMUP: iconRes = R.drawable.step_warmup; break;
          case RECOVERY: iconRes = R.drawable.step_recovery; break;
          case COOLDOWN: iconRes = R.drawable.step_cooldown; break;
          case RESTING: iconRes = R.drawable.step_resting; break;
          case REPEAT: iconRes = R.drawable.step_repeat; break;
          case ACTIVE:
          default: iconRes = R.drawable.step_active; break;
        }
        icon.setImageResource(iconRes);
      }
      type.setText("");
      type.setVisibility(View.GONE);
      distance.setText(formatDistanceKm(d));
      time.setText(formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, t));
      pace.setText(actualPaceSecKm > 0 ? formatPaceSecondsPerKm(actualPaceSecKm) + "/km" : "--:--/km");

      int statusColor = ContextCompat.getColor(this, R.color.colorTextSecondary);
      String statusLabel = "Sem alvo definido";
      if (!partial && hasTarget && actualPaceSecKm > 0) {
        if (achieved) {
          statusColor = ContextCompat.getColor(this, R.color.coachFast);
          statusLabel = "Dentro do alvo";
        } else if (slower) {
          statusColor = ContextCompat.getColor(this, R.color.coachSlower);
          statusLabel = "Mais lento que o alvo";
        } else if (faster) {
          statusColor = ContextCompat.getColor(this, R.color.coachFaster);
          statusLabel = "Mais rápido que o alvo";
        }
      } else if (partial) {
        statusLabel = "Parcial";
      }

      targetPace.setText(hasTarget
          ? formatPaceSecondsPerKm(targetPaceSecKm) + "/km"
          : "—");
      targetPace.setTextColor(ContextCompat.getColor(this, R.color.colorTextSecondary));
      targetStatus.setText(statusLabel);
      targetStatus.setTextColor(statusColor);
      if (statusBar != null) statusBar.setBackgroundColor(statusColor);
      if (pace != null) pace.setTextColor(statusColor);
      if (result != null) {
        result.setText(statusLabel);
        result.setTextColor(statusColor);
      }
      blockListContainer.addView(row);

      addBlockTableRow(number, title.getText().toString(), d, t, actualPaceSecKm, targetPaceSecKm, hasTarget, achieved);
      number++;
    }

    if (blockSummary != null) {
      // Use the same official activity totals shown in the approved header.
      // Do not sum laps here: GPS/lap records may differ slightly from the activity totals.
      double totalDistance = headerData != null && headerData.containsKey(DB.ACTIVITY.DISTANCE)
          ? headerData.getAsDouble(DB.ACTIVITY.DISTANCE) : 0;
      long totalTime = headerData != null && headerData.containsKey(DB.ACTIVITY.TIME)
          ? headerData.getAsLong(DB.ACTIVITY.TIME) : 0;
      blockSummary.setText(laps.length + " blocos  •  "
          + formatter.formatDistance(Formatter.Format.TXT_SHORT, (long) totalDistance)
          + "  •  " + formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, totalTime));
    }
    if (blockPerformanceValue != null) {
      if (targetCount > 0) {
        int percent = Math.round((achievedCount * 100f) / targetCount);
        blockPerformanceValue.setText(percent + "%");
        if (blockPerformanceDetail != null) {
          blockPerformanceDetail.setText("Objetivo de pace alcançado");
        }
      } else {
        blockPerformanceValue.setText("—");
        if (blockPerformanceDetail != null) {
          blockPerformanceDetail.setText("Nenhum bloco possui pace alvo definido");
        }
      }
    }
    setPerformanceStat(R.id.block_perf_inside, targetCount > 0 ? achievedCount : 0,
        "Dentro do alvo");
    setPerformanceStat(R.id.block_perf_slow, targetCount > 0 ? slowerCount : 0,
        "Mais lento que o alvo");
    setPerformanceStat(R.id.block_perf_fast, targetCount > 0 ? fasterCount : 0,
        "Mais rápido que o alvo");
    setPerformanceStat(R.id.block_perf_total, targetCount, "Total de blocos (" + targetCount + " no cálculo)");
    setBlockDisplayMode(false);
  }

  private String formatDistanceKm(double meters) {
    double km = Math.max(0.0, meters) / 1000.0;
    return String.format(Locale.getDefault(), "%.2f km", km).replace('.', ',');
  }

  private void setPerformanceStat(int id, int value, String label) {
    TextView v = findViewById(id);
    if (v == null) return;
    v.setText(value + "\n" + label);
  }

  private void addBlockTableRow(int number, String title, double distance, long time,
      double actualPaceSecKm, double targetPaceSecKm, boolean hasTarget, boolean achieved) {
    if (blockTableContainer == null) return;
    LinearLayout row = new LinearLayout(this);
    row.setOrientation(LinearLayout.HORIZONTAL);
    row.setGravity(android.view.Gravity.CENTER_VERTICAL);
    row.setPadding(6, 9, 6, 9);
    if (number % 2 == 0) row.setBackgroundResource(R.drawable.bg_coach_list_row);

    addTableCell(row, String.valueOf(number), 0.35f, true);
    addTableCell(row, title, 1.15f, false);
    addTableCell(row, formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, time), 0.8f, false);
    addTableCell(row, formatter.formatDistance(Formatter.Format.TXT_LONG, (long) distance), 0.9f, false);
    addTableCell(row, actualPaceSecKm > 0 ? formatPaceSecondsPerKm(actualPaceSecKm) : "—", 0.9f, false);
    addTableCell(row, hasTarget ? formatPaceSecondsPerKm(targetPaceSecKm) : "—", 1.0f, false);
    addTableCell(row, hasTarget ? (achieved ? "Atingido" : "Não atingido") : "Sem alvo", 1.0f, false);
    blockTableContainer.addView(row);
  }

  private void addTableCell(LinearLayout row, String text, float weight, boolean bold) {
    TextView v = new TextView(this);
    v.setText(text);
    v.setTextColor(ContextCompat.getColor(this, bold ? android.R.color.white : R.color.colorTextSecondary));
    v.setTextSize(11);
    if (bold) v.setTypeface(v.getTypeface(), android.graphics.Typeface.BOLD);
    v.setPadding(4, 0, 4, 0);
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
    row.addView(v, lp);
  }

  private void setBlockDisplayMode(boolean table) {
    // The approved Blocks interface is now a single fixed view.
    // Keep the old table container hidden so legacy data/code remains harmless.
    if (blockListContainer != null) blockListContainer.setVisibility(View.VISIBLE);
    if (blockListHeader != null) blockListHeader.setVisibility(View.GONE);
    if (blockTableContainer != null) blockTableContainer.setVisibility(View.GONE);
  }

  private void updateWorkoutTypeLabel() {
    if (workoutTypeValue == null) return;
    boolean interval = false;
    if (laps != null) {
      for (ContentValues lap : laps) {
        if (!lap.containsKey(DB.LAP.INTENSITY)) continue;
        int value = lap.getAsInteger(DB.LAP.INTENSITY);
        if (value == Intensity.WARMUP.ordinal()
            || value == Intensity.COOLDOWN.ordinal()
            || value == Intensity.RECOVERY.ordinal()
            || value == Intensity.REPEAT.ordinal()
            || value == Intensity.RESTING.ordinal()) {
          interval = true;
          break;
        }
      }
      if (laps.length > 1) interval = true;
    }
    workoutTypeValue.setText(interval ? "Treino Intervalado" : "Treino de corrida");
  }

  private String formatElapsedTimeShort(long seconds) {
    long safe = Math.max(0L, seconds);
    long hours = safe / 3600L;
    long minutes = (safe % 3600L) / 60L;
    long secs = safe % 60L;
    if (hours > 0) {
      return String.format(Locale.getDefault(), "%dh%02d", hours, minutes);
    }
    return String.format(Locale.getDefault(), "%02d:%02d", minutes, secs);
  }

  private String formatPaceSecondsPerKm(double secondsPerKm) {
    if (secondsPerKm <= 0 || Double.isNaN(secondsPerKm) || Double.isInfinite(secondsPerKm)) {
      return "--:--";
    }
    long totalSeconds = Math.round(secondsPerKm);
    long minutes = totalSeconds / 60;
    long seconds = totalSeconds % 60;
    return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
  }

  private String getBlockTitle(Intensity intensity, int number) {
    switch (intensity) {
      case WARMUP: return "Aquecimento";
      case COOLDOWN: return "Desaquecimento";
      case RECOVERY: return "Recuperação";
      case RESTING: return "Descanso Off";
      case REPEAT: return "Repetição";
      case ACTIVE: return "Intervalo";
      default: return "Bloco " + number;
    }
  }

  private void updateViewForSport(int sportValue) {
    if (edit && Sport.hasManualDistance(sportValue)) {
      manualDistance.setVisibility(View.VISIBLE);
      manualDistance.setEnabled(true);
    } else {
      manualDistance.setVisibility(View.GONE);
    }

    if (mapTab != null) {
      if (Sport.isWithoutGps(sportValue)) {
        mapTab.setVisibility(View.GONE);
      } else {
        mapTab.setVisibility(View.VISIBLE);
      }
    }
    if (graphWrapper != null) {
      boolean use_distance_as_x = !Sport.isWithoutGps(sportValue);
      graphWrapper.setUseDistanceAsX(use_distance_as_x);
    }
  }

  private void setUploadVisibility() {
    boolean enabled = !pendingSynchronizers.isEmpty();
    if (enabled) {
      uploadButton.setVisibility(View.VISIBLE);
    } else {
      uploadButton.setVisibility(View.GONE);
    }
    ViewCompat.requestApplyInsets(rootView);
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.detail_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    int id = item.getItemId();
    if (id == android.R.id.home) {
      finish();
      return true;
    } else if (id == R.id.menu_delete_activity) {
      deleteButtonClick.onClick(null);
    } else if (id == R.id.menu_edit_activity) {
      if (!edit) {
        setEdit(true);
        notes.requestFocus();
        requery();
      }
    } else if (id == R.id.menu_recompute_activity) {
      new AlertDialog.Builder(this)
          .setTitle(org.runnerup.common.R.string.Recompute_activity)
          .setMessage(org.runnerup.common.R.string.Are_you_sure)
          .setPositiveButton(
              org.runnerup.common.R.string.Yes,
              (dialog, which) -> {
                dialog.dismiss();
                new ActivityCleaner().recompute(mDB, mID);
                requery();
                fillHeaderData();
                finish();
              })
          .setNegativeButton(org.runnerup.common.R.string.No, (dialog, which) -> dialog.dismiss())
          .show();
    } else if (id == R.id.menu_simplify_path) {
      new AlertDialog.Builder(this)
          .setTitle(org.runnerup.common.R.string.path_simplification_menu)
          .setMessage(org.runnerup.common.R.string.Are_you_sure)
          .setPositiveButton(
              org.runnerup.common.R.string.Yes,
              (dialog, which) -> {
                dialog.dismiss();
                PathSimplifier simplifier = new PathSimplifier(this);
                ArrayList<String> ids = simplifier.getNoisyLocationIDsAsStrings(mDB, mID);
                ActivityCleaner.deleteLocations(mDB, ids);
                new ActivityCleaner().recompute(mDB, mID);
                requery();
                fillHeaderData();
                finish();
              })
          .setNegativeButton(org.runnerup.common.R.string.No, (dialog, which) -> dialog.dismiss())
          .show();
    } else if (id == R.id.menu_share_activity) {
      shareActivity();
    }

    return true;
  }

  @Override
  public void onResume() {
    super.onResume();
    if (mapWrapper != null) {
      mapWrapper.onResume();
    }
  }

  @Override
  public void onStart() {
    super.onStart();
    if (mapWrapper != null) {
      mapWrapper.onStart();
    }
  }

  @Override
  public void onStop() {
    super.onStop();
    if (mapWrapper != null) {
      mapWrapper.onStop();
    }
  }

  @Override
  public void onPause() {
    super.onPause();
    if (mapWrapper != null) {
      mapWrapper.onPause();
    }
  }

  @Override
  public void onSaveInstanceState(@NonNull Bundle outState) {
    super.onSaveInstanceState(outState);
    if (mapWrapper != null) {
      mapWrapper.onSaveInstanceState(outState);
    }
  }

  @Override
  public void onLowMemory() {
    super.onLowMemory();
    if (mapWrapper != null) {
      mapWrapper.onLowMemory();
    }
  }

  @Override
  public void onDestroy() {
    super.onDestroy();
    DBHelper.closeDB(mDB);
    syncManager.close();
    if (graphWrapper != null) {
      graphWrapper.onDestroy();
      graphWrapper = null;
    }
    if (mapWrapper != null) {
      mapWrapper.onDestroy();
    }
  }

  private void requery() {
    {
      /*
       * Laps
       */
      String[] from =
          new String[] {
            "_id",
            DB.LAP.LAP,
            DB.LAP.INTENSITY,
            DB.LAP.TIME,
            DB.LAP.DISTANCE,
            DB.LAP.PLANNED_TIME,
            DB.LAP.PLANNED_DISTANCE,
            DB.LAP.PLANNED_PACE,
            DB.LAP.AVG_HR
          };

      Cursor c =
          mDB.query(
              DB.LAP.TABLE, from, DB.LAP.ACTIVITY + " == " + mID, null, null, null, "_id", null);

      laps = DBHelper.toArray(c);
      c.close();
      selectMapLap(mapLapIndex);

      // The GPX importer stores elevation and heart-rate on the GPS points.
      // Build per-lap values here so the Voltas tab can present the same
      // visual information even when the LAP table itself has no HR/elevation.
      lapElevation = new double[laps.length];
      lapHrAverage = new int[laps.length];
      double[] firstElevation = new double[laps.length];
      double[] lastElevation = new double[laps.length];
      boolean[] hasElevation = new boolean[laps.length];
      long[] hrSum = new long[laps.length];
      int[] hrCount = new int[laps.length];

      String[] locationColumns = {DB.LOCATION.LAP, DB.LOCATION.ALTITUDE, DB.LOCATION.HR, DB.LOCATION.TIME};
      Cursor locationCursor = mDB.query(
          DB.LOCATION.TABLE,
          locationColumns,
          DB.LOCATION.ACTIVITY + " == " + mID,
          null,
          null,
          null,
          DB.LOCATION.LAP + " asc, " + DB.LOCATION.TIME + " asc",
          null);
      while (locationCursor.moveToNext()) {
        int lapIndex = locationCursor.isNull(0) ? -1 : locationCursor.getInt(0);
        if (lapIndex < 0 || lapIndex >= laps.length) continue;

        if (!locationCursor.isNull(1)) {
          double elevation = locationCursor.getDouble(1);
          if (!hasElevation[lapIndex]) {
            firstElevation[lapIndex] = elevation;
            hasElevation[lapIndex] = true;
          }
          lastElevation[lapIndex] = elevation;
        }
        if (!locationCursor.isNull(2)) {
          int hr = locationCursor.getInt(2);
          if (hr > 0) {
            hrSum[lapIndex] += hr;
            hrCount[lapIndex]++;
          }
        }
      }
      locationCursor.close();

      lapHrPresent = false;
      lapElevationPresent = false;
      for (int i = 0; i < laps.length; i++) {
        if (hasElevation[i]) {
          lapElevation[i] = lastElevation[i] - firstElevation[i];
          lapElevationPresent = true;
        }
        if (hrCount[i] > 0) {
          lapHrAverage[i] = Math.round((float) hrSum[i] / hrCount[i]);
          lapHrPresent = true;
        } else if (laps[i].containsKey(DB.LAP.AVG_HR) && laps[i].getAsInteger(DB.LAP.AVG_HR) > 0) {
          lapHrAverage[i] = laps[i].getAsInteger(DB.LAP.AVG_HR);
          lapHrPresent = true;
        }
      }

      TextView lapElevationHeader = findViewById(R.id.lap_list_elevation_header);
      TextView lapHrHeader = findViewById(R.id.lap_list_hr_header);
      if (lapElevationHeader != null) lapElevationHeader.setVisibility(lapElevationPresent ? View.VISIBLE : View.GONE);
      if (lapHrHeader != null) lapHrHeader.setVisibility(lapHrPresent ? View.VISIBLE : View.GONE);

      populateBlockDetails();
      updateWorkoutTypeLabel();
    }

    {
      /*
       * Accounts/reports
       */
      String sql =
          "SELECT DISTINCT "
              + "  acc._id, "
              + ("  acc." + DB.ACCOUNT.NAME + ", ")
              + ("  acc." + DB.ACCOUNT.FLAGS + ", ")
              + ("  acc." + DB.ACCOUNT.AUTH_CONFIG + ", ")
              + ("  acc." + DB.ACCOUNT.FORMAT + ", ")
              + ("  rep._id as repid, ")
              + ("  rep." + DB.EXPORT.ACCOUNT + ", ")
              + ("  rep." + DB.EXPORT.ACTIVITY + ", ")
              + ("  rep." + DB.EXPORT.EXTERNAL_ID + ", ")
              + ("  rep." + DB.EXPORT.STATUS)
              + (" FROM " + DB.ACCOUNT.TABLE + " acc ")
              + (" LEFT OUTER JOIN " + DB.EXPORT.TABLE + " rep ")
              + (" ON ( acc._id = rep." + DB.EXPORT.ACCOUNT)
              + ("     AND rep." + DB.EXPORT.ACTIVITY + " = " + mID + " )");

      Cursor c = mDB.rawQuery(sql, null);
      alreadySynched.clear();
      synchedExternalId.clear();
      pendingSynchronizers.clear();
      reports.clear();
      if (c.moveToFirst()) {
        do {
          ContentValues tmp = DBHelper.get(c);
          Synchronizer synchronizer = syncManager.add(tmp);
          // Note: Show all configured accounts (also those are not currently enabled)
          // Uploaded but removed accounts are not displayed
          if (synchronizer == null
              || !synchronizer.checkSupport(Feature.UPLOAD)
              || !synchronizer.isConfigured()) {
            continue;
          }

          String name = tmp.getAsString(DB.ACCOUNT.NAME);
          reports.add(tmp);
          if (tmp.containsKey("repid")) {
            alreadySynched.add(name);
            if (tmp.containsKey(DB.EXPORT.STATUS)
                && tmp.getAsInteger(DB.EXPORT.STATUS)
                    == Synchronizer.ExternalIdStatus.getInt(Synchronizer.ExternalIdStatus.OK)) {
              String url =
                  syncManager
                      .getSynchronizerByName(name)
                      .getActivityUrl(synchedExternalId.get(name));
              if (url != null) {
                synchedExternalId.put(name, tmp.getAsString(DB.EXPORT.EXTERNAL_ID));
              }
            }
          } else if (tmp.containsKey(DB.ACCOUNT.FLAGS)
              && Bitfield.test(tmp.getAsLong(DB.ACCOUNT.FLAGS), DB.ACCOUNT.FLAG_UPLOAD)) {
            pendingSynchronizers.add(name);
          }
        } while (c.moveToNext());
      }
      c.close();
    }

    if (mode == MODE_DETAILS) {
      setUploadVisibility();
    }

    for (BaseAdapter a : adapters) {
      a.notifyDataSetChanged();
    }
  }

  private void fillHeaderData() {
    // Fields from the database (projection)
    // Must include the _id column for the adapter to work
    String[] from =
        new String[] {
          DB.ACTIVITY.START_TIME,
          DB.ACTIVITY.NAME,
          DB.ACTIVITY.DISTANCE,
          DB.ACTIVITY.TIME,
          DB.ACTIVITY.COMMENT,
          DB.ACTIVITY.SPORT
        };

    Cursor c = mDB.query(DB.ACTIVITY.TABLE, from, "_id == " + mID, null, null, null, null, null);
    c.moveToFirst();
    ContentValues tmp = DBHelper.get(c);
    c.close();

    if (tmp.containsKey(DB.ACTIVITY.NAME) && activityNameValue != null) {
      String activityName = tmp.getAsString(DB.ACTIVITY.NAME);
      activityNameValue.setText(activityName == null || activityName.trim().isEmpty() ? "Corrida" : activityName.trim());
    }

    if (tmp.containsKey(DB.ACTIVITY.START_TIME)) {
      long st = tmp.getAsLong(DB.ACTIVITY.START_TIME);
      mStartTime = st;
      // Keep the compact activity header with the date/time title.
      if (getSupportActionBar() != null) getSupportActionBar().setTitle(formatter.formatDateTime(st));
    }

    if (tmp.containsKey(DB.ACTIVITY.COMMENT)) {
      notes.setText(tmp.getAsString(DB.ACTIVITY.COMMENT));
    }

    headerData = tmp;
    updateHeader(tmp, /* fromManualDistance= */ false);
  }

  private void updateHeader(ContentValues data, boolean fromManualDistance) {
    double d = 0;
    if (data.containsKey(DB.ACTIVITY.DISTANCE)) {
      d = data.getAsDouble(DB.ACTIVITY.DISTANCE);
      String s = formatter.formatDistance(Formatter.Format.TXT_SHORT, (long) d);
      if (activityDistance != null) activityDistance.setText(s);
      if (!fromManualDistance) {
        /**
         * IF !fromManualDistance (e.g. from database) update the manual distance field in case (if
         * it might be needed) ELSE fromManualDistance=true e.g. from spinner, don't update or else
         * it will recurse
         */
        int distance = (int) d;
        manualDistance.setValue(Long.toString(distance));
        manualDistance.setValue(distance);
      }
    } else {
      if (activityDistance != null) activityDistance.setText("");
    }

    long t = 0;
    if (data.containsKey(DB.ACTIVITY.TIME)) {
      t = data.getAsInteger(DB.ACTIVITY.TIME);
      if (activityTime != null) activityTime.setText(formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, t));
    } else {
      if (activityTime != null) activityTime.setText("");
    }

    if (t != 0) {
      if (activityPace != null) activityPace.setVisibility(View.VISIBLE);
      if (activityPaceSeparator != null) activityPaceSeparator.setVisibility(View.VISIBLE);
      if (activityPace != null) {
        activityPace.setText(
            formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_LONG, d / t));
      }
    } else {
      if (activityPace != null) activityPace.setVisibility(View.GONE);
      if (activityPaceSeparator != null) activityPaceSeparator.setVisibility(View.GONE);
    }

    updateDetailSummary(d, t);
    if (data.containsKey(DB.ACTIVITY.SPORT)) {
      sport.setValue(data.getAsInteger(DB.ACTIVITY.SPORT));
    }
  }

  private void toggleMapInfo() {
    mapInfoVisible = !mapInfoVisible;
    if (mapInfoPanel != null) mapInfoPanel.setVisibility(mapInfoVisible ? View.VISIBLE : View.GONE);
    if (mapTopInfoPanel != null) mapTopInfoPanel.setVisibility(mapInfoVisible ? View.VISIBLE : View.GONE);
    if (mapToggleInfoButton instanceof android.widget.ImageButton) {
      ((android.widget.ImageButton) mapToggleInfoButton).setImageResource(
          mapInfoVisible ? R.drawable.ic_map_info_hide : R.drawable.ic_map_info_show);
    }
  }

  /** Updates the map selector using only completed whole kilometers. */
  private void selectMapLap(int index) {
    int mapLapCount = getCompletedMapKmCount();
    if (mapLapCount <= 0) {
      mapLapIndex = 0;
      if (mapLapTitle != null) mapLapTitle.setText("Percurso");
      if (mapTopKm != null) mapTopKm.setText("Percurso");
      if (mapTopTime != null) mapTopTime.setText("--:--");
      if (mapTopPace != null) mapTopPace.setText("--:-- /km");
      if (mapLapTime != null) mapLapTime.setText("--:--");
      if (mapLapPace != null) mapLapPace.setText("--:-- /km");
      if (mapLapElevation != null) mapLapElevation.setText("—");
      if (mapLapPrev != null) mapLapPrev.setEnabled(false);
      if (mapLapNext != null) mapLapNext.setEnabled(false);
      return;
    }

    mapLapIndex = Math.max(0, Math.min(index, mapLapCount - 1));

    double cumulativeDistance = 0.0;
    long cumulativeTime = 0L;
    ContentValues selectedLap = null;
    for (int i = 0; i <= mapLapIndex && i < mapLapCount; i++) {
      ContentValues lap = laps[i];
      cumulativeDistance += lap.containsKey(DB.LAP.DISTANCE) ? lap.getAsDouble(DB.LAP.DISTANCE) : 0.0;
      cumulativeTime += lap.containsKey(DB.LAP.TIME) ? lap.getAsLong(DB.LAP.TIME) : 0L;
      if (i == mapLapIndex) selectedLap = lap;
    }

    String distanceText = formatter.formatDistance(Formatter.Format.TXT_SHORT, Math.round(cumulativeDistance));
    String timeText = formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, cumulativeTime);
    String paceText = cumulativeTime > 0 && cumulativeDistance > 0
        ? formatter.formatVelocityByPreferredUnit(Formatter.Format.TXT_LONG, cumulativeDistance / cumulativeTime)
        : "--:--/km";

    String kmText = (mapLapIndex + 1) + " km";
    if (mapLapTitle != null) mapLapTitle.setText(kmText);

    // Top card: cumulative values at the selected kilometer.
    if (mapTopKm != null) mapTopKm.setText(kmText);
    if (mapTopTime != null) mapTopTime.setText(timeText);
    if (mapTopPace != null) mapTopPace.setText(paceText);

    // Bottom card: values belonging to the selected kilometer itself.
    String selectedTimeText = "--:--";
    String selectedPaceText = "--:-- /km";
    String selectedElevationText = "—";
    if (laps != null && mapLapIndex >= 0 && mapLapIndex < laps.length) {
      ContentValues lap = laps[mapLapIndex];
      long lapTime = lap.containsKey(DB.LAP.TIME) ? lap.getAsLong(DB.LAP.TIME) : 0L;
      double lapDistance = lap.containsKey(DB.LAP.DISTANCE) ? lap.getAsDouble(DB.LAP.DISTANCE) : 0.0;
      selectedTimeText = formatter.formatElapsedTime(Formatter.Format.TXT_SHORT, lapTime);
      if (lapTime > 0 && lapDistance > 0) {
        selectedPaceText = formatter.formatVelocityByPreferredUnit(
            Formatter.Format.TXT_LONG, lapDistance / lapTime);
      }
      if (lapElevation != null && mapLapIndex < lapElevation.length) {
        double elevation = lapElevation[mapLapIndex];
        if (Math.abs(elevation) >= 0.5) {
          selectedElevationText = (elevation > 0 ? "+" : "") + Math.round(elevation) + " m";
        } else {
          selectedElevationText = "0 m";
        }
      }
    }
    if (mapLapTime != null) mapLapTime.setText(selectedTimeText);
    if (mapLapPace != null) mapLapPace.setText(selectedPaceText);
    if (mapLapElevation != null) mapLapElevation.setText(selectedElevationText);

    if (mapWrapper != null) {
      mapWrapper.focusLap(mapLapIndex);
      mapWrapper.selectLap(mapLapIndex);
    }
    if (mapLapPrev != null) mapLapPrev.setEnabled(mapLapIndex > 0);
    if (mapLapNext != null) mapLapNext.setEnabled(mapLapIndex < mapLapCount - 1);
  }

  private int getCompletedMapKmCount() {
    if (laps == null || laps.length == 0) return 0;
    int count = 0;
    for (ContentValues lap : laps) {
      double distance = lap.containsKey(DB.LAP.DISTANCE) ? lap.getAsDouble(DB.LAP.DISTANCE) : 0.0;
      if (distance >= 990.0 && distance <= 1010.0) count++;
      else if (distance > 0 && distance < 990.0) break;
    }
    return count;
  }

  private void setLapDisplayMode(boolean timeMode) {
    lapTimeMode = timeMode;
    if (lapPrimaryHeader != null) {
      lapPrimaryHeader.setText(timeMode ? "Tempo" : "Km");
    }
    if (lapModeKm != null) {
      lapModeKm.setBackgroundResource(timeMode ? R.drawable.bg_lap_mode : R.drawable.bg_lap_mode_selected);
      lapModeKm.setTextColor(ContextCompat.getColor(this, timeMode ? R.color.colorTextSecondary : android.R.color.white));
    }
    if (lapModeTime != null) {
      if (timeMode) {
        lapModeTime.setBackgroundResource(R.drawable.bg_lap_mode_selected);
      } else {
        lapModeTime.setBackgroundColor(Color.TRANSPARENT);
      }
      lapModeTime.setTextColor(ContextCompat.getColor(this, timeMode ? android.R.color.white : R.color.colorTextSecondary));
    }
    for (BaseAdapter adapter : adapters) {
      if (adapter instanceof LapListAdapter) {
        adapter.notifyDataSetChanged();
      }
    }
  }

  private class ViewHolderLapList {
    private TextView tv0;
    private TextView tv1;
    private TextView tv2;
    private View bar;
    private TextView tvElevation;
    private TextView tvHr;
    private View row;
    private View barContainer;
  }

  private class LapListAdapter extends BaseAdapter {

    @Override
    public int getCount() {
      return laps == null ? 0 : laps.length;
    }

    @Override
    public Object getItem(int position) {
      return laps[position];
    }

    @Override
    public long getItemId(int position) {
      return laps[position].getAsLong("_id");
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      View view = convertView;
      ViewHolderLapList h;
      if (view == null) {
        h = new ViewHolderLapList();
        LayoutInflater inflater = LayoutInflater.from(DetailActivity.this);
        view = inflater.inflate(R.layout.laplist_row, parent, false);
        h.row = view;
        h.tv0 = view.findViewById(R.id.lap_list_id);
        h.tv1 = view.findViewById(R.id.lap_list_pace);
        h.tv2 = view.findViewById(R.id.lap_list_type);
        h.barContainer = view.findViewById(R.id.lap_list_bar_container);
        h.bar = view.findViewById(R.id.lap_list_bar);
        h.tvElevation = view.findViewById(R.id.lap_list_elevation);
        h.tvHr = view.findViewById(R.id.lap_list_hr);
        view.setTag(h);
      } else {
        h = (ViewHolderLapList) view.getTag();
      }

      ContentValues lap = laps[position];
      double d = lap.containsKey(DB.LAP.DISTANCE) ? lap.getAsDouble(DB.LAP.DISTANCE) : 0;
      long t = lap.containsKey(DB.LAP.TIME) ? lap.getAsLong(DB.LAP.TIME) : 0;
      double paceSeconds = t > 0 && d > 0 ? (t * 1000.0) / d : 0;
      boolean partial = position == laps.length - 1 && d < 999.0;

      if (lapTimeMode) {
        long cumulative = 0;
        for (int i = 0; i <= position; i++) {
          if (laps[i].containsKey(DB.LAP.TIME)) cumulative += Math.max(0L, laps[i].getAsLong(DB.LAP.TIME));
        }
        h.tv0.setSingleLine(true);
        h.tv0.setText(formatElapsedTimeShort(cumulative));
      } else {
        h.tv0.setSingleLine(true);
        h.tv0.setText(String.valueOf(position + 1));
      }

      h.tv2.setVisibility(partial ? View.VISIBLE : View.GONE);
      h.tv2.setText(partial ? "Parcial" : "");
      h.tv2.setTextColor(ContextCompat.getColor(DetailActivity.this, R.color.colorAccent));
      h.tv1.setSingleLine(true);
      h.tv1.setText(formatPaceSecondsPerKm(paceSeconds));

      if (partial) {
        h.row.setBackgroundResource(R.drawable.bg_lap_partial);
      } else {
        h.row.setBackgroundColor(Color.TRANSPARENT);
      }

      h.tvElevation.setVisibility(lapElevationPresent ? View.VISIBLE : View.GONE);
      if (lapElevationPresent && lapElevation != null && position < lapElevation.length &&
          Math.abs(lapElevation[position]) >= 0.5) {
        int elev = (int) Math.round(lapElevation[position]);
        h.tvElevation.setText(String.format(Locale.getDefault(), "%+d", elev));
      } else if (lapElevationPresent) {
        h.tvElevation.setText("—");
      }

      h.tvHr.setVisibility(lapHrPresent ? View.VISIBLE : View.GONE);
      if (lapHrPresent && lapHrAverage != null && position < lapHrAverage.length && lapHrAverage[position] > 0) {
        h.tvHr.setText(String.valueOf(lapHrAverage[position]));
      } else if (lapHrPresent) {
        h.tvHr.setText("—");
      }

      // Compare only complete laps. A partial final lap must never be treated as
      // the fastest/slowest split because its pace is based on a much shorter distance.
      double minPace = Double.MAX_VALUE;
      double maxPace = 0;
      for (int i = 0; i < laps.length; i++) {
        ContentValues item = laps[i];
        double itemD = item.containsKey(DB.LAP.DISTANCE) ? item.getAsDouble(DB.LAP.DISTANCE) : 0;
        long itemT = item.containsKey(DB.LAP.TIME) ? item.getAsLong(DB.LAP.TIME) : 0;
        boolean itemPartial = i == laps.length - 1 && itemD < 999.0;
        if (!itemPartial && itemD > 0 && itemT > 0) {
          double p = itemT * 1000.0 / itemD;
          minPace = Math.min(minPace, p);
          maxPace = Math.max(maxPace, p);
        }
      }
      final double normalized = partial
          ? 0.0
          : (paceSeconds > 0 && maxPace > minPace
              ? 0.08 + 0.84 * ((maxPace - paceSeconds) / (maxPace - minPace))
              : 0.46);
      h.bar.setBackgroundResource(partial ? R.drawable.bg_lap_bar_slow : R.drawable.bg_lap_bar);
      h.barContainer.post(() -> {
        int width = h.barContainer.getWidth();
        if (width > 0) {
          ViewGroup.LayoutParams lp = h.bar.getLayoutParams();
          // A partial lap is not comparable with full kilometres: keep its marker
          // deliberately short and neutral instead of suggesting a faster pace.
          lp.width = partial ? Math.max(8, (int) (width * 0.05))
              : Math.max(8, (int) (width * Math.max(0.08, Math.min(0.92, normalized))));
          h.bar.setLayoutParams(lp);
        }
      });

      return view;
    }
  }

  private class ReportListAdapter extends BaseAdapter {

    @Override
    public int getCount() {
      return reports.size() + 1;
    }

    @Override
    public Object getItem(int position) {
      if (position < reports.size()) return reports.get(position);
      return this;
    }

    @Override
    public long getItemId(int position) {
      if (position < reports.size()) return reports.get(position).getAsLong("_id");

      return 0;
    }

    private class ViewHolderDetailActivity {
      private TextView tv0;
      private CheckBox cb;
      private TextView tv1;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      if (position == reports.size()) {
        Button b = new Button(DetailActivity.this);
        b.setText(org.runnerup.common.R.string.Configure_accounts);
        b.setBackgroundResource(R.drawable.btn_blue);
        b.setTextColor(
            AppCompatResources.getColorStateList(DetailActivity.this, R.color.btn_text_color));
        b.setOnClickListener(
            v -> {
              Intent i = new Intent(DetailActivity.this, AccountListActivity.class);
              DetailActivity.this.startActivityForResult(i, EDIT_ACCOUNT_REQUEST);
            });
        return b;
      }

      View view = convertView;
      ViewHolderDetailActivity viewHolder;

      // Note: Special ViewHolder support as the Configure button is not in the view
      if (view == null || view.getTag() == null) {
        viewHolder = new ViewHolderDetailActivity();

        LayoutInflater inflater = LayoutInflater.from(DetailActivity.this);
        view = inflater.inflate(R.layout.reportlist_row, parent, false);

        viewHolder.tv0 = view.findViewById(R.id.reportlist_account_id);
        viewHolder.cb = view.findViewById(R.id.reportlist_sent);
        viewHolder.tv1 = view.findViewById(R.id.reportlist_account_name);

        view.setTag(viewHolder);
      } else {
        viewHolder = (ViewHolderDetailActivity) view.getTag();
      }

      ContentValues tmp = reports.get(position);
      String name = tmp.getAsString(DB.ACCOUNT.NAME);
      viewHolder.cb.setOnCheckedChangeListener(null);
      viewHolder.cb.setChecked(false);
      viewHolder.cb.setEnabled(false);
      viewHolder.cb.setTag(name);
      viewHolder.tv1.setTag(name);
      viewHolder.tv1.setTextColor(viewHolder.cb.getTextColors());
      if (alreadySynched.contains(name)) {
        viewHolder.cb.setChecked(true);
        if (synchedExternalId.containsKey(name)) {
          // Indicate Clickable label
          viewHolder.tv1.setTextColor(Color.BLUE);
        }
        viewHolder.cb.setText(org.runnerup.common.R.string.Uploaded);
        viewHolder.cb.setOnLongClickListener(clearUploadClick);
      } else {
        viewHolder.cb.setChecked(pendingSynchronizers.contains(name));
        viewHolder.cb.setText(org.runnerup.common.R.string.Upload);
        viewHolder.cb.setOnLongClickListener(null);
      }
      if (mode == MODE_DETAILS) {
        viewHolder.cb.setEnabled(true);
      } else if (mode == MODE_SAVE) {
        viewHolder.cb.setEnabled(true);
      }
      viewHolder.cb.setOnCheckedChangeListener(onSendChecked);

      viewHolder.tv0.setText(tmp.getAsString("_id"));
      viewHolder.tv1.setText(name);

      return view;
    }
  }

  private void saveActivity() {
    int sportValue = sport.getValueInt();
    ContentValues tmp = headerData;
    tmp.put(DB.ACTIVITY.COMMENT, notes.getText().toString());
    tmp.put(DB.ACTIVITY.SPORT, sportValue);
    String[] whereArgs = {Long.toString(mID)};
    mDB.update(DB.ACTIVITY.TABLE, tmp, "_id = ?", whereArgs);

    // path simplification (reduce resolution of location entries in database)
    try {
      PathSimplifier simplifier = PathSimplifier.getPathSimplifierForSave(this);
      if (simplifier != null) {
        ArrayList<String> ids = simplifier.getNoisyLocationIDsAsStrings(mDB, mID);
        ActivityCleaner.deleteLocations(mDB, ids);
        (new ActivityCleaner()).recompute(mDB, mID);
      }
    } catch (Exception e) {
      Log.e(getClass().getName(), "Failed to simplify path: " + e.getMessage());
    }
  }

  private final OnLongClickListener clearUploadClick =
      arg0 -> {
        final String name = (String) arg0.getTag();
        new AlertDialog.Builder(DetailActivity.this)
            .setTitle("Clear upload for " + name)
            .setMessage(org.runnerup.common.R.string.Are_you_sure)
            .setPositiveButton(
                org.runnerup.common.R.string.Yes,
                (dialog, which) -> {
                  dialog.dismiss();
                  syncManager.clearUpload(name, mID);
                  requery();
                })
            .setNegativeButton(
                org.runnerup.common.R.string.No,
                // Do nothing but close the dialog
                (dialog, which) -> dialog.dismiss())
            .show();
        return false;
      };

  // Note: onClick set in reportlist_row.xml
  public void onClickAccountName(View arg0) {
    final String name = (String) arg0.getTag();
    if (synchedExternalId.containsKey(name) && !TextUtils.isEmpty(synchedExternalId.get(name))) {
      String url =
          syncManager.getSynchronizerByName(name).getActivityUrl(synchedExternalId.get(name));
      if (url != null) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(browserIntent);
      }
    }
  }

  private final OnClickListener saveButtonClick =
      new OnClickListener() {
        public void onClick(View v) {
          saveActivity();
          if (mode == MODE_DETAILS) {
            setEdit(false);
            requery();
            return;
          }
          uploading = true;
          syncManager.startUploading(
              (synchronizerName, status) -> {
                uploading = false;
                final Intent returnIntent = new Intent();
                int sportValue = sport.getValueInt();
                if (Sport.hasManualDistance(sportValue)) {
                  returnIntent.putExtra(
                      "MANUAL_DISTANCE", headerData.getAsDouble(DB.ACTIVITY.DISTANCE));
                }
                DetailActivity.this.setResult(RESULT_OK, returnIntent);
                DetailActivity.this.finish();
              },
              pendingSynchronizers,
              mID);
        }
      };

  private final OnClickListener discardButtonClick =
      v ->
          new AlertDialog.Builder(DetailActivity.this)
              .setTitle(org.runnerup.common.R.string.Discard)
              .setMessage(org.runnerup.common.R.string.Are_you_sure)
              .setPositiveButton(
                  org.runnerup.common.R.string.Yes,
                  (dialog, which) -> {
                    dialog.dismiss();
                    DetailActivity.this.setResult(RESULT_CANCELED);
                    DetailActivity.this.finish();
                  })
              .setNegativeButton(
                  org.runnerup.common.R.string.No,
                  // Do nothing but close the dialog
                  (dialog, which) -> dialog.dismiss())
              .show();

  private final OnClickListener resumeButtonClick =
      v -> {
        DetailActivity.this.setResult(RESULT_FIRST_USER);
        DetailActivity.this.finish();
      };

  private final OnClickListener uploadButtonClick =
      v -> {
        uploading = true;
        syncManager.startUploading(
            (synchronizerName, status) -> {
              uploading = false;
              requery();
            },
            pendingSynchronizers,
            mID);
      };

  private final OnCheckedChangeListener onSendChecked =
      new OnCheckedChangeListener() {

        @Override
        public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
          final String name = (String) arg0.getTag();
          if (alreadySynched.contains(name)) {
            // Only accept long clicks
            arg0.setChecked(true);
          } else {
            if (arg1) {
              pendingSynchronizers.add((String) arg0.getTag());
            } else {
              //noinspection SuspiciousMethodCalls
              pendingSynchronizers.remove(arg0.getTag());
            }
            if (mode == MODE_DETAILS) {
              setUploadVisibility();
            }
          }
        }
      };

  private final OnClickListener deleteButtonClick =
      v ->
          new AlertDialog.Builder(DetailActivity.this)
              .setTitle(org.runnerup.common.R.string.Delete_activity)
              .setMessage(org.runnerup.common.R.string.Are_you_sure)
              .setPositiveButton(
                  org.runnerup.common.R.string.Yes,
                  (dialog, which) -> {
                    DBHelper.deleteActivity(mDB, mID);
                    dialog.dismiss();
                    DetailActivity.this.setResult(RESULT_OK);
                    DetailActivity.this.finish();
                  })
              .setNegativeButton(
                  org.runnerup.common.R.string.No,
                  // Do nothing but close the dialog
                  (dialog, which) -> dialog.dismiss())
              .show();

  @Override
  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == SyncManager.CONFIGURE_REQUEST) {
      syncManager.onActivityResult(requestCode, resultCode, data);
    }
    requery();
  }

  private void shareActivity() {
    final int[] which = {
      1 // TODO preselect tcx - choice should be remembered
    };
    final CharSequence[] items = {"gpx", "tcx"};
    new AlertDialog.Builder(this)
        .setTitle(getString(org.runnerup.common.R.string.Share_activity))
        .setPositiveButton(
            org.runnerup.common.R.string.OK,
            (dialog, w) -> {
              if (which[0] == -1) {
                dialog.dismiss();
                return;
              }

              final Context context = DetailActivity.this;
              final CharSequence fmt = items[which[0]];
              final Intent intent = new Intent(Intent.ACTION_SEND);

              if (fmt.equals("tcx")) {
                intent.setType(TCX_MIME);
              } else {
                intent.setType(GPX_MIME);
              }

              // Use of content:// (or STREAM?) instead of file:// is not supported in ES and other
              // apps
              // Solid Explorer File Manager works though
              String actType = Sport.textOf(getResources(), sport.getValueInt());
              Uri uri =
                  Uri.parse(
                      "content://"
                          + ActivityProvider.AUTHORITY
                          + "/"
                          + fmt
                          + "/"
                          + mID
                          + "/"
                          + FileNameHelper.getExportFileName(mStartTime, actType)
                          + fmt);
              intent.putExtra(Intent.EXTRA_STREAM, uri);
              context.startActivity(
                  Intent.createChooser(
                      intent, getString(org.runnerup.common.R.string.Share_activity)));
            })
        .setNegativeButton(
            org.runnerup.common.R.string.Cancel,
            (dialog, which1) -> {
              // Do nothing but close the dialog
              dialog.dismiss();
            })
        .setSingleChoiceItems(items, which[0], (dialog, w) -> which[0] = w)
        .show();
  }
}
