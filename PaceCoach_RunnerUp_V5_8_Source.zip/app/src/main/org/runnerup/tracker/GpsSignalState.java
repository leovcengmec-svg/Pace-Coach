package org.runnerup.tracker;

/**
 * Process-wide GPS signal snapshot shared by the home dashboard and the workout screen.
 * Both screens must render the same quality result instead of maintaining independent
 * GPS-quality calculations with different startup timing.
 */
public final class GpsSignalState {
  private static final GpsSignalState INSTANCE = new GpsSignalState();

  private volatile boolean enabled;
  private volatile boolean started;
  private volatile boolean fixed;
  private volatile float accuracy = -1f;
  private volatile int satellitesFixed;
  private volatile int satellitesAvailable;
  private volatile long updatedAt;

  private GpsSignalState() {}

  public static GpsSignalState get() {
    return INSTANCE;
  }

  public synchronized void update(
      boolean enabled,
      boolean started,
      boolean fixed,
      float accuracy,
      int satellitesFixed,
      int satellitesAvailable) {
    this.enabled = enabled;
    this.started = started;
    this.fixed = fixed;
    this.accuracy = accuracy;
    this.satellitesFixed = satellitesFixed;
    this.satellitesAvailable = satellitesAvailable;
    this.updatedAt = System.currentTimeMillis();
  }

  public boolean isEnabled() { return enabled; }
  public boolean isStarted() { return started; }
  public boolean isFixed() { return fixed; }
  public float getAccuracy() { return accuracy; }
  public int getSatellitesFixed() { return satellitesFixed; }
  public int getSatellitesAvailable() { return satellitesAvailable; }
  public long getUpdatedAt() { return updatedAt; }
}
